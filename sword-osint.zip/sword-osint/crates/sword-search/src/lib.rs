//! # sword-search — Search Engine
//!
//! Plans an investigation (which adapters can serve the requested categories for the
//! classified input), runs adapters concurrently under a semaphore with per-adapter time
//! budgets and cancellation, streams progress events, then merges the outputs:
//! de-duplicated findings and sources, the provenance graph, key facts, an analytical
//! summary and an explicit list of limitations.

pub mod opensearch;
pub mod summary;

use std::collections::HashMap;
use std::sync::Arc;
use std::time::{Duration, Instant};

use sword_connectors::{ConnectorContext, Registry, SourceAdapter};
use sword_core::util::{canonical_url, now};
use sword_core::{
    classify, AdapterOutput, AdapterRun, Attr, ClassifiedInput, EventSink, Finding, InvestigationEvent, InvestigationKind,
    InvestigationRecord, InvestigationRequest, InvestigationStatus, KeyFact, PlannedAdapter, RunStatus, SourceRef, SwordError,
    SwordResult,
};
use sword_graph::{Graph, GraphBuilder};
use tokio::sync::Semaphore;
use tokio::task::JoinSet;

/// Result of a finished investigation, ready to be persisted.
#[derive(Debug, Clone)]
pub struct InvestigationOutcome {
    pub record: InvestigationRecord,
    pub runs: Vec<AdapterRun>,
    pub findings: Vec<Finding>,
    pub sources: Vec<SourceRef>,
    pub graph: Graph,
}

#[derive(Clone)]
pub struct SearchEngine {
    registry: Registry,
}

impl SearchEngine {
    pub fn new(registry: Registry) -> Self {
        SearchEngine { registry }
    }

    pub fn registry(&self) -> &Registry {
        &self.registry
    }

    /// Decide which adapters run, and why the others do not.
    pub fn plan(&self, input: &ClassifiedInput, req: &InvestigationRequest, ctx: &ConnectorContext) -> Vec<PlannedAdapter> {
        self.registry
            .all()
            .iter()
            .filter(|a| a.info().serves_any(&req.categories))
            .filter(|a| req.adapters.is_empty() || req.adapters.contains(&a.info().id))
            .map(|a| {
                let info = a.info();
                let mut categories: Vec<_> = info.categories.iter().copied().filter(|c| req.categories.contains(c)).collect();
                categories.sort();
                let reason = if !ctx.settings.adapter_enabled(&info.id) {
                    Some("источник отключён в настройках".to_string())
                } else if !a.supports(input) {
                    Some(format!("не работает с типом запроса «{}»", input.kind.label_ru()))
                } else {
                    let missing = a.missing_config(ctx);
                    (!missing.is_empty()).then(|| format!("требуется настройка: {}", missing.join(", ")))
                };
                PlannedAdapter {
                    adapter_id: info.id.clone(),
                    name: info.name.clone(),
                    categories,
                    will_run: reason.is_none(),
                    reason,
                }
            })
            .collect()
    }

    /// Run a discovery investigation end-to-end.
    pub async fn run(
        &self,
        id: String,
        req: InvestigationRequest,
        ctx: ConnectorContext,
        sink: Arc<dyn EventSink>,
    ) -> SwordResult<InvestigationOutcome> {
        if req.categories.is_empty() {
            return Err(SwordError::InvalidInput("не выбрана ни одна категория".into()));
        }
        let input = classify(&req.query)?;
        let ctx = ctx.with_categories(req.categories.clone());
        let plan = self.plan(&input, &req, &ctx);
        let started_at = now();
        let t0 = Instant::now();

        sink.emit(InvestigationEvent::Started {
            investigation_id: id.clone(),
            kind: InvestigationKind::Discovery,
            query: req.query.clone(),
            input: input.clone(),
            plan: plan.clone(),
        });

        let mut runs: HashMap<String, AdapterRun> = HashMap::new();
        for p in &plan {
            let mut run = AdapterRun::new(&p.adapter_id, &p.name, if p.will_run { RunStatus::Queued } else { RunStatus::Skipped });
            run.message = p.reason.clone();
            if !p.will_run {
                sink.emit(InvestigationEvent::AdapterUpdate { investigation_id: id.clone(), run: run.clone() });
            }
            runs.insert(p.adapter_id.clone(), run);
        }

        let concurrency = ctx.settings.network.max_concurrency.max(1) as usize;
        let budget = Duration::from_secs(ctx.settings.network.adapter_timeout_secs.max(10) as u64);
        let semaphore = Arc::new(Semaphore::new(concurrency));
        let mut set: JoinSet<(String, chrono::DateTime<chrono::Utc>, u32, SwordResult<AdapterOutput>)> = JoinSet::new();

        for p in plan.iter().filter(|p| p.will_run) {
            let Some(adapter) = self.registry.get(&p.adapter_id) else { continue };
            let ctx = ctx.clone();
            let input = input.clone();
            let sink = sink.clone();
            let sem = semaphore.clone();
            let inv = id.clone();
            let name = p.name.clone();
            set.spawn(async move {
                let adapter_id = adapter.info().id.clone();
                let _permit = tokio::select! {
                    _ = ctx.cancel.cancelled() => return (adapter_id, now(), 0, Err(SwordError::Cancelled)),
                    p = sem.acquire_owned() => p,
                };
                let started = now();
                let mut running = AdapterRun::new(&adapter_id, &name, RunStatus::Running);
                running.started_at = Some(started);
                sink.emit(InvestigationEvent::AdapterUpdate { investigation_id: inv.clone(), run: running });
                let t = Instant::now();
                let result = run_adapter(adapter.as_ref(), &input, &ctx, budget).await;
                let ms = t.elapsed().as_millis().min(u32::MAX as u128) as u32;
                (adapter_id, started, ms, result)
            });
        }

        let mut outputs: Vec<(String, AdapterOutput)> = Vec::new();
        while let Some(joined) = set.join_next().await {
            let (adapter_id, started, ms, result) = match joined {
                Ok(v) => v,
                Err(e) => {
                    tracing::error!(error = %e, "adapter task panicked");
                    continue;
                }
            };
            let Some(run) = runs.get_mut(&adapter_id) else { continue };
            run.started_at = Some(started);
            run.finished_at = Some(now());
            run.duration_ms = Some(ms);
            match result {
                Ok(out) => {
                    run.status = RunStatus::Done;
                    run.result_count = out.findings.len() as u32;
                    run.message = if out.findings.is_empty() {
                        Some(out.notes.first().cloned().unwrap_or_else(|| "Источник не вернул данных".into()))
                    } else {
                        None
                    };
                    if !out.findings.is_empty() {
                        sink.emit(InvestigationEvent::Findings {
                            investigation_id: id.clone(),
                            adapter_id: adapter_id.clone(),
                            findings: out.findings.clone(),
                        });
                    }
                    outputs.push((adapter_id.clone(), out));
                }
                Err(e) => {
                    run.status = match e {
                        SwordError::Cancelled => RunStatus::Cancelled,
                        SwordError::Timeout => RunStatus::TimedOut,
                        _ => RunStatus::Failed,
                    };
                    run.error_kind = Some(e.kind());
                    run.message = Some(e.to_string());
                }
            }
            sink.emit(InvestigationEvent::AdapterUpdate { investigation_id: id.clone(), run: run.clone() });
        }

        // Keep the plan order in the persisted runs.
        let runs: Vec<AdapterRun> = plan.iter().filter_map(|p| runs.remove(&p.adapter_id)).collect();
        let outcome = self.assemble(id.clone(), &req, &input, started_at, t0.elapsed(), runs, outputs, ctx.cancel.is_cancelled());
        sink.emit(InvestigationEvent::Finished { investigation_id: id, record: outcome.record.clone() });
        Ok(outcome)
    }

    #[allow(clippy::too_many_arguments)]
    fn assemble(
        &self,
        id: String,
        req: &InvestigationRequest,
        input: &ClassifiedInput,
        started_at: chrono::DateTime<chrono::Utc>,
        elapsed: Duration,
        runs: Vec<AdapterRun>,
        outputs: Vec<(String, AdapterOutput)>,
        cancelled: bool,
    ) -> InvestigationOutcome {
        let names: HashMap<String, String> = self.registry.all().iter().map(|a| (a.info().id.clone(), a.info().name.clone())).collect();
        let homepages: HashMap<String, String> =
            self.registry.all().iter().map(|a| (a.info().id.clone(), a.info().homepage.clone())).collect();

        let findings = dedupe_findings(outputs.iter().flat_map(|(_, o)| o.findings.iter().cloned()).collect(), &names);
        let sources = dedupe_sources(outputs.iter().flat_map(|(_, o)| o.sources.iter().cloned()).collect());
        let facts: Vec<KeyFact> = outputs.iter().flat_map(|(_, o)| o.facts.iter().cloned()).collect();

        let mut gb = GraphBuilder::new();
        for (adapter_id, out) in &outputs {
            gb.add_output(adapter_id, out);
        }
        gb.add_source_nodes(&names, &homepages);
        let graph = gb.build();

        let limitations = summary::limitations(&runs, &outputs, &names);
        let summary_text = summary::compose(input, &runs, &findings, sources.len(), &graph, &facts, &names);

        let done = runs.iter().filter(|r| r.status == RunStatus::Done).count();
        let failed = runs.iter().filter(|r| matches!(r.status, RunStatus::Failed | RunStatus::TimedOut)).count();
        let status = if cancelled {
            InvestigationStatus::Cancelled
        } else if done == 0 {
            InvestigationStatus::Failed
        } else if failed > 0 {
            InvestigationStatus::Partial
        } else {
            InvestigationStatus::Completed
        };
        let error = (status == InvestigationStatus::Failed).then(|| {
            if runs.iter().all(|r| r.status == RunStatus::Skipped) {
                "Ни один источник не может обработать запрос: проверьте категории и настройки подключений".to_string()
            } else {
                "Все запущенные источники завершились с ошибкой".to_string()
            }
        });
        let non_source_nodes = graph.nodes.iter().filter(|n| n.kind != sword_core::EntityKind::Source).count();
        let record = InvestigationRecord {
            id,
            kind: InvestigationKind::Discovery,
            query: req.query.trim().to_string(),
            input_kind: input.kind,
            categories: req.categories.clone(),
            status,
            created_at: started_at,
            finished_at: Some(now()),
            duration_ms: Some(elapsed.as_millis().min(u32::MAX as u128) as u32),
            result_count: findings.len() as u32,
            source_count: sources.len() as u32,
            node_count: non_source_nodes as u32,
            edge_count: graph.edges.iter().filter(|e| e.relation != "documented_by").count() as u32,
            adapters: runs.iter().filter(|r| r.status != RunStatus::Skipped).map(|r| r.adapter_id.clone()).collect(),
            summary: summary_text,
            key_facts: facts,
            limitations,
            error,
            notes: String::new(),
        };
        InvestigationOutcome { record, runs, findings, sources, graph }
    }
}

/// Run one adapter within its time budget, honouring cancellation.
pub async fn run_adapter(
    adapter: &dyn SourceAdapter,
    input: &ClassifiedInput,
    ctx: &ConnectorContext,
    budget: Duration,
) -> SwordResult<AdapterOutput> {
    tokio::select! {
        _ = ctx.cancel.cancelled() => Err(SwordError::Cancelled),
        r = tokio::time::timeout(budget, adapter.search(input, ctx)) => match r {
            Ok(res) => res,
            Err(_) => Err(SwordError::Timeout),
        },
    }
}

/// Merge findings that point to the same primary source (same canonical URL and kind).
pub fn dedupe_findings(all: Vec<Finding>, names: &HashMap<String, String>) -> Vec<Finding> {
    let mut out: Vec<Finding> = Vec::with_capacity(all.len());
    let mut index: HashMap<String, usize> = HashMap::new();
    for f in all {
        let key = match &f.url {
            Some(u) => format!("{}|{}", f.kind.as_str(), canonical_url(u)),
            None => format!("{}|{}|{}", f.adapter_id, f.kind.as_str(), f.title.to_lowercase()),
        };
        match index.get(&key) {
            Some(&i) => {
                let existing = &mut out[i];
                if existing.adapter_id != f.adapter_id {
                    let label = names.get(&f.adapter_id).cloned().unwrap_or_else(|| f.adapter_id.clone());
                    if !existing.attributes.iter().any(|a| a.label == "Также найдено" && a.value.contains(&label)) {
                        existing.attributes.push(Attr::new("Также найдено", label));
                    }
                    existing.confidence = existing.confidence.max(f.confidence);
                }
            }
            None => {
                index.insert(key, out.len());
                out.push(f);
            }
        }
    }
    out
}

pub fn dedupe_sources(all: Vec<SourceRef>) -> Vec<SourceRef> {
    let mut seen = std::collections::HashSet::new();
    all.into_iter().filter(|s| seen.insert(canonical_url(&s.url))).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use async_trait::async_trait;
    use sword_connectors::output::OutputBuilder;
    use sword_core::{
        AdapterInfo, AppSettings, Category, FindingKind, InputKind, MemorySecretStore, NullSink, OwnedAssets, PermissionCheck,
    };
    use tokio_util::sync::CancellationToken;

    struct Fake {
        info: AdapterInfo,
        fail: bool,
    }

    #[async_trait]
    impl SourceAdapter for Fake {
        fn info(&self) -> &AdapterInfo {
            &self.info
        }
        async fn check(&self, _ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
            Ok(vec![])
        }
        async fn search(&self, input: &ClassifiedInput, _ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
            if self.fail {
                return Err(SwordError::Upstream("HTTP 500".into()));
            }
            let mut b = OutputBuilder::new(&self.info);
            let url = format!("https://{}/", input.domain.clone().unwrap_or_default());
            b.finding(Category::DomainIntel, FindingKind::Website, "Главная", Some(&url));
            b.source(&url, "Главная");
            Ok(b.finish())
        }
    }

    fn fake(id: &str, fail: bool) -> Arc<dyn SourceAdapter> {
        Arc::new(Fake {
            fail,
            info: AdapterInfo {
                id: id.into(),
                name: id.into(),
                provider: "test".into(),
                description: String::new(),
                methodology: "test".into(),
                categories: vec![Category::DomainIntel],
                input_kinds: vec![InputKind::Domain],
                credentials: vec![],
                options: vec![],
                rate_limit_per_minute: 60,
                homepage: "https://example.test/".into(),
                docs_url: None,
                official_api: true,
            },
        })
    }

    #[tokio::test]
    async fn runs_dedupes_and_reports_partial() {
        let engine = SearchEngine::new(Registry::from_adapters(vec![fake("a", false), fake("b", false), fake("c", true)]));
        let settings = Arc::new(AppSettings::default());
        let http = sword_connectors::HttpClient::new(&settings.network).unwrap();
        let ctx = ConnectorContext::new(http, Arc::new(MemorySecretStore::default()), settings, Arc::new(OwnedAssets::default()), CancellationToken::new());
        let req = InvestigationRequest { query: "example.com".into(), categories: vec![Category::DomainIntel], adapters: vec![] };
        let out = engine.run("test".into(), req, ctx, Arc::new(NullSink)).await.unwrap();
        assert_eq!(out.record.status, InvestigationStatus::Partial);
        assert_eq!(out.findings.len(), 1, "same URL from two adapters is merged");
        assert!(out.findings[0].attributes.iter().any(|a| a.label == "Также найдено"));
        assert_eq!(out.sources.len(), 1);
        assert_eq!(out.runs.iter().filter(|r| r.status == RunStatus::Failed).count(), 1);
        assert!(!out.record.summary.is_empty());
    }
}
