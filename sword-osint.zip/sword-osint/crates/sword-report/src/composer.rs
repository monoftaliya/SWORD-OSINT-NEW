//! A small flow-layout engine on top of printpdf operations: pages, wrapped paragraphs,
//! headings with PDF bookmarks, key/value blocks, paginated tables with repeated headers,
//! callouts, clickable links and vector primitives. Coordinates are kept «from the top»
//! and converted to PDF space (origin bottom-left) when emitted.

use printpdf::{
    Actions, BorderArray, Color, ColorArray, ExtendedGraphicsStateId, HighlightingMode, Line, LinePoint, LinkAnnotation, Op,
    PaintMode, PdfFontHandle, Point, Polygon, PolygonRing, Pt, Rect, Rgb, TextItem, WindingOrder,
};

use crate::fonts::{Font, Fonts};
use crate::theme::{Rgb3, Theme};

#[derive(Clone, Copy, PartialEq, Eq)]
pub enum PageKind {
    Cover,
    Content,
}

pub struct Col {
    pub title: String,
    pub frac: f32,
    pub mono: bool,
}

#[derive(Default, Clone)]
pub struct Cell {
    pub text: String,
    pub sub: Option<String>,
    pub link: Option<String>,
    pub color: Option<Rgb3>,
    pub bold: bool,
}

impl Cell {
    pub fn new(text: impl Into<String>) -> Self {
        Cell { text: text.into(), ..Default::default() }
    }
    pub fn sub(mut self, s: impl Into<String>) -> Self {
        let s = s.into();
        self.sub = if s.trim().is_empty() { None } else { Some(s) };
        self
    }
    pub fn link(mut self, url: Option<String>) -> Self {
        self.link = url.filter(|u| u.starts_with("http"));
        self
    }
    pub fn color(mut self, c: Rgb3) -> Self {
        self.color = Some(c);
        self
    }
    pub fn bold(mut self) -> Self {
        self.bold = true;
        self
    }
}

pub struct Composer<'a> {
    pub fonts: &'a Fonts,
    pub theme: &'a Theme,
    pub w: f32,
    pub h: f32,
    pub ml: f32,
    pub mr: f32,
    pub mt: f32,
    pub mb: f32,
    pub pages: Vec<(PageKind, Vec<Op>)>,
    pub ops: Vec<Op>,
    pub kind: PageKind,
    pub y: f32,
    pub bookmarks: Vec<(String, usize)>,
    alpha: Vec<(f32, ExtendedGraphicsStateId)>,
    started: bool,
}

fn rgb(c: Rgb3) -> Color {
    Color::Rgb(Rgb::new(c.0.clamp(0.0, 1.0), c.1.clamp(0.0, 1.0), c.2.clamp(0.0, 1.0), None))
}

pub fn mix(a: Rgb3, b: Rgb3, t: f32) -> Rgb3 {
    (a.0 + (b.0 - a.0) * t, a.1 + (b.1 - a.1) * t, a.2 + (b.2 - a.2) * t)
}

impl<'a> Composer<'a> {
    pub fn new(fonts: &'a Fonts, theme: &'a Theme, w: f32, h: f32, alpha: Vec<(f32, ExtendedGraphicsStateId)>) -> Self {
        Composer {
            fonts,
            theme,
            w,
            h,
            ml: 54.0,
            mr: 54.0,
            mt: 70.0,
            mb: 64.0,
            pages: Vec::new(),
            ops: Vec::new(),
            kind: PageKind::Content,
            y: 70.0,
            bookmarks: Vec::new(),
            alpha,
            started: false,
        }
    }

    pub fn content_width(&self) -> f32 {
        self.w - self.ml - self.mr
    }

    pub fn page_number(&self) -> usize {
        self.pages.len() + 1
    }

    pub fn bottom(&self) -> f32 {
        self.h - self.mb
    }

    pub fn new_page(&mut self, kind: PageKind) {
        if self.started {
            let ops = std::mem::take(&mut self.ops);
            self.pages.push((self.kind, ops));
        }
        self.started = true;
        self.kind = kind;
        self.y = self.mt;
        if kind == PageKind::Content && self.theme.dark_pages {
            let bg = self.theme.page_bg;
            self.fill_rect(0.0, 0.0, self.w, self.h, bg, None);
        }
    }

    pub fn finish(mut self) -> (Vec<(PageKind, Vec<Op>)>, Vec<(String, usize)>) {
        if self.started {
            let ops = std::mem::take(&mut self.ops);
            self.pages.push((self.kind, ops));
        }
        (self.pages, self.bookmarks)
    }

    /// Start a new page if `height` does not fit.
    pub fn ensure(&mut self, height: f32) -> bool {
        if self.y + height > self.bottom() {
            self.new_page(PageKind::Content);
            return true;
        }
        false
    }

    pub fn space(&mut self, h: f32) {
        self.y += h;
    }

    // ------------------------------------------------------------------ primitives

    fn pdf_y(&self, y_top: f32) -> f32 {
        self.h - y_top
    }

    fn with_alpha(&mut self, alpha: Option<f32>, draw: impl FnOnce(&mut Vec<Op>)) {
        match alpha.filter(|a| *a < 0.995) {
            Some(a) => {
                let id = self
                    .alpha
                    .iter()
                    .min_by(|x, y| (x.0 - a).abs().partial_cmp(&(y.0 - a).abs()).unwrap_or(std::cmp::Ordering::Equal))
                    .map(|(_, id)| id.clone());
                self.ops.push(Op::SaveGraphicsState);
                if let Some(id) = id {
                    self.ops.push(Op::LoadGraphicsState { gs: id });
                }
                draw(&mut self.ops);
                self.ops.push(Op::RestoreGraphicsState);
            }
            None => draw(&mut self.ops),
        }
    }

    /// Draw a single line of text with its baseline at `baseline` (from top).
    pub fn text(&mut self, x: f32, baseline: f32, font: &Font, size: f32, color: Rgb3, s: &str) {
        self.text_spaced(x, baseline, font, size, color, s, 0.0)
    }

    #[allow(clippy::too_many_arguments)]
    pub fn text_spaced(&mut self, x: f32, baseline: f32, font: &Font, size: f32, color: Rgb3, s: &str, spacing: f32) {
        let clean = self.fonts.sanitize(s).replace('\n', " ");
        if clean.trim().is_empty() {
            return;
        }
        let y = self.pdf_y(baseline);
        self.ops.push(Op::StartTextSection);
        self.ops.push(Op::SetFont { font: PdfFontHandle::External(font.id.clone()), size: Pt(size) });
        self.ops.push(Op::SetFillColor { col: rgb(color) });
        if spacing != 0.0 {
            self.ops.push(Op::SetCharacterSpacing { multiplier: spacing });
        }
        self.ops.push(Op::SetTextCursor { pos: Point { x: Pt(x), y: Pt(y) } });
        self.ops.push(Op::ShowText { items: vec![TextItem::Text(clean)] });
        if spacing != 0.0 {
            self.ops.push(Op::SetCharacterSpacing { multiplier: 0.0 });
        }
        self.ops.push(Op::EndTextSection);
    }

    pub fn text_right(&mut self, right_x: f32, baseline: f32, font: &Font, size: f32, color: Rgb3, s: &str) {
        let w = font.width(&self.fonts.sanitize(s), size);
        self.text(right_x - w, baseline, font, size, color, s);
    }

    pub fn fill_rect(&mut self, x: f32, y_top: f32, w: f32, h: f32, color: Rgb3, alpha: Option<f32>) {
        let y = self.pdf_y(y_top + h);
        let col = rgb(color);
        self.with_alpha(alpha, |ops| {
            ops.push(Op::SetFillColor { col });
            ops.push(Op::DrawRectangle {
                rectangle: Rect { x: Pt(x), y: Pt(y), width: Pt(w), height: Pt(h), mode: Some(PaintMode::Fill), winding_order: Some(WindingOrder::NonZero) },
            });
        });
    }

    pub fn stroke_rect(&mut self, x: f32, y_top: f32, w: f32, h: f32, color: Rgb3, thickness: f32) {
        let y = self.pdf_y(y_top + h);
        self.ops.push(Op::SetOutlineColor { col: rgb(color) });
        self.ops.push(Op::SetOutlineThickness { pt: Pt(thickness) });
        self.ops.push(Op::DrawRectangle {
            rectangle: Rect { x: Pt(x), y: Pt(y), width: Pt(w), height: Pt(h), mode: Some(PaintMode::Stroke), winding_order: Some(WindingOrder::NonZero) },
        });
    }

    #[allow(clippy::too_many_arguments)]
    pub fn line(&mut self, x1: f32, y1: f32, x2: f32, y2: f32, color: Rgb3, thickness: f32, alpha: Option<f32>) {
        let (p1, p2) = (Point { x: Pt(x1), y: Pt(self.pdf_y(y1)) }, Point { x: Pt(x2), y: Pt(self.pdf_y(y2)) });
        let col = rgb(color);
        self.with_alpha(alpha, |ops| {
            ops.push(Op::SetOutlineColor { col });
            ops.push(Op::SetOutlineThickness { pt: Pt(thickness) });
            ops.push(Op::DrawLine {
                line: Line { points: vec![LinePoint { p: p1, bezier: false }, LinePoint { p: p2, bezier: false }], is_closed: false },
            });
        });
    }

    pub fn hrule(&mut self, y: f32, color: Rgb3, thickness: f32) {
        let (x1, x2) = (self.ml, self.w - self.mr);
        self.line(x1, y, x2, y, color, thickness, None);
    }

    /// Filled circle approximated by a 20-gon (crisp at report scales).
    pub fn circle(&mut self, cx: f32, cy: f32, r: f32, color: Rgb3, alpha: Option<f32>) {
        let cyp = self.pdf_y(cy);
        let points: Vec<LinePoint> = (0..20)
            .map(|i| {
                let a = i as f32 / 20.0 * std::f32::consts::TAU;
                LinePoint { p: Point { x: Pt(cx + r * a.cos()), y: Pt(cyp + r * a.sin()) }, bezier: false }
            })
            .collect();
        let col = rgb(color);
        self.with_alpha(alpha, |ops| {
            ops.push(Op::SetFillColor { col });
            ops.push(Op::DrawPolygon {
                polygon: Polygon { rings: vec![PolygonRing { points }], mode: PaintMode::Fill, winding_order: WindingOrder::NonZero },
            });
        });
    }

    /// Clickable area (PDF link annotation).
    pub fn link(&mut self, x: f32, y_top: f32, w: f32, h: f32, url: &str) {
        if !(url.starts_with("http://") || url.starts_with("https://")) {
            return;
        }
        let y = self.pdf_y(y_top + h);
        self.ops.push(Op::LinkAnnotation {
            link: LinkAnnotation::new(
                Rect::from_xywh(Pt(x), Pt(y), Pt(w), Pt(h)),
                Actions::Uri(url.to_string()),
                Some(BorderArray::Solid([0.0, 0.0, 0.0])),
                Some(ColorArray::Transparent),
                Some(HighlightingMode::Invert),
            ),
        });
    }

    // ------------------------------------------------------------------ text layout

    /// Word-wrap `text` to `width`; long tokens (URLs) are broken by characters.
    pub fn wrap(&self, text: &str, font: &Font, size: f32, width: f32) -> Vec<String> {
        let clean = self.fonts.sanitize(text);
        let mut lines = Vec::new();
        for para in clean.split('\n') {
            let mut line = String::new();
            for word in para.split(' ').filter(|w| !w.is_empty()) {
                let candidate = if line.is_empty() { word.to_string() } else { format!("{line} {word}") };
                if font.width(&candidate, size) <= width {
                    line = candidate;
                    continue;
                }
                if !line.is_empty() {
                    lines.push(std::mem::take(&mut line));
                }
                if font.width(word, size) <= width {
                    line = word.to_string();
                } else {
                    let mut chunk = String::new();
                    for ch in word.chars() {
                        let next = format!("{chunk}{ch}");
                        if font.width(&next, size) > width && !chunk.is_empty() {
                            lines.push(std::mem::take(&mut chunk));
                            chunk.push(ch);
                        } else {
                            chunk = next;
                        }
                    }
                    line = chunk;
                }
            }
            lines.push(line);
        }
        while lines.last().map(|l| l.is_empty()).unwrap_or(false) && lines.len() > 1 {
            lines.pop();
        }
        lines
    }

    /// Wrapped paragraph flowing across pages.
    #[allow(clippy::too_many_arguments)]
    pub fn paragraph(&mut self, text: &str, font: &Font, size: f32, color: Rgb3, leading: f32, indent: f32, width: Option<f32>) {
        let width = width.unwrap_or(self.content_width() - indent);
        for line in self.wrap(text, font, size, width) {
            self.ensure(leading);
            let baseline = self.y + size;
            if !line.is_empty() {
                self.text(self.ml + indent, baseline, font, size, color, &line);
            }
            self.y += leading;
        }
    }

    pub fn body(&mut self, text: &str) {
        let (f, c) = (&self.fonts.regular, self.theme.text);
        for (i, p) in text.split("\n\n").enumerate() {
            if i > 0 {
                self.space(5.0);
            }
            self.paragraph(p, f, 9.5, c, 14.2, 0.0, None);
        }
    }

    pub fn muted(&mut self, text: &str) {
        let (f, c) = (&self.fonts.regular, self.theme.muted);
        self.paragraph(text, f, 8.5, c, 12.5, 0.0, None);
    }

    /// Section heading: large index number, title, rule and a PDF bookmark.
    pub fn heading(&mut self, index: usize, title: &str) {
        if self.y > self.mt + 1.0 {
            self.space(14.0);
        }
        if self.ensure(70.0) {
            // fresh page
        }
        self.bookmarks.push((title.to_string(), self.page_number()));
        let num = format!("{index:02}");
        let (light, semi) = (&self.fonts.light, &self.fonts.semibold);
        let (accent, text, rule) = (self.theme.accent, self.theme.text, self.theme.rule);
        self.text(self.ml, self.y + 24.0, light, 24.0, accent, &num);
        let nx = self.ml + light.width(&num, 24.0) + 12.0;
        self.text(nx, self.y + 22.0, semi, 15.0, text, title);
        self.y += 34.0;
        self.hrule(self.y, rule, 0.6);
        self.y += 14.0;
    }

    pub fn subheading(&mut self, title: &str, meta: Option<&str>) {
        self.space(6.0);
        self.ensure(40.0);
        let (f, m) = (&self.fonts.medium, &self.fonts.regular);
        let (text, muted) = (self.theme.text, self.theme.muted);
        self.text(self.ml, self.y + 11.0, f, 11.0, text, title);
        if let Some(meta) = meta {
            let x = self.ml + f.width(&self.fonts.sanitize(title), 11.0) + 10.0;
            self.text(x, self.y + 11.0, m, 8.5, muted, meta);
        }
        self.y += 20.0;
    }

    /// Two-column label/value block.
    pub fn kv(&mut self, rows: &[(String, String)]) {
        let label_w = 150.0;
        let value_w = self.content_width() - label_w;
        let (lf, vf) = (&self.fonts.medium, &self.fonts.regular);
        let (muted, text, rule) = (self.theme.muted, self.theme.text, self.theme.rule);
        for (label, value) in rows {
            let lines = self.wrap(value, vf, 9.5, value_w);
            let h = (lines.len().max(1) as f32) * 13.5 + 8.0;
            self.ensure(h);
            self.text(self.ml, self.y + 11.0, lf, 7.5, muted, &label.to_uppercase());
            let mut yy = self.y + 11.0;
            for l in &lines {
                self.text(self.ml + label_w, yy, vf, 9.5, text, l);
                yy += 13.5;
            }
            self.y += h;
            self.line(self.ml, self.y - 3.0, self.w - self.mr, self.y - 3.0, rule, 0.4, None);
        }
    }

    pub fn bullets(&mut self, items: &[String], color: Option<Rgb3>) {
        let f = &self.fonts.regular;
        let (accent, text) = (self.theme.accent, color.unwrap_or(self.theme.text));
        let width = self.content_width() - 14.0;
        for item in items {
            let lines = self.wrap(item, f, 9.3, width);
            for (i, l) in lines.iter().enumerate() {
                self.ensure(13.6);
                if i == 0 {
                    self.circle(self.ml + 3.0, self.y + 6.6, 1.6, accent, None);
                }
                self.text(self.ml + 14.0, self.y + 9.5, f, 9.3, text, l);
                self.y += 13.6;
            }
            self.y += 2.5;
        }
    }

    /// Framed note box (analyst notes, hints).
    pub fn callout(&mut self, title: &str, text: &str) {
        let f = &self.fonts.regular;
        let width = self.content_width() - 28.0;
        let lines = self.wrap(text, f, 9.3, width);
        let mut i = 0;
        while i < lines.len() {
            let available = ((self.bottom() - self.y - 34.0) / 13.6).floor().max(0.0) as usize;
            if available < 2 {
                self.new_page(PageKind::Content);
                continue;
            }
            let take = available.min(lines.len() - i);
            let h = 26.0 + take as f32 * 13.6 + 8.0;
            let (bg, accent, muted, txt) = (self.theme.callout, self.theme.accent, self.theme.muted, self.theme.text);
            self.fill_rect(self.ml, self.y, self.content_width(), h, bg, None);
            self.fill_rect(self.ml, self.y, 2.2, h, accent, None);
            let mf = &self.fonts.medium;
            self.text(self.ml + 14.0, self.y + 16.0, mf, 7.5, muted, &title.to_uppercase());
            let mut yy = self.y + 32.0;
            for l in &lines[i..i + take] {
                self.text(self.ml + 14.0, yy, f, 9.3, txt, l);
                yy += 13.6;
            }
            self.y += h + 10.0;
            i += take;
        }
    }

    /// Paginated table with header repetition, wrapped cells, zebra rows and links.
    pub fn table(&mut self, cols: &[Col], rows: &[Vec<Cell>], size: f32) {
        let cw = self.content_width();
        let widths: Vec<f32> = cols.iter().map(|c| c.frac * cw).collect();
        let pad = 5.0;
        let lead = size * 1.42;
        self.ensure(22.0 + lead * 2.0);
        self.table_header(cols, &widths);
        for (ri, row) in rows.iter().enumerate() {
            // lay out cells
            let mut cell_lines: Vec<(Vec<String>, Vec<String>)> = Vec::new();
            for (ci, cell) in row.iter().enumerate().take(cols.len()) {
                let font = if cols[ci].mono { &self.fonts.mono } else if cell.bold { &self.fonts.medium } else { &self.fonts.regular };
                let mut main = self.wrap(&cell.text, font, size, widths[ci] - pad * 2.0);
                main.truncate(10);
                let mut sub = cell.sub.as_ref().map(|s| self.wrap(s, &self.fonts.regular, size - 1.3, widths[ci] - pad * 2.0)).unwrap_or_default();
                sub.truncate(5);
                cell_lines.push((main, sub));
            }
            let row_h = cell_lines
                .iter()
                .map(|(m, s)| m.len() as f32 * lead + s.len() as f32 * (lead - 1.6))
                .fold(lead, f32::max)
                + pad * 2.0;
            if self.ensure(row_h) {
                self.table_header(cols, &widths);
            }
            if ri % 2 == 1 {
                let z = self.theme.zebra;
                self.fill_rect(self.ml, self.y, cw, row_h, z, None);
            }
            let mut x = self.ml;
            for (ci, (main, sub)) in cell_lines.iter().enumerate() {
                let cell = &row[ci];
                let font = if cols[ci].mono { &self.fonts.mono } else if cell.bold { &self.fonts.medium } else { &self.fonts.regular };
                let color = cell.color.unwrap_or(if cell.link.is_some() { self.theme.link } else { self.theme.text });
                let mut yy = self.y + pad + size;
                for l in main {
                    self.text(x + pad, yy, font, size, color, l);
                    yy += lead;
                }
                let (rf, muted) = (&self.fonts.regular, self.theme.muted);
                for l in sub {
                    self.text(x + pad, yy, rf, size - 1.3, muted, l);
                    yy += lead - 1.6;
                }
                if let Some(url) = &cell.link {
                    self.link(x, self.y, widths[ci], row_h, url);
                }
                x += widths[ci];
            }
            self.y += row_h;
            let rule = self.theme.rule;
            self.line(self.ml, self.y, self.ml + cw, self.y, rule, 0.35, None);
        }
        self.y += 8.0;
    }

    fn table_header(&mut self, cols: &[Col], widths: &[f32]) {
        let (bg, muted) = (self.theme.table_head, self.theme.muted);
        let cw = self.content_width();
        self.fill_rect(self.ml, self.y, cw, 20.0, bg, None);
        let mut x = self.ml;
        let f = &self.fonts.medium;
        for (c, w) in cols.iter().zip(widths) {
            self.text_spaced(x + 5.0, self.y + 13.0, f, 6.8, muted, &c.title.to_uppercase(), 0.35);
            x += w;
        }
        self.y += 20.0;
    }
}
