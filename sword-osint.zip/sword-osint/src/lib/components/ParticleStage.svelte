<!--
  Full-window 3D particle universe behind every section. Owns the engine lifecycle:
  lazy creation (and re-creation when the renderer or quality tier changes), pause while
  the window is hidden, dimming behind other sections, beacon and analysis synchronisation,
  and periodic performance metrics for ANALYTICS.
-->
<script lang="ts">
  import { onMount, untrack } from 'svelte';
  import { api, desktop } from '../api/client';
  import type { Category, GraphicsSettings } from '../api/types';
  import { app } from '../stores/app.svelte';
  import { run, type RunState } from '../stores/run.svelte';
  import { CATEGORIES } from '../util/labels';
  import type { EngineOptions, EngineStats, ParticleEngine, RunVisual } from '../engine/particles/ParticleEngine';

  const DEFAULT_GRAPHICS: GraphicsSettings = {
    renderer: 'auto',
    quality: 'auto',
    bloom: true,
    trails: true,
    fpsLimit: 0,
    reduceMotion: false,
    backgroundAnimation: true,
    maxPixelRatio: 2,
    showFps: false,
  };

  let host = $state<HTMLDivElement | null>(null);
  let labels = $state<HTMLDivElement | null>(null);
  let engine = $state.raw<ParticleEngine | null>(null);
  let status = $state<'loading' | 'ready' | 'failed' | 'lost'>('loading');
  let failure = $state('');
  let hidden = $state(false);

  const graphics = $derived(app.settings?.graphics ?? DEFAULT_GRAPHICS);
  const onDiscovery = $derived(app.section === 'discovery');

  function options(g: GraphicsSettings): EngineOptions {
    const safe = app.gpuSafeMode;
    return {
      renderer: safe >= 2 ? 'webgl2' : g.renderer,
      quality: g.quality,
      bloom: g.bloom && safe === 0,
      trails: g.trails && safe === 0,
      fpsLimit: g.fpsLimit,
      reduceMotion: g.reduceMotion || matchMedia('(prefers-reduced-motion: reduce)').matches,
      maxPixelRatio: g.maxPixelRatio,
    };
  }

  /**
   * Engine calls made from reactive effects must never throw into Svelte's update cycle:
   * a failing GPU would otherwise stall unrelated UI updates.
   */
  function safely(fn: () => void) {
    try {
      fn();
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      console.error('[3D]', message);
      if (!app.recoverGpu(message)) status = 'failed';
    }
  }

  function onStats(s: EngineStats) {
    const mem = (performance as Performance & { memory?: { usedJSHeapSize: number } }).memory;
    app.perf = { fps: s.fps, particles: s.particles, backend: s.backend, gpu: s.gpu, heapMb: mem ? mem.usedJSHeapSize / 1048576 : null, simplified: s.simplified };
  }

  function onBeaconClick(id: string) {
    if (app.section !== 'discovery') return;
    const c = id as Category;
    const cur = app.selectedCategories;
    app.selectedCategories = cur.includes(c) ? cur.filter((x) => x !== c) : [...cur, c];
  }

  // ---- engine lifecycle: one engine (and one canvas) per graphics epoch
  $effect(() => {
    const epoch = app.engineEpoch;
    const h = host;
    const l = labels;
    if (!h || !l) return;
    if (app.backend === 'connecting') return; // wait for the stored graphics settings
    const g = untrack(() => app.settings?.graphics ?? DEFAULT_GRAPHICS);
    const canvas = document.createElement('canvas');
    canvas.className = 'universe';
    canvas.dataset.epoch = String(epoch);
    h.prepend(canvas);
    let cancelled = false;
    let instance: ParticleEngine | null = null;
    status = 'loading';
    import('../engine/particles/ParticleEngine')
      .then(async ({ ParticleEngine }) => {
        if (cancelled) return;
        instance = new ParticleEngine(canvas, l, options(g), {
          onStats,
          onBeaconClick,
          onLost: (message) => {
            // rebuild automatically in a safer mode; show the manual notice only when out of options
            if (!app.recoverGpu(message)) {
              status = 'lost';
              failure = message;
            }
          },
        });
        await instance.init();
        if (cancelled) return;
        engine = instance;
        status = 'ready';
      })
      .catch((e: unknown) => {
        if (cancelled) return;
        const message = e instanceof Error ? e.message : String(e);
        // WebGPU could not start: retry in a safer mode before giving up on the 3D scene
        if (app.recoverGpu(message)) return;
        status = 'failed';
        failure = message;
        app.perf = { ...app.perf, backend: 'нет 3D' };
      });
    return () => {
      cancelled = true;
      engine = null;
      instance?.dispose();
      canvas.remove();
    };
  });

  // ---- settings that apply without a new renderer
  $effect(() => {
    const o = options(graphics);
    safely(() => engine?.updateOptions(o));
  });

  // ---- section, visibility and backdrop behaviour
  $effect(() => {
    const e = engine;
    if (!e) return;
    const paused = hidden || app.section === 'network' || (!onDiscovery && !graphics.backgroundAnimation);
    const interactive = onDiscovery;
    safely(() => {
      e.setInteractive(interactive);
      e.setThrottle(interactive ? 0 : 30);
      e.setPaused(paused);
    });
  });

  // ---- category beacons
  $effect(() => {
    const e = engine;
    if (!e) return;
    const selected = app.selectedCategories;
    const beacons = CATEGORIES.map((c) => {
      const r = app.readiness(c.id);
      return {
        id: c.id,
        title: `${c.title} — ${c.hint}`,
        short: c.short,
        detail: r.total ? `${c.label} · готово ${r.ready} из ${r.total}` : c.label,
        selected: selected.includes(c.id),
        ready: r.ready > 0,
      };
    });
    safely(() => e.setBeacons(beacons));
  });

  // ---- analysis → convergence of the particle structure
  function runVisual(r: RunState | null): RunVisual {
    const levels = new Array<number>(CATEGORIES.length).fill(0);
    if (!r) return { active: false, complete: false, levels, participating: [] };
    const finished = !r.live;
    const ok = r.record !== null && (r.record.status === 'completed' || r.record.status === 'partial');
    const fromPlan = new Set<Category>();
    for (const p of r.plan) if (p.willRun) for (const c of p.categories) fromPlan.add(c);
    let cats: Category[] = [...fromPlan];
    if (!cats.length && r.record) cats = r.record.categories;
    if (!cats.length) cats = app.selectedCategories;
    CATEGORIES.forEach((c, i) => {
      const list = r.plan.filter((p) => p.willRun && p.categories.includes(c.id));
      if (finished) {
        levels[i] = 1;
        return;
      }
      if (!list.length) {
        levels[i] = 0.12;
        return;
      }
      let done = 0;
      for (const p of list) {
        const s = r.runs[p.adapterId]?.status;
        if (s === 'running') done += 0.35;
        else if (s && s !== 'queued') done += 1;
      }
      levels[i] = 0.12 + 0.88 * (done / list.length);
    });
    const participating = cats.map((c) => CATEGORIES.findIndex((x) => x.id === c)).filter((i) => i >= 0);
    return { active: r.live, complete: finished && ok, levels, participating };
  }

  $effect(() => {
    const visual = runVisual(run.discovery);
    safely(() => engine?.setRun(visual));
  });

  onMount(() => {
    const vis = () => (hidden = document.hidden);
    document.addEventListener('visibilitychange', vis);

    // performance samples for ANALYTICS (real measurements only)
    const timer = setInterval(() => {
      if (!desktop() || app.backend !== 'ready' || status !== 'ready' || hidden) return;
      const p = app.perf;
      const samples = [
        { name: 'particles', value: p.particles },
        { name: 'renderer', value: 1, labels: p.gpu ? `${p.backend} · ${p.gpu}` : p.backend },
      ];
      if (app.section === 'discovery' && p.fps > 0) samples.push({ name: 'fps', value: p.fps }, { name: 'frame_ms', value: 1000 / p.fps });
      if (p.heapMb !== null) samples.push({ name: 'js_heap_mb', value: Math.round(p.heapMb * 10) / 10 });
      api.recordMetrics(samples).catch(() => {});
    }, 60_000);

    return () => {
      document.removeEventListener('visibilitychange', vis);
      clearInterval(timer);
    };
  });
</script>

<div class="stage" class:dim={!onDiscovery} bind:this={host} aria-hidden={!onDiscovery}>
  <div class="labels" bind:this={labels}></div>
  <div class="vignette"></div>
</div>

{#if (status === 'failed' || status === 'lost') && onDiscovery}
  <div class="notice glass" role="status">
    <span class="eyebrow">{status === 'lost' ? 'GPU' : '3D'}</span>
    <span class="msg">
      {status === 'lost' ? 'Графическое устройство было сброшено драйвером.' : '3D-сцена недоступна на этом устройстве.'}
      <span class="faint">{failure}</span>
    </span>
    <button class="btn sm" onclick={() => app.engineEpoch++}>Перезапустить сцену</button>
  </div>
{/if}

<style>
  .stage {
    position: fixed;
    inset: 0;
    z-index: 0;
    background: #000;
    overflow: hidden;
  }
  .stage :global(canvas.universe) {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    display: block;
    outline: none;
    transition: opacity 0.8s var(--ease);
    touch-action: none;
  }
  .stage.dim :global(canvas.universe) {
    opacity: 0.4;
  }
  .vignette {
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: radial-gradient(ellipse 75% 70% at 50% 48%, transparent 55%, rgba(0, 0, 0, 0.62) 100%);
  }
  .labels {
    position: absolute;
    inset: 0;
    pointer-events: none;
    overflow: hidden;
    z-index: 1;
    transition: opacity 0.5s var(--ease);
  }
  .labels:global(.hidden) {
    opacity: 0;
  }
  .labels :global(.beacon-label) {
    position: absolute;
    left: 0;
    top: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 3px;
    white-space: nowrap;
    will-change: transform, opacity;
  }
  .labels :global(.bl-title) {
    font-family: var(--font-display);
    font-size: 8.5px;
    letter-spacing: 0.28em;
    color: var(--fg-2);
    transition: color 0.3s, text-shadow 0.3s;
  }
  .labels :global(.bl-detail) {
    font-size: 10.5px;
    color: var(--fg-2);
    opacity: 0;
    transform: translateY(-3px);
    transition: opacity 0.25s var(--ease), transform 0.3s var(--ease);
    padding: 2px 8px;
    border-radius: 6px;
    background: rgba(5, 7, 10, 0.7);
    border: 1px solid var(--line);
  }
  .labels :global(.beacon-label.hover .bl-detail) {
    opacity: 1;
    transform: none;
  }
  .labels :global(.beacon-label.selected .bl-title) {
    color: #fff;
    text-shadow: 0 0 10px rgba(235, 242, 255, 0.85);
  }
  .labels :global(.beacon-label.unready .bl-title) {
    color: var(--fg-4);
  }
  .notice {
    position: fixed;
    left: 50%;
    bottom: 26px;
    transform: translateX(-50%);
    z-index: 30;
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 10px 12px 10px 16px;
    max-width: min(760px, calc(100vw - 140px));
    font-size: 12.5px;
  }
  .msg {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }
  .msg .faint {
    font-size: 11px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
</style>
