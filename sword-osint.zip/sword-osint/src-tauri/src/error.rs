//! Command error envelope: `{ kind, message }`, serialised to the UI.

use serde::Serialize;
use sword_core::{ErrorKind, SwordError};

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct ApiError {
    pub kind: ErrorKind,
    pub message: String,
}

pub type ApiResult<T> = Result<T, ApiError>;

impl From<SwordError> for ApiError {
    fn from(e: SwordError) -> Self {
        ApiError { kind: e.kind(), message: e.to_string() }
    }
}

impl From<tauri::Error> for ApiError {
    fn from(e: tauri::Error) -> Self {
        ApiError { kind: ErrorKind::Internal, message: e.to_string() }
    }
}

impl From<std::io::Error> for ApiError {
    fn from(e: std::io::Error) -> Self {
        ApiError { kind: ErrorKind::Io, message: e.to_string() }
    }
}

impl ApiError {
    pub fn invalid(msg: impl Into<String>) -> Self {
        ApiError { kind: ErrorKind::InvalidInput, message: msg.into() }
    }
    pub fn internal(msg: impl Into<String>) -> Self {
        ApiError { kind: ErrorKind::Internal, message: msg.into() }
    }
    pub fn not_found(msg: impl Into<String>) -> Self {
        ApiError { kind: ErrorKind::NotFound, message: msg.into() }
    }
    pub fn forbidden(msg: impl Into<String>) -> Self {
        ApiError { kind: ErrorKind::Forbidden, message: msg.into() }
    }
}
