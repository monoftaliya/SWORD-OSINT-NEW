<script lang="ts" generics="T extends string | number">
  let { options, value = $bindable(), onchange, size = 'md' }: { options: { value: T; label: string }[]; value: T; onchange?: (v: T) => void; size?: 'sm' | 'md' } = $props();
</script>

<div class="seg {size}" role="tablist">
  {#each options as o (o.value)}
    <button
      type="button"
      role="tab"
      aria-selected={value === o.value}
      class:active={value === o.value}
      onclick={() => {
        value = o.value;
        onchange?.(o.value);
      }}>{o.label}</button
    >
  {/each}
</div>

<style>
  .seg {
    display: inline-flex;
    padding: 3px;
    gap: 2px;
    border-radius: 999px;
    border: 1px solid var(--line);
    background: rgba(0, 0, 0, 0.35);
  }
  button {
    border: none;
    background: transparent;
    color: var(--fg-3);
    height: 28px;
    padding: 0 13px;
    border-radius: 999px;
    cursor: pointer;
    font-size: 12px;
    transition: color 0.2s, background 0.25s var(--ease), box-shadow 0.25s;
    white-space: nowrap;
  }
  .sm button {
    height: 24px;
    padding: 0 10px;
    font-size: 11.5px;
  }
  button:hover {
    color: var(--fg);
  }
  button.active {
    color: #05070a;
    background: #eef2f7;
    box-shadow: 0 0 16px rgba(225, 235, 250, 0.25);
  }
</style>
