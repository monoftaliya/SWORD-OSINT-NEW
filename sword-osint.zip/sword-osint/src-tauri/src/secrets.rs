//! OS credential vault: Windows Credential Manager (DPAPI-protected, per Windows user).
//! API keys, tokens and own e-mail addresses are stored here — never in SQLite or logs.

use std::sync::Arc;

use sword_core::{MemorySecretStore, SecretStore, SwordError, SwordResult};

const SERVICE: &str = "SWORD OSINT";

pub struct VaultStore;

impl VaultStore {
    fn entry(key: &str) -> SwordResult<keyring::Entry> {
        keyring::Entry::new(SERVICE, key).map_err(|e| SwordError::Internal(format!("хранилище учётных данных: {e}")))
    }
}

impl SecretStore for VaultStore {
    fn get(&self, key: &str) -> SwordResult<Option<String>> {
        match Self::entry(key)?.get_password() {
            Ok(v) => Ok(Some(v)),
            Err(keyring::Error::NoEntry) => Ok(None),
            Err(e) => Err(SwordError::Internal(format!("хранилище учётных данных: {e}"))),
        }
    }

    fn set(&self, key: &str, value: &str) -> SwordResult<()> {
        Self::entry(key)?.set_password(value).map_err(|e| SwordError::Internal(format!("хранилище учётных данных: {e}")))
    }

    fn delete(&self, key: &str) -> SwordResult<()> {
        match Self::entry(key)?.delete_credential() {
            Ok(()) | Err(keyring::Error::NoEntry) => Ok(()),
            Err(e) => Err(SwordError::Internal(format!("хранилище учётных данных: {e}"))),
        }
    }
}

/// The OS vault, or an in-memory fallback when the vault is unavailable (the UI then
/// warns that secrets are not persisted).
pub fn open_store() -> (Arc<dyn SecretStore>, bool) {
    let probe = VaultStore::entry("__probe__").and_then(|e| match e.get_password() {
        Ok(_) | Err(keyring::Error::NoEntry) => Ok(()),
        Err(err) => Err(SwordError::Internal(err.to_string())),
    });
    match probe {
        Ok(()) => (Arc::new(VaultStore), true),
        Err(e) => {
            tracing::error!(error = %e, "OS credential vault unavailable, secrets will not persist");
            (Arc::new(MemorySecretStore::default()), false)
        }
    }
}
