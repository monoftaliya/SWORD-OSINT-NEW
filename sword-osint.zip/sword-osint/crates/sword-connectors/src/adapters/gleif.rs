//! GLEIF — Global Legal Entity Identifier Foundation: official LEI reference data and
//! Level-2 «who owns whom» parent relationships.

use async_trait::async_trait;
use serde_json::Value;
use sword_core::util::{fmt_date, parse_date};
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordError, SwordResult,
};

use super::{arr, info, sp};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::output::{FindingExt, OutputBuilder};

const API: &str = "https://api.gleif.org/api/v1";

pub struct Gleif {
    info: AdapterInfo,
}

impl Default for Gleif {
    fn default() -> Self {
        Self::new()
    }
}

fn address(a: Option<&Value>) -> Option<String> {
    let a = a?;
    let lines: Vec<String> = arr(a, "/addressLines").iter().filter_map(|l| l.as_str().map(str::to_string)).collect();
    let parts: Vec<String> = [Some(lines.join(", ")), sp(a, "/city"), sp(a, "/region"), sp(a, "/country"), sp(a, "/postalCode")]
        .into_iter()
        .flatten()
        .filter(|p| !p.is_empty())
        .collect();
    (!parts.is_empty()).then(|| parts.join(", "))
}

impl Gleif {
    pub fn new() -> Self {
        Gleif {
            info: info(
                "gleif",
                "GLEIF (LEI)",
                "Global Legal Entity Identifier Foundation",
                "Официальные справочные данные юридических лиц с кодом LEI: наименование, юрисдикция, адреса, статус, \
                 а также прямые и конечные материнские компании (Level 2).",
                "GLEIF API v1: /lei-records?filter[fulltext]=… и /lei-records/{LEI}/direct-parent, /ultimate-parent. \
                 Данные публикуются LOU и проходят валидацию GLEIF; связи «дочерняя — материнская» имеют достоверность 0.98.",
                &[Category::OrgIntel],
                &[InputKind::Text],
                vec![],
                vec![],
                55,
                "https://www.gleif.org/",
                Some("https://documenter.getpostman.com/view/7679680/SVYrrxuU"),
                true,
            ),
        }
    }

    async fn get(&self, ctx: &ConnectorContext, url: &str) -> SwordResult<Value> {
        ctx.json(&self.info, ctx.get(url).header("accept", "application/vnd.api+json")).await
    }

    fn add_record(&self, b: &mut OutputBuilder, rec: &Value) -> Option<(String, String, String)> {
        let lei = rec.get("id").and_then(Value::as_str)?.to_string();
        let a = rec.get("attributes")?;
        let name = sp(a, "/entity/legalName/name").unwrap_or_else(|| lei.clone());
        let page = format!("https://search.gleif.org/#/record/{lei}");
        let api_url = format!("{API}/lei-records/{lei}");
        let key = keys::org("lei", &lei);
        b.entity(&key, EntityKind::Organization, &name);
        let facts = [
            ("LEI", Some(lei.clone())),
            ("Юрисдикция", sp(a, "/entity/jurisdiction")),
            ("Статус юрлица", sp(a, "/entity/status")),
            ("Категория", sp(a, "/entity/category")),
            ("Код правовой формы", sp(a, "/entity/legalForm/id")),
            ("Регистрационный номер", sp(a, "/entity/registeredAs")),
            ("Юридический адрес", address(a.pointer("/entity/legalAddress"))),
            ("Адрес штаб-квартиры", address(a.pointer("/entity/headquartersAddress"))),
            ("Статус LEI", sp(a, "/registration/status")),
            ("Выдан", sp(a, "/registration/initialRegistrationDate").and_then(|d| parse_date(&d)).map(|d| fmt_date(&d))),
            ("Продлить до", sp(a, "/registration/nextRenewalDate").and_then(|d| parse_date(&d)).map(|d| fmt_date(&d))),
        ];
        let mut snippet = Vec::new();
        for (label, value) in facts.iter() {
            if let Some(v) = value {
                b.attr(&key, label, v, &api_url);
                if matches!(*label, "Юрисдикция" | "Статус юрлица" | "Юридический адрес") {
                    snippet.push(format!("{label}: {v}"));
                }
            }
        }
        b.finding(Category::OrgIntel, FindingKind::Organization, &name, Some(&page))
            .snippet(&snippet.join("; "))
            .confidence(0.98)
            .attr("LEI", lei.clone())
            .attr("Статус LEI", sp(a, "/registration/status").unwrap_or_default())
            .entity(&key);
        b.source(&page, &format!("GLEIF: {name}"));
        Some((lei, key, name))
    }
}

#[async_trait]
impl SourceAdapter for Gleif {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        self.get(ctx, &format!("{API}/lei-records?page[size]=1")).await?;
        Ok(vec![PermissionCheck::granted("GLEIF API", "Доступ без ключа (лимит ~60 запросов в минуту)")])
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let mut b = OutputBuilder::new(&self.info);
        let size = ctx.max_results.clamp(3, 15);
        let mut url = url::Url::parse(&format!("{API}/lei-records")).map_err(|e| SwordError::Internal(e.to_string()))?;
        url.query_pairs_mut().append_pair("filter[fulltext]", &input.text).append_pair("page[size]", &size.to_string());
        let v = self.get(ctx, url.as_str()).await?;
        let mut added = Vec::new();
        for rec in arr(&v, "/data") {
            if let Some(r) = self.add_record(&mut b, rec) {
                added.push(r);
            }
        }
        if added.is_empty() {
            b.note("GLEIF: юридических лиц с LEI по запросу не найдено.");
            return Ok(b.finish());
        }
        // Level 2: parents of the top matches.
        for (lei, key, name) in added.iter().take(3) {
            for (path, note) in [("direct-parent", "прямая материнская компания (GLEIF Level 2)"), ("ultimate-parent", "конечная материнская компания (GLEIF Level 2)")] {
                let url = format!("{API}/lei-records/{lei}/{path}");
                match self.get(ctx, &url).await {
                    Ok(pv) => {
                        if let Some(parent) = pv.get("data") {
                            if let Some((plei, pkey, pname)) = self.add_record(&mut b, parent) {
                                if plei != *lei {
                                    b.relate(key, &pkey, "subsidiary_of", 0.98, &url, Some(note));
                                    b.fact(&format!("{name}: {note}"), &format!("{pname} (LEI {plei})"), &url);
                                }
                            }
                        }
                    }
                    Err(SwordError::NotFound(_)) => {}
                    Err(e) => b.note(format!("GLEIF {path} для {lei}: {e}")),
                }
            }
        }
        Ok(b.finish())
    }
}
