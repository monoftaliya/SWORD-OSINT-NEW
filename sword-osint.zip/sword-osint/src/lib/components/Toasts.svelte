<script lang="ts">
  import Icon from './Icon.svelte';
  import { app } from '../stores/app.svelte';
</script>

<div class="toasts" aria-live="polite">
  {#each app.toasts as t (t.id)}
    <div class="toast glass {t.tone}">
      <Icon name={t.tone === 'err' ? 'alert' : t.tone === 'ok' ? 'check' : 'info'} size={16} />
      <span class="text">{t.text}</span>
      <button class="x" onclick={() => app.dismiss(t.id)} aria-label="Закрыть"><Icon name="x" size={13} /></button>
    </div>
  {/each}
</div>

<style>
  .toasts {
    position: fixed;
    right: 22px;
    bottom: 22px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    z-index: 100;
    max-width: 420px;
  }
  .toast {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 12px 12px 12px 14px;
    font-size: 12.5px;
    animation: enter 0.45s var(--ease-out) both;
  }
  .toast.ok {
    color: #dff5ea;
  }
  .toast.err {
    color: #ffe0e0;
    border-color: rgba(240, 138, 138, 0.28);
  }
  .text {
    flex: 1;
    line-height: 1.45;
  }
  .x {
    border: none;
    background: none;
    color: var(--fg-3);
    cursor: pointer;
    padding: 2px;
  }
  .x:hover {
    color: #fff;
  }
</style>
