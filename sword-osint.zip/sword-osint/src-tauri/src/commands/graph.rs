//! NETWORK: relationship graph of an investigation or merged knowledge graph; export.

use base64::{engine::general_purpose::STANDARD, Engine as _};
use serde::Deserialize;
use sword_graph::{export, Graph};
use tauri::{AppHandle, State};

use super::save_dialog;
use crate::error::{ApiError, ApiResult};
use crate::state::{blocking, AppState};

#[derive(Debug, Clone, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GraphScope {
    /// One investigation…
    pub investigation_id: Option<String>,
    /// …or the merged graph of the N most recent investigations.
    pub recent: Option<u32>,
}

async fn load(state: &AppState, scope: &GraphScope) -> ApiResult<Graph> {
    let db = state.db.clone();
    match (&scope.investigation_id, scope.recent) {
        (Some(id), _) => {
            let id = id.clone();
            blocking(move || db.graph_of(&id)).await
        }
        (None, Some(n)) => {
            let n = n.clamp(1, 200);
            let graphs = blocking(move || db.recent_graphs(n)).await?;
            Ok(sword_graph::merge(graphs))
        }
        (None, None) => Err(ApiError::invalid("не указан источник графа")),
    }
}

#[tauri::command]
pub async fn get_graph(state: State<'_, AppState>, scope: GraphScope) -> ApiResult<Graph> {
    load(&state, &scope).await
}

#[tauri::command]
pub async fn export_graph(app: AppHandle, state: State<'_, AppState>, scope: GraphScope, format: String) -> ApiResult<Option<String>> {
    let graph = load(&state, &scope).await?;
    let (ext, filter, body) = match format.as_str() {
        "json" => ("json", "JSON", export::to_json(&graph)),
        "graphml" => ("graphml", "GraphML", export::to_graphml(&graph)),
        "gexf" => ("gexf", "GEXF (Gephi)", export::to_gexf(&graph)),
        _ => return Err(ApiError::invalid("формат: json, graphml или gexf")),
    };
    let name = format!("sword-osint-graph-{}.{ext}", chrono::Utc::now().format("%Y%m%d-%H%M"));
    let Some(path) = save_dialog(&app, "Экспорт графа", &name, filter, &[ext]).await? else { return Ok(None) };
    std::fs::write(&path, body)?;
    let p = path.display().to_string();
    let db = state.db.clone();
    let p2 = p.clone();
    blocking(move || db.record_export("graph", &p2)).await?;
    Ok(Some(p))
}

/// Save a PNG snapshot of the 3D view (`data:image/png;base64,…`).
#[tauri::command]
pub async fn save_image(app: AppHandle, state: State<'_, AppState>, data_url: String, suggested_name: String) -> ApiResult<Option<String>> {
    let b64 = data_url.strip_prefix("data:image/png;base64,").ok_or_else(|| ApiError::invalid("ожидается PNG в формате data URL"))?;
    let bytes = STANDARD.decode(b64.trim()).map_err(|e| ApiError::invalid(format!("base64: {e}")))?;
    if bytes.len() < 8 || &bytes[..8] != b"\x89PNG\r\n\x1a\n" {
        return Err(ApiError::invalid("данные не являются PNG"));
    }
    let Some(path) = save_dialog(&app, "Сохранить изображение", &suggested_name, "PNG", &["png"]).await? else { return Ok(None) };
    std::fs::write(&path, bytes)?;
    let p = path.display().to_string();
    let db = state.db.clone();
    let p2 = p.clone();
    blocking(move || db.record_export("image", &p2)).await?;
    Ok(Some(p))
}
