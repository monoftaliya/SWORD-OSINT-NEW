//! Classification of the analyst's query.
//!
//! The Discovery Engine routes a query only to adapters that can process its type:
//! a DNS adapter needs a domain, VK resolves screen names, Telegram works with public
//! channel usernames, web search engines accept free text, and so on.

use std::net::IpAddr;
use std::sync::LazyLock;

use regex::Regex;
use serde::{Deserialize, Serialize};
use url::Url;

use crate::error::{SwordError, SwordResult};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum InputKind {
    Domain,
    Url,
    Email,
    Ip,
    VkRef,
    TelegramRef,
    Text,
}

impl InputKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            InputKind::Domain => "domain",
            InputKind::Url => "url",
            InputKind::Email => "email",
            InputKind::Ip => "ip",
            InputKind::VkRef => "vk_ref",
            InputKind::TelegramRef => "telegram_ref",
            InputKind::Text => "text",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "domain" => InputKind::Domain,
            "url" => InputKind::Url,
            "email" => InputKind::Email,
            "ip" => InputKind::Ip,
            "vk_ref" => InputKind::VkRef,
            "telegram_ref" => InputKind::TelegramRef,
            "text" => InputKind::Text,
            _ => return None,
        })
    }

    pub fn label_ru(&self) -> &'static str {
        match self {
            InputKind::Domain => "домен",
            InputKind::Url => "URL",
            InputKind::Email => "e-mail",
            InputKind::Ip => "IP-адрес",
            InputKind::VkRef => "ссылка VK",
            InputKind::TelegramRef => "публичный канал Telegram",
            InputKind::Text => "текстовый запрос / организация",
        }
    }
}

/// Normalised representation of the query.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ClassifiedInput {
    pub raw: String,
    pub kind: InputKind,
    /// Text suitable for full-text search engines.
    pub text: String,
    /// ASCII (punycode) host name for domain/URL/e-mail inputs.
    pub domain: Option<String>,
    /// Registrable domain (eTLD+1) of `domain`, from the Public Suffix List.
    pub registrable_domain: Option<String>,
    pub url: Option<String>,
    pub email: Option<String>,
    pub ip: Option<String>,
    /// VK screen name or Telegram username (without `@`).
    pub handle: Option<String>,
    /// Extra free-text part after a handle: `@channel keyword` searches inside the channel.
    pub handle_query: Option<String>,
}

static EMAIL_RE: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"(?i)^[a-z0-9._%+\-]{1,64}@([a-z0-9\-\p{L}]+(\.[a-z0-9\-\p{L}]+)+)$").unwrap());
static DOMAIN_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r"(?i)^(?:[a-z0-9\p{L}](?:[a-z0-9\-\p{L}]{0,61}[a-z0-9\p{L}])?\.)+(?:[a-z\p{L}]{2,63}|xn--[a-z0-9\-]{2,59})\.?$")
        .unwrap()
});
static TG_URL_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r"(?i)^(?:https?://)?(?:www\.)?(?:t|telegram)\.me/(?:s/)?([a-z][a-z0-9_]{3,31})/?(?:\?.*)?$").unwrap()
});
static TG_HANDLE_RE: LazyLock<Regex> =
    LazyLock::new(|| Regex::new(r"(?i)^@([a-z][a-z0-9_]{3,31})(?:\s+(.+))?$").unwrap());
static VK_URL_RE: LazyLock<Regex> = LazyLock::new(|| {
    Regex::new(r"(?i)^(?:https?://)?(?:www\.|m\.)?vk\.(?:com|ru)/([a-z0-9_.]{2,64})/?(?:\?.*)?$").unwrap()
});

/// Classify a raw query.
pub fn classify(raw: &str) -> SwordResult<ClassifiedInput> {
    let trimmed = raw.trim();
    if trimmed.is_empty() {
        return Err(SwordError::InvalidInput("пустой запрос".into()));
    }
    if trimmed.chars().count() > 512 {
        return Err(SwordError::InvalidInput("запрос длиннее 512 символов".into()));
    }

    let mut out = ClassifiedInput {
        raw: trimmed.to_string(),
        kind: InputKind::Text,
        text: trimmed.to_string(),
        domain: None,
        registrable_domain: None,
        url: None,
        email: None,
        ip: None,
        handle: None,
        handle_query: None,
    };

    // Telegram: @channel [query] or t.me/channel
    if let Some(c) = TG_HANDLE_RE.captures(trimmed) {
        out.kind = InputKind::TelegramRef;
        out.handle = Some(c[1].to_lowercase());
        out.handle_query = c.get(2).map(|m| m.as_str().trim().to_string()).filter(|s| !s.is_empty());
        out.text = out.handle_query.clone().unwrap_or_else(|| c[1].to_string());
        return Ok(out);
    }
    if let Some(c) = TG_URL_RE.captures(trimmed) {
        out.kind = InputKind::TelegramRef;
        out.handle = Some(c[1].to_lowercase());
        out.text = c[1].to_string();
        return Ok(out);
    }

    // VK: vk.com/screen_name
    if let Some(c) = VK_URL_RE.captures(trimmed) {
        let name = c[1].to_lowercase();
        out.kind = InputKind::VkRef;
        out.text = name.clone();
        out.handle = Some(name);
        out.url = Some(format!("https://vk.com/{}", out.handle.as_deref().unwrap_or_default()));
        return Ok(out);
    }

    // IP address
    if let Ok(ip) = trimmed.parse::<IpAddr>() {
        out.kind = InputKind::Ip;
        out.ip = Some(ip.to_string());
        return Ok(out);
    }

    // E-mail
    if EMAIL_RE.is_match(trimmed) {
        let lower = trimmed.to_lowercase();
        let (_, domain_part) = lower.rsplit_once('@').unwrap_or(("", ""));
        let host = ascii_host(domain_part).ok_or_else(|| SwordError::InvalidInput("некорректный домен e-mail".into()))?;
        out.kind = InputKind::Email;
        out.email = Some(lower.clone());
        out.registrable_domain = registrable(&host);
        out.domain = Some(host.clone());
        out.text = host;
        return Ok(out);
    }

    // URL with scheme
    if trimmed.starts_with("http://") || trimmed.starts_with("https://") {
        let url = Url::parse(trimmed).map_err(|e| SwordError::InvalidInput(format!("URL: {e}")))?;
        let host = url
            .host_str()
            .map(|h| h.trim_end_matches('.').to_lowercase())
            .ok_or_else(|| SwordError::InvalidInput("в URL нет хоста".into()))?;
        if let Ok(ip) = host.trim_matches(|c| c == '[' || c == ']').parse::<IpAddr>() {
            out.ip = Some(ip.to_string());
        }
        out.kind = InputKind::Url;
        out.url = Some(url.to_string());
        out.registrable_domain = registrable(&host);
        out.text = out.registrable_domain.clone().unwrap_or_else(|| host.clone());
        out.domain = Some(host);
        return Ok(out);
    }

    // Bare domain (no spaces)
    if !trimmed.contains(char::is_whitespace) && DOMAIN_RE.is_match(trimmed) {
        if let Some(host) = ascii_host(trimmed) {
            // Must end in a known public suffix to count as a domain (rejects "notes.draft").
            let known_suffix = psl::suffix(host.as_bytes()).map(|s| s.is_known()).unwrap_or(false);
            if known_suffix && psl::suffix_str(&host).map(|s| s != host).unwrap_or(false) && registrable(&host).is_some() {
                out.kind = InputKind::Domain;
                out.registrable_domain = registrable(&host);
                out.url = Some(format!("https://{host}/"));
                out.text = host.clone();
                out.domain = Some(host);
                return Ok(out);
            }
        }
    }

    Ok(out)
}

/// Convert a (possibly internationalised) host to lowercase ASCII via the URL parser.
pub fn ascii_host(host: &str) -> Option<String> {
    let h = host.trim().trim_end_matches('.');
    let url = Url::parse(&format!("http://{h}/")).ok()?;
    url.host_str().map(|s| s.to_lowercase())
}

/// eTLD+1 of an ASCII host according to the Public Suffix List.
pub fn registrable(host: &str) -> Option<String> {
    psl::domain_str(host.trim_end_matches('.')).map(|s| s.to_lowercase())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn classifies_domains_and_urls() {
        let d = classify("Example.COM").unwrap();
        assert_eq!(d.kind, InputKind::Domain);
        assert_eq!(d.domain.as_deref(), Some("example.com"));
        let u = classify("https://sub.example.co.uk/path?x=1").unwrap();
        assert_eq!(u.kind, InputKind::Url);
        assert_eq!(u.registrable_domain.as_deref(), Some("example.co.uk"));
        let idn = classify("пример.рф").unwrap();
        assert_eq!(idn.kind, InputKind::Domain);
        assert!(idn.domain.unwrap().starts_with("xn--"));
    }

    #[test]
    fn classifies_handles_and_emails() {
        assert_eq!(classify("@durov").unwrap().kind, InputKind::TelegramRef);
        let q = classify("@telegram новости").unwrap();
        assert_eq!(q.handle_query.as_deref(), Some("новости"));
        assert_eq!(classify("https://t.me/s/telegram").unwrap().handle.as_deref(), Some("telegram"));
        assert_eq!(classify("vk.com/team").unwrap().kind, InputKind::VkRef);
        let e = classify("Security@Example.org").unwrap();
        assert_eq!(e.kind, InputKind::Email);
        assert_eq!(e.domain.as_deref(), Some("example.org"));
        assert_eq!(classify("8.8.8.8").unwrap().kind, InputKind::Ip);
    }

    #[test]
    fn falls_back_to_text() {
        assert_eq!(classify("Сбербанк России").unwrap().kind, InputKind::Text);
        assert_eq!(classify("notes.notarealtld").unwrap().kind, InputKind::Text);
        assert!(classify("   ").is_err());
    }
}
