//! Bridges engine events to the WebView (`sword://investigation`).

use sword_core::{EventSink, InvestigationEvent};
use tauri::{AppHandle, Emitter};

pub const INVESTIGATION_EVENT: &str = "sword://investigation";

pub struct TauriSink {
    app: AppHandle,
}

impl TauriSink {
    pub fn new(app: AppHandle) -> Self {
        TauriSink { app }
    }
}

impl EventSink for TauriSink {
    fn emit(&self, event: InvestigationEvent) {
        if let Err(e) = self.app.emit(INVESTIGATION_EVENT, &event) {
            tracing::warn!(error = %e, "failed to emit investigation event");
        }
    }
}
