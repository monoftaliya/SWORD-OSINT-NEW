import './app.css';
import { mount } from 'svelte';
import { getCurrentWindow } from '@tauri-apps/api/window';
import App from './App.svelte';
import { desktop } from './lib/api/client';

const target = document.getElementById('app');
if (!target) throw new Error('#app not found');

const app = mount(App, { target });

if (desktop()) {
  // The window is created hidden (no white flash); reveal it once the first frame is painted.
  requestAnimationFrame(() =>
    requestAnimationFrame(() => {
      const w = getCurrentWindow();
      w.show()
        .then(() => w.setFocus())
        .catch(() => {});
    }),
  );
}

if (import.meta.env.PROD) {
  // Desktop behaviour: no browser context menu (except in text fields) and no page reload,
  // which would drop the live state of running investigations.
  document.addEventListener('contextmenu', (e) => {
    const t = e.target as HTMLElement | null;
    if (!t?.closest('input, textarea, [contenteditable="true"]')) e.preventDefault();
  });
  document.addEventListener('keydown', (e) => {
    const reload = e.key === 'F5' || ((e.ctrlKey || e.metaKey) && (e.key === 'r' || e.key === 'R'));
    const print = (e.ctrlKey || e.metaKey) && (e.key === 'p' || e.key === 'P');
    if (reload || print) e.preventDefault();
  });
}

export default app;
