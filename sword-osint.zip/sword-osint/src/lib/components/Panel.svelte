<!-- Glass panel: eyebrow title, optional subtitle and header actions, scrollable body. -->
<script lang="ts">
  import type { Snippet } from 'svelte';

  let {
    title,
    subtitle = '',
    actions,
    children,
    footer,
    class: klass = '',
    scroll = true,
    pad = true,
    style = '',
  }: {
    title: string;
    subtitle?: string;
    actions?: Snippet;
    children: Snippet;
    footer?: Snippet;
    class?: string;
    scroll?: boolean;
    pad?: boolean;
    style?: string;
  } = $props();
</script>

<section class="panel glass {klass}" {style}>
  <header>
    <div class="titles">
      <span class="eyebrow">{title}</span>
      {#if subtitle}<span class="sub">{subtitle}</span>{/if}
    </div>
    {#if actions}<div class="actions">{@render actions()}</div>{/if}
  </header>
  <div class="body" class:scroll class:pad>{@render children()}</div>
  {#if footer}<footer>{@render footer()}</footer>{/if}
</section>

<style>
  .panel {
    display: flex;
    flex-direction: column;
    min-height: 0;
    min-width: 0;
    overflow: hidden;
  }
  header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 12px 12px 10px 16px;
    border-bottom: 1px solid var(--line);
    flex: none;
    min-height: 46px;
  }
  .titles {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }
  .sub {
    font-size: 11.5px;
    color: var(--fg-3);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .actions {
    display: flex;
    align-items: center;
    gap: 6px;
    flex: none;
  }
  .body {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
  }
  .body.scroll {
    overflow: auto;
  }
  .body.pad {
    padding: 12px 16px 16px;
  }
  footer {
    flex: none;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 12px;
    border-top: 1px solid var(--line);
  }
</style>
