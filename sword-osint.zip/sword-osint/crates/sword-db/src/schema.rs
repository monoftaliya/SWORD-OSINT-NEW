//! Versioned schema migrations (tracked with `PRAGMA user_version`).

use rusqlite::Connection;

/// Ordered list of migrations. Index + 1 is the schema version.
const MIGRATIONS: &[&str] = &[
    // v1 — initial schema
    r#"
    CREATE TABLE investigations (
        id           TEXT PRIMARY KEY,
        kind         TEXT NOT NULL,
        query        TEXT NOT NULL,
        input_kind   TEXT NOT NULL,
        categories   TEXT NOT NULL DEFAULT '[]',
        status       TEXT NOT NULL,
        created_at   TEXT NOT NULL,
        finished_at  TEXT,
        duration_ms  INTEGER,
        result_count INTEGER NOT NULL DEFAULT 0,
        source_count INTEGER NOT NULL DEFAULT 0,
        node_count   INTEGER NOT NULL DEFAULT 0,
        edge_count   INTEGER NOT NULL DEFAULT 0,
        adapters     TEXT NOT NULL DEFAULT '[]',
        summary      TEXT NOT NULL DEFAULT '',
        key_facts    TEXT NOT NULL DEFAULT '[]',
        limitations  TEXT NOT NULL DEFAULT '[]',
        error        TEXT,
        notes        TEXT NOT NULL DEFAULT ''
    );
    CREATE INDEX idx_investigations_created ON investigations(created_at DESC);
    CREATE INDEX idx_investigations_status ON investigations(status);

    CREATE VIRTUAL TABLE investigations_fts USING fts5(
        query, summary, notes,
        content='investigations', content_rowid='rowid',
        tokenize='unicode61 remove_diacritics 2'
    );
    CREATE TRIGGER investigations_ai AFTER INSERT ON investigations BEGIN
        INSERT INTO investigations_fts(rowid, query, summary, notes) VALUES (new.rowid, new.query, new.summary, new.notes);
    END;
    CREATE TRIGGER investigations_ad AFTER DELETE ON investigations BEGIN
        INSERT INTO investigations_fts(investigations_fts, rowid, query, summary, notes) VALUES ('delete', old.rowid, old.query, old.summary, old.notes);
    END;
    CREATE TRIGGER investigations_au AFTER UPDATE ON investigations BEGIN
        INSERT INTO investigations_fts(investigations_fts, rowid, query, summary, notes) VALUES ('delete', old.rowid, old.query, old.summary, old.notes);
        INSERT INTO investigations_fts(rowid, query, summary, notes) VALUES (new.rowid, new.query, new.summary, new.notes);
    END;

    CREATE TABLE adapter_runs (
        investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
        adapter_id       TEXT NOT NULL,
        adapter_name     TEXT NOT NULL,
        status           TEXT NOT NULL,
        started_at       TEXT,
        finished_at      TEXT,
        duration_ms      INTEGER,
        result_count     INTEGER NOT NULL DEFAULT 0,
        error_kind       TEXT,
        message          TEXT,
        PRIMARY KEY (investigation_id, adapter_id)
    );
    CREATE INDEX idx_adapter_runs_adapter ON adapter_runs(adapter_id);

    CREATE TABLE findings (
        id               TEXT PRIMARY KEY,
        investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
        adapter_id       TEXT NOT NULL,
        category         TEXT NOT NULL,
        kind             TEXT NOT NULL,
        title            TEXT NOT NULL,
        url              TEXT,
        snippet          TEXT,
        published_at     TEXT,
        retrieved_at     TEXT NOT NULL,
        confidence       REAL NOT NULL,
        severity         TEXT,
        attributes       TEXT NOT NULL DEFAULT '[]',
        entity_key       TEXT
    );
    CREATE INDEX idx_findings_investigation ON findings(investigation_id);
    CREATE INDEX idx_findings_adapter ON findings(adapter_id);

    CREATE VIRTUAL TABLE findings_fts USING fts5(
        title, snippet, url,
        content='findings', content_rowid='rowid',
        tokenize='unicode61 remove_diacritics 2'
    );
    CREATE TRIGGER findings_ai AFTER INSERT ON findings BEGIN
        INSERT INTO findings_fts(rowid, title, snippet, url) VALUES (new.rowid, new.title, coalesce(new.snippet, ''), coalesce(new.url, ''));
    END;
    CREATE TRIGGER findings_ad AFTER DELETE ON findings BEGIN
        INSERT INTO findings_fts(findings_fts, rowid, title, snippet, url) VALUES ('delete', old.rowid, old.title, coalesce(old.snippet, ''), coalesce(old.url, ''));
    END;

    CREATE TABLE sources (
        investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
        url              TEXT NOT NULL,
        title            TEXT NOT NULL DEFAULT '',
        adapter_id       TEXT NOT NULL,
        retrieved_at     TEXT NOT NULL,
        PRIMARY KEY (investigation_id, url)
    );

    CREATE TABLE graph_nodes (
        investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
        key              TEXT NOT NULL,
        kind             TEXT NOT NULL,
        label            TEXT NOT NULL,
        attributes       TEXT NOT NULL DEFAULT '[]',
        sources          TEXT NOT NULL DEFAULT '[]',
        PRIMARY KEY (investigation_id, key)
    );

    CREATE TABLE graph_edges (
        investigation_id TEXT NOT NULL REFERENCES investigations(id) ON DELETE CASCADE,
        id               TEXT NOT NULL,
        from_key         TEXT NOT NULL,
        to_key           TEXT NOT NULL,
        relation         TEXT NOT NULL,
        confidence       REAL NOT NULL,
        evidence         TEXT NOT NULL DEFAULT '[]',
        PRIMARY KEY (investigation_id, id)
    );

    CREATE TABLE settings (
        key        TEXT PRIMARY KEY,
        value      TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );

    CREATE TABLE assets (
        id                 TEXT PRIMARY KEY,
        kind               TEXT NOT NULL,
        display            TEXT NOT NULL,
        value_hash         TEXT NOT NULL,
        plain_value        TEXT,
        attested           INTEGER NOT NULL DEFAULT 0,
        verified           INTEGER NOT NULL DEFAULT 0,
        verification_token TEXT,
        created_at         TEXT NOT NULL,
        verified_at        TEXT,
        UNIQUE (kind, value_hash)
    );

    CREATE TABLE connector_status (
        adapter_id      TEXT PRIMARY KEY,
        health          TEXT NOT NULL,
        message         TEXT NOT NULL DEFAULT '',
        checked_at      TEXT,
        last_success_at TEXT,
        latency_ms      INTEGER,
        permissions     TEXT NOT NULL DEFAULT '[]'
    );

    CREATE TABLE credential_meta (
        key         TEXT PRIMARY KEY,
        updated_at  TEXT NOT NULL,
        fingerprint TEXT NOT NULL
    );

    CREATE TABLE metrics (
        id     INTEGER PRIMARY KEY AUTOINCREMENT,
        ts     TEXT NOT NULL,
        name   TEXT NOT NULL,
        value  REAL NOT NULL,
        labels TEXT
    );
    CREATE INDEX idx_metrics_name_ts ON metrics(name, ts);

    CREATE TABLE reports (
        id               TEXT PRIMARY KEY,
        investigation_id TEXT REFERENCES investigations(id) ON DELETE SET NULL,
        title            TEXT NOT NULL,
        created_at       TEXT NOT NULL,
        path             TEXT NOT NULL,
        pages            INTEGER NOT NULL DEFAULT 0,
        bytes            INTEGER NOT NULL DEFAULT 0,
        duration_ms      INTEGER NOT NULL DEFAULT 0,
        options          TEXT NOT NULL DEFAULT '{}'
    );
    CREATE INDEX idx_reports_investigation ON reports(investigation_id);

    CREATE TABLE report_drafts (
        investigation_id TEXT PRIMARY KEY REFERENCES investigations(id) ON DELETE CASCADE,
        options          TEXT NOT NULL,
        updated_at       TEXT NOT NULL
    );

    CREATE TABLE exports (
        id         TEXT PRIMARY KEY,
        created_at TEXT NOT NULL,
        kind       TEXT NOT NULL,
        path       TEXT NOT NULL
    );
    "#,
];

pub const SCHEMA_VERSION: i64 = MIGRATIONS.len() as i64;

/// Apply pending migrations inside a transaction each.
pub fn migrate(conn: &mut Connection) -> rusqlite::Result<i64> {
    let current: i64 = conn.query_row("PRAGMA user_version", [], |r| r.get(0))?;
    for (idx, sql) in MIGRATIONS.iter().enumerate() {
        let version = idx as i64 + 1;
        if version <= current {
            continue;
        }
        let tx = conn.transaction()?;
        tx.execute_batch(sql)?;
        tx.execute_batch(&format!("PRAGMA user_version = {version};"))?;
        tx.commit()?;
        tracing::info!(version, "database migrated");
    }
    conn.query_row("PRAGMA user_version", [], |r| r.get(0))
}
