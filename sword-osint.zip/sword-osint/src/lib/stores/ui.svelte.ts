/**
 * UI state that must survive switching between sections (sections are mounted lazily and
 * unmounted when the user leaves them, so their local state would otherwise be lost).
 */
import type { EntityKind, HistoryQuery } from '../api/types';

class UiStore {
  // DISCOVERY
  discoveryQuery = $state('');
  findingFilter = $state('');
  findingMinConfidence = $state(0);
  selectedFindingId = $state<string | null>(null);

  // NETWORK
  networkMode = $state<'investigation' | 'recent'>('investigation');
  networkRecent = $state(20);
  networkHidden = $state<EntityKind[]>([]);
  networkMinConfidence = $state(0);
  networkShowSources = $state(false);
  /** Entity key the graph should select after opening (from a finding). */
  networkFocusKey = $state<string | null>(null);

  // HISTORY
  history = $state<HistoryQuery>({ sort: 'created_desc', limit: 40, offset: 0 });

  // DATABASES
  databasesTab = $state<'sources' | 'knowledge' | 'storage'>('sources');
  knowledgeText = $state('');

  // ANALYTICS
  analyticsRange = $state(30);

  // SETTINGS
  settingsTab = $state<'connections' | 'network' | 'graphics' | 'privacy' | 'reports' | 'search' | 'about'>('connections');
  /** Adapter card SETTINGS should scroll to. */
  settingsFocusAdapter = $state<string | null>(null);

  // INTELLIGENCE
  auditChecks = $state<string[]>(['email_breaches', 'dns_hygiene', 'web_config', 'tls', 'incidents', 'surface']);
  auditAssets = $state<string[]>([]);
}

export const ui = new UiStore();
