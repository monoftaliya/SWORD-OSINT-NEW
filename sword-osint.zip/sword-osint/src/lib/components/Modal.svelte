<script lang="ts">
  import type { Snippet } from 'svelte';
  import Icon from './Icon.svelte';

  let { open = $bindable(false), title, width = 560, onclose, children, footer }: { open?: boolean; title: string; width?: number; onclose?: () => void; children: Snippet; footer?: Snippet } = $props();

  function close() {
    open = false;
    onclose?.();
  }

  function onkey(e: KeyboardEvent) {
    if (open && e.key === 'Escape') close();
  }
</script>

<svelte:window onkeydown={onkey} />

{#if open}
  <div class="backdrop" role="presentation" onclick={(e) => e.target === e.currentTarget && close()}>
    <div class="modal glass glass-strong" style:width="{width}px" role="dialog" aria-modal="true" aria-label={title}>
      <header>
        <span class="eyebrow">{title}</span>
        <button class="btn ghost sm icon" onclick={close} aria-label="Закрыть"><Icon name="x" size={14} /></button>
      </header>
      <div class="body scroll">{@render children()}</div>
      {#if footer}<footer>{@render footer()}</footer>{/if}
    </div>
  </div>
{/if}

<style>
  .backdrop {
    position: fixed;
    inset: 0;
    z-index: 90;
    display: grid;
    place-items: center;
    background: rgba(0, 0, 0, 0.55);
    backdrop-filter: blur(4px);
    animation: fade 0.25s var(--ease) both;
  }
  @keyframes fade {
    from {
      opacity: 0;
    }
  }
  .modal {
    max-width: calc(100vw - 80px);
    max-height: calc(100vh - 120px);
    display: flex;
    flex-direction: column;
    animation: enter 0.45s var(--ease-out) both;
  }
  header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 14px 14px 10px 20px;
    border-bottom: 1px solid var(--line);
  }
  .body {
    padding: 18px 20px;
  }
  footer {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    padding: 12px 16px;
    border-top: 1px solid var(--line);
  }
</style>
