//! Web configuration of an own domain: HTTPS redirect, security headers, cookie flags,
//! version disclosure, security.txt; and — only for domains whose ownership is proven via
//! DNS TXT — probes for accidentally published files (.git, .env, backups, status pages).

use reqwest::header::HeaderMap;
use sword_connectors::http;
use sword_connectors::output::{FindingExt, OutputBuilder};
use sword_connectors::ConnectorContext;
use sword_core::{keys, AdapterInfo, AdapterOutput, Category, EntityKind, FindingKind, Severity, SwordError, SwordResult};

fn issue(b: &mut OutputBuilder, domain: &str, sev: Severity, title: &str, details: &str, fix: &str, url: &str) {
    b.finding(Category::DomainIntel, FindingKind::AuditIssue, &format!("{domain}: {title}"), Some(url))
        .severity(sev)
        .snippet(details)
        .attr("Рекомендация", fix)
        .entity(&keys::domain(domain));
}

fn header<'a>(h: &'a HeaderMap, name: &str) -> Option<&'a str> {
    h.get(name).and_then(|v| v.to_str().ok())
}

pub async fn check(ctx: &ConnectorContext, info: &AdapterInfo, domain: &str) -> SwordResult<AdapterOutput> {
    let mut b = OutputBuilder::new(info);
    b.entity(&keys::domain(domain), EntityKind::Domain, domain);
    let https_url = format!("https://{domain}/");
    let http_url = format!("http://{domain}/");

    // 1. HTTP → HTTPS redirect
    match ctx.http.send(&info.id, info.rate_limit_per_minute, ctx.http.no_redirect().get(&http_url), &ctx.cancel).await {
        Ok(resp) => {
            let status = resp.status().as_u16();
            let location = header(resp.headers(), "location").unwrap_or_default().to_string();
            if (300..400).contains(&status) && location.starts_with("https://") {
                issue(&mut b, domain, Severity::Pass, "HTTP перенаправляет на HTTPS", &format!("HTTP {status} → {location}"), "—", &http_url);
            } else {
                issue(&mut b, domain, Severity::Medium, "нет перенаправления HTTP → HTTPS", &format!("Ответ на HTTP: {status}"), "Настройте постоянное перенаправление (301/308) на HTTPS.", &http_url);
            }
        }
        Err(SwordError::Cancelled) => return Err(SwordError::Cancelled),
        Err(e) => b.note(format!("HTTP-версия сайта недоступна: {e}")),
    }

    // 2. HTTPS response headers
    let resp = ctx.send(info, ctx.get(&https_url)).await?;
    let final_url = resp.url().to_string();
    let status = resp.status().as_u16();
    let h = resp.headers().clone();
    let cookies: Vec<String> = h.get_all("set-cookie").iter().filter_map(|v| v.to_str().ok().map(str::to_string)).collect();
    drop(resp);
    b.source(&final_url, &format!("HTTPS-ответ {domain}"));
    b.fact("Веб-конфигурация", &format!("{domain}: HTTP {status}, проверены заголовки безопасности"), &final_url);

    match header(&h, "strict-transport-security") {
        None => issue(&mut b, domain, Severity::Medium, "нет HSTS", "Браузер может открыть сайт по HTTP, что делает возможной атаку понижения.", "Добавьте Strict-Transport-Security: max-age=31536000; includeSubDomains.", &final_url),
        Some(v) => {
            let max_age = v.split(';').find_map(|p| p.trim().strip_prefix("max-age=")).and_then(|x| x.trim_matches('"').parse::<u64>().ok()).unwrap_or(0);
            if max_age < 15_552_000 {
                issue(&mut b, domain, Severity::Low, "короткий срок HSTS", &format!("max-age={max_age} (< 180 дней)"), "Увеличьте max-age до 31536000.", &final_url);
            } else {
                issue(&mut b, domain, Severity::Pass, "HSTS включён", v, "—", &final_url);
            }
        }
    }
    let csp = header(&h, "content-security-policy");
    match csp {
        None => issue(&mut b, domain, Severity::Medium, "нет Content-Security-Policy", "CSP ограничивает источники скриптов и снижает ущерб от XSS.", "Внедрите CSP, начиная с режима Content-Security-Policy-Report-Only.", &final_url),
        Some(v) if v.contains("'unsafe-inline'") && v.contains("script-src") => issue(&mut b, domain, Severity::Low, "CSP разрешает 'unsafe-inline' для скриптов", v, "Используйте nonce/hash вместо 'unsafe-inline'.", &final_url),
        Some(v) => issue(&mut b, domain, Severity::Pass, "CSP настроена", v, "—", &final_url),
    }
    let frame_protected = header(&h, "x-frame-options").is_some() || csp.map(|c| c.contains("frame-ancestors")).unwrap_or(false);
    if !frame_protected {
        issue(&mut b, domain, Severity::Low, "нет защиты от встраивания во фрейм", "Без X-Frame-Options или CSP frame-ancestors возможен clickjacking.", "Добавьте X-Frame-Options: DENY или frame-ancestors 'none'.", &final_url);
    }
    if header(&h, "x-content-type-options").map(|v| v.eq_ignore_ascii_case("nosniff")) != Some(true) {
        issue(&mut b, domain, Severity::Low, "нет X-Content-Type-Options: nosniff", "Браузер может «угадывать» тип содержимого.", "Добавьте X-Content-Type-Options: nosniff.", &final_url);
    }
    if header(&h, "referrer-policy").is_none() {
        issue(&mut b, domain, Severity::Low, "нет Referrer-Policy", "Полные URL могут передаваться сторонним сайтам.", "Добавьте Referrer-Policy: strict-origin-when-cross-origin.", &final_url);
    }
    if header(&h, "permissions-policy").is_none() {
        issue(&mut b, domain, Severity::Info, "нет Permissions-Policy", "Не ограничен доступ встроенного контента к камере, микрофону, геолокации.", "Добавьте Permissions-Policy с минимально необходимыми разрешениями.", &final_url);
    }
    for name in ["server", "x-powered-by", "x-aspnet-version", "x-generator"] {
        if let Some(v) = header(&h, name) {
            if v.chars().any(|c| c.is_ascii_digit()) {
                issue(&mut b, domain, Severity::Low, &format!("раскрытие версии ПО ({name})"), &format!("{name}: {v}"), "Скройте номера версий в заголовках ответа.", &final_url);
            }
        }
    }
    let insecure: Vec<String> = cookies
        .iter()
        .filter_map(|c| {
            let lower = c.to_lowercase();
            let name = c.split('=').next().unwrap_or("cookie").trim().to_string();
            let mut missing = Vec::new();
            if !lower.contains("; secure") {
                missing.push("Secure");
            }
            if !lower.contains("httponly") {
                missing.push("HttpOnly");
            }
            if !lower.contains("samesite") {
                missing.push("SameSite");
            }
            (!missing.is_empty()).then(|| format!("{name}: нет {}", missing.join(", ")))
        })
        .collect();
    if !insecure.is_empty() {
        issue(&mut b, domain, Severity::Low, "небезопасные флаги cookie", &insecure.join("\n"), "Устанавливайте Secure, HttpOnly и SameSite для cookie.", &final_url);
    }

    // 3. security.txt
    let sec_url = format!("https://{domain}/.well-known/security.txt");
    match ctx.send(info, ctx.get(&sec_url)).await {
        Ok(r) if r.status().is_success() => {
            let body = http::read_text(r, 64 * 1024).await.unwrap_or_default();
            if body.to_lowercase().contains("contact:") && !body.trim_start().starts_with('<') {
                let expired = body.lines().find_map(|l| {
                    let (k, v) = l.split_once(':')?;
                    k.trim().eq_ignore_ascii_case("expires").then(|| sword_core::util::parse_date(v.trim()))?
                });
                match expired {
                    Some(d) if d < sword_core::util::now() => issue(&mut b, domain, Severity::Low, "security.txt просрочен", &format!("Expires: {}", sword_core::util::fmt_date(&d)), "Обновите поле Expires.", &sec_url),
                    _ => issue(&mut b, domain, Severity::Pass, "security.txt опубликован", "Контакты для сообщений об уязвимостях доступны (RFC 9116).", "—", &sec_url),
                }
            } else {
                issue(&mut b, domain, Severity::Info, "нет security.txt", "Исследователям некуда сообщить об уязвимости.", "Опубликуйте /.well-known/security.txt (RFC 9116).", &sec_url);
            }
        }
        Ok(_) => issue(&mut b, domain, Severity::Info, "нет security.txt", "Исследователям некуда сообщить об уязвимости.", "Опубликуйте /.well-known/security.txt (RFC 9116).", &sec_url),
        Err(SwordError::Cancelled) => return Err(SwordError::Cancelled),
        Err(e) => b.note(format!("security.txt: {e}")),
    }
    Ok(b.finish())
}

/// Probe definition: path, how to recognise a real hit, severity, title.
struct Probe {
    path: &'static str,
    signature: fn(&[u8]) -> bool,
    severity: Severity,
    title: &'static str,
}

fn starts(b: &[u8], p: &[u8]) -> bool {
    b.starts_with(p)
}
fn text_contains(b: &[u8], needles: &[&str]) -> bool {
    let s = String::from_utf8_lossy(&b[..b.len().min(65536)]).to_lowercase();
    needles.iter().any(|n| s.contains(n))
}

const PROBES: &[Probe] = &[
    Probe { path: "/.git/HEAD", signature: |b| starts(b, b"ref: refs/"), severity: Severity::Critical, title: "открыт репозиторий .git" },
    Probe { path: "/.git/config", signature: |b| text_contains(b, &["[core]"]), severity: Severity::Critical, title: "открыт .git/config" },
    Probe {
        path: "/.env",
        signature: |b| !text_contains(b, &["<html", "<!doctype"]) && text_contains(b, &["db_password", "app_key", "secret", "api_key", "database_url", "password="]),
        severity: Severity::Critical,
        title: "опубликован файл .env",
    },
    Probe { path: "/.svn/wc.db", signature: |b| starts(b, b"SQLite format 3"), severity: Severity::High, title: "открыт каталог .svn" },
    Probe { path: "/.DS_Store", signature: |b| b.len() > 8 && &b[4..8] == b"Bud1", severity: Severity::Low, title: "опубликован .DS_Store (раскрывает структуру каталогов)" },
    Probe { path: "/server-status", signature: |b| text_contains(b, &["apache server status"]), severity: Severity::Medium, title: "открыта страница server-status" },
    Probe { path: "/phpinfo.php", signature: |b| text_contains(b, &["phpinfo()", "php version"]), severity: Severity::Medium, title: "открыт phpinfo.php" },
    Probe { path: "/backup.zip", signature: |b| starts(b, b"PK\x03\x04"), severity: Severity::Critical, title: "опубликован архив backup.zip" },
    Probe { path: "/backup.sql", signature: |b| !text_contains(b, &["<html"]) && text_contains(b, &["create table", "insert into"]), severity: Severity::Critical, title: "опубликован дамп backup.sql" },
    Probe { path: "/dump.sql", signature: |b| !text_contains(b, &["<html"]) && text_contains(b, &["create table", "insert into"]), severity: Severity::Critical, title: "опубликован дамп dump.sql" },
    Probe { path: "/wp-config.php.bak", signature: |b| text_contains(b, &["db_password", "db_name"]), severity: Severity::Critical, title: "опубликована копия wp-config.php" },
    Probe { path: "/config.php.bak", signature: |b| text_contains(b, &["<?php", "password"]), severity: Severity::High, title: "опубликована копия config.php" },
];

/// Exposure probes. Refuses to run unless ownership was verified via DNS TXT.
pub async fn exposed_files(ctx: &ConnectorContext, info: &AdapterInfo, domain: &str, verified: bool) -> SwordResult<AdapterOutput> {
    if !verified {
        return Err(SwordError::Forbidden(
            "проверка опубликованных файлов выполняется только для доменов с подтверждённым владением (DNS TXT)".into(),
        ));
    }
    let mut b = OutputBuilder::new(info);
    b.entity(&keys::domain(domain), EntityKind::Domain, domain);
    let base = format!("https://{domain}");
    let mut found = 0;
    for p in PROBES {
        let url = format!("{base}{}", p.path);
        let resp = match ctx.send(info, ctx.http.no_redirect().get(&url)).await {
            Ok(r) => r,
            Err(SwordError::Cancelled) => return Err(SwordError::Cancelled),
            Err(e) => {
                b.note(format!("{}: {e}", p.path));
                continue;
            }
        };
        if !resp.status().is_success() {
            continue;
        }
        let body = http::read_bytes(resp, 128 * 1024).await.unwrap_or_default();
        if (p.signature)(&body) {
            found += 1;
            issue(&mut b, domain, p.severity, p.title, &format!("Ресурс {url} доступен публично и содержит характерную сигнатуру. Содержимое не сохраняется."), "Немедленно закройте доступ к файлу на веб-сервере, удалите его и смените раскрытые секреты.", &url);
        }
    }
    // directory listing on root
    if let Ok(r) = ctx.send(info, ctx.get(&format!("{base}/"))).await {
        let body = http::read_bytes(r, 64 * 1024).await.unwrap_or_default();
        if text_contains(&body, &["<title>index of /"]) {
            found += 1;
            issue(&mut b, domain, Severity::Medium, "включён листинг каталогов", "Корневой каталог отдаёт список файлов.", "Отключите autoindex/Directory listing.", &format!("{base}/"));
        }
    }
    if found == 0 {
        issue(&mut b, domain, Severity::Pass, "типовые чувствительные файлы не опубликованы", &format!("Проверено путей: {}.", PROBES.len() + 1), "—", &base);
    }
    b.fact("Опубликованные файлы", &format!("{domain}: найдено проблем — {found}"), &base);
    Ok(b.finish())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn probe_signatures_reject_soft_404() {
        let html = b"<!doctype html><html><title>Not found</title>password= reset</html>";
        let env_probe = PROBES.iter().find(|p| p.path == "/.env").unwrap();
        assert!(!(env_probe.signature)(html));
        assert!((env_probe.signature)(b"APP_KEY=base64:xxx\nDB_PASSWORD=secret"));
        let git = PROBES.iter().find(|p| p.path == "/.git/HEAD").unwrap();
        assert!((git.signature)(b"ref: refs/heads/main\n"));
        assert!(!(git.signature)(b"<html>"));
    }
}
