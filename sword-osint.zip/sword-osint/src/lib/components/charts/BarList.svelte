<!--
  Ranked horizontal bars with the value at the bar's tip. Hovering a row lifts it and
  shows its share of the total.
-->
<script lang="ts">
  import { fmtNum } from '../../util/format';

  let {
    items,
    limit = 8,
    format = (v: number) => fmtNum(v),
    onselect,
    empty = 'Нет данных за период',
  }: {
    items: { key: string; label: string; value: number; hint?: string }[];
    limit?: number;
    format?: (v: number) => string;
    onselect?: (key: string) => void;
    empty?: string;
  } = $props();

  const shown = $derived([...items].sort((a, b) => b.value - a.value).slice(0, limit));
  const rest = $derived(items.length > limit ? items.length - limit : 0);
  const max = $derived(Math.max(1, ...shown.map((i) => i.value)));
  const total = $derived(items.reduce((s, i) => s + i.value, 0));
</script>

{#if shown.length === 0}
  <div class="nodata">{empty}</div>
{:else}
  <ul class="bars">
    {#each shown as it (it.key)}
      {@const share = total ? Math.round((it.value / total) * 100) : 0}
      <li>
        <button type="button" class="row" class:clickable={!!onselect} title={it.hint ?? it.label} onclick={() => onselect?.(it.key)}>
          <span class="name ellipsis">{it.label}</span>
          <span class="track">
            <span class="bar" style:width="{Math.max(1.5, (it.value / max) * 100)}%"></span>
          </span>
          <span class="value num">{format(it.value)}<span class="share">{share}%</span></span>
        </button>
      </li>
    {/each}
  </ul>
  {#if rest}<div class="more">и ещё {rest}</div>{/if}
{/if}

<style>
  .bars {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .row {
    width: 100%;
    display: grid;
    grid-template-columns: minmax(80px, 38%) 1fr auto;
    align-items: center;
    gap: 10px;
    padding: 5px 6px;
    border: none;
    border-radius: 7px;
    background: transparent;
    color: var(--fg-2);
    font-size: 12px;
    text-align: left;
    cursor: default;
    transition: background 0.15s;
  }
  .row.clickable {
    cursor: pointer;
  }
  .row:hover,
  .row:focus-visible {
    background: rgba(255, 255, 255, 0.04);
    outline: none;
  }
  .track {
    height: 8px;
    position: relative;
  }
  .bar {
    position: absolute;
    left: 0;
    top: 0;
    bottom: 0;
    border-radius: 0 4px 4px 0;
    background: var(--silver);
    opacity: 0.55;
    transition: opacity 0.15s, width 0.5s var(--ease-out);
  }
  .row:hover .bar,
  .row:focus-visible .bar {
    opacity: 0.95;
  }
  .value {
    color: var(--fg);
    font-size: 12px;
    min-width: 44px;
    text-align: right;
    font-variant-numeric: tabular-nums;
  }
  .share {
    display: inline-block;
    width: 0;
    overflow: hidden;
    color: var(--fg-3);
    margin-left: 0;
    transition: width 0.2s, margin 0.2s;
    vertical-align: bottom;
  }
  .row:hover .share,
  .row:focus-visible .share {
    width: 34px;
    margin-left: 6px;
  }
  .nodata,
  .more {
    color: var(--fg-3);
    font-size: 12px;
    padding: 8px 6px;
  }
</style>
