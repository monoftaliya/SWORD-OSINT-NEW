//! Report content: cover and the analytical sections.

use std::collections::{BTreeMap, HashMap};

use sword_core::util::{fmt_date, fmt_datetime, truncate_chars};
use sword_core::{confidence_label, EntityKind, InvestigationKind, RunStatus, Severity};
use sword_graph::layout::layout_2d;

use crate::composer::{mix, Cell, Col, Composer, PageKind};
use crate::theme::Rgb3;
use crate::{ReportData, ReportOptions, SectionId};

/// Deterministic xorshift for the decorative particle field.
struct Rng(u64);

impl Rng {
    fn next(&mut self) -> f32 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.0 = x;
        (x >> 11) as f32 / (1u64 << 53) as f32
    }
}

fn seed(s: &str) -> u64 {
    s.bytes().fold(0x9E37_79B9_7F4A_7C15u64, |h, b| (h ^ b as u64).wrapping_mul(0x100_0000_01B3)) | 1
}

pub fn cover(c: &mut Composer, data: &ReportData, opts: &ReportOptions) {
    c.new_page(PageKind::Cover);
    let t = c.theme.clone();
    let (w, h) = (c.w, c.h);
    c.fill_rect(0.0, 0.0, w, h, t.cover_bg, None);

    // Particle field: a slow spiral galaxy around an off-centre core, echoing the 3D scene.
    let mut rng = Rng(seed(&data.report_id));
    let (cx, cy) = (w * 0.66, h * 0.36);
    let star = if t.cover_dark { (0.86, 0.90, 0.96) } else { (0.36, 0.40, 0.46) };
    let mut pts: Vec<(f32, f32)> = Vec::new();
    for i in 0..900 {
        let ring = rng.next();
        let (x, y, r, a) = if i < 520 {
            let radius = 30.0 + ring.powf(0.7) * w * 0.55;
            let ang = rng.next() * std::f32::consts::TAU + radius * 0.012;
            let squash = 0.42;
            (cx + radius * ang.cos(), cy + radius * ang.sin() * squash, 0.25 + rng.next() * 0.9, 0.15 + rng.next() * 0.55)
        } else {
            (rng.next() * w, rng.next() * h, 0.2 + rng.next() * 0.6, 0.06 + rng.next() * 0.3)
        };
        if y < 0.0 || y > h || x < 0.0 || x > w {
            continue;
        }
        c.circle(x, y, r, star, Some(a));
        if i < 520 && i % 9 == 0 {
            pts.push((x, y));
        }
    }
    for win in pts.windows(2).step_by(2) {
        let (a, b) = (win[0], win[1]);
        let d = ((a.0 - b.0).powi(2) + (a.1 - b.1).powi(2)).sqrt();
        if d < 70.0 {
            c.line(a.0, a.1, b.0, b.1, star, 0.35, Some(0.25));
        }
    }
    c.circle(cx, cy, 2.6, star, Some(0.95));
    c.circle(cx, cy, 9.0, star, Some(0.12));
    c.circle(cx, cy, 22.0, star, Some(0.05));

    let fonts = c.fonts;
    let ml = 56.0;
    // Wordmark
    c.text_spaced(ml, 118.0, &fonts.semibold, 40.0, t.cover_text, "SWORD", 7.0);
    let sx = ml + fonts.semibold.width_spaced("SWORD", 40.0, 7.0) + 10.0;
    c.text_spaced(sx, 118.0, &fonts.light, 40.0, t.cover_muted, "OSINT", 7.0);
    c.text_spaced(ml, 140.0, &fonts.medium, 7.5, t.cover_muted, "DESKTOP INTELLIGENCE PLATFORM", 2.4);

    // Title block
    let kind = match data.record.kind {
        InvestigationKind::Discovery => "Аналитический отчёт",
        InvestigationKind::ExposureAudit => "Отчёт об аудите цифровой безопасности",
    };
    let title = opts.title.clone().filter(|s| !s.trim().is_empty()).unwrap_or_else(|| kind.to_string());
    let mut y = h * 0.60;
    c.text_spaced(ml, y, &fonts.medium, 7.5, t.cover_muted, "ОТЧЁТ", 2.2);
    y += 30.0;
    for line in c.wrap(&title, &fonts.light, 26.0, w - ml * 2.0).into_iter().take(3) {
        c.text(ml, y, &fonts.light, 26.0, t.cover_text, &line);
        y += 32.0;
    }
    y += 6.0;
    c.text_spaced(ml, y, &fonts.medium, 7.5, t.cover_muted, "ИСХОДНЫЙ ЗАПРОС", 2.2);
    y += 18.0;
    for line in c.wrap(&data.record.query, &fonts.mono, 11.0, w - ml * 2.0).into_iter().take(3) {
        c.text(ml, y, &fonts.mono, 11.0, t.cover_text, &line);
        y += 16.0;
    }

    // Meta grid
    let rule = mix(t.cover_bg, t.cover_muted, 0.35);
    let gy = h - 168.0;
    c.line(ml, gy, w - ml, gy, rule, 0.5, None);
    let cells: Vec<(&str, String)> = vec![
        ("ID отчёта", data.report_id.clone()),
        ("Дата формирования", fmt_datetime(&data.generated_at)),
        ("Статус исследования", data.record.status.label_ru().to_string()),
        ("Результатов / источников", format!("{} / {}", data.record.result_count, data.record.source_count)),
        ("Подготовил", if opts.author.trim().is_empty() { "—".into() } else { opts.author.clone() }),
        ("Организация", if opts.organization.trim().is_empty() { "—".into() } else { opts.organization.clone() }),
    ];
    let col_w = (w - ml * 2.0) / 3.0;
    for (i, (label, value)) in cells.iter().enumerate() {
        let x = ml + (i % 3) as f32 * col_w;
        let yy = gy + 22.0 + (i / 3) as f32 * 38.0;
        c.text_spaced(x, yy, &fonts.medium, 6.5, t.cover_muted, &label.to_uppercase(), 1.4);
        let v = truncate_chars(value, 34);
        let f = if *label == "ID отчёта" { &fonts.mono } else { &fonts.regular };
        c.text(x, yy + 15.0, f, 10.0, t.cover_text, &v);
    }
    if !opts.classification.trim().is_empty() {
        let label = opts.classification.to_uppercase();
        let lw = fonts.medium.width_spaced(&label, 7.0, 1.6) + 20.0;
        c.stroke_rect(ml, h - 64.0, lw, 18.0, t.cover_muted, 0.6);
        c.text_spaced(ml + 10.0, h - 51.5, &fonts.medium, 7.0, t.cover_text, &label, 1.6);
    }
    c.text_right(w - ml, h - 51.5, &fonts.regular, 7.5, t.cover_muted, "Только публичные источники · без выдуманных данных");
}

fn status_label(s: RunStatus) -> &'static str {
    match s {
        RunStatus::Done => "выполнен",
        RunStatus::Failed => "ошибка",
        RunStatus::Skipped => "не применялся",
        RunStatus::Cancelled => "отменён",
        RunStatus::TimedOut => "тайм-аут",
        RunStatus::Queued | RunStatus::Running => "не завершён",
    }
}

fn section_note(c: &mut Composer, opts: &ReportOptions, id: SectionId) {
    if let Some(note) = opts.notes.get(id.as_str()).filter(|n| !n.trim().is_empty()) {
        c.space(4.0);
        c.callout("Заметка аналитика", note);
    }
}

pub fn query(c: &mut Composer, n: usize, d: &ReportData, opts: &ReportOptions) {
    c.heading(n, "Исходный запрос");
    let r = &d.record;
    let cats = r.categories.iter().map(|c| c.title()).collect::<Vec<_>>().join(", ");
    let rows = vec![
        ("Запрос".to_string(), r.query.clone()),
        ("Тип запроса".to_string(), r.input_kind.label_ru().to_string()),
        ("Вид исследования".to_string(), match r.kind { InvestigationKind::Discovery => "Discovery — поиск по публичным источникам".to_string(), InvestigationKind::ExposureAudit => "Аудит собственных активов".to_string() }),
        ("Категории".to_string(), if cats.is_empty() { "—".into() } else { cats }),
        ("ID исследования".to_string(), r.id.clone()),
        ("Начало".to_string(), fmt_datetime(&r.created_at)),
        ("Завершение".to_string(), r.finished_at.map(|f| fmt_datetime(&f)).unwrap_or_else(|| "—".into())),
        ("Длительность".to_string(), r.duration_ms.map(|ms| format!("{:.1} с", ms as f64 / 1000.0)).unwrap_or_else(|| "—".into())),
        ("Статус".to_string(), r.status.label_ru().to_string()),
    ];
    c.kv(&rows);
    section_note(c, opts, SectionId::Query);
}

pub fn methodology(c: &mut Composer, n: usize, d: &ReportData, opts: &ReportOptions) {
    c.heading(n, "Методология исследования");
    c.body(
        "Сведения получены автоматизированно из официальных API и официально опубликованных публичных интерфейсов. \
         Каждый результат хранит ссылку на первоисточник и время получения. Связи между объектами строятся только \
         из структурированных утверждений источников (реестры, DNS, журналы сертификатов, базы знаний, \
         самозаявленные ссылки) — упоминания в тексте связями не считаются. Запросы выполнялись с ограничением \
         частоты для каждого источника; авторизация, CAPTCHA и ограничения платформ не обходились.",
    );
    c.space(8.0);
    c.subheading("Шкала достоверности связей", None);
    c.bullets(
        &[
            "≥ 0,95 — подтверждено: регистрационные данные, DNS, журналы Certificate Transparency, официальные реестры (GLEIF).".to_string(),
            "0,80–0,94 — высокая: структурированные базы знаний (Wikidata, OpenAlex) и самозаявленные ссылки владельца ресурса.".to_string(),
            "0,60–0,79 — средняя; < 0,60 — низкая (в графе не используется по умолчанию).".to_string(),
        ],
        None,
    );
    c.space(4.0);
    c.subheading("Задействованные источники", None);
    let used: Vec<&sword_core::AdapterRun> = d.runs.iter().filter(|r| r.status != RunStatus::Skipped).collect();
    let mut items = Vec::new();
    for r in &used {
        let base = r.adapter_id.split('#').next().unwrap_or(&r.adapter_id);
        match d.adapters.iter().find(|a| a.id == base) {
            Some(info) => items.push(format!("{} ({}). {}", info.name, info.provider, info.methodology)),
            None => items.push(r.adapter_name.clone()),
        }
    }
    items.dedup();
    if items.is_empty() {
        c.muted("Ни один источник не был опрошен.");
    } else {
        c.bullets(&items, None);
    }
    section_note(c, opts, SectionId::Methodology);
}

pub fn sources(c: &mut Composer, n: usize, d: &ReportData, opts: &ReportOptions) {
    c.heading(n, "Список проверенных источников");
    let done = d.runs.iter().filter(|r| r.status == RunStatus::Done).count();
    c.muted(&format!("Запланировано источников: {}; успешно опрошено: {done}.", d.runs.len()));
    c.space(6.0);
    let cols = [
        Col { title: "Источник".into(), frac: 0.30, mono: false },
        Col { title: "Статус".into(), frac: 0.14, mono: false },
        Col { title: "Результатов".into(), frac: 0.12, mono: false },
        Col { title: "Время".into(), frac: 0.10, mono: false },
        Col { title: "Комментарий".into(), frac: 0.34, mono: false },
    ];
    let t = c.theme.clone();
    let rows: Vec<Vec<Cell>> = d
        .runs
        .iter()
        .map(|r| {
            let color = match r.status {
                RunStatus::Done => t.text,
                RunStatus::Failed | RunStatus::TimedOut => t.severity_color(Severity::High),
                _ => t.muted,
            };
            vec![
                Cell::new(r.adapter_name.clone()).bold(),
                Cell::new(status_label(r.status)).color(color),
                Cell::new(if r.status == RunStatus::Done { r.result_count.to_string() } else { "—".into() }),
                Cell::new(r.duration_ms.map(|ms| format!("{:.1} с", ms as f64 / 1000.0)).unwrap_or_else(|| "—".into())),
                Cell::new(r.message.clone().unwrap_or_default()).color(t.muted),
            ]
        })
        .collect();
    c.table(&cols, &rows, 8.4);
    section_note(c, opts, SectionId::Sources);
}

pub fn findings(c: &mut Composer, n: usize, d: &ReportData, opts: &ReportOptions) {
    c.heading(n, "Найденные результаты");
    if d.findings.is_empty() {
        c.muted("Источники не вернули результатов по запросу.");
        section_note(c, opts, SectionId::Findings);
        return;
    }
    let names: HashMap<&str, &str> = d.adapters.iter().map(|a| (a.id.as_str(), a.name.as_str())).collect();
    let mut groups: BTreeMap<&str, Vec<&sword_core::Finding>> = BTreeMap::new();
    for f in &d.findings {
        groups.entry(f.category.label_ru()).or_default().push(f);
    }
    let audit = d.record.kind == InvestigationKind::ExposureAudit;
    let t = c.theme.clone();
    let limit = opts.max_findings_per_category.max(1) as usize;
    for (cat, items) in groups {
        c.subheading(cat, Some(&format!("{} результатов", items.len())));
        let cols = if audit {
            vec![
                Col { title: "Уровень".into(), frac: 0.12, mono: false },
                Col { title: "Проверка".into(), frac: 0.68, mono: false },
                Col { title: "Модуль".into(), frac: 0.20, mono: false },
            ]
        } else {
            vec![
                Col { title: "#".into(), frac: 0.05, mono: false },
                Col { title: "Результат".into(), frac: 0.55, mono: false },
                Col { title: "Тип".into(), frac: 0.14, mono: false },
                Col { title: "Источник".into(), frac: 0.14, mono: false },
                Col { title: "Достов.".into(), frac: 0.12, mono: false },
            ]
        };
        let mut rows = Vec::new();
        for (i, f) in items.iter().take(limit).enumerate() {
            let base = f.adapter_id.split('#').next().unwrap_or(&f.adapter_id);
            let src = names.get(base).copied().unwrap_or(base).to_string();
            let mut sub = f.snippet.clone().map(|s| truncate_chars(&s, 280)).unwrap_or_default();
            if let Some(url) = &f.url {
                sub = if sub.is_empty() { truncate_chars(url, 120) } else { format!("{sub}\n{}", truncate_chars(url, 120)) };
            }
            if let Some(p) = f.published_at {
                sub = format!("{sub}\nДата: {}", fmt_date(&p));
            }
            if audit {
                let sev = f.severity.unwrap_or(Severity::Info);
                rows.push(vec![
                    Cell::new(sev.label_ru()).color(t.severity_color(sev)).bold(),
                    Cell::new(f.title.clone()).sub(sub).link(f.url.clone()),
                    Cell::new(src).color(t.muted),
                ]);
            } else {
                rows.push(vec![
                    Cell::new((i + 1).to_string()).color(t.muted),
                    Cell::new(f.title.clone()).sub(sub).link(f.url.clone()),
                    Cell::new(f.kind.label_ru()),
                    Cell::new(src),
                    Cell::new(format!("{:.2}", f.confidence)).sub(confidence_label(f.confidence)),
                ]);
            }
        }
        c.table(&cols, &rows, 8.2);
        if items.len() > limit {
            c.muted(&format!("Показано {limit} из {}. Полный перечень — в SWORD OSINT (HISTORY) и в экспорте исследования.", items.len()));
            c.space(4.0);
        }
    }
    section_note(c, opts, SectionId::Findings);
}

pub fn summary(c: &mut Composer, n: usize, d: &ReportData, opts: &ReportOptions) {
    c.heading(n, "Аналитическая сводка");
    c.body(&d.record.summary);
    if !d.record.key_facts.is_empty() {
        c.space(8.0);
        c.subheading("Ключевые факты", Some("каждый факт подтверждён первоисточником"));
        let names: HashMap<&str, &str> = d.adapters.iter().map(|a| (a.id.as_str(), a.name.as_str())).collect();
        let cols = [
            Col { title: "Факт".into(), frac: 0.26, mono: false },
            Col { title: "Значение".into(), frac: 0.52, mono: false },
            Col { title: "Источник".into(), frac: 0.22, mono: false },
        ];
        let rows: Vec<Vec<Cell>> = d
            .record
            .key_facts
            .iter()
            .take(40)
            .map(|f| {
                let base = f.adapter_id.split('#').next().unwrap_or(&f.adapter_id);
                vec![
                    Cell::new(f.label.clone()).bold(),
                    Cell::new(f.value.clone()),
                    Cell::new(names.get(base).copied().unwrap_or(base).to_string()).link(Some(f.source_url.clone())),
                ]
            })
            .collect();
        c.table(&cols, &rows, 8.2);
    }
    if !opts.analyst_conclusion.trim().is_empty() {
        c.space(4.0);
        c.callout("Заключение аналитика", &opts.analyst_conclusion);
    }
    section_note(c, opts, SectionId::Summary);
}

fn node_color(kind: EntityKind, dark: bool, accent: Rgb3) -> Rgb3 {
    let (hi, mid, lo) = if dark { ((0.95, 0.97, 1.0), (0.72, 0.77, 0.84), (0.48, 0.53, 0.60)) } else { ((0.10, 0.12, 0.15), (0.35, 0.39, 0.45), (0.60, 0.64, 0.69)) };
    match kind {
        EntityKind::Organization => hi,
        EntityKind::Domain => accent,
        EntityKind::Website => mid,
        EntityKind::Project => mix(mid, accent, 0.5),
        EntityKind::Document => mix(hi, mid, 0.5),
        EntityKind::Publication => lo,
        EntityKind::Source => mix(lo, if dark { (0.0, 0.0, 0.0) } else { (1.0, 1.0, 1.0) }, 0.3),
    }
}

pub fn graph(c: &mut Composer, n: usize, d: &ReportData, opts: &ReportOptions) {
    c.heading(n, "Граф подтверждённых связей");
    let g = if opts.include_source_nodes { d.graph.clone() } else {
        let mut g = d.graph.clone();
        g.nodes.retain(|n| n.kind != EntityKind::Source);
        g.edges.retain(|e| e.relation != "documented_by");
        g.recompute_degrees();
        g
    };
    if g.nodes.is_empty() {
        c.muted("Структурированных связей между объектами не установлено.");
        section_note(c, opts, SectionId::Graph);
        return;
    }
    c.muted(&format!(
        "Объектов: {}; связей: {}; средняя достоверность: {:.2}. На схеме — до 60 наиболее связанных объектов; полный граф доступен в разделе NETWORK и в экспорте GraphML/GEXF.",
        g.nodes.len(),
        g.edges.len(),
        g.mean_confidence()
    ));
    c.space(6.0);
    let layout = layout_2d(&g, 60, 350);
    let fig_h = (c.content_width() * 0.72).min(c.bottom() - c.mt - 60.0);
    c.ensure(fig_h + 40.0);
    let t = c.theme.clone();
    let lum = t.figure_bg.0 * 0.3 + t.figure_bg.1 * 0.59 + t.figure_bg.2 * 0.11;
    let dark = lum < 0.35;
    let accent = if dark && !t.dark_pages { (0.62, 0.78, 0.92) } else { t.accent };
    let (x0, y0, fw) = (c.ml, c.y, c.content_width());
    c.fill_rect(x0, y0, fw, fig_h, t.figure_bg, None);
    let pos = |k: &str| layout.positions.get(k).map(|(x, y)| (x0 + 14.0 + x * (fw - 28.0), y0 + 14.0 + y * (fig_h - 28.0)));
    let edge_col = if dark { (0.75, 0.80, 0.88) } else { (0.35, 0.40, 0.46) };
    for e in &layout.graph.edges {
        if let (Some(a), Some(b)) = (pos(&e.from), pos(&e.to)) {
            c.line(a.0, a.1, b.0, b.1, edge_col, 0.45 + e.confidence * 0.5, Some(0.18 + e.confidence * 0.45));
        }
    }
    let mut order: Vec<&sword_graph::GraphNode> = layout.graph.nodes.iter().collect();
    order.sort_by(|a, b| b.degree.cmp(&a.degree));
    let mut placed: Vec<(f32, f32, f32, f32)> = Vec::new();
    for node in layout.graph.nodes.iter() {
        if let Some((x, y)) = pos(&node.key) {
            let r = 2.0 + (node.degree as f32).sqrt().min(4.0) * 1.1;
            let col = node_color(node.kind, dark, accent);
            c.circle(x, y, r + 2.8, col, Some(0.12));
            c.circle(x, y, r, col, None);
        }
    }
    let label_col = if dark { (0.86, 0.89, 0.94) } else { t.text };
    for node in order.iter().take(22) {
        if let Some((x, y)) = pos(&node.key) {
            let label = truncate_chars(&node.label, 28);
            let lw = c.fonts.regular.width(&label, 6.4);
            let rect = (x + 6.0, y - 5.0, lw, 8.0);
            let overlaps = placed.iter().any(|p| rect.0 < p.0 + p.2 && rect.0 + rect.2 > p.0 && rect.1 < p.1 + p.3 && rect.1 + rect.3 > p.1);
            if overlaps || rect.0 + lw > x0 + fw - 4.0 {
                continue;
            }
            placed.push(rect);
            let font = &c.fonts.regular;
            c.text(x + 6.0, y + 2.2, font, 6.4, label_col, &label);
        }
    }
    c.y = y0 + fig_h + 10.0;
    // Legend
    let mut counts: BTreeMap<EntityKind, usize> = BTreeMap::new();
    for nd in &g.nodes {
        *counts.entry(nd.kind).or_default() += 1;
    }
    let mut lx = c.ml;
    for (kind, count) in counts {
        let label = format!("{} — {count}", kind.label_ru());
        let lw = c.fonts.regular.width(&label, 7.2) + 22.0;
        if lx + lw > c.w - c.mr {
            lx = c.ml;
            c.y += 13.0;
        }
        let col = node_color(kind, t.dark_pages, t.accent);
        c.circle(lx + 4.0, c.y + 5.0, 3.0, col, None);
        let (font, muted) = (&c.fonts.regular, t.muted);
        c.text(lx + 11.0, c.y + 7.6, font, 7.2, muted, &label);
        lx += lw;
    }
    c.y += 20.0;

    if opts.include_edge_table && !g.edges.is_empty() {
        c.subheading("Связи и их происхождение", None);
        let labels: HashMap<&str, &str> = g.nodes.iter().map(|n| (n.key.as_str(), n.label.as_str())).collect();
        let cols = [
            Col { title: "Объект".into(), frac: 0.27, mono: false },
            Col { title: "Связь".into(), frac: 0.18, mono: false },
            Col { title: "Объект".into(), frac: 0.27, mono: false },
            Col { title: "Достов.".into(), frac: 0.10, mono: false },
            Col { title: "Источник".into(), frac: 0.18, mono: false },
        ];
        let mut edges = g.edges.clone();
        edges.sort_by(|a, b| b.confidence.partial_cmp(&a.confidence).unwrap_or(std::cmp::Ordering::Equal));
        let rows: Vec<Vec<Cell>> = edges
            .iter()
            .take(120)
            .map(|e| {
                let ev = e.evidence.first();
                let src_host = ev.and_then(|v| sword_core::util::host_of(&v.source_url)).unwrap_or_else(|| ev.map(|v| v.source_url.clone()).unwrap_or_default());
                vec![
                    Cell::new(labels.get(e.from.as_str()).copied().unwrap_or(&e.from).to_string()),
                    Cell::new(e.label.clone()).color(t.muted),
                    Cell::new(labels.get(e.to.as_str()).copied().unwrap_or(&e.to).to_string()),
                    Cell::new(format!("{:.2}", e.confidence)),
                    Cell::new(src_host).link(ev.map(|v| v.source_url.clone())).sub(if e.evidence.len() > 1 { format!("+{} подтвержд.", e.evidence.len() - 1) } else { String::new() }),
                ]
            })
            .collect();
        c.table(&cols, &rows, 7.8);
        if g.edges.len() > 120 {
            c.muted(&format!("Показаны 120 связей с наибольшей достоверностью из {}.", g.edges.len()));
        }
    }
    section_note(c, opts, SectionId::Graph);
}

pub fn references(c: &mut Composer, n: usize, d: &ReportData, opts: &ReportOptions) {
    c.heading(n, "Ссылки на первоисточники");
    if d.sources.is_empty() {
        c.muted("Первоисточники не зафиксированы.");
        section_note(c, opts, SectionId::References);
        return;
    }
    c.muted(&format!("Всего первоисточников: {}. Ссылки кликабельны.", d.sources.len()));
    c.space(4.0);
    let names: HashMap<&str, &str> = d.adapters.iter().map(|a| (a.id.as_str(), a.name.as_str())).collect();
    let cols = [
        Col { title: "#".into(), frac: 0.06, mono: false },
        Col { title: "Документ".into(), frac: 0.74, mono: false },
        Col { title: "Получено через".into(), frac: 0.20, mono: false },
    ];
    let t = c.theme.clone();
    let rows: Vec<Vec<Cell>> = d
        .sources
        .iter()
        .take(600)
        .enumerate()
        .map(|(i, s)| {
            let base = s.adapter_id.split('#').next().unwrap_or(&s.adapter_id);
            vec![
                Cell::new(format!("[{}]", i + 1)).color(t.muted),
                Cell::new(if s.title.trim().is_empty() { s.url.clone() } else { s.title.clone() }).sub(truncate_chars(&s.url, 160)).link(Some(s.url.clone())),
                Cell::new(names.get(base).copied().unwrap_or(base).to_string()).sub(fmt_datetime(&s.retrieved_at)),
            ]
        })
        .collect();
    c.table(&cols, &rows, 7.8);
    if d.sources.len() > 600 {
        c.muted(&format!("Показаны первые 600 из {} первоисточников.", d.sources.len()));
    }
    section_note(c, opts, SectionId::References);
}

pub fn limitations(c: &mut Composer, n: usize, d: &ReportData, opts: &ReportOptions) {
    c.heading(n, "Ограничения исследования");
    let mut items = d.record.limitations.clone();
    if items.is_empty() {
        items.push("Ограничения не зафиксированы.".into());
    }
    c.bullets(&items, None);
    section_note(c, opts, SectionId::Limitations);
}

/// Running header and footer on content pages (needs the final page count).
#[allow(clippy::too_many_arguments)]
pub fn decorate(
    pages: &mut [(PageKind, Vec<printpdf::Op>)],
    fonts: &crate::fonts::Fonts,
    theme: &crate::theme::Theme,
    w: f32,
    h: f32,
    data: &ReportData,
    opts: &ReportOptions,
    alpha: &[(f32, printpdf::ExtendedGraphicsStateId)],
) {
    let total = pages.len();
    for (i, (kind, ops)) in pages.iter_mut().enumerate() {
        if *kind == PageKind::Cover {
            continue;
        }
        let mut comp = Composer::new(fonts, theme, w, h, alpha.to_vec());
        comp.new_page(PageKind::Cover); // overlay page: no background fill
        let (muted, rule) = (theme.muted, theme.rule);
        comp.text_spaced(54.0, 38.0, &fonts.medium, 6.8, muted, "SWORD OSINT", 1.8);
        if !opts.classification.trim().is_empty() {
            let label = opts.classification.to_uppercase();
            let lw = fonts.medium.width_spaced(&label, 6.5, 1.2);
            comp.text_spaced((w - lw) / 2.0, 38.0, &fonts.medium, 6.5, muted, &label, 1.2);
        }
        comp.text_right(w - 54.0, 38.0, &fonts.mono, 7.0, muted, &data.report_id);
        comp.line(54.0, 46.0, w - 54.0, 46.0, rule, 0.4, None);
        comp.line(54.0, h - 44.0, w - 54.0, h - 44.0, rule, 0.4, None);
        comp.text(54.0, h - 30.0, &fonts.regular, 7.0, muted, &format!("Сформировано {}", fmt_datetime(&data.generated_at)));
        comp.text_right(w - 54.0, h - 30.0, &fonts.regular, 7.0, muted, &format!("Стр. {} из {}", i + 1, total));
        let (drawn, _) = comp.finish();
        for (_, extra) in drawn {
            ops.extend(extra);
        }
    }
}
