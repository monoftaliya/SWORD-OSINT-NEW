<script lang="ts">
  import { ICONS, type IconName } from './icons';

  let { name, size = 18, stroke = 1.5, class: klass = '' }: { name: IconName; size?: number; stroke?: number; class?: string } = $props();
</script>

<svg
  class="icon {klass}"
  width={size}
  height={size}
  viewBox="0 0 24 24"
  fill="none"
  stroke="currentColor"
  stroke-width={stroke}
  stroke-linecap="round"
  stroke-linejoin="round"
  aria-hidden="true"
>
  <path d={ICONS[name]} />
</svg>

<style>
  .icon {
    flex: none;
    display: block;
  }
</style>
