<!--
  DISCOVERY — the main screen. Query + categories on top, the live source timeline on the
  left, results / summary / primary sources on the right, the particle universe in the
  middle (it assembles while the analysis runs). Nothing is shown as found until a source
  has actually returned it.
-->
<script lang="ts">
  import Icon from '../lib/components/Icon.svelte';
  import Bits from '../lib/components/Bits.svelte';
  import Panel from '../lib/components/Panel.svelte';
  import Segmented from '../lib/components/Segmented.svelte';
  import FindingList from '../lib/components/FindingList.svelte';
  import FindingDrawer from '../lib/components/FindingDrawer.svelte';
  import RunTimeline from '../lib/components/RunTimeline.svelte';
  import { api, desktop, toApiError } from '../lib/api/client';
  import type { Category, ClassifiedInput, Finding, PlannedAdapter } from '../lib/api/types';
  import { app } from '../lib/stores/app.svelte';
  import { run, runProgress } from '../lib/stores/run.svelte';
  import { ui } from '../lib/stores/ui.svelte';
  import { CATEGORIES, INPUT_KIND_LABEL, STATUS_LABEL, categoryMeta } from '../lib/util/labels';
  import { debounce, fmtDateTime, fmtDuration, fmtNum, hostOf, plural } from '../lib/util/format';
  import { guarded, openLink } from '../lib/components/ui';

  let classified = $state<ClassifiedInput | null>(null);
  let classifyError = $state<string | null>(null);
  let plan = $state<PlannedAdapter[]>([]);
  let planError = $state<string | null>(null);
  let tab = $state<'results' | 'summary' | 'sources'>('results');
  let exportOpen = $state(false);
  let input = $state<HTMLInputElement | null>(null);

  const cur = $derived(run.discovery);
  const live = $derived(!!cur?.live);
  const progress = $derived(runProgress(cur));
  const query = $derived(ui.discoveryQuery.trim());
  const online = $derived(desktop() && app.backend === 'ready');
  const canRun = $derived(online && query.length > 0 && app.selectedCategories.length > 0 && !live && !run.starting && !classifyError);
  const willRun = $derived(plan.filter((p) => p.willRun));

  const filtered = $derived.by<Finding[]>(() => {
    if (!cur) return [];
    const text = ui.findingFilter.trim().toLowerCase();
    return cur.findings.filter(
      (f) =>
        f.confidence >= ui.findingMinConfidence &&
        (!text || f.title.toLowerCase().includes(text) || (f.snippet ?? '').toLowerCase().includes(text) || (f.url ?? '').toLowerCase().includes(text)),
    );
  });
  const selectedFinding = $derived(cur?.findings.find((f) => f.id === ui.selectedFindingId) ?? null);

  // ---- input classification and plan preview (debounced)
  const refresh = debounce(async (q: string, cats: Category[]) => {
    if (!q || !online) {
      classified = null;
      classifyError = null;
      plan = [];
      planError = null;
      return;
    }
    try {
      classified = await api.classifyQuery(q);
      classifyError = null;
    } catch (e) {
      classified = null;
      classifyError = toApiError(e).message;
      plan = [];
      return;
    }
    if (!cats.length) {
      plan = [];
      return;
    }
    try {
      plan = await api.planInvestigation({ query: q, categories: cats });
      planError = null;
    } catch (e) {
      plan = [];
      planError = toApiError(e).message;
    }
  }, 260);

  $effect(() => {
    void app.adapters; // credentials or toggles changed → the plan changes too
    refresh(query, [...app.selectedCategories]);
  });

  function toggle(c: Category) {
    const cur = app.selectedCategories;
    app.selectedCategories = cur.includes(c) ? cur.filter((x) => x !== c) : [...cur, c];
  }

  async function start() {
    if (!canRun) return;
    tab = 'results';
    ui.selectedFindingId = null;
    ui.findingFilter = '';
    await run.start({ query, categories: [...app.selectedCategories] });
  }

  function onKey(e: KeyboardEvent) {
    if (e.key === 'Enter') {
      e.preventDefault();
      start();
    } else if (e.key === 'Escape') {
      input?.blur();
    }
  }

  function newSearch() {
    run.clearDiscovery();
    ui.discoveryQuery = '';
    ui.selectedFindingId = null;
    exportOpen = false;
    input?.focus();
  }

  async function exportAs(format: 'json' | 'csv' | 'md') {
    exportOpen = false;
    if (!cur) return;
    const path = await guarded(() => api.exportInvestigation(cur.id, format), 'Экспорт');
    if (path) app.toast('ok', `Сохранено: ${path}`, 6000);
  }

  function openGraph(entityKey?: string) {
    if (!cur) return;
    ui.networkMode = 'investigation';
    ui.networkFocusKey = entityKey ?? null;
    app.navigate('network', cur.id);
  }

  function configure(id: string) {
    ui.settingsTab = 'connections';
    ui.settingsFocusAdapter = id;
    app.navigate('settings');
  }
</script>

<div class="section-root discovery">
  <!-- query -->
  <div class="top">
    {#if !cur && !query}
      <div class="hero enter">
        <span class="display brand">SWORD</span>
        <span class="tagline">Разведка по открытым источникам · только публичные данные и официальные API</span>
      </div>
    {/if}
    <div class="search glass" class:focusable={!live}>
      <Icon name="search" size={18} />
      <input
        bind:this={input}
        bind:value={ui.discoveryQuery}
        onkeydown={onKey}
        class="q"
        placeholder="Домен, URL, организация, @канал Telegram, сообщество VK, e-mail…"
        spellcheck="false"
        autocomplete="off"
        disabled={live}
        aria-label="Запрос"
      />
      {#if classified && query}
        <span class="kind" title="Тип запроса определён автоматически">{INPUT_KIND_LABEL[classified.kind]}{classified.domain ? ` · ${classified.domain}` : ''}</span>
      {:else if classifyError && query}
        <span class="kind err" title={classifyError}>{classifyError}</span>
      {/if}
      {#if live}
        <button class="btn danger" onclick={() => run.cancel('discovery')}><Icon name="stop" size={14} />Остановить</button>
      {:else}
        <button class="btn primary" onclick={start} disabled={!canRun} title={online ? '' : 'Доступно в настольном приложении'}>
          {#if run.starting}<Bits kind="spinner" />{:else}<Icon name="play" size={14} />{/if}
          Анализ
        </button>
      {/if}
    </div>
    <div class="cats" role="group" aria-label="Категории источников">
      {#each CATEGORIES as c (c.id)}
        {@const r = app.readiness(c.id)}
        {@const on = app.selectedCategories.includes(c.id)}
        <button
          class="cat"
          class:on
          class:unready={on && r.total > 0 && r.ready === 0}
          title="{c.title} — {c.hint}. Готово источников: {r.ready} из {r.total}"
          onclick={() => toggle(c.id)}
          disabled={live}
          aria-pressed={on}
        >
          <Icon name={c.icon} size={13} />
          <span>{c.short}</span>
          <span class="rd num">{r.ready}/{r.total}</span>
        </button>
      {/each}
      <span class="catsep"></span>
      <button class="mini" disabled={live} onclick={() => (app.selectedCategories = CATEGORIES.map((c) => c.id))}>все</button>
      <button class="mini" disabled={live} onclick={() => (app.selectedCategories = [])}>сброс</button>
    </div>
  </div>

  <!-- panels -->
  <div class="middle">
    {#if cur}
      <Panel title="Источники" subtitle={live ? `выполняется · ${progress.done} из ${progress.total}` : `завершено · ${progress.done} из ${progress.total}`} class="left enter">
        {#snippet actions()}
          {#if live}<Bits kind="spinner" />{/if}
        {/snippet}
        <div class="progress" aria-label="Прогресс"><span style:width="{Math.round(progress.ratio * 100)}%"></span></div>
        <RunTimeline run={cur} />
      </Panel>
    {:else if query && (plan.length || planError)}
      <Panel title="План анализа" subtitle={planError ?? `${plural(willRun.length, 'источник', 'источника', 'источников')} будут опрошены`} class="left enter">
        <ul class="plan">
          {#each plan as p (p.adapterId)}
            <li class:off={!p.willRun}>
              <Bits kind="dot" tone={p.willRun ? 'ok' : 'idle'} />
              <div class="pl">
                <span class="pn">{p.name}</span>
                <span class="pc">{p.categories.map((c) => categoryMeta(c).short).join(' · ')}</span>
                {#if !p.willRun && p.reason}
                  <span class="pr">{p.reason}</span>
                  {#if /ключ|токен|настро|не задан/i.test(p.reason)}
                    <button class="fix" onclick={() => configure(p.adapterId)}><Icon name="key" size={12} />Настроить</button>
                  {/if}
                {/if}
              </div>
            </li>
          {/each}
        </ul>
      </Panel>
    {:else}
      <div class="left-spacer"></div>
    {/if}

    <div class="center">
      {#if selectedFinding}
        <div class="drawer-slot">
          <FindingDrawer finding={selectedFinding} onclose={() => (ui.selectedFindingId = null)} ongraph={(k) => openGraph(k)} />
        </div>
      {/if}
    </div>

    {#if cur}
      <Panel title={tab === 'results' ? 'Результаты' : tab === 'summary' ? 'Сводка' : 'Первоисточники'} subtitle={cur.query} class="right enter" pad={false}>
        {#snippet actions()}
          <Segmented
            size="sm"
            bind:value={tab}
            options={[
              { value: 'results', label: `Найдено ${fmtNum(cur.findings.length)}` },
              { value: 'summary', label: 'Сводка' },
              { value: 'sources', label: `Ссылки ${fmtNum(cur.sources.length)}` },
            ]}
          />
        {/snippet}
        {#if tab === 'results'}
          <div class="filters">
            <input class="input" placeholder="Фильтр по тексту и ссылке" bind:value={ui.findingFilter} />
            <Segmented
              size="sm"
              bind:value={ui.findingMinConfidence}
              options={[
                { value: 0, label: 'все' },
                { value: 0.6, label: '≥0.6' },
                { value: 0.8, label: '≥0.8' },
                { value: 0.95, label: '≥0.95' },
              ]}
            />
          </div>
          <div class="list scroll">
            <FindingList
              findings={filtered}
              selected={ui.selectedFindingId}
              onselect={(f) => (ui.selectedFindingId = ui.selectedFindingId === f.id ? null : f.id)}
              empty={live ? 'Источники ещё работают — результаты появятся по мере получения.' : cur.findings.length ? 'Нет результатов под фильтр' : 'Источники не вернули результатов по этому запросу.'}
            />
          </div>
        {:else if tab === 'summary'}
          <div class="summary scroll">
            {#if cur.record}
              {#each cur.record.summary.split('\n').filter((l) => l.trim()) as para, i (i)}
                <p>{para}</p>
              {/each}
              {#if cur.record.keyFacts.length}
                <span class="eyebrow">Ключевые факты</span>
                <dl class="facts">
                  {#each cur.record.keyFacts as f, i (i)}
                    <dt>{f.label}</dt>
                    <dd>
                      <span>{f.value}</span>
                      <button class="src" onclick={() => openLink(f.sourceUrl)} title={f.sourceUrl}>{hostOf(f.sourceUrl) || 'источник'} ↗</button>
                    </dd>
                  {/each}
                </dl>
              {/if}
              {#if cur.record.limitations.length}
                <span class="eyebrow">Ограничения</span>
                <ul class="limits">
                  {#each cur.record.limitations as l, i (i)}<li>{l}</li>{/each}
                </ul>
              {/if}
            {:else}
              <div class="empty small">Сводка будет составлена по завершении анализа из фактически полученных данных.</div>
            {/if}
          </div>
        {:else}
          <div class="sources scroll">
            {#if cur.sources.length === 0}
              <div class="empty small">{live ? 'Ссылки появятся после сохранения результатов.' : 'Нет ссылок на первоисточники.'}</div>
            {:else}
              <ol>
                {#each cur.sources as s, i (s.url)}
                  <li>
                    <button class="srcrow" onclick={() => openLink(s.url)}>
                      <span class="n num">{i + 1}</span>
                      <span class="st">
                        <span class="t">{s.title || hostOf(s.url)}</span>
                        <span class="u mono">{s.url}</span>
                        <span class="m">{app.adapters.find((a) => a.info.id === s.adapterId)?.info.name ?? s.adapterId} · {fmtDateTime(s.retrievedAt)}</span>
                      </span>
                      <Icon name="external" size={13} />
                    </button>
                  </li>
                {/each}
              </ol>
            {/if}
          </div>
        {/if}
      </Panel>
    {/if}
  </div>

  <!-- outcome -->
  <div class="bottom">
    {#if cur && !live && cur.record}
      {@const r = cur.record}
      <div class="outcome glass enter">
        <Bits kind="dot" tone={r.status === 'completed' ? 'ok' : r.status === 'partial' ? 'warn' : r.status === 'cancelled' ? 'idle' : 'err'} />
        <span class="st">{STATUS_LABEL[r.status]}</span>
        <span class="figs">
          <b class="num">{fmtNum(r.resultCount)}</b> результатов · <b class="num">{fmtNum(r.sourceCount)}</b> первоисточников · <b class="num">{fmtNum(r.nodeCount)}</b> объектов в графе · {fmtDuration(r.durationMs)}
        </span>
        <span class="sep"></span>
        <button class="btn sm" onclick={() => openGraph()} disabled={r.nodeCount === 0}><Icon name="network" size={14} />Граф</button>
        <button class="btn sm" onclick={() => app.navigate('report', cur.id)}><Icon name="report" size={14} />Отчёт PDF</button>
        <div class="menu-wrap">
          <button class="btn sm" onclick={() => (exportOpen = !exportOpen)} aria-expanded={exportOpen}><Icon name="download" size={14} />Экспорт</button>
          {#if exportOpen}
            <div class="menu glass glass-strong">
              <button onclick={() => exportAs('json')}>JSON — полные данные</button>
              <button onclick={() => exportAs('csv')}>CSV — таблица результатов</button>
              <button onclick={() => exportAs('md')}>Markdown — отчёт</button>
            </div>
          {/if}
        </div>
        <button class="btn sm ghost" onclick={newSearch}><Icon name="plus" size={14} />Новый поиск</button>
      </div>
    {:else if !cur}
      <div class="hint">
        <span>Колесо — масштаб</span><span>ЛКМ — вращение</span><span>Колесо + перетаскивание — панорама</span><span>Двойной клик — исходный вид</span><span>Клик по сфере — категория</span>
      </div>
    {/if}
  </div>
</div>

<style>
  .discovery {
    gap: 12px;
  }
  /* empty space of the layout rows lets the pointer through to the 3D scene */
  .top,
  .middle,
  .bottom {
    pointer-events: none;
  }
  .top > *,
  .bottom > * {
    pointer-events: auto;
  }
  .top {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 10px;
    flex: none;
  }
  .top > .hero,
  .bottom > .hint {
    pointer-events: none;
  }
  .hero {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 8px;
    margin: 4vh 0 10px;
  }
  .brand {
    font-size: 44px;
    letter-spacing: 0.5em;
    margin-right: -0.5em;
    color: #fff;
    text-shadow: 0 0 40px rgba(220, 232, 248, 0.35);
  }
  .tagline {
    font-size: 12.5px;
    color: var(--fg-3);
    letter-spacing: 0.04em;
  }
  .search {
    width: min(760px, 100%);
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 7px 7px 7px 18px;
    border-radius: 999px;
    color: var(--fg-3);
    transition: box-shadow 0.3s var(--ease), border-color 0.3s;
  }
  .search:focus-within {
    border-color: rgba(220, 230, 245, 0.32);
    box-shadow: 0 0 0 4px rgba(200, 215, 235, 0.05), var(--glow-strong);
  }
  .q {
    flex: 1;
    min-width: 0;
    height: 36px;
    border: none;
    outline: none;
    background: transparent;
    font-size: 14.5px;
    color: #fff;
  }
  .q::placeholder {
    color: var(--fg-4);
  }
  .kind {
    flex: none;
    max-width: 260px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 11px;
    padding: 4px 10px;
    border-radius: 999px;
    border: 1px solid var(--line);
    color: var(--fg-2);
  }
  .kind.err {
    color: var(--err);
    border-color: rgba(240, 138, 138, 0.3);
  }
  .cats {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 6px;
    max-width: 1060px;
  }
  .cat {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 28px;
    padding: 0 10px;
    border-radius: 999px;
    border: 1px solid var(--line);
    background: rgba(5, 7, 10, 0.55);
    backdrop-filter: blur(12px);
    color: var(--fg-3);
    font-family: var(--font-display);
    font-size: 9px;
    letter-spacing: 0.2em;
    cursor: pointer;
    transition: color 0.2s, border-color 0.2s, background 0.2s, box-shadow 0.25s;
  }
  .cat:hover {
    color: var(--fg);
    border-color: var(--line-strong);
  }
  .cat.on {
    color: #fff;
    border-color: rgba(230, 238, 250, 0.42);
    background: rgba(230, 238, 250, 0.09);
    box-shadow: 0 0 18px rgba(220, 232, 248, 0.14);
  }
  .cat.unready {
    border-color: rgba(232, 212, 139, 0.45);
  }
  .cat:disabled {
    cursor: default;
    opacity: 0.6;
  }
  .rd {
    font-family: var(--font-mono);
    font-size: 10px;
    letter-spacing: 0;
    color: var(--fg-3);
  }
  .catsep {
    width: 1px;
    height: 16px;
    background: var(--line);
    align-self: center;
    margin: 0 4px;
  }
  .mini {
    border: none;
    background: none;
    color: var(--fg-3);
    font-size: 11.5px;
    cursor: pointer;
    padding: 0 4px;
  }
  .mini:hover:not(:disabled) {
    color: #fff;
  }
  .mini:disabled {
    opacity: 0.4;
    cursor: default;
  }

  .middle {
    flex: 1;
    min-height: 0;
    display: flex;
    gap: 14px;
  }
  .middle > :global(*) {
    pointer-events: auto;
  }
  .middle :global(.left) {
    width: 318px;
    flex: none;
  }
  .left-spacer {
    width: 318px;
    flex: none;
    pointer-events: none !important;
  }
  .middle :global(.right) {
    width: 430px;
    flex: none;
  }
  .center {
    flex: 1;
    min-width: 0;
    display: flex;
    justify-content: flex-end;
    pointer-events: none !important;
  }
  .drawer-slot {
    width: min(400px, 100%);
    display: flex;
    flex-direction: column;
    min-height: 0;
    pointer-events: auto;
  }
  .progress {
    height: 2px;
    border-radius: 2px;
    background: rgba(255, 255, 255, 0.06);
    margin-bottom: 8px;
    overflow: hidden;
    flex: none;
  }
  .progress span {
    display: block;
    height: 100%;
    background: #fff;
    box-shadow: 0 0 10px #fff;
    transition: width 0.6s var(--ease-out);
  }
  .plan {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .plan li {
    display: flex;
    gap: 10px;
    padding: 7px 2px;
    align-items: baseline;
  }
  .plan li.off .pn {
    color: var(--fg-3);
  }
  .pl {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }
  .pn {
    font-size: 12.5px;
  }
  .pc {
    font-family: var(--font-display);
    font-size: 8.5px;
    letter-spacing: 0.18em;
    color: var(--fg-4);
  }
  .pr {
    font-size: 11px;
    color: var(--fg-3);
    line-height: 1.4;
  }
  .fix {
    align-self: flex-start;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    border: none;
    background: none;
    color: var(--fg-2);
    font-size: 11px;
    cursor: pointer;
    padding: 2px 0;
  }
  .fix:hover {
    color: #fff;
  }
  .filters {
    display: flex;
    gap: 8px;
    align-items: center;
    padding: 10px 12px;
    border-bottom: 1px solid var(--line);
    flex: none;
  }
  .filters .input {
    min-height: 30px;
    padding: 5px 10px;
    font-size: 12px;
  }
  .list {
    flex: 1;
    padding: 8px 8px 12px;
  }
  .summary {
    flex: 1;
    padding: 14px 16px 18px;
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .summary p {
    margin: 0;
    font-size: 12.5px;
    line-height: 1.6;
    color: var(--fg-2);
    user-select: text;
  }
  .facts {
    display: grid;
    grid-template-columns: minmax(100px, 36%) 1fr;
    gap: 7px 12px;
    margin: 0;
    font-size: 12px;
  }
  .facts dt {
    color: var(--fg-3);
  }
  .facts dd {
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
    user-select: text;
  }
  .src {
    align-self: flex-start;
    border: none;
    background: none;
    padding: 0;
    color: var(--fg-3);
    font-size: 10.5px;
    cursor: pointer;
  }
  .src:hover {
    color: #fff;
  }
  .limits {
    margin: 0;
    padding-left: 16px;
    font-size: 12px;
    color: var(--fg-2);
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
  .sources {
    flex: 1;
    padding: 6px 8px 12px;
  }
  .sources ol {
    list-style: none;
    margin: 0;
    padding: 0;
  }
  .srcrow {
    width: 100%;
    display: flex;
    gap: 10px;
    align-items: flex-start;
    padding: 8px;
    border: none;
    border-radius: 8px;
    background: none;
    color: var(--fg-3);
    text-align: left;
    cursor: pointer;
  }
  .srcrow:hover {
    background: rgba(255, 255, 255, 0.035);
    color: #fff;
  }
  .srcrow .n {
    width: 22px;
    flex: none;
    font-size: 11px;
    color: var(--fg-4);
    text-align: right;
  }
  .st {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 1px;
  }
  .st .t {
    font-size: 12.5px;
    color: var(--fg);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .st .u {
    font-size: 10.5px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .st .m {
    font-size: 10.5px;
    color: var(--fg-4);
  }

  .bottom {
    flex: none;
    display: flex;
    justify-content: center;
    min-height: 44px;
    align-items: flex-end;
  }
  .outcome {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 7px 8px 7px 16px;
    border-radius: 999px;
    max-width: 100%;
  }
  .outcome .st {
    font-size: 12px;
    color: #fff;
    white-space: nowrap;
  }
  .figs {
    font-size: 12px;
    color: var(--fg-3);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .figs b {
    color: var(--fg);
    font-weight: 500;
  }
  .sep {
    width: 1px;
    height: 18px;
    background: var(--line);
  }
  .menu-wrap {
    position: relative;
  }
  .menu {
    position: absolute;
    bottom: 40px;
    left: 0;
    display: flex;
    flex-direction: column;
    padding: 6px;
    min-width: 230px;
    z-index: 5;
  }
  .menu button {
    border: none;
    background: none;
    color: var(--fg-2);
    text-align: left;
    padding: 8px 10px;
    border-radius: 7px;
    font-size: 12px;
    cursor: pointer;
  }
  .menu button:hover {
    background: rgba(255, 255, 255, 0.06);
    color: #fff;
  }
  .hint {
    display: flex;
    gap: 18px;
    font-size: 11px;
    color: var(--fg-4);
    padding-bottom: 6px;
  }
</style>
