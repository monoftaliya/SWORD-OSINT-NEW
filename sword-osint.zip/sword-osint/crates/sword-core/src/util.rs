//! Small, dependency-light helpers shared across engines.

use chrono::{DateTime, NaiveDate, TimeZone, Utc};
use sha2::{Digest, Sha256};
use url::Url;

/// Time-ordered unique id (UUID v7) — sorts by creation time in SQLite.
pub fn new_id() -> String {
    uuid::Uuid::now_v7().to_string()
}

/// Random token (UUID v4, hex without dashes) — e.g. DNS ownership verification.
pub fn random_token() -> String {
    uuid::Uuid::new_v4().simple().to_string()
}

pub fn now() -> DateTime<Utc> {
    Utc::now()
}

pub fn sha256_hex(data: &[u8]) -> String {
    hex::encode(Sha256::digest(data))
}

/// Short stable id derived from parts (used for edge ids and finding dedupe keys).
pub fn short_hash(parts: &[&str]) -> String {
    let mut h = Sha256::new();
    for p in parts {
        h.update(p.as_bytes());
        h.update([0x1f]);
    }
    hex::encode(&h.finalize()[..8])
}

/// Lower-cased host of a URL.
pub fn host_of(url: &str) -> Option<String> {
    Url::parse(url).ok()?.host_str().map(|h| h.trim_end_matches('.').to_lowercase())
}

/// Canonical form of a URL for de-duplication: lower-case host, no fragment, no tracking
/// parameters, no default port, no trailing slash on non-root paths.
pub fn canonical_url(raw: &str) -> String {
    let Ok(mut url) = Url::parse(raw.trim()) else {
        return raw.trim().to_string();
    };
    url.set_fragment(None);
    let kept: Vec<(String, String)> = url
        .query_pairs()
        .filter(|(k, _)| {
            let k = k.to_ascii_lowercase();
            !(k.starts_with("utm_") || k == "fbclid" || k == "gclid" || k == "yclid" || k == "ref_src")
        })
        .map(|(k, v)| (k.into_owned(), v.into_owned()))
        .collect();
    if kept.is_empty() {
        url.set_query(None);
    } else {
        url.query_pairs_mut().clear().extend_pairs(kept);
    }
    let mut s = url.to_string();
    if s.ends_with('/') && url.path() != "/" {
        s.pop();
    }
    s
}

/// Mask an e-mail for display: `a***@example.com`.
pub fn mask_email(email: &str) -> String {
    match email.split_once('@') {
        Some((local, domain)) => {
            let first: String = local.chars().take(1).collect();
            format!("{first}***@{domain}")
        }
        None => "***".into(),
    }
}

/// Redact a secret value for display: keeps a 4-char prefix only.
pub fn redact_secret(value: &str) -> String {
    let prefix: String = value.chars().take(4).collect();
    format!("{prefix}••••••")
}

/// Truncate by characters (not bytes), adding an ellipsis.
pub fn truncate_chars(s: &str, max: usize) -> String {
    if s.chars().count() <= max {
        return s.to_string();
    }
    let mut out: String = s.chars().take(max.saturating_sub(1)).collect();
    out.push('…');
    out
}

/// Remove HTML tags and decode common entities; collapses whitespace.
pub fn strip_html(input: &str) -> String {
    let mut out = String::with_capacity(input.len());
    let mut in_tag = false;
    for ch in input.chars() {
        match ch {
            '<' => in_tag = true,
            '>' if in_tag => {
                in_tag = false;
                out.push(' ');
            }
            _ if !in_tag => out.push(ch),
            _ => {}
        }
    }
    collapse_ws(&decode_entities(&out))
}

pub fn collapse_ws(s: &str) -> String {
    s.split_whitespace().collect::<Vec<_>>().join(" ")
}

/// Decode the HTML entities that appear in API snippets.
pub fn decode_entities(s: &str) -> String {
    if !s.contains('&') {
        return s.to_string();
    }
    let mut out = String::with_capacity(s.len());
    let mut rest = s;
    while let Some(pos) = rest.find('&') {
        out.push_str(&rest[..pos]);
        let tail = &rest[pos..];
        if let Some(end) = tail.find(';').filter(|&e| e <= 10) {
            let entity = &tail[1..end];
            let decoded = match entity {
                "amp" => Some('&'),
                "lt" => Some('<'),
                "gt" => Some('>'),
                "quot" => Some('"'),
                "apos" => Some('\''),
                "nbsp" => Some(' '),
                "laquo" => Some('«'),
                "raquo" => Some('»'),
                "mdash" => Some('—'),
                "ndash" => Some('–'),
                "hellip" => Some('…'),
                _ if entity.starts_with("#x") || entity.starts_with("#X") => {
                    u32::from_str_radix(&entity[2..], 16).ok().and_then(char::from_u32)
                }
                _ if entity.starts_with('#') => entity[1..].parse::<u32>().ok().and_then(char::from_u32),
                _ => None,
            };
            if let Some(c) = decoded {
                out.push(c);
                rest = &tail[end + 1..];
                continue;
            }
        }
        out.push('&');
        rest = &tail[1..];
    }
    out.push_str(rest);
    out
}

/// Shannon entropy in bits per character (secret detection heuristics).
pub fn shannon_entropy(s: &str) -> f64 {
    if s.is_empty() {
        return 0.0;
    }
    let mut counts = std::collections::HashMap::new();
    let mut total = 0usize;
    for c in s.chars() {
        *counts.entry(c).or_insert(0usize) += 1;
        total += 1;
    }
    counts
        .values()
        .map(|&n| {
            let p = n as f64 / total as f64;
            -p * p.log2()
        })
        .sum()
}

/// Parse the many date formats returned by registries and APIs.
pub fn parse_date(s: &str) -> Option<DateTime<Utc>> {
    let s = s.trim();
    if s.is_empty() {
        return None;
    }
    if let Ok(dt) = DateTime::parse_from_rfc3339(s) {
        return Some(dt.with_timezone(&Utc));
    }
    if let Ok(dt) = DateTime::parse_from_rfc2822(s) {
        return Some(dt.with_timezone(&Utc));
    }
    for fmt in ["%Y-%m-%dT%H:%M:%S%.f", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S", "%Y.%m.%d %H:%M:%S"] {
        if let Ok(ndt) = chrono::NaiveDateTime::parse_from_str(s, fmt) {
            return Some(Utc.from_utc_datetime(&ndt));
        }
    }
    for fmt in ["%Y-%m-%d", "%Y.%m.%d", "%d.%m.%Y", "%Y%m%d"] {
        let head = s.get(..10).unwrap_or(s);
        if let Ok(d) = NaiveDate::parse_from_str(head, fmt) {
            return d.and_hms_opt(0, 0, 0).map(|ndt| Utc.from_utc_datetime(&ndt));
        }
    }
    // Wayback timestamps: 20240131235959
    if s.len() == 14 && s.chars().all(|c| c.is_ascii_digit()) {
        if let Ok(ndt) = chrono::NaiveDateTime::parse_from_str(s, "%Y%m%d%H%M%S") {
            return Some(Utc.from_utc_datetime(&ndt));
        }
    }
    None
}

/// Date formatted for Russian UI/report text.
pub fn fmt_date(dt: &DateTime<Utc>) -> String {
    dt.format("%d.%m.%Y").to_string()
}

pub fn fmt_datetime(dt: &DateTime<Utc>) -> String {
    dt.format("%d.%m.%Y %H:%M UTC").to_string()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn canonicalizes_urls() {
        assert_eq!(canonical_url("https://Example.com/a/?utm_source=x#top"), "https://example.com/a");
        assert_eq!(canonical_url("https://example.com/?q=1&utm_medium=y"), "https://example.com/?q=1");
    }

    #[test]
    fn strips_html_and_entities() {
        assert_eq!(strip_html("<b>Tauri</b> &amp; Rust&nbsp;app &#x41;"), "Tauri & Rust app A");
    }

    #[test]
    fn parses_dates() {
        assert!(parse_date("2024-03-01T10:00:00Z").is_some());
        assert!(parse_date("1997-09-15").is_some());
        assert!(parse_date("20240131235959").is_some());
        assert!(parse_date("2001.07.09").is_some());
    }

    #[test]
    fn masks() {
        assert_eq!(mask_email("alice@example.com"), "a***@example.com");
        assert!(shannon_entropy("aaaa") < 0.1);
        assert!(shannon_entropy("aB3$xY9!") > 2.5);
    }
}
