<!--
  ANALYTICS — figures computed by the core from the local database only: investigations,
  results, source reliability, errors and measured application performance. Nothing is
  estimated or simulated; empty periods show as empty.
-->
<script lang="ts">
  import Icon from '../lib/components/Icon.svelte';
  import Bits from '../lib/components/Bits.svelte';
  import Panel from '../lib/components/Panel.svelte';
  import Segmented from '../lib/components/Segmented.svelte';
  import StatTile from '../lib/components/StatTile.svelte';
  import AreaChart from '../lib/components/charts/AreaChart.svelte';
  import Columns from '../lib/components/charts/Columns.svelte';
  import BarList from '../lib/components/charts/BarList.svelte';
  import Donut from '../lib/components/charts/Donut.svelte';
  import Sparkline from '../lib/components/charts/Sparkline.svelte';
  import { api, desktop } from '../lib/api/client';
  import type { AnalyticsReport, Category, FindingKind, InvestigationStatus, Severity } from '../lib/api/types';
  import { app } from '../lib/stores/app.svelte';
  import { ui } from '../lib/stores/ui.svelte';
  import { FINDING_KIND_LABEL, SEVERITY_META, STATUS_LABEL, categoryMeta } from '../lib/util/labels';
  import { fmtAgo, fmtBytes, fmtDateTime, fmtDuration, fmtNum } from '../lib/util/format';
  import { shortDate } from '../lib/components/charts/scale';

  const ERROR_LABEL: Record<string, string> = {
    network: 'Сеть недоступна',
    timeout: 'Тайм-аут',
    rate_limited: 'Лимит запросов',
    unauthorized: 'Ключ отклонён',
    forbidden: 'Нет прав',
    not_found: 'Не найдено',
    invalid_input: 'Некорректный запрос',
    not_configured: 'Не настроен',
    parse: 'Ошибка разбора ответа',
    upstream: 'Ошибка сервиса',
    unsupported: 'Не поддерживается',
    cancelled: 'Отменено',
    internal: 'Внутренняя ошибка',
    io: 'Ввод-вывод',
    database: 'База данных',
  };
  const STATUS_COLOR: Record<InvestigationStatus, string> = {
    completed: 'var(--ok)',
    partial: 'var(--warn)',
    failed: 'var(--err)',
    cancelled: 'rgba(226, 231, 239, 0.32)',
    running: 'var(--info)',
  };

  let report = $state<AnalyticsReport | null>(null);
  let loading = $state(false);
  let error = $state<string | null>(null);
  let showTable = $state(false);

  $effect(() => {
    const days = ui.analyticsRange;
    if (!desktop()) return;
    let cancelled = false;
    loading = true;
    api
      .getAnalytics(days)
      .then((r) => {
        if (!cancelled) {
          report = r;
          error = null;
        }
      })
      .catch((e) => {
        if (!cancelled) error = e?.message ?? String(e);
      })
      .finally(() => {
        if (!cancelled) loading = false;
      });
    return () => {
      cancelled = true;
    };
  });

  async function reload() {
    if (!desktop()) return;
    loading = true;
    try {
      report = await api.getAnalytics(ui.analyticsRange);
      error = null;
    } catch (e) {
      app.error(e, 'Аналитика');
    } finally {
      loading = false;
    }
  }

  const t = $derived(report?.totals);
  const perDayInv = $derived(report?.perDay.map((d) => ({ label: d.date, value: d.investigations })) ?? []);
  const perDayFind = $derived(report?.perDay.map((d) => ({ label: d.date, value: d.findings })) ?? []);
  const perDayErr = $derived(report?.perDay.map((d) => ({ label: d.date, value: d.errors })) ?? []);
</script>

<div class="section-root an enter">
  <div class="head">
    <Segmented
      bind:value={ui.analyticsRange}
      options={[
        { value: 7, label: '7 дней' },
        { value: 30, label: '30 дней' },
        { value: 90, label: '90 дней' },
        { value: 365, label: 'Год' },
      ]}
    />
    {#if loading}<Bits kind="spinner" />{/if}
    <span class="spacer"></span>
    {#if report}<span class="faint small">Рассчитано {fmtDateTime(report.generatedAt)} по локальной базе</span>{/if}
    <button class="btn sm ghost" onclick={() => (showTable = !showTable)} aria-pressed={showTable}><Icon name="layers" size={13} />{showTable ? 'Графики' : 'Таблица по дням'}</button>
    <button class="btn sm" onclick={reload} disabled={!desktop() || loading}><Icon name="refresh" size={13} />Обновить</button>
  </div>

  {#if !desktop()}
    <div class="empty">Аналитика рассчитывается ядром приложения и доступна в настольной версии.</div>
  {:else if error && !report}
    <div class="empty"><Icon name="alert" size={20} />{error}</div>
  {:else if report && t}
    <div class="body scroll" class:stale={loading}>
      <div class="tiles">
        <StatTile label="Исследования" value={fmtNum(t.investigations)} sub="{fmtNum(t.completed)} завершено · {fmtNum(t.partial)} частично" />
        <StatTile label="Аудиты экспозиции" value={fmtNum(t.audits)} sub="{fmtNum(t.failed)} с ошибкой · {fmtNum(t.cancelled)} отменено" />
        <StatTile label="Результаты" value={fmtNum(t.findings)} sub="{fmtNum(t.uniqueSources)} уникальных первоисточников" />
        <StatTile
          label="Успешность источников"
          value={t.adapterRuns ? `${Math.round(t.successRate * 100)}%` : '—'}
          sub="{fmtNum(t.adapterRuns)} запусков источников"
          tone={t.adapterRuns === 0 ? 'neutral' : t.successRate >= 0.9 ? 'ok' : t.successRate >= 0.7 ? 'warn' : 'err'}
        />
        <StatTile label="Среднее время анализа" value={t.investigations + t.audits ? fmtDuration(t.avgDurationMs) : '—'} sub="p95 {fmtDuration(report.performance.p95InvestigationMs)}" />
        <StatTile label="Граф связей" value={fmtNum(t.graphNodes)} sub="{fmtNum(t.graphEdges)} подтверждённых связей" />
        <StatTile label="PDF-отчёты" value={fmtNum(t.reports)} sub={report.performance.reportMsAvg !== null ? `в среднем ${fmtDuration(report.performance.reportMsAvg)} на отчёт` : 'нет замеров'} />
        <StatTile label="Размер базы" value={fmtBytes(report.performance.dbSizeBytes)} sub="версия {report.performance.appVersion}" />
      </div>

      {#if showTable}
        <Panel title="По дням" subtitle="Те же данные, что на графиках" class="tbl">
          <table class="table">
            <thead><tr><th>Дата</th><th class="r">Исследования</th><th class="r">Результаты</th><th class="r">Ошибки источников</th></tr></thead>
            <tbody>
              {#each [...report.perDay].reverse() as d (d.date)}
                <tr><td>{shortDate(d.date)}</td><td class="r num">{fmtNum(d.investigations)}</td><td class="r num">{fmtNum(d.findings)}</td><td class="r num">{fmtNum(d.errors)}</td></tr>
              {/each}
            </tbody>
          </table>
        </Panel>
      {:else}
        <div class="trio">
          <Panel title="Исследования в день" scroll={false}><Columns data={perDayInv} name="Исследования" /></Panel>
          <Panel title="Результаты в день" scroll={false}><AreaChart data={perDayFind} name="Результаты" height={130} /></Panel>
          <Panel title="Ошибки источников в день" scroll={false}><Columns data={perDayErr} name="Ошибки" tone="err" /></Panel>
        </div>
      {/if}

      <div class="quad">
        <Panel title="Категории" subtitle="результаты по категориям" scroll={false}>
          <BarList items={report.categories.map((b) => ({ key: b.key, label: categoryMeta(b.key as Category).label, value: b.count }))} />
        </Panel>
        <Panel title="Типы результатов" scroll={false}>
          <BarList items={report.findingKinds.map((b) => ({ key: b.key, label: FINDING_KIND_LABEL[b.key as FindingKind] ?? b.key, value: b.count }))} />
        </Panel>
        <Panel title="Первоисточники" subtitle="домены, на которые ссылаются результаты" scroll={false}>
          <BarList items={report.topSourceHosts.map((b) => ({ key: b.key, label: b.key, value: b.count }))} />
        </Panel>
        <Panel title="Статусы" scroll={false}>
          <Donut
            caption="исследований"
            items={report.statuses.map((b) => ({ key: b.key, label: STATUS_LABEL[b.key as InvestigationStatus] ?? b.key, value: b.count, color: STATUS_COLOR[b.key as InvestigationStatus] ?? 'var(--silver)' }))}
          />
        </Panel>
      </div>

      <div class="duo">
        <Panel title="Источники" subtitle="надёжность и скорость каждого адаптера за период" pad={false} class="adapters">
          <table class="table">
            <thead>
              <tr><th>Источник</th><th class="r">Запуски</th><th class="r">Успешно</th><th class="r">Ошибки</th><th class="r">Пропуски</th><th class="r">Результаты</th><th class="r">Среднее</th><th class="r">p95</th><th>Последний</th></tr>
            </thead>
            <tbody>
              {#each report.adapters as a (a.adapterId)}
                <tr>
                  <td>{a.adapterName}</td>
                  <td class="r num">{fmtNum(a.runs)}</td>
                  <td class="r num">{fmtNum(a.done)}</td>
                  <td class="r num" class:bad={a.failed > 0}>{fmtNum(a.failed)}</td>
                  <td class="r num faint">{fmtNum(a.skipped)}</td>
                  <td class="r num">{fmtNum(a.results)}</td>
                  <td class="r num">{fmtDuration(a.avgMs)}</td>
                  <td class="r num">{fmtDuration(a.p95Ms)}</td>
                  <td class="faint">{fmtAgo(a.lastRun)}</td>
                </tr>
              {:else}
                <tr><td colspan="9" class="faint">За период источники не запускались.</td></tr>
              {/each}
            </tbody>
          </table>
        </Panel>
        <div class="col side">
          <Panel title="Ошибки по типам" scroll={false}>
            {#if report.errors.length}
              <ul class="errs">
                {#each report.errors as e (e.kind)}
                  <li>
                    <div class="eh"><span>{ERROR_LABEL[e.kind] ?? e.kind}</span><b class="num">{fmtNum(e.count)}</b></div>
                    <span class="ea">{e.adapters.map((a) => `${app.adapters.find((x) => x.info.id === a.key)?.info.name ?? a.key} (${a.count})`).join(', ')}</span>
                  </li>
                {/each}
              </ul>
            {:else}
              <div class="faint small">Ошибок за период нет.</div>
            {/if}
          </Panel>
          {#if report.severities.length}
            <Panel title="Критичность находок аудита" scroll={false}>
              <Donut
                caption="проверок"
                items={report.severities.map((b) => ({ key: b.key, label: SEVERITY_META[b.key as Severity]?.label ?? b.key, value: b.count, color: SEVERITY_META[b.key as Severity]?.color ?? 'var(--silver)' }))}
              />
            </Panel>
          {/if}
        </div>
      </div>

      <Panel title="Производительность приложения" subtitle="реальные замеры этого компьютера" scroll={false}>
        <div class="perf">
          <div class="pm"><span class="pl">Частота кадров</span><span class="pv">{report.performance.fpsAvg !== null ? `${Math.round(report.performance.fpsAvg)} FPS` : '—'}</span><span class="ps">{report.performance.fpsMin !== null ? `минимум ${Math.round(report.performance.fpsMin)}` : 'нет замеров'}</span></div>
          <div class="pm wide"><span class="pl">FPS · последние замеры</span><Sparkline values={[...report.performance.fpsSeries].reverse()} name="FPS" /></div>
          <div class="pm"><span class="pl">Частицы (в среднем)</span><span class="pv">{report.performance.particlesAvg !== null ? fmtNum(Math.round(report.performance.particlesAvg)) : '—'}</span><span class="ps">сейчас {fmtNum(app.perf.particles)}</span></div>
          <div class="pm"><span class="pl">Память интерфейса</span><span class="pv">{report.performance.heapMbAvg !== null ? `${Math.round(report.performance.heapMbAvg)} МБ` : '—'}</span><span class="ps">{app.perf.heapMb !== null ? `сейчас ${Math.round(app.perf.heapMb)} МБ` : ''}</span></div>
          <div class="pm"><span class="pl">Графический движок</span><span class="pv sm">{report.performance.renderer ?? app.perf.backend}</span><span class="ps">{app.perf.gpu}</span></div>
        </div>
      </Panel>
    </div>
  {:else}
    <div class="empty"><Bits kind="spinner" /></div>
  {/if}
</div>

<style>
  .head {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .body {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 14px;
    padding-right: 4px;
    transition: opacity 0.2s;
  }
  .body.stale {
    opacity: 0.6;
  }
  .tiles {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 12px;
  }
  .trio {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 14px;
  }
  .quad {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 14px;
  }
  .duo {
    display: grid;
    grid-template-columns: minmax(0, 2.2fr) minmax(0, 1fr);
    gap: 14px;
    align-items: start;
  }
  .side {
    gap: 14px;
  }
  .r {
    text-align: right;
  }
  .bad {
    color: var(--err);
  }
  .errs {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 8px;
  }
  .eh {
    display: flex;
    justify-content: space-between;
    font-size: 12.5px;
  }
  .eh b {
    font-weight: 500;
  }
  .ea {
    font-size: 11px;
    color: var(--fg-3);
    line-height: 1.4;
  }
  .perf {
    display: grid;
    grid-template-columns: 1fr 1.6fr 1fr 1fr 1.4fr;
    gap: 18px;
  }
  .pm {
    display: flex;
    flex-direction: column;
    gap: 3px;
    min-width: 0;
  }
  .pl {
    font-size: 11.5px;
    color: var(--fg-3);
  }
  .pv {
    font-size: 20px;
    font-weight: 600;
    color: #fff;
  }
  .pv.sm {
    font-size: 13px;
    font-weight: 500;
    line-height: 1.4;
    word-break: break-word;
  }
  .ps {
    font-size: 11px;
    color: var(--fg-3);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
</style>
