//! E-mail and DNS hygiene of an own domain: SPF (including the 10-lookup limit), DMARC,
//! DKIM (common selectors), MTA-STS, TLS-RPT, CAA, DNSSEC and NS redundancy.

use sword_connectors::adapters::dns::{dmarc_policy, spf_all};
use sword_connectors::doh::{self, RecordType};
use sword_connectors::output::{FindingExt, OutputBuilder};
use sword_connectors::ConnectorContext;
use sword_core::{keys, AdapterInfo, AdapterOutput, Category, EntityKind, FindingKind, Severity, SwordResult};

const DKIM_SELECTORS: &[&str] = &[
    "default", "google", "selector1", "selector2", "k1", "k2", "mail", "dkim", "s1", "s2", "smtp", "mx", "email", "mta", "yandex",
];

fn issue(b: &mut OutputBuilder, domain: &str, sev: Severity, title: &str, details: &str, fix: &str, url: &str) {
    b.finding(Category::DomainIntel, FindingKind::AuditIssue, &format!("{domain}: {title}"), Some(url))
        .severity(sev)
        .snippet(details)
        .attr("Рекомендация", fix)
        .entity(&keys::domain(domain));
}

/// Count DNS-querying SPF mechanisms recursively (RFC 7208 §4.6.4 limit is 10).
/// Returns an explicitly boxed `Send` future so the recursion type-checks.
fn spf_lookups<'a>(
    ctx: &'a ConnectorContext,
    record: &'a str,
    depth: u8,
    budget: &'a mut u8,
) -> std::pin::Pin<Box<dyn std::future::Future<Output = u32> + Send + 'a>> {
    Box::pin(async move {
        let mut count = 0u32;
        for term in record.split_whitespace().skip(1) {
            let t = term.trim_start_matches(['+', '-', '~', '?']).to_lowercase();
            let is_lookup = t.starts_with("include:")
                || t == "a"
                || t.starts_with("a:")
                || t.starts_with("a/")
                || t == "mx"
                || t.starts_with("mx:")
                || t.starts_with("mx/")
                || t.starts_with("ptr")
                || t.starts_with("exists:")
                || t.starts_with("redirect=");
            if !is_lookup {
                continue;
            }
            count += 1;
            let target = t.strip_prefix("include:").or_else(|| t.strip_prefix("redirect=")).map(str::to_string);
            if let Some(target) = target {
                if depth < 4 && *budget > 0 {
                    *budget -= 1;
                    if let Ok(r) = doh::query(ctx, &target, RecordType::Txt).await {
                        if let Some(inner) = r.data_of(RecordType::Txt).into_iter().find(|x| x.to_lowercase().starts_with("v=spf1")) {
                            count += spf_lookups(ctx, &inner, depth + 1, &mut *budget).await;
                        }
                    }
                }
            }
        }
        count
    })
}

pub async fn check(ctx: &ConnectorContext, info: &AdapterInfo, domain: &str) -> SwordResult<AdapterOutput> {
    let mut b = OutputBuilder::new(info);
    let dkey = keys::domain(domain);
    b.entity(&dkey, EntityKind::Domain, domain);

    let mx = doh::query(ctx, domain, RecordType::Mx).await?;
    let has_mx = !mx.data_of(RecordType::Mx).is_empty();
    b.source(&mx.query_url, "DoH MX");

    // SPF
    let txt = doh::query(ctx, domain, RecordType::Txt).await?;
    let spf: Vec<String> = txt.data_of(RecordType::Txt).into_iter().filter(|t| t.to_lowercase().starts_with("v=spf1")).collect();
    match spf.as_slice() {
        [] => issue(
            &mut b,
            domain,
            Severity::High,
            "нет SPF-записи",
            "Без SPF любой сервер может отправлять письма от имени домена — это упрощает фишинг.",
            if has_mx { "Опубликуйте TXT «v=spf1 include:<ваш почтовый провайдер> -all»." } else { "Домен не отправляет почту: опубликуйте «v=spf1 -all»." },
            &txt.query_url,
        ),
        [one] => {
            let all = spf_all(one);
            let (sev, text) = match all.as_deref() {
                Some("+all") => (Severity::Critical, "SPF «+all» разрешает отправку почты от имени домена с любого сервера."),
                Some("?all") => (Severity::Medium, "SPF «?all» (neutral) не защищает от подделки отправителя."),
                Some("~all") => (Severity::Low, "SPF «~all» (softfail): подозрительные письма помечаются, но не отклоняются."),
                Some(_) => (Severity::Pass, "SPF завершается «-all» — посторонние отправители отклоняются."),
                None => (Severity::Medium, "В SPF нет механизма all — политика для остальных отправителей не определена."),
            };
            issue(&mut b, domain, sev, &format!("SPF {}", all.unwrap_or_else(|| "без all".into())), &format!("{text}\n{one}"), "Рекомендуется завершать SPF механизмом «-all» после проверки всех легитимных отправителей.", &txt.query_url);
            let mut budget = 12u8;
            let lookups = spf_lookups(ctx, one, 0, &mut budget).await;
            if lookups > 10 {
                issue(&mut b, domain, Severity::Medium, &format!("SPF требует {lookups} DNS-запросов (> 10)"), "Превышение лимита RFC 7208 приводит к PermError — проверка SPF у получателей завершается ошибкой.", "Сократите вложенные include или используйте ip4/ip6 вместо части include.", &txt.query_url);
            }
        }
        many => issue(&mut b, domain, Severity::High, &format!("{} SPF-записей", many.len()), "Несколько записей v=spf1 — по RFC 7208 это PermError, SPF фактически не работает.", "Объедините механизмы в одну запись v=spf1.", &txt.query_url),
    }

    // DMARC
    let dmarc = doh::query(ctx, &format!("_dmarc.{domain}"), RecordType::Txt).await?;
    b.source(&dmarc.query_url, "DoH _dmarc");
    match dmarc.data_of(RecordType::Txt).into_iter().find(|t| t.to_lowercase().starts_with("v=dmarc1")) {
        None => issue(&mut b, domain, Severity::High, "нет DMARC", "Получатели не знают, что делать с письмами, не прошедшими SPF/DKIM.", "Начните с «v=DMARC1; p=none; rua=mailto:dmarc@<домен>», затем ужесточите до quarantine/reject.", &dmarc.query_url),
        Some(rec) => {
            let policy = dmarc_policy(&rec).unwrap_or_default();
            let (sev, text) = match policy.as_str() {
                "reject" => (Severity::Pass, "Политика reject — поддельные письма отклоняются."),
                "quarantine" => (Severity::Low, "Политика quarantine — поддельные письма попадают в спам."),
                "none" => (Severity::Medium, "Политика none — только мониторинг, защита от подделки не действует."),
                _ => (Severity::Medium, "Политика DMARC не распознана."),
            };
            issue(&mut b, domain, sev, &format!("DMARC p={policy}"), &format!("{text}\n{rec}"), "Целевое состояние — p=reject с отчётами rua.", &dmarc.query_url);
            if !rec.to_lowercase().contains("rua=") {
                issue(&mut b, domain, Severity::Low, "DMARC без отчётов (rua)", "Без агрегированных отчётов нельзя увидеть, кто отправляет почту от имени домена.", "Добавьте rua=mailto:<адрес для отчётов>.", &dmarc.query_url);
            }
            if let Some(pct) = rec.split(';').map(str::trim).find_map(|kv| kv.strip_prefix("pct=")).and_then(|v| v.parse::<u32>().ok()) {
                if pct < 100 {
                    issue(&mut b, domain, Severity::Low, &format!("DMARC применяется к {pct}% писем"), "Политика распространяется не на все письма.", "Установите pct=100 после периода наблюдения.", &dmarc.query_url);
                }
            }
        }
    }

    // DKIM — common selectors only (selectors are not discoverable in DNS)
    if has_mx {
        let mut found = Vec::new();
        for sel in DKIM_SELECTORS {
            if ctx.cancel.is_cancelled() {
                break;
            }
            if let Ok(r) = doh::query(ctx, &format!("{sel}._domainkey.{domain}"), RecordType::Txt).await {
                if let Some(rec) = r.data_of(RecordType::Txt).into_iter().find(|t| t.contains("p=")) {
                    let key_len = rec.split(';').map(str::trim).find_map(|kv| kv.strip_prefix("p=")).map(|p| p.len()).unwrap_or(0);
                    found.push((sel.to_string(), key_len, r.query_url.clone()));
                }
            }
        }
        if found.is_empty() {
            issue(&mut b, domain, Severity::Info, "DKIM не найден по распространённым селекторам", &format!("Проверены селекторы: {}. Селектор может отличаться — уточните у почтового провайдера.", DKIM_SELECTORS.join(", ")), "Убедитесь, что исходящая почта подписывается DKIM (ключ RSA ≥ 2048 бит).", &mx.query_url);
        }
        for (sel, len, url) in found {
            if len == 0 {
                issue(&mut b, domain, Severity::Info, &format!("DKIM {sel}: ключ отозван"), "Пустое значение p= означает отозванный ключ.", "Удалите неиспользуемую запись.", &url);
            } else if len < 300 {
                issue(&mut b, domain, Severity::Medium, &format!("DKIM {sel}: короткий ключ (~1024 бит)"), "Ключи RSA 1024 бит считаются недостаточно стойкими.", "Перейдите на RSA 2048 бит или Ed25519.", &url);
            } else {
                issue(&mut b, domain, Severity::Pass, &format!("DKIM {sel}: ключ опубликован"), "Ключ подписи DKIM найден.", "—", &url);
            }
        }
        // MTA-STS / TLS-RPT
        let sts = doh::query(ctx, &format!("_mta-sts.{domain}"), RecordType::Txt).await?;
        if sts.data_of(RecordType::Txt).iter().any(|t| t.to_lowercase().starts_with("v=stsv1")) {
            issue(&mut b, domain, Severity::Pass, "MTA-STS включён", "Отправители обязаны доставлять почту по TLS.", "—", &sts.query_url);
        } else {
            issue(&mut b, domain, Severity::Low, "нет MTA-STS", "Без MTA-STS возможна атака понижения до незашифрованной доставки почты.", "Опубликуйте _mta-sts TXT и политику https://mta-sts.<домен>/.well-known/mta-sts.txt.", &sts.query_url);
        }
        let rpt = doh::query(ctx, &format!("_smtp._tls.{domain}"), RecordType::Txt).await?;
        if !rpt.data_of(RecordType::Txt).iter().any(|t| t.to_lowercase().starts_with("v=tlsrptv1")) {
            issue(&mut b, domain, Severity::Info, "нет TLS-RPT", "Не настроены отчёты о проблемах TLS при доставке почты.", "Опубликуйте _smtp._tls TXT «v=TLSRPTv1; rua=mailto:…».", &rpt.query_url);
        }
    } else {
        issue(&mut b, domain, Severity::Info, "домен не принимает почту (нет MX)", "Для таких доменов важны SPF «-all» и DMARC «p=reject», чтобы их нельзя было подделать.", "Опубликуйте v=spf1 -all и v=DMARC1; p=reject.", &mx.query_url);
    }

    // CAA
    let caa = doh::query(ctx, domain, RecordType::Caa).await?;
    let caa_records = caa.data_of(RecordType::Caa);
    if caa_records.is_empty() {
        issue(&mut b, domain, Severity::Low, "нет CAA", "Любой удостоверяющий центр может выпустить сертификат для домена.", "Ограничьте выпуск сертификатов записями CAA (например, 0 issue \"letsencrypt.org\").", &caa.query_url);
    } else {
        issue(&mut b, domain, Severity::Pass, "CAA настроены", &caa_records.join("\n"), "—", &caa.query_url);
    }

    // DNSSEC
    let a = doh::query(ctx, domain, RecordType::A).await?;
    if a.ad {
        issue(&mut b, domain, Severity::Pass, "DNSSEC проверен", "Резолвер подтвердил подпись зоны (флаг AD).", "—", &a.query_url);
    } else {
        issue(&mut b, domain, Severity::Low, "DNSSEC не подтверждён", "Ответы DNS не подписаны или подпись не проверяется — возможна подмена ответов.", "Включите DNSSEC у DNS-провайдера и опубликуйте DS у регистратора.", &a.query_url);
    }

    // NS redundancy
    let ns = doh::query(ctx, domain, RecordType::Ns).await?;
    let ns_list = ns.data_of(RecordType::Ns);
    if ns_list.len() < 2 {
        issue(&mut b, domain, Severity::Medium, "меньше двух DNS-серверов", "Отказ единственного сервера сделает домен недоступным.", "Используйте не менее двух NS в разных сетях.", &ns.query_url);
    }
    b.fact("DNS-гигиена", &format!("{domain}: проверены SPF, DMARC, DKIM, MTA-STS, CAA, DNSSEC, NS"), &a.query_url);
    Ok(b.finish())
}
