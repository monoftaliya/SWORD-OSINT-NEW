//! # sword-graph — Network Engine
//!
//! Assembles the relationship graph from adapter outputs. Rules:
//!
//! * a node exists only if some adapter described it or referenced it in a relation;
//! * an edge exists only for a structured, source-backed statement ([`Relation`]) and
//!   keeps *all* evidence (source URL, adapter, time) that supports it;
//! * duplicate statements from several sources raise confidence to the maximum observed
//!   and accumulate evidence;
//! * optional «Verified Sources» nodes link every entity to the sources that confirmed it,
//!   making the origin of every fact visible in the 3D view and in reports.

pub mod export;
pub mod layout;

use std::collections::{BTreeSet, HashMap};

use serde::{Deserialize, Serialize};
use sword_core::{keys, util, AdapterOutput, Entity, EntityKind, Evidence, NodeAttribute, Relation};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GraphNode {
    pub key: String,
    pub kind: EntityKind,
    pub label: String,
    pub attributes: Vec<NodeAttribute>,
    /// Adapter ids that reported this node.
    pub sources: Vec<String>,
    pub degree: u32,
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct GraphEdge {
    pub id: String,
    pub from: String,
    pub to: String,
    pub relation: String,
    pub label: String,
    pub confidence: f32,
    pub evidence: Vec<Evidence>,
}

#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Graph {
    pub nodes: Vec<GraphNode>,
    pub edges: Vec<GraphEdge>,
}

impl Graph {
    pub fn node(&self, key: &str) -> Option<&GraphNode> {
        self.nodes.iter().find(|n| n.key == key)
    }

    /// Average confidence of all edges (0 when empty).
    pub fn mean_confidence(&self) -> f32 {
        if self.edges.is_empty() {
            return 0.0;
        }
        self.edges.iter().map(|e| e.confidence).sum::<f32>() / self.edges.len() as f32
    }

    /// Drop edges below `min_confidence` and nodes left without edges (except roots
    /// given in `keep`).
    pub fn filtered(&self, min_confidence: f32, keep: &[String]) -> Graph {
        let edges: Vec<GraphEdge> = self.edges.iter().filter(|e| e.confidence >= min_confidence).cloned().collect();
        let mut used: BTreeSet<&str> = edges.iter().flat_map(|e| [e.from.as_str(), e.to.as_str()]).collect();
        for k in keep {
            used.insert(k.as_str());
        }
        let nodes = self.nodes.iter().filter(|n| used.contains(n.key.as_str())).cloned().collect();
        let mut g = Graph { nodes, edges };
        g.recompute_degrees();
        g
    }

    pub fn recompute_degrees(&mut self) {
        let mut deg: HashMap<&str, u32> = HashMap::new();
        for e in &self.edges {
            *deg.entry(e.from.as_str()).or_default() += 1;
            *deg.entry(e.to.as_str()).or_default() += 1;
        }
        let degrees: Vec<u32> = self.nodes.iter().map(|n| deg.get(n.key.as_str()).copied().unwrap_or(0)).collect();
        for (n, d) in self.nodes.iter_mut().zip(degrees) {
            n.degree = d;
        }
    }
}

/// Russian label of a relation type.
pub fn relation_label(relation: &str) -> &'static str {
    match relation {
        "hosted_on" => "размещено на домене",
        "subdomain_of" => "поддомен",
        "official_website" => "официальный сайт",
        "official_account" => "официальный аккаунт",
        "declares_website" => "указывает сайт",
        "declares_profile" => "ссылается на профиль",
        "registered_via" => "зарегистрирован через",
        "hosted_on_network" => "сеть размещения (RIR)",
        "mail_handled_by" => "почта обслуживается",
        "dns_hosted_by" => "DNS обслуживается",
        "certificates_issued_by" => "сертификаты выданы",
        "subsidiary_of" => "дочерняя организация",
        "parent_of" => "материнская организация",
        "maintained_by" => "поддерживается",
        "affiliated_with" => "аффилиация",
        "published_on" => "опубликовано на",
        "same_as" => "тот же объект",
        "documented_by" => "подтверждено источником",
        _ => "связь",
    }
}

/// Incrementally merges adapter outputs into a graph.
#[derive(Default)]
pub struct GraphBuilder {
    nodes: Vec<GraphNode>,
    node_index: HashMap<String, usize>,
    edges: Vec<GraphEdge>,
    edge_index: HashMap<(String, String, String), usize>,
}

impl GraphBuilder {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn add_output(&mut self, adapter_id: &str, output: &AdapterOutput) {
        for e in &output.entities {
            self.add_entity(adapter_id, e);
        }
        for r in &output.relations {
            self.add_relation(r);
        }
    }

    pub fn add_entity(&mut self, adapter_id: &str, e: &Entity) {
        let idx = self.ensure_node(&e.key, Some(e.kind), Some(&e.label));
        let node = &mut self.nodes[idx];
        if !node.sources.iter().any(|s| s == adapter_id) {
            node.sources.push(adapter_id.to_string());
        }
        for a in &e.attributes {
            let duplicate = node.attributes.iter().any(|x| x.label == a.label && x.value == a.value);
            if !duplicate {
                node.attributes.push(a.clone());
            }
        }
    }

    pub fn add_relation(&mut self, r: &Relation) {
        if r.from == r.to {
            return;
        }
        self.ensure_node(&r.from, None, None);
        self.ensure_node(&r.to, None, None);
        for key in [&r.from, &r.to] {
            if let Some(&i) = self.node_index.get(key.as_str()) {
                let n = &mut self.nodes[i];
                if !n.sources.iter().any(|s| s == &r.evidence.adapter_id) {
                    n.sources.push(r.evidence.adapter_id.clone());
                }
            }
        }
        let k = (r.from.clone(), r.to.clone(), r.relation.clone());
        match self.edge_index.get(&k) {
            Some(&i) => {
                let edge = &mut self.edges[i];
                edge.confidence = edge.confidence.max(r.confidence);
                let dup = edge
                    .evidence
                    .iter()
                    .any(|ev| ev.source_url == r.evidence.source_url && ev.adapter_id == r.evidence.adapter_id);
                if !dup {
                    edge.evidence.push(r.evidence.clone());
                }
            }
            None => {
                let id = util::short_hash(&[&r.from, &r.relation, &r.to]);
                self.edges.push(GraphEdge {
                    id,
                    from: r.from.clone(),
                    to: r.to.clone(),
                    relation: r.relation.clone(),
                    label: relation_label(&r.relation).to_string(),
                    confidence: r.confidence.clamp(0.0, 1.0),
                    evidence: vec![r.evidence.clone()],
                });
                self.edge_index.insert(k, self.edges.len() - 1);
            }
        }
    }

    /// Add one «Verified Source» node per adapter and connect every node to the sources
    /// that reported it (`documented_by`). `names` maps adapter id → display name, and
    /// `homepages` adapter id → canonical URL of the source.
    pub fn add_source_nodes(&mut self, names: &HashMap<String, String>, homepages: &HashMap<String, String>) {
        let now = util::now();
        let snapshot: Vec<(String, Vec<String>)> = self
            .nodes
            .iter()
            .filter(|n| n.kind != EntityKind::Source)
            .map(|n| (n.key.clone(), n.sources.clone()))
            .collect();
        for (key, sources) in snapshot {
            for adapter in sources {
                let skey = keys::source(&adapter);
                let label = names.get(&adapter).cloned().unwrap_or_else(|| adapter.clone());
                let idx = self.ensure_node(&skey, Some(EntityKind::Source), Some(&label));
                if !self.nodes[idx].sources.contains(&adapter) {
                    self.nodes[idx].sources.push(adapter.clone());
                }
                let url = homepages.get(&adapter).cloned().unwrap_or_default();
                self.add_relation(&Relation {
                    from: key.clone(),
                    to: skey,
                    relation: "documented_by".into(),
                    confidence: 1.0,
                    evidence: Evidence { source_url: url, adapter_id: adapter.clone(), retrieved_at: now, note: None },
                });
            }
        }
    }

    pub fn build(self) -> Graph {
        let mut g = Graph { nodes: self.nodes, edges: self.edges };
        g.recompute_degrees();
        g
    }

    fn ensure_node(&mut self, key: &str, kind: Option<EntityKind>, label: Option<&str>) -> usize {
        if let Some(&i) = self.node_index.get(key) {
            if let Some(l) = label {
                let node = &mut self.nodes[i];
                // Prefer a human label over a key-derived fallback.
                if node.label == keys::label_of(key) && l != node.label && !l.is_empty() {
                    node.label = l.to_string();
                }
            }
            return i;
        }
        let kind = kind.or_else(|| keys::kind_of(key)).unwrap_or(EntityKind::Website);
        let label = label.filter(|l| !l.is_empty()).map(str::to_string).unwrap_or_else(|| keys::label_of(key));
        self.nodes.push(GraphNode {
            key: key.to_string(),
            kind,
            label,
            attributes: Vec::new(),
            sources: Vec::new(),
            degree: 0,
        });
        self.node_index.insert(key.to_string(), self.nodes.len() - 1);
        self.nodes.len() - 1
    }
}

/// Merge several graphs (e.g. all investigations) by entity key.
pub fn merge(graphs: impl IntoIterator<Item = Graph>) -> Graph {
    let mut b = GraphBuilder::new();
    for g in graphs {
        for n in g.nodes {
            let idx = b.ensure_node(&n.key, Some(n.kind), Some(&n.label));
            let node = &mut b.nodes[idx];
            for s in n.sources {
                if !node.sources.contains(&s) {
                    node.sources.push(s);
                }
            }
            for a in n.attributes {
                if !node.attributes.iter().any(|x| x.label == a.label && x.value == a.value) {
                    node.attributes.push(a);
                }
            }
        }
        for e in g.edges {
            for ev in e.evidence {
                b.add_relation(&Relation {
                    from: e.from.clone(),
                    to: e.to.clone(),
                    relation: e.relation.clone(),
                    confidence: e.confidence,
                    evidence: ev,
                });
            }
        }
    }
    b.build()
}

#[cfg(test)]
mod tests {
    use super::*;
    use sword_core::util::now;

    fn ev(adapter: &str, url: &str) -> Evidence {
        Evidence { source_url: url.into(), adapter_id: adapter.into(), retrieved_at: now(), note: None }
    }

    #[test]
    fn merges_relations_and_evidence() {
        let mut b = GraphBuilder::new();
        let out = AdapterOutput {
            entities: vec![Entity {
                key: keys::domain("example.com"),
                kind: EntityKind::Domain,
                label: "example.com".into(),
                attributes: vec![],
            }],
            relations: vec![Relation {
                from: keys::org("wikidata", "Q1"),
                to: keys::domain("example.com"),
                relation: "official_website".into(),
                confidence: 0.85,
                evidence: ev("wikidata", "https://www.wikidata.org/wiki/Q1"),
            }],
            ..Default::default()
        };
        b.add_output("wikidata", &out);
        b.add_relation(&Relation {
            from: keys::org("wikidata", "Q1"),
            to: keys::domain("example.com"),
            relation: "official_website".into(),
            confidence: 0.9,
            evidence: ev("website", "https://example.com/"),
        });
        let g = b.build();
        assert_eq!(g.nodes.len(), 2);
        assert_eq!(g.edges.len(), 1);
        assert_eq!(g.edges[0].evidence.len(), 2);
        assert!((g.edges[0].confidence - 0.9).abs() < f32::EPSILON);
        assert_eq!(g.node("org:wikidata:Q1").unwrap().kind, EntityKind::Organization);
    }

    #[test]
    fn source_nodes_document_provenance() {
        let mut b = GraphBuilder::new();
        b.add_entity(
            "rdap",
            &Entity { key: keys::domain("a.ru"), kind: EntityKind::Domain, label: "a.ru".into(), attributes: vec![] },
        );
        let names = HashMap::from([("rdap".to_string(), "RDAP".to_string())]);
        b.add_source_nodes(&names, &HashMap::new());
        let g = b.build();
        assert!(g.node("source:rdap").is_some());
        assert_eq!(g.edges[0].relation, "documented_by");
    }
}
