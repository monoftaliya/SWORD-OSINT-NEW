/**
 * Typed mirror of the Rust DTOs (serde camelCase). Keep in sync with
 * crates/sword-core (model.rs, adapter_meta.rs, settings.rs), crates/sword-db,
 * crates/sword-analytics, crates/sword-report and src-tauri/src/commands.
 */

export type Category =
  | 'web_search'
  | 'social_networks'
  | 'vk'
  | 'telegram'
  | 'public_websites'
  | 'domain_intel'
  | 'email_exposure'
  | 'public_documents'
  | 'org_intel'
  | 'digital_footprint';

export type InputKind = 'domain' | 'url' | 'email' | 'ip' | 'vk_ref' | 'telegram_ref' | 'text';

export type FindingKind =
  | 'web_page'
  | 'document'
  | 'publication'
  | 'social_post'
  | 'community'
  | 'channel'
  | 'organization'
  | 'domain'
  | 'dns_record'
  | 'registration'
  | 'certificate'
  | 'subdomain'
  | 'archive'
  | 'breach'
  | 'project'
  | 'website'
  | 'network'
  | 'encyclopedia'
  | 'audit_issue';

export type Severity = 'critical' | 'high' | 'medium' | 'low' | 'info' | 'pass';
export type EntityKind = 'domain' | 'organization' | 'website' | 'project' | 'document' | 'publication' | 'source';
export type RunStatus = 'queued' | 'running' | 'done' | 'failed' | 'skipped' | 'cancelled' | 'timed_out';
export type InvestigationKind = 'discovery' | 'exposure_audit';
export type InvestigationStatus = 'running' | 'completed' | 'partial' | 'failed' | 'cancelled';
export type ErrorKind =
  | 'network'
  | 'timeout'
  | 'rate_limited'
  | 'unauthorized'
  | 'forbidden'
  | 'not_found'
  | 'invalid_input'
  | 'not_configured'
  | 'parse'
  | 'database'
  | 'io'
  | 'cancelled'
  | 'upstream'
  | 'unsupported'
  | 'internal';
export type AdapterHealth = 'online' | 'degraded' | 'unconfigured' | 'unauthorized' | 'rate_limited' | 'offline' | 'disabled' | 'unknown';

export interface ApiError {
  kind: ErrorKind;
  message: string;
}

export interface ClassifiedInput {
  raw: string;
  kind: InputKind;
  text: string;
  domain: string | null;
  registrableDomain: string | null;
  url: string | null;
  email: string | null;
  ip: string | null;
  handle: string | null;
  handleQuery: string | null;
}

export interface Attr {
  label: string;
  value: string;
}

export interface Finding {
  id: string;
  adapterId: string;
  category: Category;
  kind: FindingKind;
  title: string;
  url: string | null;
  snippet: string | null;
  publishedAt: string | null;
  retrievedAt: string;
  confidence: number;
  severity: Severity | null;
  attributes: Attr[];
  entityKey: string | null;
}

export interface NodeAttribute {
  label: string;
  value: string;
  sourceUrl: string;
  adapterId: string;
  retrievedAt: string;
}

export interface Evidence {
  sourceUrl: string;
  adapterId: string;
  retrievedAt: string;
  note: string | null;
}

export interface GraphNode {
  key: string;
  kind: EntityKind;
  label: string;
  attributes: NodeAttribute[];
  sources: string[];
  degree: number;
}

export interface GraphEdge {
  id: string;
  from: string;
  to: string;
  relation: string;
  label: string;
  confidence: number;
  evidence: Evidence[];
}

export interface Graph {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export interface SourceRef {
  url: string;
  title: string;
  adapterId: string;
  retrievedAt: string;
}

export interface KeyFact {
  label: string;
  value: string;
  adapterId: string;
  sourceUrl: string;
}

export interface AdapterRun {
  adapterId: string;
  adapterName: string;
  status: RunStatus;
  startedAt: string | null;
  finishedAt: string | null;
  durationMs: number | null;
  resultCount: number;
  errorKind: ErrorKind | null;
  message: string | null;
}

export interface PlannedAdapter {
  adapterId: string;
  name: string;
  categories: Category[];
  willRun: boolean;
  reason: string | null;
}

export interface InvestigationRecord {
  id: string;
  kind: InvestigationKind;
  query: string;
  inputKind: InputKind;
  categories: Category[];
  status: InvestigationStatus;
  createdAt: string;
  finishedAt: string | null;
  durationMs: number | null;
  resultCount: number;
  sourceCount: number;
  nodeCount: number;
  edgeCount: number;
  adapters: string[];
  summary: string;
  keyFacts: KeyFact[];
  limitations: string[];
  error: string | null;
  notes: string;
}

export interface InvestigationRequest {
  query: string;
  categories: Category[];
  adapters?: string[];
}

export type InvestigationEvent =
  | { type: 'started'; investigationId: string; kind: InvestigationKind; query: string; input: ClassifiedInput; plan: PlannedAdapter[] }
  | { type: 'adapterUpdate'; investigationId: string; run: AdapterRun }
  | { type: 'findings'; investigationId: string; adapterId: string; findings: Finding[] }
  | { type: 'finished'; investigationId: string; record: InvestigationRecord };

// ---------------------------------------------------------------- adapters

export interface CredentialSpec {
  key: string;
  label: string;
  required: boolean;
  help: string;
  helpUrl: string | null;
  placeholder: string | null;
}

export interface OptionSpec {
  key: string;
  label: string;
  required: boolean;
  default: string | null;
  help: string;
  placeholder: string | null;
}

export interface AdapterInfo {
  id: string;
  name: string;
  provider: string;
  description: string;
  methodology: string;
  categories: Category[];
  inputKinds: InputKind[];
  credentials: CredentialSpec[];
  options: OptionSpec[];
  rateLimitPerMinute: number;
  homepage: string;
  docsUrl: string | null;
  officialApi: boolean;
}

export interface PermissionCheck {
  name: string;
  granted: boolean;
  detail: string;
}

export interface AdapterStatus {
  adapterId: string;
  health: AdapterHealth;
  message: string;
  checkedAt: string | null;
  lastSuccessAt: string | null;
  latencyMs: number | null;
  permissions: PermissionCheck[];
}

export interface CredentialState {
  key: string;
  isSet: boolean;
  updatedAt: string | null;
  fingerprint: string | null;
}

export interface AdapterView {
  info: AdapterInfo;
  enabled: boolean;
  configured: boolean;
  missing: string[];
  credentials: CredentialState[];
  options: Record<string, string>;
  status: AdapterStatus;
}

// ---------------------------------------------------------------- settings

export interface NetworkSettings {
  requestTimeoutSecs: number;
  adapterTimeoutSecs: number;
  maxConcurrency: number;
  maxResultsPerAdapter: number;
  proxyUrl: string | null;
  contactEmail: string | null;
  dohProvider: 'cloudflare' | 'google';
}

export interface GraphicsSettings {
  renderer: 'auto' | 'webgpu' | 'webgl2';
  quality: 'auto' | 'low' | 'medium' | 'high' | 'ultra';
  bloom: boolean;
  trails: boolean;
  fpsLimit: number;
  reduceMotion: boolean;
  backgroundAnimation: boolean;
  maxPixelRatio: number;
  showFps: boolean;
}

export interface AppSettings {
  network: NetworkSettings;
  adapters: Record<string, { enabled: boolean; options: Record<string, string> }>;
  graphics: GraphicsSettings;
  privacy: { retentionDays: number; storeSnippets: boolean };
  search: { backend: 'sqlite' | 'opensearch'; opensearchUrl: string | null; opensearchIndex: string; opensearchUsername: string | null };
  report: { author: string; organization: string; classification: string; theme: ReportTheme; paper: 'a4' | 'letter' };
}

// ---------------------------------------------------------------- history & knowledge

export interface HistoryQuery {
  search?: string;
  status?: string;
  kind?: string;
  category?: string;
  adapter?: string;
  from?: string;
  to?: string;
  sort?: 'created_desc' | 'created_asc' | 'results_desc' | 'results_asc' | 'duration_desc' | 'query_asc' | 'sources_desc';
  limit?: number;
  offset?: number;
}

export interface HistoryPage {
  items: InvestigationRecord[];
  total: number;
}

export interface InvestigationDetail {
  record: InvestigationRecord;
  runs: AdapterRun[];
  findings: Finding[];
  sources: SourceRef[];
}

export interface FindingBrief {
  title: string;
  url: string | null;
  adapterId: string;
  kind: FindingKind;
}

export interface AdapterDelta {
  adapterId: string;
  adapterName: string;
  aStatus: RunStatus | null;
  bStatus: RunStatus | null;
  aResults: number | null;
  bResults: number | null;
}

export interface Comparison {
  a: InvestigationRecord;
  b: InvestigationRecord;
  commonSources: string[];
  onlyASources: string[];
  onlyBSources: string[];
  commonFindings: FindingBrief[];
  onlyAFindings: FindingBrief[];
  onlyBFindings: FindingBrief[];
  commonEntities: string[];
  onlyAEntities: string[];
  onlyBEntities: string[];
  adapters: AdapterDelta[];
}

export interface KnowledgeQuery {
  text: string;
  adapter?: string;
  category?: string;
  kind?: string;
  limit?: number;
}

export interface KnowledgeHit {
  finding: Finding;
  investigationId: string;
  investigationQuery: string;
  investigationCreatedAt: string;
  rank: number;
}

export interface GraphScope {
  investigationId?: string;
  recent?: number;
}

// ---------------------------------------------------------------- intelligence

export type AssetKind = 'email' | 'domain' | 'repo_local' | 'repo_github';

export interface Asset {
  id: string;
  kind: AssetKind;
  display: string;
  valueHash: string;
  plainValue: string | null;
  attested: boolean;
  verified: boolean;
  verificationToken: string | null;
  createdAt: string;
  verifiedAt: string | null;
}

export type AuditCheck =
  | 'email_breaches'
  | 'dns_hygiene'
  | 'web_config'
  | 'tls'
  | 'exposed_files'
  | 'dangling_dns'
  | 'incidents'
  | 'surface'
  | 'secrets_local'
  | 'secrets_github';

export interface PasswordExposure {
  exposed: boolean;
  count: number;
  bucketSize: number;
}

// ---------------------------------------------------------------- analytics

export interface Bucket {
  key: string;
  count: number;
}

export interface AnalyticsReport {
  rangeDays: number;
  generatedAt: string;
  totals: {
    investigations: number;
    audits: number;
    completed: number;
    partial: number;
    failed: number;
    cancelled: number;
    findings: number;
    uniqueSources: number;
    adapterRuns: number;
    successRate: number;
    avgDurationMs: number;
    graphNodes: number;
    graphEdges: number;
    reports: number;
  };
  perDay: { date: string; investigations: number; findings: number; errors: number }[];
  adapters: {
    adapterId: string;
    adapterName: string;
    runs: number;
    done: number;
    failed: number;
    skipped: number;
    results: number;
    avgMs: number;
    p95Ms: number;
    lastRun: string | null;
  }[];
  categories: Bucket[];
  findingKinds: Bucket[];
  topSourceHosts: Bucket[];
  statuses: Bucket[];
  severities: Bucket[];
  errors: { kind: string; count: number; adapters: Bucket[] }[];
  performance: {
    avgInvestigationMs: number;
    p95InvestigationMs: number;
    fpsAvg: number | null;
    fpsMin: number | null;
    fpsSeries: number[];
    heapMbAvg: number | null;
    reportMsAvg: number | null;
    renderer: string | null;
    particlesAvg: number | null;
    dbSizeBytes: number;
    appVersion: string;
  };
}

// ---------------------------------------------------------------- reports

export type SectionId = 'query' | 'methodology' | 'sources' | 'findings' | 'summary' | 'graph' | 'references' | 'limitations';
export type ReportTheme = 'graphite' | 'midnight' | 'paper';

export interface ReportOptions {
  title: string | null;
  sections: SectionId[];
  notes: Record<string, string>;
  analystConclusion: string;
  theme: ReportTheme;
  accent: 'silver' | 'ice' | 'amber';
  paper: 'a4' | 'letter';
  author: string;
  organization: string;
  classification: string;
  maxFindingsPerCategory: number;
  includeEdgeTable: boolean;
  includeSourceNodes: boolean;
}

export interface ReportRecord {
  id: string;
  investigationId: string | null;
  title: string;
  createdAt: string;
  path: string;
  pages: number;
  bytes: number;
  durationMs: number;
  exists: boolean;
}

// ---------------------------------------------------------------- storage & system

export interface DbStats {
  path: string;
  sizeBytes: number;
  walBytes: number;
  pageSize: number;
  pageCount: number;
  freelistPages: number;
  schemaVersion: number;
  sqliteVersion: string;
  tables: { name: string; rows: number }[];
}

export interface AppInfo {
  name: string;
  version: string;
  dataDir: string;
  dbPath: string;
  reportsDir: string;
  logsDir: string;
  os: string;
  arch: string;
  uptimeSecs: number;
  vaultPersistent: boolean;
  adapters: number;
}

export interface MetricSample {
  name: string;
  value: number;
  labels?: string | null;
}
