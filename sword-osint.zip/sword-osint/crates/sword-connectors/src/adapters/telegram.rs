//! Telegram — public channels only, through officially provided public interfaces:
//!
//! * the public channel web preview `https://t.me/s/<channel>` (published by Telegram for
//!   every public channel, supports in-channel search via `?q=`);
//! * optionally the Telegram Bot API (`getChat`, `getChatMemberCount`) with the analyst's
//!   own bot token for channel metadata.
//!
//! Private chats, private channels and user profiles are never queried; no MTProto user
//! session is used.

use async_trait::async_trait;
use scraper::{Html, Selector};
use serde_json::Value;
use sword_core::util::parse_date;
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordError, SwordResult,
};

use super::{cred, info, num, s};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::http;
use crate::output::{FindingExt, OutputBuilder};

const BOT_TOKEN: &str = "telegram.bot_token";

pub struct Telegram {
    info: AdapterInfo,
}

impl Default for Telegram {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Default)]
struct ChannelPage {
    title: Option<String>,
    description: Option<String>,
    subscribers: Option<String>,
    links: Vec<String>,
    posts: Vec<Post>,
}

struct Post {
    path: String,
    text: String,
    datetime: Option<String>,
    views: Option<String>,
}

fn parse_channel_page(html: &str) -> ChannelPage {
    let doc = Html::parse_document(html);
    let sel = |q: &str| Selector::parse(q).expect("static selector");
    let text_of = |el: scraper::ElementRef<'_>| el.text().collect::<Vec<_>>().join(" ").split_whitespace().collect::<Vec<_>>().join(" ");
    let mut page = ChannelPage::default();
    page.title = doc.select(&sel(".tgme_channel_info_header_title")).next().map(text_of).filter(|t| !t.is_empty());
    if let Some(desc) = doc.select(&sel(".tgme_channel_info_description")).next() {
        page.description = Some(text_of(desc)).filter(|t| !t.is_empty());
        for a in desc.select(&sel("a[href]")) {
            if let Some(h) = a.value().attr("href") {
                if h.starts_with("http") && !h.contains("t.me/") {
                    page.links.push(h.to_string());
                }
            }
        }
    }
    for c in doc.select(&sel(".tgme_channel_info_counter")) {
        let ty = c.select(&sel(".counter_type")).next().map(text_of).unwrap_or_default();
        if ty.contains("subscriber") || ty.contains("подписчик") {
            page.subscribers = c.select(&sel(".counter_value")).next().map(text_of);
        }
    }
    let text_sel = sel(".tgme_widget_message_text");
    let date_sel = sel(".tgme_widget_message_date time");
    let views_sel = sel(".tgme_widget_message_views");
    for m in doc.select(&sel(".tgme_widget_message[data-post]")) {
        let Some(path) = m.value().attr("data-post") else { continue };
        page.posts.push(Post {
            path: path.to_string(),
            text: m.select(&text_sel).next().map(text_of).unwrap_or_default(),
            datetime: m.select(&date_sel).next().and_then(|t| t.value().attr("datetime")).map(str::to_string),
            views: m.select(&views_sel).next().map(text_of),
        });
    }
    page
}

impl Telegram {
    pub fn new() -> Self {
        Telegram {
            info: info(
                "telegram",
                "Telegram (публичные каналы)",
                "Telegram",
                "Публичные каналы Telegram: описание, число подписчиков, последние публикации и поиск внутри канала (@канал запрос).",
                "Официальный публичный веб-предпросмотр каналов (t.me/s/<канал>, поиск внутри канала — параметр q); \
                 при наличии токена бота — Telegram Bot API getChat и getChatMemberCount. Закрытые чаты и профили пользователей не запрашиваются.",
                &[Category::Telegram, Category::SocialNetworks],
                &[InputKind::TelegramRef],
                vec![cred(
                    BOT_TOKEN,
                    "Токен бота (необязательно)",
                    false,
                    "Создайте бота у @BotFather командой /newbot и скопируйте выданный токен. Бот используется только для чтения \
                     метаданных публичных каналов (getChat).",
                    Some("https://core.telegram.org/bots/features#botfather"),
                    Some("123456789:AA…"),
                )],
                vec![],
                20,
                "https://telegram.org/",
                Some("https://core.telegram.org/bots/api#getchat"),
                true,
            ),
        }
    }

    async fn bot(&self, ctx: &ConnectorContext, token: &str, method: &str, chat: &str) -> SwordResult<Value> {
        let url = format!("https://api.telegram.org/bot{token}/{method}");
        let resp = ctx.send_with("telegram-bot", 25, ctx.get(&url).query(&[("chat_id", chat)])).await?;
        let status = resp.status();
        let v: Value = serde_json::from_str(&http::read_text(resp, 1024 * 1024).await?).map_err(|e| SwordError::Parse(e.to_string()))?;
        if v.get("ok").and_then(Value::as_bool) == Some(true) {
            return Ok(v.get("result").cloned().unwrap_or(Value::Null));
        }
        let desc = s(&v, "description").unwrap_or_else(|| format!("HTTP {}", status.as_u16()));
        Err(match num(&v, "error_code").unwrap_or(status.as_u16() as i64) {
            401 => SwordError::Unauthorized("токен бота недействителен".into()),
            429 => SwordError::RateLimited { retry_after_secs: v.pointer("/parameters/retry_after").and_then(Value::as_u64) },
            400 | 403 | 404 => SwordError::NotFound(format!("Bot API: {desc}")),
            _ => SwordError::Upstream(format!("Bot API: {desc}")),
        })
    }
}

#[async_trait]
impl SourceAdapter for Telegram {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let mut perms = Vec::new();
        let resp = ctx.send(&self.info, ctx.get("https://t.me/s/telegram")).await?;
        let resp = http::ensure_success(resp).await?;
        perms.push(PermissionCheck::granted("Публичный предпросмотр t.me/s", format!("Доступен (HTTP {})", resp.status().as_u16())));
        match ctx.secret(BOT_TOKEN) {
            Some(token) => {
                let url = format!("https://api.telegram.org/bot{token}/getMe");
                let v: SwordResult<Value> = ctx.json(&self.info, ctx.get(&url)).await;
                perms.push(match v {
                    Ok(v) if v.get("ok").and_then(Value::as_bool) == Some(true) => PermissionCheck::granted(
                        "Bot API",
                        format!("Бот @{}", v.pointer("/result/username").and_then(Value::as_str).unwrap_or("?")),
                    ),
                    Ok(_) => PermissionCheck::denied("Bot API", "Токен не принят"),
                    Err(e) => PermissionCheck::denied("Bot API", e.to_string()),
                });
            }
            None => perms.push(PermissionCheck::denied("Bot API", "Токен бота не задан — метаданные берутся из веб-предпросмотра")),
        }
        Ok(perms)
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let handle = input.handle.clone().ok_or_else(|| SwordError::InvalidInput("не указан канал".into()))?;
        let mut b = OutputBuilder::new(&self.info);
        let channel_url = format!("https://t.me/{handle}");
        let ckey = keys::site(&channel_url);

        // Bot API metadata (optional).
        let mut bot_title = None;
        let mut bot_members = None;
        if let Some(token) = ctx.secret(BOT_TOKEN) {
            match self.bot(ctx, &token, "getChat", &format!("@{handle}")).await {
                Ok(chat) => {
                    let ty = s(&chat, "type").unwrap_or_default();
                    if ty == "private" {
                        b.note("Имя принадлежит пользователю, а не каналу — данные профиля не запрашивались.");
                        return Ok(b.finish());
                    }
                    bot_title = s(&chat, "title");
                    if let Ok(n) = self.bot(ctx, &token, "getChatMemberCount", &format!("@{handle}")).await {
                        bot_members = n.as_i64();
                    }
                    if let Some(desc) = s(&chat, "description") {
                        b.fact("Описание канала (Bot API)", &desc, &channel_url);
                    }
                }
                Err(e) => b.note(format!("Bot API getChat: {e}")),
            }
        }

        // Public web preview (+ in-channel search).
        let mut preview = format!("https://t.me/s/{handle}");
        if let Some(q) = &input.handle_query {
            preview = format!("{preview}?q={}", url::form_urlencoded::byte_serialize(q.as_bytes()).collect::<String>());
        }
        let resp = ctx.send(&self.info, ctx.get(&preview)).await?;
        let final_url = resp.url().to_string();
        let resp = http::ensure_success(resp).await?;
        let html = http::read_text(resp, 4 * 1024 * 1024).await?;
        if !final_url.contains("/s/") {
            b.note("Публичный предпросмотр канала недоступен (канал не существует, закрыт или предпросмотр отключён владельцем).");
            if bot_title.is_none() {
                return Ok(b.finish());
            }
        }
        let page = parse_channel_page(&html);
        let title = bot_title.or(page.title.clone()).unwrap_or_else(|| format!("@{handle}"));
        b.entity(&ckey, EntityKind::Website, &format!("Telegram: {title}"));
        b.attr(&ckey, "Канал", &format!("@{handle}"), &channel_url);
        let members = bot_members.map(super::fmt_int).or(page.subscribers.clone());
        if let Some(m) = &members {
            b.attr(&ckey, "Подписчики", m, &preview);
        }
        if let Some(d) = &page.description {
            b.attr(&ckey, "Описание", d, &preview);
        }
        b.finding(Category::Telegram, FindingKind::Channel, &title, Some(&channel_url))
            .snippet(page.description.as_deref().unwrap_or_default())
            .confidence(0.95)
            .attr("Подписчики", members.clone().unwrap_or_default())
            .entity(&ckey);
        b.source(&preview, &format!("Telegram: предпросмотр @{handle}"));
        b.fact("Публичный канал Telegram", &format!("{title} (@{handle}), подписчиков: {}", members.unwrap_or_else(|| "н/д".into())), &channel_url);

        for link in page.links.iter().take(10) {
            if let Some(host) = sword_core::util::host_of(link) {
                let reg = sword_core::input::registrable(&host).unwrap_or(host);
                let dkey = keys::domain(&reg);
                b.entity(&dkey, EntityKind::Domain, &reg);
                b.relate(&ckey, &dkey, "declares_website", 0.8, &preview, Some("ссылка в описании канала"));
            }
        }

        for p in page.posts.iter().rev().take(ctx.max_results) {
            let url = format!("https://t.me/{}", p.path);
            let title: String = if p.text.is_empty() { "Публикация в канале".into() } else { p.text.chars().take(90).collect() };
            let pkey = keys::publication("telegram", &p.path);
            b.finding(Category::Telegram, FindingKind::SocialPost, &title, Some(&url))
                .snippet(&p.text)
                .published(p.datetime.as_deref().and_then(parse_date))
                .confidence(0.9)
                .attr("Просмотры", p.views.clone().unwrap_or_default())
                .entity(&pkey);
            b.entity(&pkey, EntityKind::Publication, &title);
            b.relate(&pkey, &ckey, "published_on", 1.0, &url, None);
            b.source(&url, "Публикация Telegram");
        }
        if page.posts.is_empty() {
            b.note(if input.handle_query.is_some() { "Поиск внутри канала не дал результатов." } else { "В предпросмотре нет публикаций." });
        }
        Ok(b.finish())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_preview_markup() {
        let html = r#"<div class="tgme_channel_info_header_title"><span>Test Channel</span></div>
        <div class="tgme_channel_info_description">Official news <a href="https://example.com/">site</a></div>
        <div class="tgme_channel_info_counter"><span class="counter_value">12.3K</span> <span class="counter_type">subscribers</span></div>
        <div class="tgme_widget_message" data-post="testchan/42"><div class="tgme_widget_message_text">Hello world</div>
        <span class="tgme_widget_message_views">1.2K</span><a class="tgme_widget_message_date"><time datetime="2026-10-01T10:00:00+00:00">Oct 1</time></a></div>"#;
        let p = parse_channel_page(html);
        assert_eq!(p.title.as_deref(), Some("Test Channel"));
        assert_eq!(p.subscribers.as_deref(), Some("12.3K"));
        assert_eq!(p.links, vec!["https://example.com/"]);
        assert_eq!(p.posts.len(), 1);
        assert_eq!(p.posts[0].path, "testchan/42");
        assert_eq!(p.posts[0].datetime.as_deref(), Some("2026-10-01T10:00:00+00:00"));
    }
}
