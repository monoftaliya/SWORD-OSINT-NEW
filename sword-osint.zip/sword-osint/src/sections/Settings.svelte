<!--
  SETTINGS — API connections (keys are stored in Windows Credential Manager, never in
  plain text; each key comes with instructions where to obtain it), network, graphics,
  privacy, report defaults, search backend and information about the application.
-->
<script lang="ts">
  import { tick } from 'svelte';
  import Icon from '../lib/components/Icon.svelte';
  import Bits from '../lib/components/Bits.svelte';
  import Segmented from '../lib/components/Segmented.svelte';
  import Toggle from '../lib/components/Toggle.svelte';
  import { api, desktop } from '../lib/api/client';
  import type { AdapterView, AppSettings, Category, GraphicsSettings } from '../lib/api/types';
  import { app } from '../lib/stores/app.svelte';
  import { ui } from '../lib/stores/ui.svelte';
  import { SIMPLIFY_STEPS } from '../lib/engine/quality';
  import { CATEGORIES, HEALTH_META, categoryMeta } from '../lib/util/labels';
  import { fmtAgo, fmtDateTime, fmtDuration } from '../lib/util/format';
  import { guarded, openLink } from '../lib/components/ui';

  const TABS: { value: typeof ui.settingsTab; label: string }[] = [
    { value: 'connections', label: 'Подключения' },
    { value: 'network', label: 'Сеть' },
    { value: 'graphics', label: 'Графика' },
    { value: 'privacy', label: 'Приватность' },
    { value: 'reports', label: 'Отчёты' },
    { value: 'search', label: 'Поиск' },
    { value: 'about', label: 'О программе' },
  ];

  // local editable copy for forms with an explicit «Сохранить»
  let draft = $state<AppSettings | null>(app.settings ? structuredClone($state.snapshot(app.settings)) : null);
  $effect(() => {
    if (app.settings && !draft) draft = structuredClone($state.snapshot(app.settings));
  });
  const editable = (s: AppSettings) => JSON.stringify([s.network, s.privacy, s.report, s.search]);
  const dirty = $derived(!!draft && !!app.settings && editable(draft) !== editable(app.settings));

  async function saveDraft() {
    if (!draft) return;
    const d = $state.snapshot(draft) as AppSettings;
    const ok = await app.patchSettings((s) => ({ ...s, network: d.network, privacy: d.privacy, report: d.report, search: d.search }));
    if (ok && app.settings) {
      draft = structuredClone($state.snapshot(app.settings));
      app.toast('ok', 'Настройки сохранены', 2200);
    }
  }

  function revert() {
    if (app.settings) draft = structuredClone($state.snapshot(app.settings));
  }

  // graphics apply immediately
  async function setGraphics(patch: Partial<GraphicsSettings>, restart = false) {
    if (!app.settings) return;
    const ok = await app.patchSettings((s) => ({ ...s, graphics: { ...s.graphics, ...patch } }), { restartEngine: restart });
    if (ok && draft && app.settings) draft.graphics = { ...app.settings.graphics };
  }

  // ---------------------------------------------------------------- connections
  let catFilter = $state<Category | 'all'>('all');
  let secretInputs = $state<Record<string, string>>({});
  let reveal = $state<Record<string, boolean>>({});
  let optionInputs = $state<Record<string, string>>({});
  let busy = $state<Record<string, boolean>>({});
  let highlight = $state<string | null>(null);

  const adapters = $derived(catFilter === 'all' ? app.adapters : app.adapters.filter((a) => a.info.categories.includes(catFilter as Category)));
  const configuredCount = $derived(app.adapters.filter((a) => a.configured).length);

  $effect(() => {
    const focus = ui.settingsFocusAdapter;
    if (!focus || ui.settingsTab !== 'connections') return;
    catFilter = 'all';
    highlight = focus;
    ui.settingsFocusAdapter = null;
    tick().then(() => document.getElementById(`adapter-${focus}`)?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
    setTimeout(() => (highlight = null), 2600);
  });

  async function withBusy<T>(key: string, fn: () => Promise<T>, label: string) {
    busy = { ...busy, [key]: true };
    const r = await guarded(fn, label);
    busy = { ...busy, [key]: false };
    return r;
  }

  async function saveSecret(a: AdapterView, key: string) {
    const value = (secretInputs[key] ?? '').trim();
    if (!value) return;
    const st = await withBusy(key, () => api.setCredential(key, value), 'Сохранение ключа');
    if (!st) return;
    secretInputs = { ...secretInputs, [key]: '' };
    reveal = { ...reveal, [key]: false };
    await app.refreshAdapters();
    app.toast('ok', `Ключ сохранён в хранилище Windows · отпечаток ${st.fingerprint ?? ''}`);
    const fresh = app.adapters.find((x) => x.info.id === a.info.id);
    if (fresh?.configured) check(fresh);
  }

  async function deleteSecret(key: string) {
    const ok = await withBusy(key, () => api.deleteCredential(key).then(() => true), 'Удаление ключа');
    if (ok) {
      await app.refreshAdapters();
      app.toast('ok', 'Ключ удалён');
    }
  }

  async function saveOption(a: AdapterView, key: string) {
    const value = optionInputs[`${a.info.id}.${key}`] ?? a.options[key] ?? '';
    const v = await withBusy(`${a.info.id}.${key}`, () => api.setAdapterOption(a.info.id, key, value.trim()), 'Параметр');
    if (v) {
      app.replaceAdapter(v);
      app.toast('ok', 'Параметр сохранён', 2000);
    }
  }

  async function check(a: AdapterView) {
    const st = await withBusy(`check.${a.info.id}`, () => api.checkAdapter(a.info.id), a.info.name);
    if (st) app.replaceAdapter({ ...a, status: st });
  }

  async function setEnabled(a: AdapterView, enabled: boolean) {
    const v = await guarded(() => api.setAdapterEnabled(a.info.id, enabled), a.info.name);
    if (v) app.replaceAdapter(v);
  }
</script>

<div class="section-root settings enter">
  <div class="head">
    <Segmented bind:value={ui.settingsTab} options={TABS} />
    <span class="spacer"></span>
    {#if ui.settingsTab !== 'connections' && ui.settingsTab !== 'graphics' && ui.settingsTab !== 'about'}
      <button class="btn sm ghost" onclick={revert} disabled={!dirty}>Отменить</button>
      <button class="btn sm primary" onclick={saveDraft} disabled={!dirty}><Icon name="check" size={14} />Сохранить</button>
    {/if}
  </div>

  {#if !desktop() || !draft || !app.settings}
    <div class="empty">Настройки доступны в настольном приложении.</div>
  {:else if ui.settingsTab === 'connections'}
    <div class="conn-head">
      <p class="lead">
        Ключи и токены хранятся только в диспетчере учётных данных Windows (служба «SWORD OSINT»), в базу попадает лишь отпечаток.
        Используются только официальные API и публичные интерфейсы источников. Настроено {configuredCount} из {app.adapters.length}.
      </p>
      <div class="catbar">
        <button class="chip" class:on={catFilter === 'all'} onclick={() => (catFilter = 'all')}>Все</button>
        {#each CATEGORIES as c (c.id)}
          <button class="chip" class:on={catFilter === c.id} onclick={() => (catFilter = c.id)}><Icon name={c.icon} size={12} />{c.label}</button>
        {/each}
      </div>
    </div>
    <div class="cards scroll">
      {#each adapters as a (a.info.id)}
        {@const h = HEALTH_META[a.status.health]}
        <article class="card glass" class:flash={highlight === a.info.id} id="adapter-{a.info.id}">
          <header>
            <div class="t">
              <span class="name">{a.info.name}</span>
              <span class="prov">{a.info.provider}{a.info.officialApi ? ' · официальный API' : ' · публичный интерфейс'} · {a.info.categories.map((c) => categoryMeta(c).label).join(', ')}</span>
            </div>
            <span class="health"><Bits kind="dot" tone={h.tone} />{h.label}</span>
            <Toggle checked={a.enabled} onchange={(v) => setEnabled(a, v)} label={a.enabled ? 'включён' : 'выключен'} />
          </header>
          <p class="desc">{a.info.description}</p>
          <details>
            <summary>Методология и ограничения</summary>
            <p class="method">{a.info.methodology}</p>
            <p class="method">Лимит: {a.info.rateLimitPerMinute} запросов в минуту. Поддерживаемые запросы: {a.info.inputKinds.join(', ')}.</p>
          </details>

          {#if a.info.credentials.length === 0 && a.info.options.length === 0}
            <p class="nokey"><Icon name="check" size={13} />Ключ не требуется — источник работает через открытый официальный интерфейс.</p>
          {/if}

          {#each a.info.credentials as c (c.key)}
            {@const st = a.credentials.find((x) => x.key === c.key)}
            <div class="cred">
              <div class="cl">
                <span class="cn">{c.label}{c.required ? '' : ' · необязательно'}</span>
                {#if st?.isSet}
                  <span class="set"><Icon name="lock" size={12} />задан · отпечаток {st.fingerprint ?? '—'} · {fmtAgo(st.updatedAt)}</span>
                {:else}
                  <span class="unset">не задан</span>
                {/if}
              </div>
              <div class="row">
                <div class="secret">
                  <input
                    class="input"
                    type={reveal[c.key] ? 'text' : 'password'}
                    autocomplete="off"
                    spellcheck="false"
                    placeholder={st?.isSet ? 'Введите новое значение, чтобы заменить' : (c.placeholder ?? 'Значение')}
                    value={secretInputs[c.key] ?? ''}
                    oninput={(e) => (secretInputs = { ...secretInputs, [c.key]: e.currentTarget.value })}
                    onkeydown={(e) => e.key === 'Enter' && saveSecret(a, c.key)}
                  />
                  <button class="eye" onclick={() => (reveal = { ...reveal, [c.key]: !reveal[c.key] })} aria-label="Показать или скрыть"><Icon name={reveal[c.key] ? 'eyeOff' : 'eye'} size={14} /></button>
                </div>
                <button class="btn sm" onclick={() => saveSecret(a, c.key)} disabled={busy[c.key] || !(secretInputs[c.key] ?? '').trim()}>
                  {#if busy[c.key]}<Bits kind="spinner" />{/if}Сохранить
                </button>
                {#if st?.isSet}
                  <button class="btn sm ghost icon" title="Удалить ключ" onclick={() => deleteSecret(c.key)} disabled={busy[c.key]}><Icon name="trash" size={13} /></button>
                {/if}
              </div>
              <p class="help">
                {c.help}
                {#if c.helpUrl}<button class="link" onclick={() => openLink(c.helpUrl)}>Где получить ↗</button>{/if}
              </p>
            </div>
          {/each}

          {#each a.info.options as o (o.key)}
            {@const id = `${a.info.id}.${o.key}`}
            <div class="cred">
              <div class="cl"><span class="cn">{o.label}{o.required ? '' : ' · необязательно'}</span></div>
              <div class="row">
                <input
                  class="input"
                  placeholder={o.placeholder ?? o.default ?? ''}
                  value={optionInputs[id] ?? a.options[o.key] ?? ''}
                  oninput={(e) => (optionInputs = { ...optionInputs, [id]: e.currentTarget.value })}
                  onkeydown={(e) => e.key === 'Enter' && saveOption(a, o.key)}
                />
                <button class="btn sm" onclick={() => saveOption(a, o.key)} disabled={busy[id] || optionInputs[id] === undefined}>Сохранить</button>
              </div>
              <p class="help">{o.help}{o.default ? ` По умолчанию: ${o.default}.` : ''}</p>
            </div>
          {/each}

          <footer>
            <button class="btn sm" onclick={() => check(a)} disabled={busy[`check.${a.info.id}`]}>
              {#if busy[`check.${a.info.id}`]}<Bits kind="spinner" />{:else}<Icon name="refresh" size={13} />{/if}Проверить подключение
            </button>
            <span class="smsg">{a.status.message}{a.status.checkedAt ? ` · ${fmtAgo(a.status.checkedAt)}` : ''}</span>
            <span class="spacer"></span>
            <button class="btn sm ghost" onclick={() => openLink(a.info.docsUrl ?? a.info.homepage)}><Icon name="external" size={12} />Документация API</button>
          </footer>
          {#if a.status.permissions.length}
            <ul class="perms">
              {#each a.status.permissions as p, i (i)}
                <li class:no={!p.granted}><Icon name={p.granted ? 'check' : 'x'} size={12} /><b>{p.name}</b><span>{p.detail}</span></li>
              {/each}
            </ul>
          {/if}
        </article>
      {/each}
    </div>
  {:else if ui.settingsTab === 'network'}
    <div class="form glass scroll">
      <div class="grid">
        <div class="field">
          <label for="rt">Тайм-аут запроса, с</label>
          <input id="rt" class="input" type="number" min="3" max="120" bind:value={draft.network.requestTimeoutSecs} />
          <span class="help">Ожидание ответа на один HTTP-запрос.</span>
        </div>
        <div class="field">
          <label for="at">Тайм-аут источника, с</label>
          <input id="at" class="input" type="number" min="10" max="600" bind:value={draft.network.adapterTimeoutSecs} />
          <span class="help">Максимальное время работы одного источника в исследовании.</span>
        </div>
        <div class="field">
          <label for="mc">Параллельных источников</label>
          <input id="mc" class="input" type="number" min="1" max="16" bind:value={draft.network.maxConcurrency} />
          <span class="help">Сколько источников опрашивается одновременно.</span>
        </div>
        <div class="field">
          <label for="mr">Результатов на источник</label>
          <input id="mr" class="input" type="number" min="5" max="500" bind:value={draft.network.maxResultsPerAdapter} />
          <span class="help">Верхняя граница результатов от одного источника.</span>
        </div>
        <div class="field">
          <label for="px">Прокси</label>
          <input id="px" class="input" placeholder="http://proxy.company:3128" value={draft.network.proxyUrl ?? ''} oninput={(e) => draft && (draft.network.proxyUrl = e.currentTarget.value.trim() || null)} />
          <span class="help">По умолчанию используются системные настройки прокси Windows.</span>
        </div>
        <div class="field">
          <label for="ce">Контактный e-mail для API</label>
          <input id="ce" class="input" placeholder="не передаётся, если пусто" value={draft.network.contactEmail ?? ''} oninput={(e) => draft && (draft.network.contactEmail = e.currentTarget.value.trim() || null)} />
          <span class="help">Необязательно. Некоторые открытые API (OpenAlex, Wikimedia) просят контакт для «вежливого» доступа. Без вашего указания адрес никуда не отправляется.</span>
        </div>
        <div class="field">
          <span class="label">DNS через HTTPS</span>
          <Segmented size="sm" bind:value={draft.network.dohProvider} options={[{ value: 'cloudflare', label: 'Cloudflare' }, { value: 'google', label: 'Google' }]} />
          <span class="help">Резолвер для DNS-запросов разведки по домену и аудита.</span>
        </div>
      </div>
    </div>
  {:else if ui.settingsTab === 'graphics'}
    {@const g = app.settings.graphics}
    <div class="form glass scroll">
      <div class="gpu">
        <Icon name="cpu" size={18} />
        <div>
          <b>{app.perf.gpu || 'Графический адаптер не определён'}</b>
          <span class="faint small">
            {app.perf.backend} · {app.perf.simplified >= 3 ? 'статичный кадр' : `${app.perf.fps} FPS`} · {app.perf.particles.toLocaleString('ru-RU')} частиц
          </span>
        </div>
      </div>
      {#if app.perf.simplified > 0}
        <div class="simplified" role="status">
          <Icon name="alert" size={16} />
          <div>
            <b>Графика упрощена автоматически</b>
            <span class="faint small">
              Даже при минимальном числе частиц кадры не успевали отрисовываться — так бывает в виртуальных машинах и при программной отрисовке без видеокарты.
              Применено: {SIMPLIFY_STEPS.slice(1, app.perf.simplified + 1).join(' → ')}.
            </span>
          </div>
          <button class="btn sm" onclick={() => app.restoreGraphics()}>Вернуть полное качество</button>
        </div>
      {/if}
      <div class="grid">
        <div class="field">
          <span class="label">Графический API</span>
          <Segmented size="sm" value={g.renderer} onchange={(v) => setGraphics({ renderer: v }, true)} options={[{ value: 'auto', label: 'Авто' }, { value: 'webgpu', label: 'WebGPU' }, { value: 'webgl2', label: 'WebGL 2' }]} />
          <span class="help">WebGPU — основной режим (NVIDIA RTX, AMD, Intel Arc). WebGL 2 — совместимость со старыми драйверами. Смена пересоздаёт сцену.</span>
        </div>
        <div class="field">
          <span class="label">Качество</span>
          <Segmented
            size="sm"
            value={g.quality}
            onchange={(v) => setGraphics({ quality: v }, true)}
            options={[{ value: 'auto', label: 'Авто' }, { value: 'low', label: '14k' }, { value: 'medium', label: '42k' }, { value: 'high', label: '110k' }, { value: 'ultra', label: '240k' }]}
          />
          <span class="help">Число частиц. «Авто» выбирает бюджет по GPU и снижает его при падении частоты кадров.</span>
        </div>
        <div class="field">
          <span class="label">Ограничение FPS</span>
          <Segmented size="sm" value={g.fpsLimit} onchange={(v) => setGraphics({ fpsLimit: v })} options={[{ value: 0, label: 'Частота экрана' }, { value: 30, label: '30' }, { value: 60, label: '60' }, { value: 120, label: '120' }, { value: 144, label: '144' }]} />
        </div>
        <div class="field">
          <span class="label">Максимальная плотность пикселей</span>
          <Segmented size="sm" value={g.maxPixelRatio} onchange={(v) => setGraphics({ maxPixelRatio: v })} options={[{ value: 1, label: '1×' }, { value: 1.5, label: '1.5×' }, { value: 2, label: '2×' }]} />
          <span class="help">На 4K-мониторах 1.5× заметно снижает нагрузку.</span>
        </div>
        <div class="toggles">
          <Toggle checked={g.bloom} onchange={(v) => setGraphics({ bloom: v })} label="Свечение (bloom)" />
          <Toggle checked={g.trails} onchange={(v) => setGraphics({ trails: v })} label="Шлейфы частиц" />
          <Toggle checked={g.backgroundAnimation} onchange={(v) => setGraphics({ backgroundAnimation: v })} label="Анимация фона в других разделах" />
          <Toggle checked={g.reduceMotion} onchange={(v) => setGraphics({ reduceMotion: v })} label="Уменьшить движение" />
          <Toggle checked={g.showFps} onchange={(v) => setGraphics({ showFps: v })} label="Показывать FPS в заголовке" />
        </div>
      </div>
    </div>
  {:else if ui.settingsTab === 'privacy'}
    <div class="form glass scroll">
      <div class="grid">
        <div class="field">
          <label for="rd">Хранить историю, дней</label>
          <input id="rd" class="input" type="number" min="0" max="3650" bind:value={draft.privacy.retentionDays} />
          <span class="help">0 — хранить бессрочно. Более старые исследования удаляются при запуске приложения.</span>
        </div>
        <div class="field">
          <span class="label">Фрагменты текста</span>
          <Toggle bind:checked={draft.privacy.storeSnippets} label="Сохранять фрагменты результатов в базе" />
          <span class="help">Если выключено, в базе остаются заголовки и ссылки на первоисточники.</span>
        </div>
      </div>
      <div class="notes">
        <p><Icon name="lock" size={14} />Ключи API, пароли и адреса e-mail ваших активов хранятся в диспетчере учётных данных Windows{app.info?.vaultPersistent ? '' : ' (сейчас недоступен — значения хранятся только до закрытия приложения)'}.</p>
        <p><Icon name="intelligence" size={14} />Проверка утечек — только через официальный API Have I Been Pwned и только для ваших адресов. Пароли проверяются по k-анонимности и не сохраняются.</p>
        <p><Icon name="globe" size={14} />Приложение не обходит авторизацию, CAPTCHA и ограничения платформ, не обращается к закрытым профилям и не использует утёкшие базы.</p>
      </div>
    </div>
  {:else if ui.settingsTab === 'reports'}
    <div class="form glass scroll">
      <div class="grid">
        <div class="field"><label for="ra">Автор</label><input id="ra" class="input" bind:value={draft.report.author} /></div>
        <div class="field"><label for="ro">Организация</label><input id="ro" class="input" bind:value={draft.report.organization} /></div>
        <div class="field"><label for="rc">Гриф по умолчанию</label><input id="rc" class="input" bind:value={draft.report.classification} /></div>
        <div class="field">
          <span class="label">Тема</span>
          <Segmented size="sm" bind:value={draft.report.theme} options={[{ value: 'graphite', label: 'Графит' }, { value: 'midnight', label: 'Полночь' }, { value: 'paper', label: 'Бумага' }]} />
        </div>
        <div class="field">
          <span class="label">Формат бумаги</span>
          <Segmented size="sm" bind:value={draft.report.paper} options={[{ value: 'a4', label: 'A4' }, { value: 'letter', label: 'Letter' }]} />
        </div>
      </div>
      <p class="help">Значения по умолчанию для новых отчётов; в REPORT STUDIO их можно изменить для каждого отчёта.</p>
    </div>
  {:else if ui.settingsTab === 'search'}
    <div class="form glass scroll">
      <div class="grid">
        <div class="field">
          <span class="label">Поисковый движок</span>
          <Segmented size="sm" bind:value={draft.search.backend} options={[{ value: 'sqlite', label: 'SQLite FTS5 (встроенный)' }, { value: 'opensearch', label: 'OpenSearch' }]} />
          <span class="help">OpenSearch необязателен: используется для больших объёмов и совместного доступа к индексу.</span>
        </div>
        <div class="field">
          <label for="ou">Адрес OpenSearch</label>
          <input id="ou" class="input" placeholder="https://opensearch.company:9200" value={draft.search.opensearchUrl ?? ''} oninput={(e) => draft && (draft.search.opensearchUrl = e.currentTarget.value.trim() || null)} />
        </div>
        <div class="field"><label for="oi">Индекс</label><input id="oi" class="input" bind:value={draft.search.opensearchIndex} /></div>
        <div class="field">
          <label for="on">Пользователь</label>
          <input id="on" class="input" value={draft.search.opensearchUsername ?? ''} oninput={(e) => draft && (draft.search.opensearchUsername = e.currentTarget.value.trim() || null)} />
          <span class="help">Пароль задаётся в DATABASES → Хранилище и хранится в диспетчере учётных данных Windows.</span>
        </div>
      </div>
    </div>
  {:else}
    {@const info = app.info}
    <div class="form glass scroll about">
      <div class="brand"><Icon name="sword" size={26} /><div><b class="display">SWORD OSINT</b><span class="faint">версия {info?.version} · {info?.os} {info?.arch}</span></div></div>
      <dl>
        <dt>Данные</dt><dd class="mono">{info?.dataDir}</dd>
        <dt>База</dt><dd class="mono">{info?.dbPath}</dd>
        <dt>Отчёты</dt><dd class="mono">{info?.reportsDir}</dd>
        <dt>Журналы</dt><dd class="mono">{info?.logsDir}</dd>
        <dt>Источники</dt><dd>{info?.adapters}</dd>
        <dt>Работает</dt><dd>{fmtDuration((info?.uptimeSecs ?? 0) * 1000)} (на момент открытия раздела)</dd>
        <dt>Хранилище ключей</dt><dd>{info?.vaultPersistent ? 'диспетчер учётных данных Windows' : 'временное (в памяти)'}</dd>
      </dl>
      <div class="row">
        <button class="btn sm" onclick={() => guarded(() => api.openDataDir(), 'Папка данных')}><Icon name="folder" size={13} />Папка данных</button>
        <button class="btn sm" onclick={() => guarded(() => api.openLogsDir(), 'Журналы')}><Icon name="file" size={13} />Журналы</button>
      </div>
      <div class="notes">
        <p><b>Принципы.</b> Только публичные данные и официальные интерфейсы. Никаких обходов авторизации, CAPTCHA и закрытых профилей. Утечки — только через легальные сервисы и только для ваших активов. Граф показывает лишь подтверждённые связи между разрешёнными публичными объектами. Если источник недоступен, приложение сообщает об этом честно и не подставляет данные.</p>
        <p><b>Компоненты.</b> Tauri 2, Rust, Svelte 5, three.js (MIT), SQLite (public domain), printpdf (MIT), шрифты IBM Plex и Unbounded (SIL OFL 1.1).</p>
        <p class="faint">Сформировано {fmtDateTime(new Date().toISOString())}.</p>
      </div>
    </div>
  {/if}
</div>

<style>
  .head {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .conn-head {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .lead {
    margin: 0;
    font-size: 12.5px;
    color: var(--fg-2);
    max-width: 980px;
    line-height: 1.55;
  }
  .catbar {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  }
  .catbar .chip {
    cursor: pointer;
  }
  .catbar .chip.on {
    color: #fff;
    border-color: rgba(230, 238, 250, 0.4);
    background: rgba(230, 238, 250, 0.08);
  }
  .cards {
    flex: 1;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(520px, 1fr));
    gap: 12px;
    align-content: start;
    padding-right: 4px;
  }
  .card {
    display: flex;
    flex-direction: column;
    gap: 10px;
    padding: 14px 16px;
    scroll-margin-top: 10px;
    transition: border-color 0.4s, box-shadow 0.4s;
  }
  .card.flash {
    border-color: rgba(230, 238, 250, 0.6);
    box-shadow: 0 0 36px rgba(220, 232, 248, 0.25);
  }
  .card header {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .t {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .name {
    font-size: 14.5px;
    font-weight: 500;
    color: #fff;
  }
  .prov {
    font-size: 11px;
    color: var(--fg-3);
  }
  .health {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 11.5px;
    color: var(--fg-2);
    white-space: nowrap;
  }
  .desc {
    margin: 0;
    font-size: 12.5px;
    color: var(--fg-2);
    line-height: 1.5;
  }
  details summary {
    cursor: pointer;
    font-size: 11.5px;
    color: var(--fg-3);
  }
  .method {
    margin: 6px 0 0;
    font-size: 11.5px;
    color: var(--fg-3);
    line-height: 1.5;
  }
  .nokey {
    margin: 0;
    display: flex;
    align-items: center;
    gap: 7px;
    font-size: 12px;
    color: var(--ok);
  }
  .cred {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding: 10px 12px;
    border-radius: 10px;
    border: 1px solid var(--line);
    background: rgba(0, 0, 0, 0.22);
  }
  .cl {
    display: flex;
    justify-content: space-between;
    gap: 10px;
    align-items: baseline;
  }
  .cn {
    font-size: 12px;
    color: var(--fg);
  }
  .set {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-size: 11px;
    color: var(--ok);
  }
  .unset {
    font-size: 11px;
    color: var(--fg-3);
  }
  .secret {
    position: relative;
    flex: 1;
  }
  .secret .input {
    padding-right: 34px;
    font-family: var(--font-mono);
    font-size: 12px;
  }
  .eye {
    position: absolute;
    right: 6px;
    top: 50%;
    transform: translateY(-50%);
    border: none;
    background: none;
    color: var(--fg-3);
    cursor: pointer;
    padding: 4px;
  }
  .eye:hover {
    color: #fff;
  }
  .help {
    margin: 0;
  }
  .link {
    border: none;
    background: none;
    padding: 0;
    color: var(--fg);
    font-size: 11.5px;
    cursor: pointer;
    text-decoration: underline;
    text-underline-offset: 3px;
  }
  .card footer {
    display: flex;
    align-items: center;
    gap: 10px;
  }
  .smsg {
    font-size: 11px;
    color: var(--fg-3);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
  }
  .perms {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 3px;
    font-size: 11.5px;
  }
  .perms li {
    display: grid;
    grid-template-columns: 14px auto 1fr;
    gap: 7px;
    align-items: baseline;
    color: var(--ok);
  }
  .perms li.no {
    color: var(--err);
  }
  .perms b {
    font-weight: 500;
    color: var(--fg-2);
  }
  .perms span {
    color: var(--fg-3);
  }
  .form {
    padding: 20px 22px;
    display: flex;
    flex-direction: column;
    gap: 18px;
    max-width: 1100px;
  }
  .grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 18px 24px;
  }
  .toggles {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  .gpu {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 12px;
    border-radius: 10px;
    border: 1px solid var(--line);
  }
  .gpu div {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .gpu b {
    font-weight: 500;
  }
  .simplified {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 12px;
    border-radius: 10px;
    border: 1px solid rgba(232, 212, 139, 0.28);
    background: rgba(232, 212, 139, 0.05);
    color: var(--warn);
  }
  .simplified div {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 3px;
    color: var(--fg);
  }
  .simplified b {
    font-weight: 500;
  }
  .simplified .btn {
    flex: none;
  }
  .notes {
    display: flex;
    flex-direction: column;
    gap: 10px;
    font-size: 12.5px;
    color: var(--fg-2);
    line-height: 1.55;
  }
  .notes p {
    margin: 0;
    display: flex;
    gap: 10px;
    align-items: flex-start;
  }
  .notes p :global(.icon) {
    margin-top: 3px;
    flex: none;
  }
  .about .brand {
    display: flex;
    align-items: center;
    gap: 14px;
  }
  .about .brand div {
    display: flex;
    flex-direction: column;
    gap: 3px;
  }
  .about .brand b {
    font-size: 16px;
    color: #fff;
  }
  .about dl {
    display: grid;
    grid-template-columns: 150px 1fr;
    gap: 6px 16px;
    margin: 0;
    font-size: 12.5px;
  }
  .about dt {
    color: var(--fg-3);
  }
  .about dd {
    margin: 0;
    word-break: break-all;
    user-select: text;
  }
  .notes b {
    color: #fff;
    font-weight: 500;
  }
</style>
