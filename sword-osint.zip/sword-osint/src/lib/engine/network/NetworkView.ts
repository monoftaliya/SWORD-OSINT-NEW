/**
 * 3D view of the confirmed-link graph.
 *
 * Nodes are instanced meshes — one shape per entity type (organisations = octahedra,
 * domains = icosahedra, websites = spheres, projects = cubes, documents = tetrahedra,
 * publications = dodecahedra, verified sources = rings). Edge brightness encodes the
 * link confidence. Layout runs in a Web Worker (3D force simulation with a Barnes–Hut
 * octree); rendering happens on demand, so an idle graph costs almost nothing.
 */
import * as THREE from 'three/webgpu';
import { abs, dot, float, instancedBufferAttribute, mix, normalView, pass, positionViewDirection, pow, smoothstep, uniform, uv, vec3, vec4 } from 'three/tsl';
import { bloom } from 'three/addons/tsl/display/BloomNode.js';
import { CameraRig } from '../CameraRig';
import { FramePacer, detectGpu, settle, silenceDeviceLossEchoes } from '../quality';
import type { EntityKind } from '../../api/types';
import { ENTITY_META } from '../../util/labels';
import type { LayoutRequest, LayoutResponse } from './layout.worker';

export interface ViewNode {
  key: string;
  kind: EntityKind;
  label: string;
  degree: number;
}

export interface ViewEdge {
  id: string;
  from: number;
  to: number;
  confidence: number;
  relation: string;
}

export interface NetworkOptions {
  renderer: 'auto' | 'webgpu' | 'webgl2';
  bloom: boolean;
  fpsLimit: number;
  reduceMotion: boolean;
  maxPixelRatio: number;
}

export interface NetworkCallbacks {
  onSelect?: (key: string | null) => void;
  onHover?: (key: string | null) => void;
  onLayout?: (running: boolean) => void;
  onLost?: (message: string) => void;
}

const KINDS: EntityKind[] = ['organization', 'domain', 'website', 'project', 'document', 'publication', 'source'];
const MAX_LABELS = 44;
const MAX_FLOWS = 160;

function geometryFor(kind: EntityKind): THREE.BufferGeometry {
  switch (kind) {
    case 'organization':
      return new THREE.OctahedronGeometry(1.1, 0);
    case 'domain':
      return new THREE.IcosahedronGeometry(1, 0);
    case 'website':
      return new THREE.SphereGeometry(0.88, 22, 16);
    case 'project':
      return new THREE.BoxGeometry(1.3, 1.3, 1.3);
    case 'document':
      return new THREE.TetrahedronGeometry(1.2, 0);
    case 'publication':
      return new THREE.DodecahedronGeometry(1, 0);
    case 'source':
      return new THREE.TorusGeometry(0.8, 0.2, 10, 28);
  }
}

const RELATION_DISTANCE: Record<string, number> = {
  documented_by: 26,
  subdomain_of: 13,
  hosted_on: 15,
  same_as: 9,
};

export class NetworkView {
  private renderer: THREE.WebGPURenderer | null = null;
  private readonly scene = new THREE.Scene();
  private readonly camera = new THREE.PerspectiveCamera(50, 1, 0.5, 6000);
  private rig: CameraRig | null = null;
  private pipeline: THREE.RenderPipeline | null = null;
  private fx: { dispose(): void }[] = [];
  private worker: Worker | null = null;
  private epoch = 0;
  private disposed = false;
  private lost = false;
  private frameErrors = 0;
  private backendName = '';

  private nodes: ViewNode[] = [];
  private edges: ViewEdge[] = [];
  private positions: Float32Array = new Float32Array(0);
  private readonly known = new Map<string, [number, number, number]>();
  private readonly meshes = new Map<EntityKind, THREE.InstancedMesh>();
  private readonly geometries = new Map<EntityKind, THREE.BufferGeometry>();
  private readonly materials = new Map<EntityKind, THREE.MeshBasicNodeMaterial>();
  private slots: { mesh: THREE.InstancedMesh; index: number }[] = [];
  private scales = new Float32Array(0);
  private adjacency: number[][] = [];
  private edgesOf: number[][] = [];
  private lines: THREE.LineSegments | null = null;
  private readonly lineMat = new THREE.LineBasicNodeMaterial({ vertexColors: true, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });

  private flowSprite: THREE.Sprite | null = null;
  private flowAttr: THREE.InstancedBufferAttribute | null = null;
  private readonly flowOpacity = uniform(0);

  private selected = -1;
  private hovered = -1;
  private highlighted = -1;
  private layoutRunning = false;
  private autoFit = true;
  private earlyFit = false;
  private dirtyPositions = false;
  private dirtyColors = false;
  private needsRender = true;
  private labelSet: number[] = [];
  private labelPool: HTMLDivElement[] = [];

  private width = 1;
  private height = 1;
  private readonly pacer = new FramePacer();
  private time = 0;
  private ro: ResizeObserver | null = null;
  private readonly disposables: { dispose(): void }[] = [];
  private readonly dummy = new THREE.Object3D();
  private readonly color = new THREE.Color();
  private readonly v = new THREE.Vector3();
  private readonly viewProj = new THREE.Matrix4();

  constructor(
    private readonly canvas: HTMLCanvasElement,
    private readonly labelLayer: HTMLElement,
    private opts: NetworkOptions,
    private readonly cb: NetworkCallbacks = {},
  ) {}

  get backend() {
    return this.backendName;
  }

  async init(): Promise<void> {
    silenceDeviceLossEchoes();
    const gpu = await detectGpu();
    if (this.disposed) return;
    const forceWebGL = this.opts.renderer === 'webgl2' || (this.opts.renderer === 'auto' && !gpu.webgpu);
    const renderer = new THREE.WebGPURenderer({ canvas: this.canvas, antialias: true, alpha: false, powerPreference: 'high-performance', forceWebGL });
    this.renderer = renderer;
    await renderer.init();
    if (this.disposed) return;
    this.backendName = (renderer.backend as unknown as { isWebGPUBackend?: boolean }).isWebGPUBackend ? 'WebGPU' : 'WebGL 2';
    const defaultLost = renderer.onDeviceLost.bind(renderer);
    renderer.onDeviceLost = (info) => {
      defaultLost(info);
      this.lost = true;
      settle(renderer.setAnimationLoop(null));
      this.cb.onLost?.(info.message || 'графическое устройство потеряно');
    };
    renderer.setClearColor(0x000000, 1);

    // node materials: faceted "crystal" shading — rim-lit edges, instance colour carries type and state
    const rim = pow(float(1).sub(abs(dot(normalView, positionViewDirection))), 1.6);
    const shade = mix(float(0.5), float(1.3), rim);
    for (const kind of KINDS) {
      const geo = geometryFor(kind);
      const mat = new THREE.MeshBasicNodeMaterial({ color: 0xffffff });
      mat.colorNode = vec4(vec3(shade), 1);
      this.geometries.set(kind, geo);
      this.materials.set(kind, mat);
      this.disposables.push(geo, mat);
    }
    this.disposables.push(this.lineMat);

    this.buildBackdrop();
    this.buildFlows();
    this.buildPipeline();

    for (let i = 0; i < MAX_LABELS; i++) {
      const el = document.createElement('div');
      el.className = 'node-label';
      el.style.opacity = '0';
      this.labelLayer.appendChild(el);
      this.labelPool.push(el);
    }

    const rig = new CameraRig(this.camera, this.canvas, {
      distance: 140,
      minDistance: 6,
      maxDistance: 2400,
      phi: Math.PI / 2.4,
      theta: 0.5,
      parallax: 0.03,
      autoRotate: 0,
      reduceMotion: this.opts.reduceMotion,
    });
    rig.onClick = (ndc) => {
      const i = this.pick(ndc);
      this.select(i >= 0 ? this.nodes[i].key : null);
      this.cb.onSelect?.(i >= 0 ? this.nodes[i].key : null);
    };
    rig.onDoubleClick = (ndc) => {
      const i = this.pick(ndc);
      if (i < 0) return false;
      this.focusNode(i);
      return true;
    };
    this.rig = rig;

    this.worker = new Worker(new URL('./layout.worker.ts', import.meta.url), { type: 'module' });
    this.worker.onmessage = (e: MessageEvent<LayoutResponse>) => this.onLayout(e.data);

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(this.canvas.parentElement ?? this.canvas);
    this.resize();
    this.pacer.reset(performance.now());
    settle(renderer.setAnimationLoop((t) => this.frame(t)));
  }

  // ------------------------------------------------------------------ scene parts

  private buildBackdrop() {
    const n = 2600;
    const arr = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const u = Math.random() * 2 - 1;
      const a = Math.random() * Math.PI * 2;
      const r = 900 + Math.random() * 1600;
      const s = Math.sqrt(1 - u * u);
      arr[i * 3] = Math.cos(a) * s * r;
      arr[i * 3 + 1] = u * r * 0.6;
      arr[i * 3 + 2] = Math.sin(a) * s * r;
    }
    const attr = new THREE.InstancedBufferAttribute(arr, 3);
    const mat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    mat.positionNode = instancedBufferAttribute(attr);
    mat.scaleNode = float(3.2);
    mat.colorNode = vec4(0.8, 0.86, 0.95, 1);
    mat.opacityNode = pow(smoothstep(0, 1, uv().sub(0.5).length().mul(2)).oneMinus(), 2).mul(0.35);
    const stars = new THREE.Sprite(mat);
    stars.count = n;
    stars.frustumCulled = false;
    this.scene.add(stars);
    this.disposables.push(mat);
  }

  private buildFlows() {
    const arr = new Float32Array(MAX_FLOWS * 3);
    const attr = new THREE.InstancedBufferAttribute(arr, 3);
    attr.setUsage(THREE.DynamicDrawUsage);
    const mat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    mat.positionNode = instancedBufferAttribute(attr);
    mat.scaleNode = float(1.1);
    mat.colorNode = vec4(0.92, 0.96, 1, 1);
    mat.opacityNode = pow(smoothstep(0, 1, uv().sub(0.5).length().mul(2)).oneMinus(), 2.2).mul(this.flowOpacity);
    const s = new THREE.Sprite(mat);
    s.count = 0;
    s.frustumCulled = false;
    this.scene.add(s);
    this.flowSprite = s;
    this.flowAttr = attr;
    this.disposables.push(mat);
  }

  private buildPipeline() {
    const renderer = this.renderer;
    if (!renderer || this.lost) return;
    this.pipeline?.dispose();
    for (const n of this.fx) n.dispose();
    this.fx = [];
    this.pipeline = null;
    if (!this.opts.bloom) return;
    const pipeline = new THREE.RenderPipeline(renderer);
    const scenePass = pass(this.scene, this.camera);
    const color = scenePass.getTextureNode('output');
    const glow = bloom(color, 0.55, 0.3, 0.12);
    this.fx.push(scenePass, glow);
    pipeline.outputNode = color.add(glow);
    this.pipeline = pipeline;
    this.needsRender = true;
  }

  // ------------------------------------------------------------------ data

  /** Replace the displayed graph; positions of nodes seen before are kept. */
  setGraph(nodes: ViewNode[], edges: ViewEdge[], refit = false) {
    // remember current positions
    this.nodes.forEach((n, i) => {
      if (this.positions.length >= (i + 1) * 3) this.known.set(n.key, [this.positions[i * 3], this.positions[i * 3 + 1], this.positions[i * 3 + 2]]);
    });
    const selectedKey = this.selected >= 0 ? this.nodes[this.selected]?.key : null;
    this.nodes = nodes;
    this.edges = edges;
    this.selected = selectedKey ? nodes.findIndex((n) => n.key === selectedKey) : -1;
    this.hovered = -1;
    this.highlighted = -1;
    this.autoFit = refit || this.autoFit;

    // adjacency
    this.adjacency = nodes.map(() => []);
    this.edgesOf = nodes.map(() => []);
    edges.forEach((e, k) => {
      this.adjacency[e.from].push(e.to);
      this.adjacency[e.to].push(e.from);
      this.edgesOf[e.from].push(k);
      this.edgesOf[e.to].push(k);
    });

    // instanced meshes per kind
    for (const m of this.meshes.values()) {
      this.scene.remove(m);
      m.dispose();
    }
    this.meshes.clear();
    const counts = new Map<EntityKind, number>();
    for (const n of nodes) counts.set(n.kind, (counts.get(n.kind) ?? 0) + 1);
    for (const [kind, count] of counts) {
      const mesh = new THREE.InstancedMesh(this.geometries.get(kind)!, this.materials.get(kind)!, count);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
      mesh.frustumCulled = false;
      mesh.count = count;
      this.meshes.set(kind, mesh);
      this.scene.add(mesh);
    }
    const fill = new Map<EntityKind, number>();
    this.slots = nodes.map((n) => {
      const index = fill.get(n.kind) ?? 0;
      fill.set(n.kind, index + 1);
      return { mesh: this.meshes.get(n.kind)!, index };
    });
    this.scales = new Float32Array(nodes.map((n) => 0.9 + Math.log2(1 + n.degree) * 0.5));

    // edges
    if (this.lines) {
      this.scene.remove(this.lines);
      this.lines.geometry.dispose();
      this.lines = null;
    }
    if (edges.length) {
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(edges.length * 6), 3).setUsage(THREE.DynamicDrawUsage));
      g.setAttribute('color', new THREE.BufferAttribute(new Float32Array(edges.length * 6), 3));
      this.lines = new THREE.LineSegments(g, this.lineMat);
      this.lines.frustumCulled = false;
      this.scene.add(this.lines);
    }

    // initial positions & layout
    const init = new Float32Array(nodes.length * 3).fill(Number.NaN);
    nodes.forEach((n, i) => {
      const p = this.known.get(n.key);
      if (p) init.set(p, i * 3);
      else {
        // start next to an already placed neighbour if there is one
        const nb = this.adjacency[i].map((j) => this.known.get(nodes[j].key)).find(Boolean);
        if (nb) init.set([nb[0] + (Math.random() - 0.5) * 8, nb[1] + (Math.random() - 0.5) * 8, nb[2] + (Math.random() - 0.5) * 8], i * 3);
      }
    });
    this.positions = new Float32Array(nodes.length * 3);
    for (let i = 0; i < init.length; i++) this.positions[i] = Number.isFinite(init[i]) ? init[i] : 0;

    const links = new Uint32Array(edges.length * 2);
    const distance = new Float32Array(edges.length);
    const strength = new Float32Array(edges.length);
    edges.forEach((e, k) => {
      links[k * 2] = e.from;
      links[k * 2 + 1] = e.to;
      distance[k] = RELATION_DISTANCE[e.relation] ?? 17;
      strength[k] = 0.4 + 0.6 * Math.max(0, Math.min(1, e.confidence));
    });
    this.epoch++;
    this.earlyFit = false;
    this.layoutRunning = nodes.length > 0;
    this.cb.onLayout?.(this.layoutRunning);
    const req: LayoutRequest = { type: 'start', epoch: this.epoch, count: nodes.length, init, links, distance, strength };
    this.worker?.postMessage(req, [init.buffer, links.buffer, distance.buffer, strength.buffer]);

    this.rebuildLabels();
    this.dirtyPositions = true;
    this.dirtyColors = true;
  }

  private onLayout(m: LayoutResponse) {
    if (m.epoch !== this.epoch || m.positions.length !== this.nodes.length * 3) return;
    this.positions = m.positions;
    this.dirtyPositions = true;
    if (m.done) {
      this.layoutRunning = false;
      this.cb.onLayout?.(false);
      if (this.autoFit) {
        this.autoFit = false;
        this.fit();
      }
    } else if (this.autoFit && !this.earlyFit && m.alpha < 0.3) {
      // frame the graph once while it is still settling, then again when it is done
      this.earlyFit = true;
      this.fit(false);
    }
  }

  relayout() {
    this.known.clear();
    this.autoFit = true;
    this.setGraph(this.nodes, this.edges, true);
  }

  // ------------------------------------------------------------------ selection

  select(key: string | null, focus = false) {
    const i = key ? this.nodes.findIndex((n) => n.key === key) : -1;
    this.selected = i;
    this.highlighted = -1;
    this.dirtyColors = true;
    this.rebuildLabels();
    if (focus && i >= 0) this.focusNode(i);
  }

  highlightEdge(id: string | null) {
    this.highlighted = id ? this.edges.findIndex((e) => e.id === id) : -1;
    this.dirtyColors = true;
  }

  focusNode(i: number) {
    if (!this.rig || i < 0) return;
    const p = this.v.set(this.positions[i * 3], this.positions[i * 3 + 1], this.positions[i * 3 + 2]);
    this.rig.focus(p.clone(), 34 + this.scales[i] * 6);
  }

  /** Frame the whole graph. */
  fit(animate = true) {
    if (!this.rig || !this.nodes.length) return;
    const n = this.nodes.length;
    const d: number[] = [];
    for (let i = 0; i < n; i++) d.push(Math.hypot(this.positions[i * 3], this.positions[i * 3 + 1], this.positions[i * 3 + 2]));
    d.sort((a, b) => a - b);
    const radius = Math.max(12, d[Math.floor((n - 1) * 0.95)] + 6);
    const fov = (this.camera.fov * Math.PI) / 180;
    const fovMin = Math.min(fov, 2 * Math.atan(Math.tan(fov / 2) * this.camera.aspect));
    const dist = radius / Math.sin(fovMin / 2);
    this.rig.setHome(dist, new THREE.Vector3());
    if (animate) this.rig.reset(1.1);
    else this.rig.focus(new THREE.Vector3(), dist, 0.6);
  }

  resetCamera() {
    this.rig?.reset();
  }

  /** PNG snapshot of the current view. */
  snapshot(): string {
    this.renderNow();
    return this.canvas.toDataURL('image/png');
  }

  updateOptions(next: Partial<NetworkOptions>) {
    const prev = this.opts;
    this.opts = { ...prev, ...next };
    if (this.opts.reduceMotion !== prev.reduceMotion) this.rig?.setReduceMotion(this.opts.reduceMotion);
    if (this.opts.bloom !== prev.bloom) this.buildPipeline();
    if (this.opts.maxPixelRatio !== prev.maxPixelRatio) this.resize();
  }

  dispose() {
    this.disposed = true;
    // isolated steps: releasing GPU objects of a lost device may throw inside three.js
    const safe = (fn: () => void) => {
      try {
        fn();
      } catch {
        /* resource already gone with the lost device */
      }
    };
    safe(() => settle(this.renderer?.setAnimationLoop(null)));
    safe(() => this.worker?.postMessage({ type: 'stop' } satisfies LayoutRequest));
    safe(() => this.worker?.terminate());
    safe(() => this.ro?.disconnect());
    safe(() => this.rig?.dispose());
    for (const el of this.labelPool) el.remove();
    safe(() => this.pipeline?.dispose());
    for (const n of this.fx) safe(() => n.dispose());
    for (const m of this.meshes.values()) safe(() => m.dispose());
    safe(() => this.lines?.geometry.dispose());
    for (const d of this.disposables) safe(() => d.dispose());
    safe(() => settle(this.renderer?.dispose()));
    this.renderer = null;
  }

  // ------------------------------------------------------------------ per-frame work

  private resize() {
    const renderer = this.renderer;
    if (!renderer) return;
    const host = this.canvas.parentElement ?? this.canvas;
    this.width = Math.max(1, host.clientWidth);
    this.height = Math.max(1, host.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, Math.max(0.5, this.opts.maxPixelRatio)));
    renderer.setSize(this.width, this.height, false);
    this.camera.aspect = this.width / this.height;
    this.camera.updateProjectionMatrix();
    this.needsRender = true;
  }

  private updateMatrices() {
    const p = this.positions;
    this.nodes.forEach((_, i) => {
      const s = this.scales[i] * (i === this.selected ? 1.4 : i === this.hovered ? 1.2 : 1);
      this.dummy.position.set(p[i * 3], p[i * 3 + 1], p[i * 3 + 2]);
      this.dummy.scale.setScalar(s);
      this.dummy.updateMatrix();
      const slot = this.slots[i];
      slot.mesh.setMatrixAt(slot.index, this.dummy.matrix);
    });
    for (const m of this.meshes.values()) m.instanceMatrix.needsUpdate = true;
    if (this.lines) {
      const attr = this.lines.geometry.getAttribute('position') as THREE.BufferAttribute;
      const arr = attr.array as Float32Array;
      this.edges.forEach((e, k) => {
        arr[k * 6] = p[e.from * 3];
        arr[k * 6 + 1] = p[e.from * 3 + 1];
        arr[k * 6 + 2] = p[e.from * 3 + 2];
        arr[k * 6 + 3] = p[e.to * 3];
        arr[k * 6 + 4] = p[e.to * 3 + 1];
        arr[k * 6 + 5] = p[e.to * 3 + 2];
      });
      attr.needsUpdate = true;
    }
  }

  private updateColors() {
    const sel = this.selected;
    const near = new Set<number>(sel >= 0 ? [sel, ...this.adjacency[sel]] : []);
    this.nodes.forEach((n, i) => {
      this.color.set(ENTITY_META[n.kind].color);
      let k = 1;
      if (sel >= 0) k = i === sel ? 1.6 : near.has(i) ? 1.05 : 0.22;
      if (i === this.hovered) k = Math.max(k, 1.3);
      this.color.multiplyScalar(k);
      const slot = this.slots[i];
      slot.mesh.setColorAt(slot.index, this.color);
    });
    for (const m of this.meshes.values()) if (m.instanceColor) m.instanceColor.needsUpdate = true;
    if (this.lines) {
      const attr = this.lines.geometry.getAttribute('color') as THREE.BufferAttribute;
      const arr = attr.array as Float32Array;
      this.edges.forEach((e, k) => {
        let b = 0.16 + 0.42 * Math.max(0, Math.min(1, e.confidence));
        if (sel >= 0) b = e.from === sel || e.to === sel ? 0.55 + 0.45 * e.confidence : 0.05;
        if (k === this.highlighted) b = 1.6;
        if (this.hovered >= 0 && sel < 0 && (e.from === this.hovered || e.to === this.hovered)) b = Math.max(b, 0.8);
        for (let j = 0; j < 6; j++) arr[k * 6 + j] = b * (j % 3 === 2 ? 1 : 0.94);
      });
      attr.needsUpdate = true;
    }
    this.dirtyPositions = true; // scales depend on selection/hover
  }

  private updateFlows(dt: number) {
    const sprite = this.flowSprite;
    const attr = this.flowAttr;
    if (!sprite || !attr) return;
    const list = this.selected >= 0 ? this.edgesOf[this.selected] : [];
    const goal = list.length && !this.opts.reduceMotion ? 1 : 0;
    this.flowOpacity.value += (goal - this.flowOpacity.value) * (1 - Math.exp(-dt * 5));
    if (!list.length || this.opts.reduceMotion) {
      sprite.count = 0;
      return;
    }
    const arr = attr.array as Float32Array;
    const p = this.positions;
    let c = 0;
    for (let q = 0; q < list.length && c < MAX_FLOWS; q++) {
      const e = this.edges[list[q]];
      // pulses travel from the evidence towards the selected node
      const [a, b] = e.to === this.selected ? [e.from, e.to] : [e.to, e.from];
      for (let r = 0; r < 2 && c < MAX_FLOWS; r++) {
        const t = (this.time * 0.35 + q * 0.17 + r * 0.5) % 1;
        arr[c * 3] = p[a * 3] + (p[b * 3] - p[a * 3]) * t;
        arr[c * 3 + 1] = p[a * 3 + 1] + (p[b * 3 + 1] - p[a * 3 + 1]) * t;
        arr[c * 3 + 2] = p[a * 3 + 2] + (p[b * 3 + 2] - p[a * 3 + 2]) * t;
        c++;
      }
    }
    sprite.count = c;
    attr.needsUpdate = true;
  }

  private rebuildLabels() {
    const set = new Set<number>();
    if (this.selected >= 0) {
      set.add(this.selected);
      [...this.adjacency[this.selected]].sort((a, b) => this.nodes[b].degree - this.nodes[a].degree).slice(0, 24).forEach((i) => set.add(i));
    } else {
      this.nodes
        .map((n, i) => [n.degree, i] as const)
        .sort((a, b) => b[0] - a[0])
        .slice(0, 14)
        .forEach(([, i]) => set.add(i));
    }
    if (this.hovered >= 0) set.add(this.hovered);
    this.labelSet = [...set].slice(0, MAX_LABELS);
    this.labelPool.forEach((el, j) => {
      const i = this.labelSet[j];
      if (i === undefined) {
        el.style.opacity = '0';
        el.textContent = '';
        return;
      }
      const n = this.nodes[i];
      el.textContent = n.label.length > 46 ? `${n.label.slice(0, 45)}…` : n.label;
      el.className = `node-label${i === this.selected ? ' selected' : ''}${i === this.hovered ? ' hover' : ''}`;
    });
    this.needsRender = true;
  }

  private placeLabels() {
    const tanHalf = Math.tan((this.camera.fov * Math.PI) / 360);
    this.labelPool.forEach((el, j) => {
      const i = this.labelSet[j];
      if (i === undefined) return;
      this.v.set(this.positions[i * 3], this.positions[i * 3 + 1], this.positions[i * 3 + 2]);
      const dist = this.v.distanceTo(this.camera.position);
      this.v.project(this.camera);
      if (this.v.z > 1 || this.v.z < -1) {
        el.style.opacity = '0';
        return;
      }
      const x = (this.v.x * 0.5 + 0.5) * this.width;
      const y = (-this.v.y * 0.5 + 0.5) * this.height;
      const pr = (this.scales[i] * this.height) / (2 * dist * tanHalf);
      el.style.transform = `translate(${x.toFixed(1)}px, ${(y + pr + 6).toFixed(1)}px) translate(-50%, 0)`;
      el.style.opacity = i === this.selected || i === this.hovered ? '1' : '0.72';
    });
  }

  /** Nearest node to the pointer in screen space (accounts for the node's projected size). */
  private pick(ndc: THREE.Vector2): number {
    const n = this.nodes.length;
    if (!n) return -1;
    this.camera.updateMatrixWorld();
    this.viewProj.multiplyMatrices(this.camera.projectionMatrix, this.camera.matrixWorldInverse);
    const e = this.viewProj.elements;
    const px = (ndc.x * 0.5 + 0.5) * this.width;
    const py = (-ndc.y * 0.5 + 0.5) * this.height;
    const tanHalf = Math.tan((this.camera.fov * Math.PI) / 360);
    let best = -1;
    let bestD = Infinity;
    for (let i = 0; i < n; i++) {
      const x = this.positions[i * 3];
      const y = this.positions[i * 3 + 1];
      const z = this.positions[i * 3 + 2];
      const w = e[3] * x + e[7] * y + e[11] * z + e[15];
      if (w <= 0.0001) continue;
      const sx = (((e[0] * x + e[4] * y + e[8] * z + e[12]) / w) * 0.5 + 0.5) * this.width;
      const sy = (-((e[1] * x + e[5] * y + e[9] * z + e[13]) / w) * 0.5 + 0.5) * this.height;
      const d2 = (sx - px) ** 2 + (sy - py) ** 2;
      const pr = (this.scales[i] * 1.3 * this.height) / (2 * w * tanHalf);
      const lim = Math.max(9, pr + 4);
      if (d2 < lim * lim && d2 < bestD) {
        bestD = d2;
        best = i;
      }
    }
    return best;
  }

  private renderNow() {
    const renderer = this.renderer;
    if (!renderer) return;
    if (this.pipeline) this.pipeline.render();
    else renderer.render(this.scene, this.camera);
  }

  /**
   * Animation-loop entry. A GPU failure that is not reported as a device loss (e.g. errors
   * thrown by a broken device after a driver reset) is detected here and escalated to the
   * owner, which rebuilds the scene in a safer mode.
   */
  private frame(now: number) {
    try {
      this.drawFrame(now);
      this.frameErrors = 0;
    } catch (e) {
      if (++this.frameErrors < 3 || this.lost) return;
      this.lost = true;
      settle(this.renderer?.setAnimationLoop(null));
      this.cb.onLost?.(e instanceof Error ? e.message : String(e));
    }
  }

  private drawFrame(now: number) {
    const rig = this.rig;
    if (this.disposed || this.lost || !rig) return;
    const frameDt = this.pacer.tick(now, this.opts.fpsLimit);
    if (frameDt === null) return;
    const dt = Math.min(0.05, frameDt);
    this.time += dt;

    rig.update(dt);
    if (rig.moving) this.needsRender = true;

    const h = rig.pointerInside ? this.pick(rig.pointer) : -1;
    if (h !== this.hovered) {
      this.hovered = h;
      this.canvas.style.cursor = h >= 0 ? 'pointer' : '';
      this.cb.onHover?.(h >= 0 ? this.nodes[h].key : null);
      this.dirtyColors = true;
      this.rebuildLabels();
    }
    if (this.dirtyColors) {
      this.dirtyColors = false;
      this.updateColors();
    }
    if (this.dirtyPositions) {
      this.dirtyPositions = false;
      this.updateMatrices();
      this.needsRender = true;
    }
    if (this.selected >= 0 || this.flowOpacity.value > 0.01) {
      this.updateFlows(dt);
      this.needsRender = true;
    }
    if (this.needsRender) {
      this.needsRender = false;
      this.placeLabels();
      this.renderNow();
    }
  }
}
