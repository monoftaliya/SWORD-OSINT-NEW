<!-- Stat tile: label · value · optional context line and trend sparkline. -->
<script lang="ts">
  import Sparkline from './charts/Sparkline.svelte';

  let {
    label,
    value,
    sub = '',
    trend = null,
    tone = 'neutral',
  }: { label: string; value: string; sub?: string; trend?: number[] | null; tone?: 'neutral' | 'ok' | 'warn' | 'err' } = $props();
</script>

<div class="tile {tone}">
  <span class="caption">{label}</span>
  <span class="value">{value}</span>
  {#if sub}<span class="sub">{sub}</span>{/if}
  {#if trend && trend.length > 1}
    <div class="trend"><Sparkline values={trend} name={label} /></div>
  {/if}
</div>

<style>
  .tile {
    display: flex;
    flex-direction: column;
    gap: 3px;
    padding: 13px 15px 12px;
    border-radius: 12px;
    border: 1px solid var(--line);
    background: rgba(255, 255, 255, 0.022);
    min-width: 0;
  }
  .caption {
    font-size: 11.5px;
    color: var(--fg-3);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .value {
    font-size: 24px;
    font-weight: 600;
    letter-spacing: -0.01em;
    color: #fff;
    line-height: 1.15;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .sub {
    font-size: 11px;
    color: var(--fg-3);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .ok .sub {
    color: var(--ok);
  }
  .warn .sub {
    color: var(--warn);
  }
  .err .sub {
    color: var(--err);
  }
  .trend {
    margin-top: 6px;
  }
</style>
