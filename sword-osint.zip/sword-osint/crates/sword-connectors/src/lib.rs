//! # sword-connectors — Source Connectors
//!
//! Infrastructure ([`http`], [`ratelimit`], [`doh`], [`whois`]) plus one module per source
//! adapter in [`adapters`]. The [`Registry`] is the catalogue the Search Engine plans
//! investigations from and the UI lists in DATABASES → Sources.
//!
//! All sources are official APIs or officially published public interfaces. No adapter
//! bypasses authentication, CAPTCHA, platform limits or private profiles.

pub mod adapter;
pub mod adapters;
pub mod context;
pub mod doh;
pub mod http;
pub mod output;
pub mod ratelimit;
pub mod whois;

use std::sync::Arc;

pub use adapter::{health, SourceAdapter};
pub use context::ConnectorContext;
pub use http::HttpClient;

/// Catalogue of adapters.
#[derive(Clone)]
pub struct Registry {
    adapters: Vec<Arc<dyn SourceAdapter>>,
}

impl Registry {
    /// All built-in adapters, in display order.
    pub fn builtin() -> Self {
        let adapters: Vec<Arc<dyn SourceAdapter>> = vec![
            Arc::new(adapters::brave::Brave::new()),
            Arc::new(adapters::searxng::Searxng::new()),
            Arc::new(adapters::wikipedia::Wikipedia::new()),
            Arc::new(adapters::vk::Vk::new()),
            Arc::new(adapters::telegram::Telegram::new()),
            Arc::new(adapters::bluesky::Bluesky::new()),
            Arc::new(adapters::mastodon::Mastodon::new()),
            Arc::new(adapters::hackernews::HackerNews::new()),
            Arc::new(adapters::website::Website::new()),
            Arc::new(adapters::wayback::Wayback::new()),
            Arc::new(adapters::dns::Dns::new()),
            Arc::new(adapters::rdap::Rdap::new()),
            Arc::new(adapters::ct::CertTransparency::new()),
            Arc::new(adapters::hibp::Hibp::new()),
            Arc::new(adapters::openalex::OpenAlex::new()),
            Arc::new(adapters::wikidata::Wikidata::new()),
            Arc::new(adapters::gleif::Gleif::new()),
            Arc::new(adapters::github::GitHub::new()),
        ];
        Registry { adapters }
    }

    /// Custom catalogue (tests, embedding).
    pub fn from_adapters(adapters: Vec<Arc<dyn SourceAdapter>>) -> Self {
        Registry { adapters }
    }

    pub fn all(&self) -> &[Arc<dyn SourceAdapter>] {
        &self.adapters
    }

    pub fn get(&self, id: &str) -> Option<Arc<dyn SourceAdapter>> {
        self.adapters.iter().find(|a| a.info().id == id).cloned()
    }

    pub fn infos(&self) -> Vec<sword_core::AdapterInfo> {
        self.adapters.iter().map(|a| a.info().clone()).collect()
    }

    /// Vault keys of all credentials declared by adapters (+ audit-only keys).
    pub fn credential_keys(&self) -> Vec<String> {
        self.adapters.iter().flat_map(|a| a.info().credentials.iter().map(|c| c.key.clone())).collect()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashSet;
    use sword_core::Category;

    #[test]
    fn registry_is_consistent() {
        let r = Registry::builtin();
        let ids: HashSet<_> = r.all().iter().map(|a| a.info().id.clone()).collect();
        assert_eq!(ids.len(), r.all().len(), "adapter ids must be unique");
        for c in Category::ALL {
            assert!(r.all().iter().any(|a| a.info().categories.contains(&c)), "category {c:?} has no adapter");
        }
        for a in r.all() {
            let info = a.info();
            assert!(info.rate_limit_per_minute > 0);
            assert!(!info.methodology.is_empty());
            assert!(!info.input_kinds.is_empty());
        }
    }
}
