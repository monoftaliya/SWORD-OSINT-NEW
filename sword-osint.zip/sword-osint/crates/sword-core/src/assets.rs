//! The analyst's own assets.
//!
//! Checks that reveal information about a specific account (e.g. «was this e-mail address
//! part of a breach») are allowed only for addresses the analyst registered as their own
//! in INTELLIGENCE → «Мои активы». Active HTTP probes (exposed files) require a domain
//! ownership proof via a DNS TXT record. Only hashes of e-mail addresses are kept here.

use std::collections::HashSet;

use crate::util::sha256_hex;

#[derive(Debug, Clone, Default)]
pub struct OwnedAssets {
    /// SHA-256 of lower-cased e-mail addresses the analyst attested as their own.
    pub email_hashes: HashSet<String>,
    /// Domains whose ownership was proven with a DNS TXT record.
    pub verified_domains: HashSet<String>,
    /// Domains the analyst attested as their own (not yet proven).
    pub attested_domains: HashSet<String>,
}

impl OwnedAssets {
    pub fn owns_email(&self, email: &str) -> bool {
        self.email_hashes.contains(&email_hash(email))
    }

    pub fn domain_verified(&self, domain: &str) -> bool {
        let d = domain.trim().trim_end_matches('.').to_lowercase();
        self.verified_domains.contains(&d)
    }
}

/// Canonical hash of an e-mail address used across the app.
pub fn email_hash(email: &str) -> String {
    sha256_hex(email.trim().to_lowercase().as_bytes())
}
