//! DNS records of a domain via DNS-over-HTTPS: A/AAAA/MX/NS/TXT/CAA/SOA, SPF/DMARC policies
//! and the DNSSEC validation flag.

use async_trait::async_trait;
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordError, SwordResult,
};

use super::info;
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::doh::{self, RecordType};
use crate::output::{FindingExt, OutputBuilder};

pub struct Dns {
    info: AdapterInfo,
}

impl Default for Dns {
    fn default() -> Self {
        Self::new()
    }
}

/// Extract `p=` from a DMARC record.
pub fn dmarc_policy(record: &str) -> Option<String> {
    record.split(';').map(str::trim).find_map(|kv| kv.strip_prefix("p=").map(|v| v.trim().to_lowercase()))
}

/// Final `all` qualifier of an SPF record: `-all`, `~all`, `?all`, `+all`.
pub fn spf_all(record: &str) -> Option<String> {
    record.split_whitespace().find(|t| t.trim_start_matches(['-', '~', '?', '+']) == "all").map(str::to_string)
}

impl Dns {
    pub fn new() -> Self {
        Dns {
            info: info(
                "dns",
                "DNS (DoH)",
                "Cloudflare / Google Public DNS",
                "DNS-записи домена: адреса, почтовые серверы, DNS-серверы, TXT (SPF, верификации), CAA, DMARC, признак DNSSEC.",
                "DNS-over-HTTPS JSON API выбранного резолвера (cloudflare-dns.com или dns.google). Запрашиваются A, AAAA, MX, NS, \
                 TXT, CAA, SOA и _dmarc TXT; флаг AD отражает успешную проверку DNSSEC резолвером. Каждая запись цитируется URL запроса.",
                &[Category::DomainIntel, Category::EmailExposure],
                &[InputKind::Domain, InputKind::Url, InputKind::Email],
                vec![],
                vec![],
                600,
                "https://developers.cloudflare.com/1.1.1.1/encryption/dns-over-https/make-api-requests/dns-json/",
                Some("https://developers.google.com/speed/public-dns/docs/doh/json"),
                true,
            ),
        }
    }
}

#[async_trait]
impl SourceAdapter for Dns {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let r = doh::query(ctx, "example.com", RecordType::A).await?;
        Ok(vec![PermissionCheck::granted(
            "DoH",
            format!("Резолвер {} отвечает (DNSSEC AD={})", ctx.settings.network.doh_provider, r.ad),
        )])
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let host = input.domain.clone().ok_or_else(|| SwordError::InvalidInput("нужен домен".into()))?;
        // For e-mail and URL inputs the mail/zone records live on the registrable domain.
        let zone = if input.kind == InputKind::Url { host.clone() } else { input.registrable_domain.clone().unwrap_or_else(|| host.clone()) };
        let mut b = OutputBuilder::new(&self.info);
        let dkey = keys::domain(&zone);
        b.entity(&dkey, EntityKind::Domain, &zone);
        let category = if input.kind == InputKind::Email { Category::EmailExposure } else { Category::DomainIntel };

        let a = doh::query(ctx, &zone, RecordType::A).await?;
        if a.is_nxdomain() {
            b.finding(category, FindingKind::DnsRecord, &format!("{zone}: домен не существует (NXDOMAIN)"), Some(&a.query_url));
            b.fact("DNS", &format!("{zone} не существует (NXDOMAIN)"), &a.query_url);
            b.source(&a.query_url, "DoH: A");
            return Ok(b.finish());
        }
        let mut dnssec = a.ad;
        let add = |b: &mut OutputBuilder, label: &str, values: &[String], url: &str| {
            if values.is_empty() {
                return;
            }
            b.attr(&dkey, label, &values.join(", "), url);
            b.finding(category, FindingKind::DnsRecord, &format!("{label}: {zone}"), Some(url))
                .snippet(&values.join("\n"))
                .entity(&dkey)
                .attr("Количество", values.len());
            b.source(url, &format!("DoH: {label} {zone}"));
        };
        add(&mut b, "A", &a.data_of(RecordType::A), &a.query_url);

        let aaaa = doh::query(ctx, &zone, RecordType::Aaaa).await?;
        add(&mut b, "AAAA", &aaaa.data_of(RecordType::Aaaa), &aaaa.query_url);

        let mx = doh::query(ctx, &zone, RecordType::Mx).await?;
        dnssec &= mx.ad;
        let mx_data = mx.data_of(RecordType::Mx);
        add(&mut b, "MX", &mx_data, &mx.query_url);
        let mut providers = std::collections::BTreeSet::new();
        for m in &mx_data {
            if let Some((_, host)) = doh::parse_mx(m) {
                if let Some(reg) = sword_core::input::registrable(&host) {
                    if reg != zone {
                        providers.insert(reg);
                    }
                }
            }
        }
        for p in &providers {
            let pk = keys::domain(p);
            b.entity(&pk, EntityKind::Domain, p);
            b.relate(&dkey, &pk, "mail_handled_by", 1.0, &mx.query_url, Some("MX-запись"));
        }
        if !providers.is_empty() {
            b.fact("Почта домена обслуживается", &providers.iter().cloned().collect::<Vec<_>>().join(", "), &mx.query_url);
        } else if mx_data.is_empty() {
            b.fact("Почта", "MX-записи отсутствуют — домен не принимает почту", &mx.query_url);
        }

        let ns = doh::query(ctx, &zone, RecordType::Ns).await?;
        let ns_data = ns.data_of(RecordType::Ns);
        add(&mut b, "NS", &ns_data, &ns.query_url);
        let ns_providers: std::collections::BTreeSet<String> =
            ns_data.iter().filter_map(|n| sword_core::input::registrable(n)).filter(|r| r != &zone).collect();
        for p in &ns_providers {
            let pk = keys::domain(p);
            b.entity(&pk, EntityKind::Domain, p);
            b.relate(&dkey, &pk, "dns_hosted_by", 1.0, &ns.query_url, Some("NS-запись"));
        }

        let txt = doh::query(ctx, &zone, RecordType::Txt).await?;
        let txt_data = txt.data_of(RecordType::Txt);
        add(&mut b, "TXT", &txt_data, &txt.query_url);
        let spf: Vec<&String> = txt_data.iter().filter(|t| t.to_lowercase().starts_with("v=spf1")).collect();
        match spf.as_slice() {
            [] => b.fact("SPF", "запись отсутствует", &txt.query_url),
            [one] => b.fact("SPF", &format!("{} (политика {})", one, spf_all(one).unwrap_or_else(|| "без all".into())), &txt.query_url),
            many => b.fact("SPF", &format!("{} записей — ошибка конфигурации (должна быть одна)", many.len()), &txt.query_url),
        }

        let dmarc = doh::query(ctx, &format!("_dmarc.{zone}"), RecordType::Txt).await?;
        let dmarc_rec = dmarc.data_of(RecordType::Txt).into_iter().find(|t| t.to_lowercase().starts_with("v=dmarc1"));
        match &dmarc_rec {
            Some(r) => {
                b.attr(&dkey, "DMARC", r, &dmarc.query_url);
                b.fact("DMARC", &format!("политика p={}", dmarc_policy(r).unwrap_or_else(|| "?".into())), &dmarc.query_url);
                b.finding(category, FindingKind::DnsRecord, &format!("DMARC: {zone}"), Some(&dmarc.query_url)).snippet(r).entity(&dkey);
            }
            None => b.fact("DMARC", "запись отсутствует", &dmarc.query_url),
        }
        b.source(&dmarc.query_url, "DoH: _dmarc");

        let caa = doh::query(ctx, &zone, RecordType::Caa).await?;
        add(&mut b, "CAA", &caa.data_of(RecordType::Caa), &caa.query_url);
        let soa = doh::query(ctx, &zone, RecordType::Soa).await?;
        add(&mut b, "SOA", &soa.data_of(RecordType::Soa), &soa.query_url);

        b.attr(&dkey, "DNSSEC", if dnssec { "проверено резолвером (AD)" } else { "не подтверждено" }, &a.query_url);
        b.fact("DNSSEC", if dnssec { "подпись зоны проверена резолвером" } else { "не подтверждено (флаг AD отсутствует)" }, &a.query_url);
        Ok(b.finish())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_policies() {
        assert_eq!(dmarc_policy("v=DMARC1; p=reject; rua=mailto:x@y"), Some("reject".into()));
        assert_eq!(spf_all("v=spf1 include:_spf.google.com ~all"), Some("~all".into()));
        assert_eq!(spf_all("v=spf1 mx"), None);
    }
}
