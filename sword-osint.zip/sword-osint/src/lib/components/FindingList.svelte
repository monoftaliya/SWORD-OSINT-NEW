<!--
  Findings grouped by category (or severity for audits). Rows show the source host, kind,
  date and confidence; long groups are revealed in steps to keep the DOM light.
-->
<script lang="ts">
  import Icon from './Icon.svelte';
  import Bits from './Bits.svelte';
  import type { Finding, Severity } from '../api/types';
  import type { IconName } from './icons';
  import { CATEGORIES, FINDING_KIND_LABEL, SEVERITY_META, categoryMeta } from '../util/labels';
  import { fmtDate, hostOf } from '../util/format';

  let {
    findings,
    selected = null,
    groupBy = 'category',
    onselect,
    empty = 'Результатов нет',
  }: {
    findings: Finding[];
    selected?: string | null;
    groupBy?: 'category' | 'severity';
    onselect: (f: Finding) => void;
    empty?: string;
  } = $props();

  const STEP = 30;
  let limits = $state<Record<string, number>>({});
  let collapsed = $state<Record<string, boolean>>({});

  const SEV_ORDER: Severity[] = ['critical', 'high', 'medium', 'low', 'info', 'pass'];

  type Group = { key: string; title: string; icon: IconName | null; items: Finding[] };

  const groups = $derived.by<Group[]>(() => {
    if (groupBy === 'severity') {
      return SEV_ORDER.map((s) => ({
        key: s,
        title: SEVERITY_META[s].label,
        icon: null,
        items: findings.filter((f) => (f.severity ?? 'info') === s),
      })).filter((g) => g.items.length);
    }
    return CATEGORIES.map((c) => ({
      key: c.id,
      title: c.label,
      icon: c.icon,
      items: findings.filter((f) => f.category === c.id).sort((a, b) => b.confidence - a.confidence),
    })).filter((g) => g.items.length);
  });
</script>

{#if findings.length === 0}
  <div class="empty small">{empty}</div>
{:else}
  <div class="groups">
    {#each groups as g (g.key)}
      {@const limit = limits[g.key] ?? STEP}
      <div class="group">
        <button class="ghead" onclick={() => (collapsed[g.key] = !collapsed[g.key])} aria-expanded={!collapsed[g.key]}>
          {#if g.icon}<Icon name={g.icon} size={14} />{:else}<span class="sevdot" style:background={SEVERITY_META[g.key as Severity].color}></span>{/if}
          <span class="gtitle">{g.title}</span>
          <span class="gcount num">{g.items.length}</span>
          <span class="spacer"></span>
          <Icon name={collapsed[g.key] ? 'chevronRight' : 'chevronDown'} size={13} />
        </button>
        {#if !collapsed[g.key]}
          <ul>
            {#each g.items.slice(0, limit) as f (f.id)}
              <li>
                <button class="row" class:selected={selected === f.id} onclick={() => onselect(f)}>
                  <span class="top">
                    {#if f.severity && groupBy === 'severity'}<Bits kind="severity" severity={f.severity} />{/if}
                    <span class="title">{f.title}</span>
                  </span>
                  <span class="meta">
                    <span class="kind">{FINDING_KIND_LABEL[f.kind]}</span>
                    {#if f.url}<span class="host mono">{hostOf(f.url)}</span>{/if}
                    {#if f.publishedAt}<span class="date">{fmtDate(f.publishedAt)}</span>{/if}
                    {#if groupBy === 'severity'}<span class="cat">{categoryMeta(f.category).label}</span>{/if}
                    <span class="spacer"></span>
                    <Bits kind="confidence" value={f.confidence} />
                  </span>
                </button>
              </li>
            {/each}
          </ul>
          {#if g.items.length > limit}
            <button class="more" onclick={() => (limits[g.key] = limit + STEP)}>Показать ещё {Math.min(STEP, g.items.length - limit)} из {g.items.length - limit}</button>
          {/if}
        {/if}
      </div>
    {/each}
  </div>
{/if}

<style>
  .groups {
    display: flex;
    flex-direction: column;
    gap: 10px;
  }
  .ghead {
    width: 100%;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 4px;
    border: none;
    background: none;
    color: var(--fg-2);
    cursor: pointer;
    font-size: 11px;
    letter-spacing: 0.08em;
    text-transform: uppercase;
  }
  .ghead:hover {
    color: #fff;
  }
  .gcount {
    color: var(--fg-3);
    letter-spacing: 0;
  }
  .sevdot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
  }
  ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .row {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: 4px;
    padding: 8px 10px;
    border-radius: 9px;
    border: 1px solid transparent;
    background: transparent;
    text-align: left;
    cursor: pointer;
    transition: background 0.15s, border-color 0.15s;
  }
  .row:hover {
    background: rgba(255, 255, 255, 0.035);
  }
  .row.selected {
    background: rgba(200, 215, 235, 0.07);
    border-color: var(--line-strong);
  }
  .top {
    display: flex;
    align-items: flex-start;
    gap: 8px;
  }
  .title {
    flex: 1;
    min-width: 0;
    color: var(--fg);
    font-size: 12.5px;
    line-height: 1.4;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
  .meta {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 11px;
    color: var(--fg-3);
    min-width: 0;
  }
  .host {
    font-size: 10.5px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    max-width: 150px;
  }
  .kind,
  .date,
  .cat {
    white-space: nowrap;
  }
  .more {
    margin: 4px 0 0 10px;
    border: none;
    background: none;
    color: var(--fg-3);
    font-size: 11.5px;
    cursor: pointer;
    padding: 4px 0;
  }
  .more:hover {
    color: #fff;
  }
</style>
