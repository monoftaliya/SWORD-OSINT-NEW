//! Secret detection in own repositories and in text the analyst plans to publish.
//!
//! * Local repository scan: respects `.gitignore` (ignored files are not published),
//!   skips binaries and large files, matches high-signal token formats plus generic
//!   high-entropy assignments.
//! * GitHub secret scanning alerts of own repositories (official API).
//! * Pre-publication text check: secrets plus personal data patterns validated with
//!   checksums (bank cards — Luhn, ИНН, СНИЛС, IBAN).
//!
//! Secret values are never stored: findings keep a 4-character prefix and a SHA-256
//! fingerprint only.

use std::path::{Path, PathBuf};
use std::sync::LazyLock;

use regex::Regex;
use serde_json::Value;
use sword_connectors::output::{FindingExt, OutputBuilder};
use sword_connectors::{http, ConnectorContext};
use sword_core::util::{redact_secret, sha256_hex, shannon_entropy};
use sword_core::{AdapterInfo, AdapterOutput, Category, FindingKind, Severity, SwordError, SwordResult};

pub struct Rule {
    pub id: &'static str,
    pub title: &'static str,
    pub severity: Severity,
    pub re: Regex,
    /// Capture group holding the secret (0 = whole match).
    pub group: usize,
    /// Minimal Shannon entropy of the secret (0 = no check).
    pub min_entropy: f64,
}

fn rule(id: &'static str, title: &'static str, severity: Severity, pattern: &str, group: usize, min_entropy: f64) -> Rule {
    Rule { id, title, severity, re: Regex::new(pattern).expect("valid secret pattern"), group, min_entropy }
}

pub static RULES: LazyLock<Vec<Rule>> = LazyLock::new(|| {
    vec![
        rule("private-key", "Закрытый ключ (PEM)", Severity::Critical, r"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP |ENCRYPTED )?PRIVATE KEY(?: BLOCK)?-----", 0, 0.0),
        rule("aws-access-key", "AWS Access Key ID", Severity::High, r"\b((?:AKIA|ASIA)[0-9A-Z]{16})\b", 1, 3.0),
        rule("aws-secret", "AWS Secret Access Key", Severity::Critical, r#"(?i)aws_secret_access_key\s*[:=]\s*["']?([A-Za-z0-9/+=]{40})"#, 1, 4.0),
        rule("github-token", "Токен GitHub", Severity::Critical, r"\b((?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{36,255}|github_pat_[A-Za-z0-9_]{22,255})\b", 1, 3.5),
        rule("gitlab-token", "Токен GitLab", Severity::Critical, r"\b(glpat-[A-Za-z0-9\-_]{20,})\b", 1, 3.5),
        rule("slack-token", "Токен Slack", Severity::High, r"\b(xox[baprs]-[A-Za-z0-9-]{10,})\b", 1, 3.0),
        rule("slack-webhook", "Webhook Slack", Severity::High, r"(https://hooks\.slack\.com/services/[A-Za-z0-9/_-]{20,})", 1, 0.0),
        rule("google-api-key", "Ключ Google API", Severity::High, r"\b(AIza[0-9A-Za-z\-_]{35})\b", 1, 3.5),
        rule("stripe-live", "Боевой ключ Stripe", Severity::Critical, r"\b((?:sk|rk)_live_[0-9a-zA-Z]{24,})\b", 1, 3.5),
        rule("telegram-bot", "Токен бота Telegram", Severity::Critical, r"\b([0-9]{8,10}:AA[0-9A-Za-z_-]{33})\b", 1, 3.5),
        rule("vk-token", "Ключ доступа VK", Severity::Critical, r"\b(vk1\.a\.[A-Za-z0-9_-]{30,})", 1, 3.5),
        rule("yandex-oauth", "OAuth-токен Яндекса", Severity::High, r"\b(y0_[A-Za-z0-9_-]{50,})", 1, 3.5),
        rule("openai-key", "Ключ OpenAI API", Severity::Critical, r"\b(sk-(?:proj|svcacct|admin)-[A-Za-z0-9_-]{40,})", 1, 3.5),
        rule("anthropic-key", "Ключ Anthropic API", Severity::Critical, r"\b(sk-ant-(?:api03|admin01)-[A-Za-z0-9_-]{80,})", 1, 3.5),
        rule("jwt", "JSON Web Token", Severity::Medium, r"\b(eyJ[A-Za-z0-9_-]{10,}\.eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})\b", 1, 3.5),
        rule(
            "connection-string",
            "Строка подключения с паролем",
            Severity::High,
            r"(?i)\b(?:postgres(?:ql)?|mysql|mariadb|mongodb(?:\+srv)?|redis|amqps?|mssql)://[^:\s/@]+:([^@\s/]{6,})@",
            1,
            2.5,
        ),
        rule(
            "generic-secret",
            "Секрет в присваивании",
            Severity::Medium,
            r#"(?i)\b(?:password|passwd|pwd|secret|api[_-]?key|access[_-]?token|auth[_-]?token|client[_-]?secret)\b\s*[:=]\s*["']([^"'\s]{10,})["']"#,
            1,
            3.6,
        ),
    ]
});

const PLACEHOLDERS: &[&str] = &["changeme", "example", "xxxx", "your", "placeholder", "dummy", "sample", "test", "${", "{{", "<", "****", "redacted"];

#[derive(Debug, Clone)]
pub struct SecretHit {
    pub rule_id: &'static str,
    pub title: &'static str,
    pub severity: Severity,
    pub line: usize,
    pub preview: String,
    pub fingerprint: String,
}

/// Find secrets in a text blob.
pub fn scan_text_for_secrets(text: &str) -> Vec<SecretHit> {
    let mut hits = Vec::new();
    for rule in RULES.iter() {
        for caps in rule.re.captures_iter(text) {
            let Some(m) = caps.get(rule.group).or_else(|| caps.get(0)) else { continue };
            let secret = m.as_str();
            let lower = secret.to_lowercase();
            if rule.group != 0 && PLACEHOLDERS.iter().any(|p| lower.contains(p)) {
                continue;
            }
            if rule.min_entropy > 0.0 && shannon_entropy(secret) < rule.min_entropy {
                continue;
            }
            let line = text[..m.start()].matches('\n').count() + 1;
            let fp = sha256_hex(secret.as_bytes());
            if hits.iter().any(|h: &SecretHit| h.fingerprint == fp[..12]) {
                continue;
            }
            hits.push(SecretHit {
                rule_id: rule.id,
                title: rule.title,
                severity: rule.severity,
                line,
                preview: if rule.id == "private-key" { "-----BEGIN … PRIVATE KEY-----".into() } else { redact_secret(secret) },
                fingerprint: fp[..12].to_string(),
            });
        }
    }
    hits
}

const SKIP_DIRS: &[&str] = &["node_modules", "target", "dist", "build", ".venv", "venv", "vendor", "__pycache__", ".next", ".nuxt", ".gradle"];
const MAX_FILE: u64 = 2 * 1024 * 1024;

#[derive(Debug, Default, Clone)]
pub struct LocalScanStats {
    pub files_scanned: usize,
    pub files_skipped: usize,
    pub bytes: u64,
}

/// Walk a local repository (blocking; call from a worker thread).
pub fn scan_local_repository(
    root: &Path,
    info: &AdapterInfo,
    cancel: &tokio_util::sync::CancellationToken,
) -> SwordResult<(AdapterOutput, LocalScanStats)> {
    if !root.is_dir() {
        return Err(SwordError::InvalidInput(format!("каталог не найден: {}", root.display())));
    }
    let mut b = OutputBuilder::new(info);
    let mut stats = LocalScanStats::default();
    let repo_name = root.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_else(|| root.display().to_string());
    let walker = ignore::WalkBuilder::new(root)
        .hidden(false)
        .git_ignore(true)
        .git_exclude(true)
        .filter_entry(|e| {
            let name = e.file_name().to_string_lossy();
            !(name == ".git" || SKIP_DIRS.contains(&name.as_ref()))
        })
        .build();
    let mut total_hits = 0usize;
    for entry in walker {
        if cancel.is_cancelled() {
            return Err(SwordError::Cancelled);
        }
        let Ok(entry) = entry else {
            stats.files_skipped += 1;
            continue;
        };
        if !entry.file_type().map(|t| t.is_file()).unwrap_or(false) {
            continue;
        }
        let path: PathBuf = entry.path().to_path_buf();
        let size = entry.metadata().map(|m| m.len()).unwrap_or(0);
        if size == 0 || size > MAX_FILE {
            stats.files_skipped += 1;
            continue;
        }
        let Ok(bytes) = std::fs::read(&path) else {
            stats.files_skipped += 1;
            continue;
        };
        if bytes.iter().take(8192).any(|&c| c == 0) {
            stats.files_skipped += 1; // binary
            continue;
        }
        stats.files_scanned += 1;
        stats.bytes += size;
        let text = String::from_utf8_lossy(&bytes);
        let rel = path.strip_prefix(root).unwrap_or(&path).display().to_string().replace('\\', "/");
        for hit in scan_text_for_secrets(&text) {
            total_hits += 1;
            b.finding(Category::DigitalFootprint, FindingKind::AuditIssue, &format!("{repo_name}: {} — {rel}:{}", hit.title, hit.line), None)
                .severity(hit.severity)
                .snippet(&format!("Файл {rel}, строка {}. Фрагмент: {}", hit.line, hit.preview))
                .attr("Правило", hit.rule_id)
                .attr("Отпечаток (SHA-256)", &hit.fingerprint)
                .attr("Рекомендация", "Отзовите и перевыпустите секрет, удалите его из истории git (git filter-repo / BFG) и храните секреты вне репозитория.");
            if total_hits >= 500 {
                b.note("Достигнут предел в 500 находок — сканирование прервано.");
                return Ok((b.finish(), stats));
            }
        }
    }
    if total_hits == 0 {
        b.finding(Category::DigitalFootprint, FindingKind::AuditIssue, &format!("{repo_name}: секреты не обнаружены"), None)
            .severity(Severity::Pass)
            .snippet(&format!("Проверено файлов: {}, пропущено: {}. История коммитов не анализировалась.", stats.files_scanned, stats.files_skipped));
    }
    b.note("Анализируется рабочая копия с учётом .gitignore; история коммитов не просматривается.");
    Ok((b.finish(), stats))
}

/// GitHub secret scanning alerts of an own repository (`owner/repo`).
pub async fn github_alerts(ctx: &ConnectorContext, info: &AdapterInfo, repo: &str) -> SwordResult<AdapterOutput> {
    let token = ctx
        .secret(sword_connectors::adapters::github::TOKEN)
        .ok_or_else(|| SwordError::NotConfigured("токен GitHub с правом Secret scanning alerts: read".into()))?;
    if !repo.contains('/') || repo.contains(char::is_whitespace) {
        return Err(SwordError::InvalidInput("ожидается owner/repo".into()));
    }
    let url = format!("https://api.github.com/repos/{repo}/secret-scanning/alerts");
    let req = ctx
        .http
        .client()
        .get(&url)
        .query(&[("state", "open"), ("per_page", "100"), ("hide_secret", "true")])
        .header("accept", "application/vnd.github+json")
        .header("x-github-api-version", "2022-11-28")
        .bearer_auth(token);
    let resp = ctx.send_with("github", 25, req).await?;
    let v: Value = http::read_json(resp).await.map_err(|e| match e {
        SwordError::NotFound(_) => SwordError::NotFound(format!("{repo}: secret scanning не включён или нет доступа к репозиторию")),
        SwordError::Forbidden(_) | SwordError::Unauthorized(_) => SwordError::Forbidden(format!("{repo}: токену нужны права «Secret scanning alerts: read»")),
        other => other,
    })?;
    let mut b = OutputBuilder::new(info);
    let page = format!("https://github.com/{repo}/security/secret-scanning");
    b.source(&page, &format!("GitHub secret scanning: {repo}"));
    let alerts = v.as_array().cloned().unwrap_or_default();
    if alerts.is_empty() {
        b.finding(Category::DigitalFootprint, FindingKind::AuditIssue, &format!("{repo}: открытых оповещений secret scanning нет"), Some(&page)).severity(Severity::Pass);
    }
    for a in &alerts {
        // The `secret` field is never read — `hide_secret=true` asks GitHub to omit it.
        let kind = a.get("secret_type_display_name").and_then(Value::as_str).unwrap_or("секрет");
        let html = a.get("html_url").and_then(Value::as_str).unwrap_or(&page).to_string();
        let validity = a.get("validity").and_then(Value::as_str).unwrap_or("unknown");
        let sev = if validity == "active" { Severity::Critical } else { Severity::High };
        b.finding(Category::DigitalFootprint, FindingKind::AuditIssue, &format!("{repo}: {kind}"), Some(&html))
            .severity(sev)
            .published(a.get("created_at").and_then(Value::as_str).and_then(sword_core::util::parse_date))
            .snippet(&format!("Оповещение #{}; валидность: {validity}.", a.get("number").and_then(Value::as_i64).unwrap_or(0)))
            .attr("Рекомендация", "Отзовите секрет у поставщика, затем закройте оповещение.");
    }
    b.fact("GitHub secret scanning", &format!("{repo}: открытых оповещений {}", alerts.len()), &page);
    Ok(b.finish())
}

// ---------------------------------------------------------------------------------------
// Pre-publication personal data check
// ---------------------------------------------------------------------------------------

static EMAIL: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"(?i)\b[a-z0-9._%+-]{1,64}@[a-z0-9.-]+\.[a-z]{2,}\b").unwrap());
static PHONE: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"(?:\+7|\b8)[\s(-]*\d{3}[\s)-]*\d{3}[\s-]*\d{2}[\s-]*\d{2}\b|\+\d{1,3}[\s-]?\(?\d{2,4}\)?[\s-]?\d{3}[\s-]?\d{2,4}[\s-]?\d{0,4}\b").unwrap());
static CARD: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"\b(?:\d[ -]?){13,19}\b").unwrap());
static INN: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"(?i)\bИНН\s*:?\s*(\d{10}|\d{12})\b").unwrap());
static SNILS: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"\b(\d{3})[- ]?(\d{3})[- ]?(\d{3})[ -]?(\d{2})\b").unwrap());
static IBAN: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"\b([A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]{4}){3,7}(?:[ ]?[A-Z0-9]{1,3})?)\b").unwrap());
static PASSPORT_RU: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"(?i)паспорт\w*[^\d]{0,20}(\d{2}\s?\d{2})\s?№?\s?(\d{6})").unwrap());
static BIRTH: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"(?i)(дата рождения|д\.\s?р\.|date of birth|born)\s*:?\s*\d{1,2}[./-]\d{1,2}[./-]\d{2,4}").unwrap());
static GEO: LazyLock<Regex> = LazyLock::new(|| Regex::new(r"\b-?\d{1,2}\.\d{4,},\s*-?\d{1,3}\.\d{4,}\b").unwrap());

pub fn luhn(digits: &str) -> bool {
    let ds: Vec<u32> = digits.chars().filter_map(|c| c.to_digit(10)).collect();
    if ds.len() < 13 || ds.len() > 19 {
        return false;
    }
    let sum: u32 = ds
        .iter()
        .rev()
        .enumerate()
        .map(|(i, &d)| if i % 2 == 1 { let x = d * 2; if x > 9 { x - 9 } else { x } } else { d })
        .sum();
    sum % 10 == 0
}

pub fn inn_valid(inn: &str) -> bool {
    let d: Vec<u32> = inn.chars().filter_map(|c| c.to_digit(10)).collect();
    let check = |coef: &[u32], n: usize| -> bool { (coef.iter().zip(d.iter()).map(|(c, x)| c * x).sum::<u32>() % 11) % 10 == d[n] };
    match d.len() {
        10 => check(&[2, 4, 10, 3, 5, 9, 4, 6, 8], 9),
        12 => check(&[7, 2, 4, 10, 3, 5, 9, 4, 6, 8], 10) && check(&[3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8], 11),
        _ => false,
    }
}

pub fn snils_valid(number9: &str, control: u32) -> bool {
    let d: Vec<u32> = number9.chars().filter_map(|c| c.to_digit(10)).collect();
    if d.len() != 9 {
        return false;
    }
    let sum: u32 = d.iter().enumerate().map(|(i, x)| x * (9 - i as u32)).sum();
    let expected = match sum {
        s if s < 100 => s,
        100 | 101 => 0,
        s => {
            let r = s % 101;
            if r == 100 { 0 } else { r }
        }
    };
    expected == control
}

pub fn iban_valid(iban: &str) -> bool {
    let s: String = iban.chars().filter(|c| !c.is_whitespace()).collect();
    if !s.is_ascii() || s.len() < 15 || s.len() > 34 {
        return false;
    }
    let rearranged = format!("{}{}", &s[4..], &s[..4]);
    let mut rem: u64 = 0;
    for c in rearranged.chars() {
        let v = if c.is_ascii_digit() { c.to_digit(10).unwrap() as u64 } else if c.is_ascii_uppercase() { c as u64 - 'A' as u64 + 10 } else { return false };
        rem = if v >= 10 { (rem * 100 + v) % 97 } else { (rem * 10 + v) % 97 };
    }
    rem == 1
}

/// Personal data + secrets in a text the analyst intends to publish (or already published).
pub fn scan_publication_text(text: &str, info: &AdapterInfo, label: &str) -> AdapterOutput {
    let mut b = OutputBuilder::new(info);
    let add = |b: &mut OutputBuilder, sev: Severity, title: &str, samples: Vec<String>, fix: &str| {
        if samples.is_empty() {
            return;
        }
        b.finding(Category::DigitalFootprint, FindingKind::AuditIssue, &format!("{label}: {title}"), None)
            .severity(sev)
            .snippet(&format!("Найдено: {}. Примеры (замаскированы): {}", samples.len(), samples.iter().take(5).cloned().collect::<Vec<_>>().join(", ")))
            .attr("Рекомендация", fix);
    };
    let mask = |s: &str| {
        let chars: Vec<char> = s.chars().collect();
        if chars.len() <= 4 {
            return "••••".to_string();
        }
        format!("{}••••{}", chars[..2].iter().collect::<String>(), chars[chars.len() - 2..].iter().collect::<String>())
    };
    let emails: Vec<String> = EMAIL.find_iter(text).map(|m| sword_core::util::mask_email(m.as_str())).collect();
    add(&mut b, Severity::Low, "адреса e-mail", emails, "Убедитесь, что публикация адресов необходима; используйте общие адреса (info@, security@).");
    let phones: Vec<String> = PHONE.find_iter(text).map(|m| mask(m.as_str())).collect();
    add(&mut b, Severity::Medium, "номера телефонов", phones, "Удалите личные номера или замените их корпоративными.");
    let cards: Vec<String> = CARD.find_iter(text).map(|m| m.as_str()).filter(|s| luhn(s)).map(mask).collect();
    add(&mut b, Severity::Critical, "номера банковских карт (проверка Луна)", cards, "Никогда не публикуйте номера карт.");
    let inns: Vec<String> = INN.captures_iter(text).filter_map(|c| c.get(1)).map(|m| m.as_str()).filter(|s| inn_valid(s)).map(mask).collect();
    add(&mut b, Severity::Medium, "ИНН (с корректной контрольной суммой)", inns, "ИНН физического лица — персональные данные (152-ФЗ); не публикуйте без необходимости.");
    let snils: Vec<String> = SNILS
        .captures_iter(text)
        .filter(|c| {
            let num = format!("{}{}{}", &c[1], &c[2], &c[3]);
            c[4].parse::<u32>().map(|ctrl| snils_valid(&num, ctrl)).unwrap_or(false)
        })
        .map(|c| mask(c.get(0).map(|m| m.as_str()).unwrap_or_default()))
        .collect();
    add(&mut b, Severity::High, "СНИЛС (с корректной контрольной суммой)", snils, "СНИЛС — персональные данные; удалите из публикации.");
    let ibans: Vec<String> = IBAN.find_iter(text).map(|m| m.as_str()).filter(|s| iban_valid(s)).map(mask).collect();
    add(&mut b, Severity::Medium, "банковские счета IBAN", ibans, "Проверьте необходимость публикации реквизитов.");
    let passports: Vec<String> = PASSPORT_RU.find_iter(text).map(|m| mask(m.as_str())).collect();
    add(&mut b, Severity::High, "паспортные данные", passports, "Удалите паспортные данные из публикации.");
    let births: Vec<String> = BIRTH.find_iter(text).map(|m| mask(m.as_str())).collect();
    add(&mut b, Severity::Medium, "даты рождения", births, "Дата рождения в сочетании с именем облегчает кражу личности.");
    let geo: Vec<String> = GEO.find_iter(text).map(|m| mask(m.as_str())).collect();
    add(&mut b, Severity::Low, "точные координаты", geo, "Проверьте, не раскрывают ли координаты домашний адрес или охраняемые объекты.");
    for hit in scan_text_for_secrets(text) {
        b.finding(Category::DigitalFootprint, FindingKind::AuditIssue, &format!("{label}: {} (строка {})", hit.title, hit.line), None)
            .severity(hit.severity)
            .snippet(&format!("Фрагмент: {}", hit.preview))
            .attr("Отпечаток (SHA-256)", &hit.fingerprint)
            .attr("Рекомендация", "Удалите секрет из текста и перевыпустите его.");
    }
    if b.finding_count() == 0 {
        b.finding(Category::DigitalFootprint, FindingKind::AuditIssue, &format!("{label}: персональные данные и секреты не обнаружены"), None)
            .severity(Severity::Pass)
            .snippet(&format!("Проверено символов: {}.", text.chars().count()));
    }
    b.finish()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn detects_tokens_and_skips_placeholders() {
        let text = "token = \"ghp_aB3dE5fG7hI9jK1lM3nO5pQ7rS9tU1vW3xY5\"\npassword = \"changeme123\"\nkey=AKIAIOSFODNN7EXAMPLQ";
        let hits = scan_text_for_secrets(text);
        assert!(hits.iter().any(|h| h.rule_id == "github-token" && h.line == 1));
        assert!(!hits.iter().any(|h| h.rule_id == "generic-secret"));
        assert!(hits.iter().all(|h| !h.preview.contains("aB3dE5")));
    }

    #[test]
    fn checksums() {
        assert!(luhn("4111 1111 1111 1111"));
        assert!(!luhn("4111 1111 1111 1112"));
        assert!(inn_valid("7707083893")); // ПАО Сбербанк
        assert!(!inn_valid("7707083894"));
        assert!(snils_valid("112233445", 95));
        assert!(iban_valid("GB82 WEST 1234 5698 7654 32"));
    }
}
