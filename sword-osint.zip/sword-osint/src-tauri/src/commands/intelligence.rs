//! INTELLIGENCE: own assets, ownership verification and the Privacy & Exposure Audit.

use std::sync::Arc;

use serde::Deserialize;
use sword_audit::identity::{self, PasswordExposure};
use sword_audit::{AuditCheck, AuditRequest, AuditTarget, TargetKind};
use sword_core::assets::email_hash;
use sword_core::util::{mask_email, new_id, now, random_token, sha256_hex};
use sword_core::{classify, EventSink, Finding, InputKind, InvestigationKind, InvestigationRecord, InvestigationStatus};
use sword_db::{Asset, AssetKind};
use tauri::{AppHandle, State};
use tauri_plugin_dialog::DialogExt;
use tokio_util::sync::CancellationToken;

use super::discovery::{persist_failure, persist_outcome};
use crate::error::{ApiError, ApiResult};
use crate::events::TauriSink;
use crate::state::{blocking, AppState};

fn vault_key(asset_id: &str) -> String {
    format!("asset.email.{asset_id}")
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NewAsset {
    pub kind: AssetKind,
    pub value: String,
    /// The analyst confirms the asset belongs to them / their organisation.
    pub attested: bool,
}

#[tauri::command]
pub async fn list_assets(state: State<'_, AppState>) -> ApiResult<Vec<Asset>> {
    let db = state.db.clone();
    blocking(move || db.list_assets()).await
}

#[tauri::command]
pub async fn add_asset(state: State<'_, AppState>, asset: NewAsset) -> ApiResult<Asset> {
    if !asset.attested {
        return Err(ApiError::invalid("подтвердите, что актив принадлежит вам или вашей организации"));
    }
    let raw = asset.value.trim().to_string();
    let id = new_id();
    let (display, value_hash, plain, token) = match asset.kind {
        AssetKind::Email => {
            let c = classify(&raw)?;
            if c.kind != InputKind::Email {
                return Err(ApiError::invalid("некорректный адрес e-mail"));
            }
            let email = c.email.unwrap_or_default();
            state.secrets.set(&vault_key(&id), &email)?;
            (mask_email(&email), email_hash(&email), None, None)
        }
        AssetKind::Domain => {
            let c = classify(&raw)?;
            let domain = match c.kind {
                InputKind::Domain | InputKind::Url => c.registrable_domain.or(c.domain),
                _ => None,
            }
            .ok_or_else(|| ApiError::invalid("укажите домен, например example.com"))?;
            (domain.clone(), sha256_hex(domain.as_bytes()), Some(domain), Some(random_token()))
        }
        AssetKind::RepoLocal => {
            let p = std::path::PathBuf::from(&raw);
            if !p.is_dir() {
                return Err(ApiError::invalid("каталог не найден"));
            }
            let display = p.file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_else(|| raw.clone());
            (display, sha256_hex(raw.as_bytes()), Some(raw.clone()), None)
        }
        AssetKind::RepoGithub => {
            let r = raw.trim_start_matches("https://github.com/").trim_end_matches('/').trim_end_matches(".git").to_string();
            let parts: Vec<&str> = r.split('/').collect();
            if parts.len() != 2 || parts.iter().any(|p| p.is_empty() || !p.chars().all(|c| c.is_ascii_alphanumeric() || "-_.".contains(c))) {
                return Err(ApiError::invalid("ожидается owner/repo"));
            }
            (r.clone(), sha256_hex(r.to_lowercase().as_bytes()), Some(r), None)
        }
    };
    let a = Asset {
        id: id.clone(),
        kind: asset.kind,
        display,
        value_hash,
        plain_value: plain,
        attested: true,
        verified: false,
        verification_token: token,
        created_at: now(),
        verified_at: None,
    };
    let db = state.db.clone();
    let to_insert = a.clone();
    let res = blocking(move || db.insert_asset(&to_insert)).await;
    if res.is_err() && a.kind == AssetKind::Email {
        let _ = state.secrets.delete(&vault_key(&id));
    }
    res?;
    Ok(a)
}

#[tauri::command]
pub async fn remove_asset(state: State<'_, AppState>, id: String) -> ApiResult<()> {
    let db = state.db.clone();
    let id2 = id.clone();
    let asset = blocking(move || db.get_asset(&id2)).await?;
    if asset.kind == AssetKind::Email {
        state.secrets.delete(&vault_key(&id))?;
    }
    let db = state.db.clone();
    blocking(move || db.delete_asset(&id)).await
}

/// Check the DNS TXT proof `sword-osint-verification=<token>` of a domain asset.
#[tauri::command]
pub async fn verify_asset(state: State<'_, AppState>, id: String) -> ApiResult<Asset> {
    let db = state.db.clone();
    let id2 = id.clone();
    let asset = blocking(move || db.get_asset(&id2)).await?;
    if asset.kind != AssetKind::Domain {
        return Err(ApiError::invalid("подтверждение через DNS доступно только для доменов"));
    }
    let (Some(domain), Some(token)) = (asset.plain_value.clone(), asset.verification_token.clone()) else {
        return Err(ApiError::invalid("у актива нет токена подтверждения"));
    };
    let ctx = state.context(CancellationToken::new())?;
    let ok = identity::verify_domain(&ctx, &domain, &token).await?;
    if !ok {
        return Err(ApiError::not_found(format!(
            "TXT-запись «{}» не найдена у {domain} или _sword-osint.{domain}. Изменения DNS могут распространяться до нескольких часов.",
            identity::verification_record(&token)
        )));
    }
    let db = state.db.clone();
    blocking(move || {
        db.set_asset_verified(&id, true)?;
        db.get_asset(&id)
    })
    .await
}

#[tauri::command]
pub async fn pick_folder(app: AppHandle) -> ApiResult<Option<String>> {
    let app2 = app.clone();
    let picked = tauri::async_runtime::spawn_blocking(move || app2.dialog().file().set_title("Выберите каталог репозитория").blocking_pick_folder())
        .await
        .map_err(|e| ApiError::internal(e.to_string()))?;
    match picked {
        Some(p) => Ok(Some(p.into_path().map_err(|e| ApiError::internal(e.to_string()))?.display().to_string())),
        None => Ok(None),
    }
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AuditRunRequest {
    pub asset_ids: Vec<String>,
    pub checks: Vec<AuditCheck>,
}

#[tauri::command]
pub async fn start_audit(app: AppHandle, state: State<'_, AppState>, request: AuditRunRequest) -> ApiResult<String> {
    if request.asset_ids.is_empty() || request.checks.is_empty() {
        return Err(ApiError::invalid("выберите активы и проверки"));
    }
    let db = state.db.clone();
    let assets = blocking(move || db.list_assets()).await?;
    let mut targets = Vec::new();
    for a in assets.into_iter().filter(|a| request.asset_ids.contains(&a.id)) {
        let (kind, value) = match a.kind {
            AssetKind::Email => {
                let v = state.secrets.get(&vault_key(&a.id))?.ok_or_else(|| ApiError::not_found(format!("адрес {} отсутствует в хранилище учётных данных", a.display)))?;
                (TargetKind::Email, v)
            }
            AssetKind::Domain => (TargetKind::Domain, a.plain_value.clone().unwrap_or_default()),
            AssetKind::RepoLocal => (TargetKind::RepoLocal, a.plain_value.clone().unwrap_or_default()),
            AssetKind::RepoGithub => (TargetKind::RepoGithub, a.plain_value.clone().unwrap_or_default()),
        };
        targets.push(AuditTarget { asset_id: a.id.clone(), kind, value, display: a.display.clone(), verified: a.verified });
    }
    if targets.is_empty() {
        return Err(ApiError::not_found("выбранные активы не найдены"));
    }
    let id = new_id();
    let cancel = CancellationToken::new();
    let ctx = state.context(cancel.clone())?;
    let mut categories: Vec<_> = request.checks.iter().map(|c| c.category()).collect();
    categories.sort();
    categories.dedup();
    let record = InvestigationRecord {
        id: id.clone(),
        kind: InvestigationKind::ExposureAudit,
        query: format!("Аудит: {}", targets.iter().map(|t| t.display.clone()).collect::<Vec<_>>().join(", ")),
        input_kind: InputKind::Text,
        categories,
        status: InvestigationStatus::Running,
        created_at: now(),
        finished_at: None,
        duration_ms: None,
        result_count: 0,
        source_count: 0,
        node_count: 0,
        edge_count: 0,
        adapters: vec![],
        summary: String::new(),
        key_facts: vec![],
        limitations: vec![],
        error: None,
        notes: String::new(),
    };
    let db = state.db.clone();
    let rec = record.clone();
    blocking(move || db.insert_running(&rec)).await?;
    state.register_run(&id, cancel);
    let app2 = app.clone();
    let id2 = id.clone();
    let req = AuditRequest { targets, checks: request.checks };
    tauri::async_runtime::spawn(async move {
        let sink: Arc<dyn EventSink> = Arc::new(TauriSink::new(app2.clone()));
        match sword_audit::run_audit(id2.clone(), req, ctx, sink.clone()).await {
            Ok(outcome) => {
                if let Err(e) = persist_outcome(&app2, &outcome).await {
                    tracing::error!(error = %e.message, "failed to persist audit");
                }
            }
            Err(e) => persist_failure(&app2, record, e.to_string(), sink.as_ref()).await,
        }
        tauri::Manager::state::<AppState>(&app2).finish_run(&id2);
    });
    Ok(id)
}

/// Pwned Passwords k-anonymity check. The password is neither stored nor logged.
#[tauri::command]
pub async fn check_password(state: State<'_, AppState>, password: String) -> ApiResult<PasswordExposure> {
    let ctx = state.context(CancellationToken::new())?;
    let r = identity::password_exposure(&ctx, &password).await;
    drop(password);
    Ok(r?)
}

/// Pre-publication check of a text for personal data and secrets (local, nothing is sent).
#[tauri::command]
pub fn scan_text(text: String, label: Option<String>) -> ApiResult<Vec<Finding>> {
    if text.len() > 2 * 1024 * 1024 {
        return Err(ApiError::invalid("текст больше 2 МБ"));
    }
    let info = AuditCheck::SecretsLocal.module_info();
    let label = label.filter(|l| !l.trim().is_empty()).unwrap_or_else(|| "Текст".into());
    Ok(sword_audit::secrets::scan_publication_text(&text, &info, &label).findings)
}

/// Fetch an own published page and run the same check over its visible text.
#[tauri::command]
pub async fn scan_url(state: State<'_, AppState>, url: String) -> ApiResult<Vec<Finding>> {
    let parsed = url::Url::parse(url.trim()).map_err(|_| ApiError::invalid("некорректный URL"))?;
    if !matches!(parsed.scheme(), "http" | "https") {
        return Err(ApiError::invalid("поддерживаются только http и https"));
    }
    // Pages are fetched and scanned only on domains whose ownership was verified via DNS.
    let host = parsed.host_str().unwrap_or_default().trim_end_matches('.').to_ascii_lowercase();
    let db = state.db.clone();
    let assets = blocking(move || db.list_assets()).await?;
    let owned = assets.iter().filter(|a| a.kind == AssetKind::Domain && a.verified).filter_map(|a| a.plain_value.as_deref()).any(|d| {
        let d = d.to_ascii_lowercase();
        host == d || host.ends_with(&format!(".{d}"))
    });
    if !owned {
        return Err(ApiError::forbidden(
            "проверка страниц доступна только для ваших доменов, подтверждённых через DNS (раздел «Ваши активы»)",
        ));
    }
    let http = state.http();
    let cancel = CancellationToken::new();
    let resp = http.send("scan-url", 30, http.client().get(parsed.as_str()), &cancel).await?;
    let resp = sword_connectors::http::ensure_success(resp).await?;
    let html = sword_connectors::http::read_text(resp, 4 * 1024 * 1024).await?;
    let text = sword_core::util::strip_html(&html.replace("</p>", "\n").replace("<br", "\n<br"));
    let info = AuditCheck::SecretsLocal.module_info();
    let label = parsed.host_str().unwrap_or("страница").to_string();
    let mut findings = sword_audit::secrets::scan_publication_text(&text, &info, &label).findings;
    for f in findings.iter_mut() {
        f.url = Some(parsed.to_string());
    }
    Ok(findings)
}
