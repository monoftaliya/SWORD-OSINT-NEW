//! Wikipedia (MediaWiki Action API) — encyclopedic articles about organisations and topics.

use async_trait::async_trait;
use sword_core::util::parse_date;
use sword_core::{AdapterInfo, AdapterOutput, Category, ClassifiedInput, FindingKind, InputKind, PermissionCheck, SwordResult};

use super::{arr, info, num, opt, s};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::output::{FindingExt, OutputBuilder};

pub struct Wikipedia {
    info: AdapterInfo,
}

impl Default for Wikipedia {
    fn default() -> Self {
        Self::new()
    }
}

impl Wikipedia {
    pub fn new() -> Self {
        Wikipedia {
            info: info(
                "wikipedia",
                "Wikipedia",
                "Wikimedia Foundation",
                "Поиск статей Википедии (русский и английский разделы) — справочный контекст об организациях, брендах и событиях.",
                "MediaWiki Action API: action=query&list=search для каждого языкового раздела. Используются заголовки, \
                 фрагменты и дата последней правки статьи; содержимое статей не копируется.",
                &[Category::WebSearch, Category::OrgIntel],
                &[InputKind::Text, InputKind::Domain, InputKind::Url],
                vec![],
                vec![opt("languages", "Языковые разделы", false, Some("ru,en"), "Коды языков через запятую.", Some("ru,en"))],
                60,
                "https://www.wikipedia.org/",
                Some("https://www.mediawiki.org/wiki/API:Search"),
                true,
            ),
        }
    }
}

#[async_trait]
impl SourceAdapter for Wikipedia {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let req = ctx
            .get("https://ru.wikipedia.org/w/api.php")
            .query(&[("action", "query"), ("meta", "siteinfo"), ("format", "json")]);
        let _: serde_json::Value = ctx.json(&self.info, req).await?;
        Ok(vec![PermissionCheck::granted("Action API", "Доступ без ключа")])
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let mut b = OutputBuilder::new(&self.info);
        let langs = ctx.option(&self.info, "languages").unwrap_or_else(|| "ru,en".into());
        let query = input.registrable_domain.clone().unwrap_or_else(|| input.text.clone());
        let per_lang = (ctx.max_results / 2).clamp(3, 10).to_string();
        for lang in langs.split(',').map(str::trim).filter(|l| l.len() >= 2 && l.len() <= 12 && l.chars().all(|c| c.is_ascii_alphabetic() || c == '-')) {
            let endpoint = format!("https://{lang}.wikipedia.org/w/api.php");
            let req = ctx.get(&endpoint).query(&[
                ("action", "query"),
                ("list", "search"),
                ("srsearch", query.as_str()),
                ("srlimit", per_lang.as_str()),
                ("srprop", "snippet|timestamp|wordcount"),
                ("format", "json"),
                ("utf8", "1"),
            ]);
            let v: serde_json::Value = ctx.json(&self.info, req).await?;
            b.source(
                &format!("https://{lang}.wikipedia.org/w/index.php?search={}", url::form_urlencoded::byte_serialize(query.as_bytes()).collect::<String>()),
                &format!("Википедия ({lang}): поиск «{query}»"),
            );
            for r in arr(&v, "/query/search") {
                let Some(title) = s(r, "title") else { continue };
                let page = format!("https://{lang}.wikipedia.org/wiki/{}", title.replace(' ', "_"));
                let url = url::Url::parse(&page).map(|u| u.to_string()).unwrap_or(page);
                b.finding(Category::OrgIntel, FindingKind::Encyclopedia, &title, Some(&url))
                    .snippet(&s(r, "snippet").unwrap_or_default())
                    .published(s(r, "timestamp").and_then(|t| parse_date(&t)))
                    .confidence(0.8)
                    .attr("Раздел", lang.to_uppercase())
                    .attr("Объём статьи, слов", num(r, "wordcount").map(|n| n.to_string()).unwrap_or_default());
                b.source(&url, &title);
            }
        }
        Ok(b.finish())
    }
}
