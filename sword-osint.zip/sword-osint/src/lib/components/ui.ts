/** Small shared UI helpers. */
import { api } from '../api/client';
import { app } from '../stores/app.svelte';

/** Open an http(s) link through the backend (validated, default browser). */
export async function openLink(url: string | null | undefined) {
  if (!url) return;
  try {
    await api.openExternal(url);
  } catch (e) {
    app.error(e, 'Открытие ссылки');
  }
}

export async function copyText(text: string, label = 'Скопировано') {
  try {
    await navigator.clipboard.writeText(text);
    app.toast('ok', label, 2200);
  } catch {
    app.toast('err', 'Не удалось скопировать в буфер обмена');
  }
}

/** Run an async action with a busy flag and error toast. */
export async function guarded<T>(fn: () => Promise<T>, errorPrefix: string): Promise<T | null> {
  try {
    return await fn();
  } catch (e) {
    app.error(e, errorPrefix);
    return null;
  }
}
