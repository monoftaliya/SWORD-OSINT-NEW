<!--
  Application shell: particle universe (background), title bar, navigation rail and the
  active section. Sections are separate lazily loaded chunks; they are prefetched while
  the app is idle so switching stays instant.
-->
<script lang="ts">
  import { onMount, type Component } from 'svelte';
  import TitleBar from './lib/components/TitleBar.svelte';
  import NavRail from './lib/components/NavRail.svelte';
  import Toasts from './lib/components/Toasts.svelte';
  import ParticleStage from './lib/components/ParticleStage.svelte';
  import Icon from './lib/components/Icon.svelte';
  import { api, desktop } from './lib/api/client';
  import { app, type SectionId } from './lib/stores/app.svelte';
  import { run } from './lib/stores/run.svelte';

  type Loader = () => Promise<{ default: Component }>;
  const loaders: Record<SectionId, Loader> = {
    discovery: () => import('./sections/Discovery.svelte'),
    network: () => import('./sections/Network.svelte'),
    intelligence: () => import('./sections/Intelligence.svelte'),
    databases: () => import('./sections/Databases.svelte'),
    analytics: () => import('./sections/Analytics.svelte'),
    history: () => import('./sections/History.svelte'),
    report: () => import('./sections/ReportStudio.svelte'),
    settings: () => import('./sections/Settings.svelte'),
  };
  const cache = new Map<SectionId, Component>();

  let current = $state.raw<{ id: SectionId; view: Component } | null>(null);
  let loadError = $state<string | null>(null);

  $effect(() => {
    const id = app.section;
    const hit = cache.get(id);
    if (hit) {
      current = { id, view: hit };
      loadError = null;
      return;
    }
    let cancelled = false;
    loaders[id]()
      .then((m) => {
        cache.set(id, m.default);
        if (cancelled) return;
        current = { id, view: m.default };
        loadError = null;
      })
      .catch((e: unknown) => {
        if (!cancelled) loadError = e instanceof Error ? e.message : String(e);
      });
    return () => {
      cancelled = true;
    };
  });

  onMount(() => {
    (async () => {
      await app.init();
      if (!desktop()) return;
      await run.bind();
      try {
        // After a reload of the interface, reattach to an investigation still running in the core.
        const live = await api.runningInvestigations();
        if (live.length) await run.open(live[0]);
      } catch {
        /* nothing running */
      }
    })();
    // WebView2 is Chromium: requestIdleCallback is always available.
    window.requestIdleCallback(() => {
      for (const [id, load] of Object.entries(loaders) as [SectionId, Loader][]) {
        if (!cache.has(id)) load().then((m) => cache.set(id, m.default)).catch(() => {});
      }
    }, { timeout: 4000 });
  });
</script>

<ParticleStage />
<TitleBar />
<NavRail />

<main class="content">
  {#if app.backend === 'offline'}
    <div class="offline glass" role="alert">
      <Icon name="alert" size={16} />
      <span>{app.backendError ?? 'Бэкенд недоступен.'}</span>
    </div>
  {/if}
  {#if loadError}
    <div class="empty">
      <Icon name="alert" size={22} />
      <span>Не удалось загрузить раздел: {loadError}</span>
      <button class="btn sm" onclick={() => app.navigate(app.section)}>Повторить</button>
    </div>
  {:else if current}
    <svelte:boundary>
      {#key current.id}
        <current.view />
      {/key}
      {#snippet failed(error, reset)}
        <div class="empty crash glass">
          <Icon name="alert" size={22} />
          <span>Ошибка интерфейса раздела: {error instanceof Error ? error.message : String(error)}</span>
          <button class="btn sm" onclick={reset}>Перезагрузить раздел</button>
        </div>
      {/snippet}
    </svelte:boundary>
  {/if}
</main>

<Toasts />

<style>
  .content {
    position: fixed;
    top: var(--titlebar);
    left: var(--rail);
    right: 0;
    bottom: 0;
    z-index: 10;
    pointer-events: none;
  }
  .content > :global(.empty),
  .offline,
  .crash {
    pointer-events: auto;
  }
  .offline {
    position: absolute;
    top: 14px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 5;
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 9px 14px;
    font-size: 12.5px;
    color: #ffe0e0;
    border-color: rgba(240, 138, 138, 0.3);
    max-width: 80%;
  }
  .crash {
    position: absolute;
    top: 30%;
    left: 50%;
    transform: translateX(-50%);
    max-width: 560px;
  }
</style>
