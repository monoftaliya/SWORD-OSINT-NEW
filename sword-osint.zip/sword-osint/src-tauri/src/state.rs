//! Application state shared by all commands.

use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::{Arc, Mutex, RwLock};
use std::time::Instant;

use sword_connectors::{ConnectorContext, HttpClient, Registry};
use sword_core::assets::OwnedAssets;
use sword_core::{AppSettings, SecretStore, SwordError, SwordResult};
use sword_db::{AssetKind, Database};
use sword_search::SearchEngine;
use tokio_util::sync::CancellationToken;

use crate::error::{ApiError, ApiResult};

pub struct AppPaths {
    pub data_dir: PathBuf,
    pub db_path: PathBuf,
    pub reports_dir: PathBuf,
    pub logs_dir: PathBuf,
}

pub struct AppState {
    pub db: Database,
    pub engine: SearchEngine,
    pub secrets: Arc<dyn SecretStore>,
    pub vault_persistent: bool,
    settings: RwLock<Arc<AppSettings>>,
    http: RwLock<HttpClient>,
    pub running: Mutex<HashMap<String, CancellationToken>>,
    pub paths: AppPaths,
    pub started: Instant,
}

impl AppState {
    pub fn new(db: Database, secrets: Arc<dyn SecretStore>, vault_persistent: bool, paths: AppPaths) -> SwordResult<Self> {
        let settings = db.load_settings()?;
        let http = HttpClient::new(&settings.network)?;
        Ok(AppState {
            db,
            engine: SearchEngine::new(Registry::builtin()),
            secrets,
            vault_persistent,
            settings: RwLock::new(Arc::new(settings)),
            http: RwLock::new(http),
            running: Mutex::new(HashMap::new()),
            paths,
            started: Instant::now(),
        })
    }

    pub fn registry(&self) -> &Registry {
        self.engine.registry()
    }

    pub fn settings(&self) -> Arc<AppSettings> {
        self.settings.read().map(|s| s.clone()).unwrap_or_default()
    }

    /// Replace settings; rebuilds the HTTP client when network options changed.
    pub fn apply_settings(&self, new: AppSettings) -> SwordResult<Arc<AppSettings>> {
        let new = Arc::new(new.sanitized());
        let network_changed = self.settings().network != new.network;
        if network_changed {
            let client = HttpClient::new(&new.network)?;
            if let Ok(mut h) = self.http.write() {
                *h = client;
            }
        }
        if let Ok(mut s) = self.settings.write() {
            *s = new.clone();
        }
        Ok(new)
    }

    pub fn http(&self) -> HttpClient {
        self.http.read().map(|h| h.clone()).expect("http client lock")
    }

    /// Own assets: hashes of attested e-mails and ownership-verified domains.
    pub fn owned_assets(&self) -> SwordResult<OwnedAssets> {
        let mut owned = OwnedAssets::default();
        for a in self.db.list_assets()? {
            match a.kind {
                AssetKind::Email if a.attested => {
                    owned.email_hashes.insert(a.value_hash.clone());
                }
                AssetKind::Domain => {
                    if let Some(d) = &a.plain_value {
                        if a.verified {
                            owned.verified_domains.insert(d.clone());
                        }
                        if a.attested {
                            owned.attested_domains.insert(d.clone());
                        }
                    }
                }
                _ => {}
            }
        }
        Ok(owned)
    }

    pub fn context(&self, cancel: CancellationToken) -> SwordResult<ConnectorContext> {
        Ok(ConnectorContext::new(self.http(), self.secrets.clone(), self.settings(), Arc::new(self.owned_assets()?), cancel))
    }

    pub fn register_run(&self, id: &str, token: CancellationToken) {
        if let Ok(mut m) = self.running.lock() {
            m.insert(id.to_string(), token);
        }
    }

    pub fn finish_run(&self, id: &str) {
        if let Ok(mut m) = self.running.lock() {
            m.remove(id);
        }
    }

    pub fn cancel_run(&self, id: &str) -> bool {
        match self.running.lock() {
            Ok(m) => m.get(id).map(|t| {
                t.cancel();
                true
            }),
            Err(_) => None,
        }
        .unwrap_or(false)
    }
}

/// Run blocking database work off the async runtime threads.
pub async fn blocking<T, F>(f: F) -> ApiResult<T>
where
    T: Send + 'static,
    F: FnOnce() -> SwordResult<T> + Send + 'static,
{
    tauri::async_runtime::spawn_blocking(f)
        .await
        .map_err(|e| ApiError::internal(format!("фоновая задача прервана: {e}")))?
        .map_err(ApiError::from)
}

pub fn not_found(what: &str) -> SwordError {
    SwordError::NotFound(what.to_string())
}
