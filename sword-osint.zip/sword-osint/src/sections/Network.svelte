<!--
  NETWORK — 3D graph of confirmed links between permitted public entities (domains,
  organisations, websites, projects, documents, publications, verified sources). Every
  link carries its relation, confidence and the evidence it was derived from.
-->
<script lang="ts">
  import { onMount, untrack } from 'svelte';
  import Icon from '../lib/components/Icon.svelte';
  import Bits from '../lib/components/Bits.svelte';
  import Panel from '../lib/components/Panel.svelte';
  import Segmented from '../lib/components/Segmented.svelte';
  import Toggle from '../lib/components/Toggle.svelte';
  import { api, desktop } from '../lib/api/client';
  import type { EntityKind, Graph, GraphEdge, GraphNode, GraphScope, InvestigationRecord } from '../lib/api/types';
  import { app } from '../lib/stores/app.svelte';
  import { run } from '../lib/stores/run.svelte';
  import { ui } from '../lib/stores/ui.svelte';
  import { ENTITY_META, RELATION_LABEL, confidenceLabel } from '../lib/util/labels';
  import { fmtDateTime, fmtNum, hostOf, truncate } from '../lib/util/format';
  import { copyText, guarded, openLink } from '../lib/components/ui';
  import type { NetworkView, ViewEdge, ViewNode } from '../lib/engine/network/NetworkView';

  const KIND_ORDER: EntityKind[] = ['organization', 'domain', 'website', 'project', 'document', 'publication', 'source'];

  let host = $state<HTMLDivElement | null>(null);
  let labels = $state<HTMLDivElement | null>(null);
  let view = $state.raw<NetworkView | null>(null);
  let viewError = $state<string | null>(null);
  let investigations = $state<InvestigationRecord[]>([]);
  let investigationId = $state<string | null>(app.focusInvestigation ?? run.discovery?.id ?? null);
  let graph = $state.raw<Graph | null>(null);
  let loading = $state(false);
  let layoutRunning = $state(false);
  let selectedKey = $state<string | null>(null);
  let search = $state('');
  let exportOpen = $state(false);

  const scope = $derived<GraphScope | null>(ui.networkMode === 'recent' ? { recent: ui.networkRecent } : investigationId ? { investigationId } : null);
  const current = $derived(investigations.find((i) => i.id === investigationId) ?? null);

  // ---- data
  async function loadInvestigations() {
    if (!desktop()) return;
    const page = await guarded(() => api.listHistory({ kind: 'discovery', sort: 'created_desc', limit: 60, offset: 0 }), 'История');
    if (!page) return;
    investigations = page.items;
    if (!investigationId || !page.items.some((i) => i.id === investigationId)) investigationId = page.items[0]?.id ?? null;
  }

  $effect(() => {
    const s = scope;
    if (!s || !desktop()) {
      graph = null;
      return;
    }
    let cancelled = false;
    loading = true;
    api
      .getGraph(s)
      .then((g) => {
        if (!cancelled) graph = g;
      })
      .catch((e) => {
        if (!cancelled) {
          graph = null;
          app.error(e, 'Граф');
        }
      })
      .finally(() => {
        if (!cancelled) loading = false;
      });
    return () => {
      cancelled = true;
    };
  });

  // ---- filtering → visible subgraph
  const visible = $derived.by(() => {
    const empty = { nodes: [] as GraphNode[], edges: [] as GraphEdge[], index: new Map<string, number>() };
    if (!graph) return empty;
    const hidden = new Set<EntityKind>(ui.networkHidden);
    if (!ui.networkShowSources) hidden.add('source');
    const nodes = graph.nodes.filter((n) => !hidden.has(n.kind));
    const index = new Map(nodes.map((n, i) => [n.key, i]));
    const edges = graph.edges.filter((e) => e.confidence >= ui.networkMinConfidence && index.has(e.from) && index.has(e.to));
    return { nodes, edges, index };
  });

  const counts = $derived.by(() => {
    const c: Partial<Record<EntityKind, number>> = {};
    for (const n of graph?.nodes ?? []) c[n.kind] = (c[n.kind] ?? 0) + 1;
    return c;
  });

  const selected = $derived(selectedKey ? (graph?.nodes.find((n) => n.key === selectedKey) ?? null) : null);
  const nodeByKey = $derived(new Map((graph?.nodes ?? []).map((n) => [n.key, n])));
  const selectedEdges = $derived(selectedKey ? visible.edges.filter((e) => e.from === selectedKey || e.to === selectedKey).sort((a, b) => b.confidence - a.confidence) : []);
  const matches = $derived.by(() => {
    const q = search.trim().toLowerCase();
    if (q.length < 2) return [];
    return visible.nodes.filter((n) => n.label.toLowerCase().includes(q) || n.key.toLowerCase().includes(q)).slice(0, 8);
  });

  // ---- 3D view lifecycle
  $effect(() => {
    const epoch = app.engineEpoch;
    const h = host;
    const l = labels;
    if (!h || !l) return;
    const g = untrack(() => app.settings?.graphics);
    const canvas = document.createElement('canvas');
    canvas.className = 'graph-canvas';
    canvas.dataset.epoch = String(epoch);
    h.prepend(canvas);
    let cancelled = false;
    let instance: NetworkView | null = null;
    import('../lib/engine/network/NetworkView')
      .then(async ({ NetworkView }) => {
        if (cancelled) return;
        instance = new NetworkView(
          canvas,
          l,
          {
            renderer: app.gpuSafeMode >= 2 ? 'webgl2' : (g?.renderer ?? 'auto'),
            bloom: (g?.bloom ?? true) && app.gpuSafeMode === 0,
            fpsLimit: g?.fpsLimit ?? 0,
            reduceMotion: g?.reduceMotion ?? false,
            maxPixelRatio: g?.maxPixelRatio ?? 2,
          },
          {
            onSelect: (key) => (selectedKey = key),
            onLayout: (r) => (layoutRunning = r),
            onLost: (m) => {
              if (!app.recoverGpu(m)) viewError = `Графическое устройство сброшено: ${m}`;
            },
          },
        );
        await instance.init();
        if (cancelled) return;
        view = instance;
        viewError = null;
      })
      .catch((e: unknown) => {
        if (cancelled) return;
        const message = e instanceof Error ? e.message : String(e);
        if (!app.recoverGpu(message)) viewError = message;
      });
    return () => {
      cancelled = true;
      view = null;
      instance?.dispose();
      canvas.remove();
    };
  });

  $effect(() => {
    const g = app.settings?.graphics;
    if (!g) return;
    const o = { bloom: g.bloom && app.gpuSafeMode === 0, fpsLimit: g.fpsLimit, reduceMotion: g.reduceMotion, maxPixelRatio: g.maxPixelRatio };
    safely(() => view?.updateOptions(o));
  });

  // push the visible subgraph into the view (re-frame the camera only when the data changes)
  let shownGraph: Graph | null = null;
  $effect(() => {
    const v = view;
    if (!v) return;
    const { nodes, edges, index } = visible;
    const refit = graph !== shownGraph;
    shownGraph = graph;
    const degree = new Map<string, number>();
    for (const e of edges) {
      degree.set(e.from, (degree.get(e.from) ?? 0) + 1);
      degree.set(e.to, (degree.get(e.to) ?? 0) + 1);
    }
    const vn: ViewNode[] = nodes.map((n) => ({ key: n.key, kind: n.kind, label: n.label, degree: degree.get(n.key) ?? 0 }));
    const ve: ViewEdge[] = edges.map((e) => ({ id: e.id, from: index.get(e.from)!, to: index.get(e.to)!, confidence: e.confidence, relation: e.relation }));
    safely(() => v.setGraph(vn, ve, refit));
    const focus = untrack(() => ui.networkFocusKey ?? selectedKey);
    if (focus && index.has(focus)) {
      selectedKey = focus;
      safely(() => v.select(focus, false));
    } else if (untrack(() => selectedKey) && !index.has(untrack(() => selectedKey) as string)) {
      selectedKey = null;
    }
    ui.networkFocusKey = null;
  });

  /** View calls from effects/handlers must not throw into Svelte's update cycle. */
  function safely(fn: () => void) {
    try {
      fn();
    } catch (e) {
      const message = e instanceof Error ? e.message : String(e);
      console.error('[3D]', message);
      if (!app.recoverGpu(message)) viewError = message;
    }
  }

  function choose(key: string | null, focus = true) {
    selectedKey = key;
    safely(() => view?.select(key, focus));
  }

  async function exportGraph(format: 'json' | 'graphml' | 'gexf') {
    exportOpen = false;
    if (!scope) return;
    const path = await guarded(() => api.exportGraph(scope, format), 'Экспорт графа');
    if (path) app.toast('ok', `Граф сохранён: ${path}`, 6000);
  }

  async function snapshot() {
    if (!view) return;
    const data = view.snapshot();
    const name = current ? `sword-graph-${current.query}` : 'sword-graph';
    const path = await guarded(() => api.saveImage(data, name), 'Снимок');
    if (path) app.toast('ok', `Снимок сохранён: ${path}`, 6000);
  }

  function toggleKind(k: EntityKind) {
    if (k === 'source') {
      ui.networkShowSources = !ui.networkShowSources;
      return;
    }
    const h = ui.networkHidden;
    ui.networkHidden = h.includes(k) ? h.filter((x) => x !== k) : [...h, k];
  }

  function kindVisible(k: EntityKind) {
    return k === 'source' ? ui.networkShowSources : !ui.networkHidden.includes(k);
  }

  function adapterName(id: string) {
    return app.adapters.find((a) => a.info.id === id)?.info.name ?? id;
  }

  onMount(() => {
    loadInvestigations();
  });
</script>

<div class="net-root">
  <div class="stage" bind:this={host}>
    <div class="labels" bind:this={labels}></div>
  </div>

  <div class="section-root overlay">
    <div class="toolbar">
      <div class="scope glass">
        <Segmented
          size="sm"
          bind:value={ui.networkMode}
          options={[
            { value: 'investigation', label: 'Исследование' },
            { value: 'recent', label: 'Сводный граф' },
          ]}
        />
        {#if ui.networkMode === 'investigation'}
          <select class="select inv" bind:value={investigationId} disabled={!investigations.length} aria-label="Исследование">
            {#each investigations as i (i.id)}
              <option value={i.id}>{truncate(i.query, 48)} · {fmtDateTime(i.createdAt)} · {i.nodeCount} об.</option>
            {:else}
              <option value={null}>Нет исследований</option>
            {/each}
          </select>
        {:else}
          <select class="select n" bind:value={ui.networkRecent} aria-label="Число исследований">
            <option value={10}>последние 10</option>
            <option value={20}>последние 20</option>
            <option value={50}>последние 50</option>
            <option value={200}>последние 200</option>
          </select>
        {/if}
        {#if loading || layoutRunning}<Bits kind="spinner" />{/if}
      </div>
      <span class="spacer"></span>
      <div class="tools glass">
        <button class="btn sm ghost icon" title="Показать весь граф" onclick={() => view?.fit()} disabled={!view}><Icon name="target" size={15} /></button>
        <button class="btn sm ghost icon" title="Пересчитать раскладку" onclick={() => safely(() => view?.relayout())} disabled={!view}><Icon name="refresh" size={15} /></button>
        <button class="btn sm ghost icon" title="Снимок PNG" onclick={snapshot} disabled={!view || !visible.nodes.length}><Icon name="camera" size={15} /></button>
        <div class="menu-wrap">
          <button class="btn sm ghost" onclick={() => (exportOpen = !exportOpen)} disabled={!scope || !graph?.nodes.length}><Icon name="download" size={14} />Экспорт</button>
          {#if exportOpen}
            <div class="menu glass glass-strong">
              <button onclick={() => exportGraph('json')}>JSON — узлы, связи, доказательства</button>
              <button onclick={() => exportGraph('graphml')}>GraphML — для Gephi / yEd</button>
              <button onclick={() => exportGraph('gexf')}>GEXF — для Gephi</button>
            </div>
          {/if}
        </div>
      </div>
    </div>

    <div class="row-main">
      <Panel title="Фильтры" subtitle="{fmtNum(visible.nodes.length)} объектов · {fmtNum(visible.edges.length)} связей" class="filters">
        <div class="col">
          <div class="searchbox">
            <input class="input" placeholder="Найти объект" bind:value={search} />
            {#if matches.length}
              <ul class="matches glass glass-strong">
                {#each matches as m (m.key)}
                  <li><button onclick={() => { choose(m.key); search = ''; }}><i class="sw" style:background={ENTITY_META[m.kind].color}></i>{truncate(m.label, 44)}</button></li>
                {/each}
              </ul>
            {/if}
          </div>
          <span class="label">Типы объектов</span>
          <ul class="legend">
            {#each KIND_ORDER as k (k)}
              <li>
                <button class:off={!kindVisible(k)} onclick={() => toggleKind(k)} aria-pressed={kindVisible(k)}>
                  <i class="sw" style:background={ENTITY_META[k].color}></i>
                  <span class="ln">{ENTITY_META[k].label}</span>
                  <span class="ls">{ENTITY_META[k].shape}</span>
                  <span class="lc num">{counts[k] ?? 0}</span>
                </button>
              </li>
            {/each}
          </ul>
          <span class="label">Минимальная достоверность связи</span>
          <Segmented
            size="sm"
            bind:value={ui.networkMinConfidence}
            options={[
              { value: 0, label: 'все' },
              { value: 0.6, label: '≥0.6' },
              { value: 0.8, label: '≥0.8' },
              { value: 0.95, label: '≥0.95' },
            ]}
          />
          <Toggle bind:checked={ui.networkShowSources} label="Показывать проверенные источники как узлы" />
          <p class="help">
            Отображаются только связи, подтверждённые данными источников (DNS, RDAP, сертификаты, официальные реестры, заявленные
            самим объектом ссылки). Яркость линии — достоверность связи.
          </p>
          <p class="help">ЛКМ — вращение · колесо — масштаб · колесо + перетаскивание — панорама · двойной клик по объекту — приблизить, по пустому месту — исходный вид.</p>
        </div>
      </Panel>

      <div class="center">
        {#if viewError}
          <div class="notice glass">
            <Icon name="alert" size={16} />
            <span>3D-вид недоступен: {viewError}</span>
            <button class="btn sm" onclick={() => app.engineEpoch++}>Перезапустить</button>
          </div>
        {:else if !desktop()}
          <div class="notice glass"><Icon name="info" size={16} /><span>Граф доступен в настольном приложении.</span></div>
        {:else if !loading && ui.networkMode === 'investigation' && !investigations.length}
          <div class="notice glass">
            <Icon name="info" size={16} />
            <span>Пока нет исследований. Запустите анализ в разделе DISCOVERY.</span>
            <button class="btn sm" onclick={() => app.navigate('discovery')}>DISCOVERY</button>
          </div>
        {:else if !loading && graph && graph.nodes.length === 0}
          <div class="notice glass"><Icon name="info" size={16} /><span>Источники не вернули подтверждённых связей для этого исследования.</span></div>
        {/if}
      </div>

      {#if selected}
        <Panel title={ENTITY_META[selected.kind].label} subtitle={selected.key} class="inspector enter">
          {#snippet actions()}
            <button class="btn sm ghost icon" title="Приблизить" onclick={() => view?.select(selected.key, true)}><Icon name="target" size={14} /></button>
            <button class="btn sm ghost icon" title="Копировать идентификатор" onclick={() => copyText(selected.key)}><Icon name="copy" size={14} /></button>
            <button class="btn sm ghost icon" title="Закрыть" onclick={() => choose(null, false)}><Icon name="x" size={14} /></button>
          {/snippet}
          <div class="col insp">
            <h3>{selected.label}</h3>

            {#if selected.attributes.length}
              <span class="label">Атрибуты и их происхождение</span>
              <ul class="attrs">
                {#each selected.attributes as a, i (i)}
                  <li>
                    <div class="av"><span class="al">{a.label}</span><span class="vv">{a.value}</span></div>
                    <button class="prov" onclick={() => openLink(a.sourceUrl)} title={a.sourceUrl}>
                      {hostOf(a.sourceUrl) || 'источник'} · {adapterName(a.adapterId)} · {fmtDateTime(a.retrievedAt)} ↗
                    </button>
                  </li>
                {/each}
              </ul>
            {/if}

            <span class="label">Связи · {selectedEdges.length}</span>
            {#if selectedEdges.length === 0}
              <span class="faint small">Нет связей при текущих фильтрах.</span>
            {/if}
            <ul class="edges">
              {#each selectedEdges as e (e.id)}
                {@const otherKey = e.from === selected.key ? e.to : e.from}
                {@const other = nodeByKey.get(otherKey)}
                {@const outgoing = e.from === selected.key}
                <li onpointerenter={() => view?.highlightEdge(e.id)} onpointerleave={() => view?.highlightEdge(null)}>
                  <div class="eh">
                    <span class="rel">{outgoing ? '' : '← '}{RELATION_LABEL[e.relation] ?? e.label}{outgoing ? ' →' : ''}</span>
                    <span class="spacer"></span>
                    <Bits kind="confidence" value={e.confidence} />
                  </div>
                  <button class="other" onclick={() => choose(otherKey)}>
                    {#if other}<i class="sw" style:background={ENTITY_META[other.kind].color}></i>{/if}
                    {other ? truncate(other.label, 60) : otherKey}
                  </button>
                  <div class="ev">
                    <span class="conf">{confidenceLabel(e.confidence)}</span>
                    {#each e.evidence.slice(0, 4) as ev, j (j)}
                      <button class="prov" onclick={() => openLink(ev.sourceUrl)} title={ev.note ?? ev.sourceUrl}>
                        {hostOf(ev.sourceUrl) || 'источник'} · {adapterName(ev.adapterId)} · {fmtDateTime(ev.retrievedAt)} ↗
                      </button>
                    {/each}
                    {#if e.evidence.length > 4}<span class="faint tiny">и ещё {e.evidence.length - 4} подтверждений</span>{/if}
                  </div>
                </li>
              {/each}
            </ul>

            {#if selected.sources.length}
              <span class="label">Подтверждено источниками · {selected.sources.length}</span>
              <div class="row wrap">
                {#each selected.sources as s (s)}
                  <span class="chip">{adapterName(s)}</span>
                {/each}
              </div>
            {/if}
          </div>
        </Panel>
      {/if}
    </div>
  </div>
</div>

<style>
  .net-root {
    position: absolute;
    inset: 0;
    pointer-events: auto;
  }
  .stage {
    position: absolute;
    inset: 0;
    background: #000;
    overflow: hidden;
  }
  .stage :global(canvas.graph-canvas) {
    position: absolute;
    inset: 0;
    width: 100%;
    height: 100%;
    display: block;
    outline: none;
    touch-action: none;
  }
  .labels {
    position: absolute;
    inset: 0;
    pointer-events: none;
    overflow: hidden;
    z-index: 1;
  }
  .labels :global(.node-label) {
    position: absolute;
    left: 0;
    top: 0;
    max-width: 260px;
    padding: 2px 7px;
    border-radius: 6px;
    font-size: 11px;
    color: var(--fg-2);
    background: rgba(3, 4, 6, 0.55);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    will-change: transform;
  }
  .labels :global(.node-label.selected) {
    color: #fff;
    font-weight: 500;
    border: 1px solid var(--line-strong);
    box-shadow: 0 0 16px rgba(220, 232, 248, 0.2);
  }
  .labels :global(.node-label.hover) {
    color: #fff;
  }
  .overlay {
    z-index: 2;
  }
  .toolbar {
    display: flex;
    align-items: center;
    gap: 10px;
    pointer-events: none;
  }
  .toolbar > * {
    pointer-events: auto;
  }
  .scope,
  .tools {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 5px 8px;
    border-radius: 999px;
  }
  .select.inv {
    width: 380px;
    min-height: 30px;
    padding: 4px 30px 4px 12px;
    font-size: 12px;
    border-radius: 999px;
  }
  .select.n {
    width: 170px;
    min-height: 30px;
    padding: 4px 30px 4px 12px;
    font-size: 12px;
    border-radius: 999px;
  }
  .row-main {
    flex: 1;
    min-height: 0;
    display: flex;
    gap: 14px;
    pointer-events: none;
  }
  .row-main > :global(*) {
    pointer-events: auto;
  }
  .row-main :global(.filters) {
    width: 290px;
    flex: none;
    align-self: flex-start;
    max-height: 100%;
  }
  .row-main :global(.inspector) {
    width: 400px;
    flex: none;
  }
  .center {
    flex: 1;
    min-width: 0;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    pointer-events: none !important;
  }
  .notice {
    pointer-events: auto;
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 10px 14px;
    font-size: 12.5px;
    margin-top: 20vh;
  }
  .searchbox {
    position: relative;
  }
  .matches {
    position: absolute;
    top: 40px;
    left: 0;
    right: 0;
    z-index: 5;
    list-style: none;
    margin: 0;
    padding: 5px;
  }
  .matches button {
    width: 100%;
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 8px;
    border: none;
    border-radius: 6px;
    background: none;
    color: var(--fg-2);
    font-size: 12px;
    text-align: left;
    cursor: pointer;
  }
  .matches button:hover {
    background: rgba(255, 255, 255, 0.06);
    color: #fff;
  }
  .sw {
    width: 8px;
    height: 8px;
    border-radius: 2px;
    flex: none;
    display: inline-block;
  }
  .legend {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 1px;
  }
  .legend button {
    width: 100%;
    display: grid;
    grid-template-columns: 8px 1fr auto 28px;
    align-items: center;
    gap: 8px;
    padding: 5px 6px;
    border: none;
    border-radius: 6px;
    background: none;
    color: var(--fg);
    font-size: 12px;
    text-align: left;
    cursor: pointer;
    transition: opacity 0.2s, background 0.15s;
  }
  .legend button:hover {
    background: rgba(255, 255, 255, 0.04);
  }
  .legend button.off {
    opacity: 0.38;
  }
  .ls {
    font-size: 10.5px;
    color: var(--fg-3);
  }
  .lc {
    font-size: 11px;
    color: var(--fg-2);
    text-align: right;
  }
  .help {
    margin: 0;
  }
  .insp h3 {
    margin: 0;
    font-size: 15px;
    font-weight: 500;
    color: #fff;
    line-height: 1.4;
    user-select: text;
  }
  .attrs,
  .edges {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 6px;
  }
  .attrs li {
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding: 6px 0;
    border-bottom: 1px solid rgba(255, 255, 255, 0.04);
  }
  .av {
    display: grid;
    grid-template-columns: minmax(90px, 36%) 1fr;
    gap: 10px;
    font-size: 12px;
  }
  .al {
    color: var(--fg-3);
  }
  .vv {
    color: var(--fg);
    word-break: break-word;
    user-select: text;
  }
  .prov {
    align-self: flex-start;
    border: none;
    background: none;
    padding: 0;
    color: var(--fg-3);
    font-size: 10.5px;
    text-align: left;
    cursor: pointer;
    word-break: break-all;
  }
  .prov:hover {
    color: #fff;
  }
  .edges li {
    display: flex;
    flex-direction: column;
    gap: 4px;
    padding: 8px 10px;
    border-radius: 9px;
    border: 1px solid var(--line);
    background: rgba(255, 255, 255, 0.02);
    transition: border-color 0.15s, background 0.15s;
  }
  .edges li:hover {
    border-color: var(--line-strong);
    background: rgba(255, 255, 255, 0.04);
  }
  .eh {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .rel {
    font-size: 11px;
    color: var(--fg-2);
  }
  .other {
    display: flex;
    align-items: center;
    gap: 8px;
    border: none;
    background: none;
    padding: 0;
    color: #fff;
    font-size: 12.5px;
    text-align: left;
    cursor: pointer;
  }
  .other:hover {
    text-decoration: underline;
    text-underline-offset: 3px;
  }
  .ev {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .conf {
    font-size: 10.5px;
    color: var(--fg-3);
  }
  .menu-wrap {
    position: relative;
  }
  .menu {
    position: absolute;
    top: 38px;
    right: 0;
    display: flex;
    flex-direction: column;
    padding: 6px;
    min-width: 260px;
    z-index: 5;
  }
  .menu button {
    border: none;
    background: none;
    color: var(--fg-2);
    text-align: left;
    padding: 8px 10px;
    border-radius: 7px;
    font-size: 12px;
    cursor: pointer;
  }
  .menu button:hover {
    background: rgba(255, 255, 255, 0.06);
    color: #fff;
  }
</style>
