//! Report themes. The palette stays monochrome (white / silver / graphite) with one
//! restrained accent, mirroring the application's «dark particle universe» style.

pub type Rgb3 = (f32, f32, f32);

fn hex(h: u32) -> Rgb3 {
    (((h >> 16) & 0xff) as f32 / 255.0, ((h >> 8) & 0xff) as f32 / 255.0, (h & 0xff) as f32 / 255.0)
}

#[derive(Debug, Clone)]
pub struct Theme {
    pub dark_pages: bool,
    pub cover_dark: bool,
    pub page_bg: Rgb3,
    pub text: Rgb3,
    pub muted: Rgb3,
    pub faint: Rgb3,
    pub rule: Rgb3,
    pub accent: Rgb3,
    pub table_head: Rgb3,
    pub zebra: Rgb3,
    pub callout: Rgb3,
    pub figure_bg: Rgb3,
    pub cover_bg: Rgb3,
    pub cover_text: Rgb3,
    pub cover_muted: Rgb3,
    pub link: Rgb3,
    pub severity: [Rgb3; 6],
}

impl Theme {
    pub fn from_options(theme: &str, accent: &str) -> Theme {
        let accent_light = match accent {
            "ice" => hex(0x3E6E8E),
            "amber" => hex(0x8A5A1E),
            _ => hex(0x5A6573),
        };
        let accent_dark = match accent {
            "ice" => hex(0x9CCBEA),
            "amber" => hex(0xE2B672),
            _ => hex(0xC7D0DC),
        };
        match theme {
            "midnight" => Theme {
                dark_pages: true,
                cover_dark: true,
                page_bg: hex(0x07090C),
                text: hex(0xE7EBF1),
                muted: hex(0x939CA8),
                faint: hex(0x5B6470),
                rule: hex(0x232A33),
                accent: accent_dark,
                table_head: hex(0x11161C),
                zebra: hex(0x0C1015),
                callout: hex(0x10151B),
                figure_bg: hex(0x0A0D11),
                cover_bg: hex(0x040608),
                cover_text: hex(0xF2F5F9),
                cover_muted: hex(0x8E98A5),
                link: accent_dark,
                severity: [hex(0xF08A8A), hex(0xF0B27A), hex(0xE8D48B), hex(0xA9C7E8), hex(0x9AA3AE), hex(0x8FD3B0)],
            },
            "paper" => Theme {
                dark_pages: false,
                cover_dark: false,
                page_bg: hex(0xFFFFFF),
                text: hex(0x15181D),
                muted: hex(0x5D6672),
                faint: hex(0x9AA2AC),
                rule: hex(0xDDE1E6),
                accent: accent_light,
                table_head: hex(0xF1F3F5),
                zebra: hex(0xF8F9FA),
                callout: hex(0xF3F5F7),
                figure_bg: hex(0xF7F8FA),
                cover_bg: hex(0xFFFFFF),
                cover_text: hex(0x101317),
                cover_muted: hex(0x6A737E),
                link: accent_light,
                severity: [hex(0xB3261E), hex(0xC0611A), hex(0x9C7A12), hex(0x3E6E8E), hex(0x6A737E), hex(0x2E7D57)],
            },
            _ => Theme {
                dark_pages: false,
                cover_dark: true,
                page_bg: hex(0xFFFFFF),
                text: hex(0x15181D),
                muted: hex(0x5D6672),
                faint: hex(0x9AA2AC),
                rule: hex(0xDDE1E6),
                accent: accent_light,
                table_head: hex(0xF1F3F5),
                zebra: hex(0xF8F9FA),
                callout: hex(0xF3F5F7),
                figure_bg: hex(0x0B0E12),
                cover_bg: hex(0x05070A),
                cover_text: hex(0xF2F5F9),
                cover_muted: hex(0x8E98A5),
                link: accent_light,
                severity: [hex(0xB3261E), hex(0xC0611A), hex(0x9C7A12), hex(0x3E6E8E), hex(0x6A737E), hex(0x2E7D57)],
            },
        }
    }

    /// Colour of a severity: 0 critical … 5 pass.
    pub fn severity_color(&self, s: sword_core::Severity) -> Rgb3 {
        use sword_core::Severity::*;
        self.severity[match s {
            Critical => 0,
            High => 1,
            Medium => 2,
            Low => 3,
            Info => 4,
            Pass => 5,
        }]
    }
}
