//! Source adapters — one module per source.

pub mod bluesky;
pub mod brave;
pub mod ct;
pub mod dns;
pub mod github;
pub mod gleif;
pub mod hackernews;
pub mod hibp;
pub mod mastodon;
pub mod openalex;
pub mod rdap;
pub mod searxng;
pub mod telegram;
pub mod vk;
pub mod wayback;
pub mod website;
pub mod wikidata;
pub mod wikipedia;

use serde_json::Value;
use sword_core::{AdapterInfo, Category, CredentialSpec, InputKind, OptionSpec};

#[allow(clippy::too_many_arguments)]
pub(crate) fn info(
    id: &str,
    name: &str,
    provider: &str,
    description: &str,
    methodology: &str,
    categories: &[Category],
    inputs: &[InputKind],
    credentials: Vec<CredentialSpec>,
    options: Vec<OptionSpec>,
    rate_limit_per_minute: u32,
    homepage: &str,
    docs_url: Option<&str>,
    official_api: bool,
) -> AdapterInfo {
    AdapterInfo {
        id: id.into(),
        name: name.into(),
        provider: provider.into(),
        description: description.into(),
        methodology: methodology.into(),
        categories: categories.to_vec(),
        input_kinds: inputs.to_vec(),
        credentials,
        options,
        rate_limit_per_minute,
        homepage: homepage.into(),
        docs_url: docs_url.map(str::to_string),
        official_api,
    }
}

pub(crate) fn cred(key: &str, label: &str, required: bool, help: &str, help_url: Option<&str>, placeholder: Option<&str>) -> CredentialSpec {
    CredentialSpec {
        key: key.into(),
        label: label.into(),
        required,
        help: help.into(),
        help_url: help_url.map(str::to_string),
        placeholder: placeholder.map(str::to_string),
    }
}

pub(crate) fn opt(key: &str, label: &str, required: bool, default: Option<&str>, help: &str, placeholder: Option<&str>) -> OptionSpec {
    OptionSpec {
        key: key.into(),
        label: label.into(),
        required,
        default: default.map(str::to_string),
        help: help.into(),
        placeholder: placeholder.map(str::to_string),
    }
}

/// String field of a JSON object (non-empty).
pub(crate) fn s(v: &Value, key: &str) -> Option<String> {
    v.get(key).and_then(Value::as_str).map(str::trim).filter(|s| !s.is_empty()).map(str::to_string)
}

/// String at a JSON pointer (non-empty).
pub(crate) fn sp(v: &Value, ptr: &str) -> Option<String> {
    v.pointer(ptr).and_then(Value::as_str).map(str::trim).filter(|s| !s.is_empty()).map(str::to_string)
}

/// Array at a JSON pointer (empty slice if absent).
pub(crate) fn arr<'a>(v: &'a Value, ptr: &str) -> &'a [Value] {
    v.pointer(ptr).and_then(Value::as_array).map(|a| a.as_slice()).unwrap_or(&[])
}

pub(crate) fn num(v: &Value, key: &str) -> Option<i64> {
    v.get(key).and_then(|x| x.as_i64().or_else(|| x.as_str().and_then(|s| s.parse().ok())))
}

/// Document-like URL (PDF, office formats).
pub(crate) fn is_document_url(url: &str) -> bool {
    let path = url.split(['?', '#']).next().unwrap_or(url).to_lowercase();
    [".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".ods", ".odp", ".rtf", ".csv"]
        .iter()
        .any(|ext| path.ends_with(ext))
}

/// Format big numbers with thin spaces: 1 234 567.
pub(crate) fn fmt_int(n: i64) -> String {
    let s = n.abs().to_string();
    let mut out = String::new();
    for (i, ch) in s.chars().enumerate() {
        if i > 0 && (s.len() - i) % 3 == 0 {
            out.push('\u{202F}');
        }
        out.push(ch);
    }
    if n < 0 {
        format!("-{out}")
    } else {
        out
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn helpers() {
        assert!(is_document_url("https://a.ru/files/Report.PDF?x=1"));
        assert!(!is_document_url("https://a.ru/page"));
        assert_eq!(fmt_int(1234567), "1\u{202F}234\u{202F}567");
        let v: Value = serde_json::json!({"a": {"b": [1, 2]}, "s": " x "});
        assert_eq!(arr(&v, "/a/b").len(), 2);
        assert_eq!(s(&v, "s").as_deref(), Some("x"));
    }
}
