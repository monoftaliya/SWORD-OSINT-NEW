<!--
  Finding details with full provenance: which source returned it, when, the primary
  link, all attributes and the confidence level.
-->
<script lang="ts">
  import Icon from './Icon.svelte';
  import Bits from './Bits.svelte';
  import type { Finding } from '../api/types';
  import { app } from '../stores/app.svelte';
  import { FINDING_KIND_LABEL, categoryMeta, confidenceLabel } from '../util/labels';
  import { fmtDateTime, hostOf } from '../util/format';
  import { copyText, openLink } from './ui';

  let {
    finding,
    onclose,
    ongraph,
  }: { finding: Finding; onclose: () => void; ongraph?: (entityKey: string) => void } = $props();

  const adapter = $derived(app.adapters.find((a) => a.info.id === finding.adapterId)?.info ?? null);
  const cat = $derived(categoryMeta(finding.category));
</script>

<aside class="drawer glass glass-strong enter" aria-label="Подробности результата">
  <header>
    <span class="eyebrow">{FINDING_KIND_LABEL[finding.kind]}</span>
    <button class="btn ghost sm icon" onclick={onclose} aria-label="Закрыть"><Icon name="x" size={14} /></button>
  </header>
  <div class="body scroll">
    <h3>{finding.title}</h3>
    <div class="row wrap tags">
      <span class="chip"><Icon name={cat.icon} size={13} />{cat.label}</span>
      {#if finding.severity}<Bits kind="severity" severity={finding.severity} />{/if}
      <span class="chip" title="Достоверность">{confidenceLabel(finding.confidence)} · {finding.confidence.toFixed(2)}</span>
    </div>

    {#if finding.url}
      <div class="link">
        <span class="mono url" title={finding.url}>{finding.url}</span>
        <div class="row">
          <button class="btn sm" onclick={() => openLink(finding.url)}><Icon name="external" size={13} />Открыть источник</button>
          <button class="btn sm ghost" onclick={() => copyText(finding.url ?? '', 'Ссылка скопирована')}><Icon name="copy" size={13} />Копировать</button>
        </div>
      </div>
    {/if}

    {#if finding.snippet}
      <p class="snippet">{finding.snippet}</p>
    {/if}

    {#if finding.attributes.length}
      <dl class="attrs">
        {#each finding.attributes as a, i (i)}
          <dt>{a.label}</dt>
          <dd>{a.value}</dd>
        {/each}
      </dl>
    {/if}

    <div class="prov">
      <span class="eyebrow">Происхождение</span>
      <dl class="attrs">
        <dt>Источник</dt>
        <dd>{adapter ? `${adapter.name} · ${adapter.provider}` : finding.adapterId}</dd>
        {#if finding.url}<dt>Домен</dt><dd class="mono">{hostOf(finding.url)}</dd>{/if}
        <dt>Получено</dt>
        <dd>{fmtDateTime(finding.retrievedAt)}</dd>
        {#if finding.publishedAt}<dt>Опубликовано</dt><dd>{fmtDateTime(finding.publishedAt)}</dd>{/if}
        {#if adapter}<dt>Метод</dt><dd class="method">{adapter.methodology}</dd>{/if}
      </dl>
    </div>
  </div>
  {#if finding.entityKey && ongraph}
    <footer>
      <button class="btn sm" onclick={() => finding.entityKey && ongraph?.(finding.entityKey)}><Icon name="network" size={14} />Показать в графе связей</button>
    </footer>
  {/if}
</aside>

<style>
  .drawer {
    display: flex;
    flex-direction: column;
    min-height: 0;
    max-height: 100%;
    overflow: hidden;
  }
  header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12px 10px 8px 16px;
  }
  .body {
    padding: 0 16px 14px;
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  h3 {
    margin: 0;
    font-size: 15px;
    font-weight: 500;
    line-height: 1.4;
    color: #fff;
    user-select: text;
  }
  .tags {
    gap: 6px;
  }
  .link {
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding: 10px;
    border-radius: 10px;
    border: 1px solid var(--line);
    background: rgba(0, 0, 0, 0.25);
  }
  .url {
    font-size: 11px;
    color: var(--fg-2);
    word-break: break-all;
    user-select: text;
  }
  .snippet {
    margin: 0;
    font-size: 12.5px;
    color: var(--fg-2);
    line-height: 1.55;
    user-select: text;
  }
  .attrs {
    display: grid;
    grid-template-columns: minmax(90px, 34%) 1fr;
    gap: 6px 12px;
    margin: 0;
    font-size: 12px;
  }
  dt {
    color: var(--fg-3);
  }
  dd {
    margin: 0;
    color: var(--fg);
    word-break: break-word;
    user-select: text;
  }
  .method {
    color: var(--fg-2);
    font-size: 11.5px;
    line-height: 1.45;
  }
  .prov {
    display: flex;
    flex-direction: column;
    gap: 8px;
    padding-top: 10px;
    border-top: 1px solid var(--line);
  }
  footer {
    padding: 10px 14px;
    border-top: 1px solid var(--line);
  }
</style>
