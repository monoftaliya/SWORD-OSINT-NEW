//! Graph export: JSON (lossless), GraphML (yEd, Gephi, Cytoscape) and GEXF 1.3 (Gephi).
//! Provenance is preserved: every edge carries its source URLs and confidence.

use crate::Graph;

pub fn to_json(graph: &Graph) -> String {
    serde_json::to_string_pretty(graph).unwrap_or_else(|_| "{}".into())
}

fn esc(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    for c in s.chars() {
        match c {
            '&' => out.push_str("&amp;"),
            '<' => out.push_str("&lt;"),
            '>' => out.push_str("&gt;"),
            '"' => out.push_str("&quot;"),
            '\'' => out.push_str("&apos;"),
            c if (c as u32) < 0x20 && c != '\n' && c != '\t' => out.push(' '),
            c => out.push(c),
        }
    }
    out
}

fn sources_of(e: &crate::GraphEdge) -> String {
    e.evidence.iter().map(|ev| ev.source_url.as_str()).filter(|s| !s.is_empty()).collect::<Vec<_>>().join(" ")
}

pub fn to_graphml(graph: &Graph) -> String {
    let mut s = String::new();
    s.push_str("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    s.push_str("<graphml xmlns=\"http://graphml.graphdrawing.org/xmlns\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xsi:schemaLocation=\"http://graphml.graphdrawing.org/xmlns http://graphml.graphdrawing.org/xmlns/1.0/graphml.xsd\">\n");
    s.push_str("  <key id=\"label\" for=\"node\" attr.name=\"label\" attr.type=\"string\"/>\n");
    s.push_str("  <key id=\"kind\" for=\"node\" attr.name=\"kind\" attr.type=\"string\"/>\n");
    s.push_str("  <key id=\"facts\" for=\"node\" attr.name=\"facts\" attr.type=\"string\"/>\n");
    s.push_str("  <key id=\"relation\" for=\"edge\" attr.name=\"relation\" attr.type=\"string\"/>\n");
    s.push_str("  <key id=\"confidence\" for=\"edge\" attr.name=\"confidence\" attr.type=\"double\"/>\n");
    s.push_str("  <key id=\"sources\" for=\"edge\" attr.name=\"sources\" attr.type=\"string\"/>\n");
    s.push_str("  <graph id=\"sword-osint\" edgedefault=\"directed\">\n");
    for n in &graph.nodes {
        let facts = n
            .attributes
            .iter()
            .map(|a| format!("{}: {} [{}]", a.label, a.value, a.source_url))
            .collect::<Vec<_>>()
            .join(" | ");
        s.push_str(&format!(
            "    <node id=\"{}\"><data key=\"label\">{}</data><data key=\"kind\">{}</data><data key=\"facts\">{}</data></node>\n",
            esc(&n.key),
            esc(&n.label),
            n.kind.as_str(),
            esc(&facts)
        ));
    }
    for e in &graph.edges {
        s.push_str(&format!(
            "    <edge id=\"{}\" source=\"{}\" target=\"{}\"><data key=\"relation\">{}</data><data key=\"confidence\">{:.2}</data><data key=\"sources\">{}</data></edge>\n",
            esc(&e.id),
            esc(&e.from),
            esc(&e.to),
            esc(&e.relation),
            e.confidence,
            esc(&sources_of(e))
        ));
    }
    s.push_str("  </graph>\n</graphml>\n");
    s
}

pub fn to_gexf(graph: &Graph) -> String {
    let mut s = String::new();
    s.push_str("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    s.push_str("<gexf xmlns=\"http://gexf.net/1.3\" version=\"1.3\">\n");
    s.push_str("  <meta><creator>SWORD OSINT</creator><description>Подтверждённые связи между публичными объектами</description></meta>\n");
    s.push_str("  <graph defaultedgetype=\"directed\" mode=\"static\">\n");
    s.push_str("    <attributes class=\"node\"><attribute id=\"0\" title=\"kind\" type=\"string\"/><attribute id=\"1\" title=\"sources\" type=\"string\"/></attributes>\n");
    s.push_str("    <attributes class=\"edge\"><attribute id=\"0\" title=\"relation\" type=\"string\"/><attribute id=\"1\" title=\"confidence\" type=\"double\"/><attribute id=\"2\" title=\"evidence\" type=\"string\"/></attributes>\n");
    s.push_str("    <nodes>\n");
    for n in &graph.nodes {
        s.push_str(&format!(
            "      <node id=\"{}\" label=\"{}\"><attvalues><attvalue for=\"0\" value=\"{}\"/><attvalue for=\"1\" value=\"{}\"/></attvalues></node>\n",
            esc(&n.key),
            esc(&n.label),
            n.kind.as_str(),
            esc(&n.sources.join(","))
        ));
    }
    s.push_str("    </nodes>\n    <edges>\n");
    for e in &graph.edges {
        s.push_str(&format!(
            "      <edge id=\"{}\" source=\"{}\" target=\"{}\" label=\"{}\" weight=\"{:.2}\"><attvalues><attvalue for=\"0\" value=\"{}\"/><attvalue for=\"1\" value=\"{:.2}\"/><attvalue for=\"2\" value=\"{}\"/></attvalues></edge>\n",
            esc(&e.id),
            esc(&e.from),
            esc(&e.to),
            esc(&e.label),
            e.confidence,
            esc(&e.relation),
            e.confidence,
            esc(&sources_of(e))
        ));
    }
    s.push_str("    </edges>\n  </graph>\n</gexf>\n");
    s
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn escapes_xml() {
        assert_eq!(esc("a<b>&\"c\""), "a&lt;b&gt;&amp;&quot;c&quot;");
        let g = Graph::default();
        assert!(to_graphml(&g).contains("<graphml"));
        assert!(to_gexf(&g).contains("<gexf"));
    }
}
