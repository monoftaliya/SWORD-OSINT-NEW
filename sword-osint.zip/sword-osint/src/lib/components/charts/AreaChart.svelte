<!--
  Single-series line + area wash over time. Crosshair snaps to the nearest point and the
  tooltip shows the value (keyboard: focus the chart, then ←/→).
-->
<script lang="ts">
  import { axisLabel, niceTicks, shortDate } from './scale';
  import { fmtNum } from '../../util/format';

  let {
    data,
    name,
    height = 150,
    format = (v: number) => fmtNum(v),
    integer = true,
  }: { data: { label: string; value: number }[]; name: string; height?: number; format?: (v: number) => string; integer?: boolean } = $props();

  let width = $state(400);
  let active = $state<number | null>(null);

  const pad = { l: 36, r: 14, t: 12, b: 22 };
  const plotW = $derived(Math.max(10, width - pad.l - pad.r));
  const plotH = $derived(Math.max(10, height - pad.t - pad.b));
  const max = $derived(Math.max(0, ...data.map((d) => d.value)));
  const ticks = $derived(niceTicks(max, 3, integer));
  const top = $derived(ticks[ticks.length - 1] || 1);
  const xs = $derived(data.map((_, i) => pad.l + (data.length <= 1 ? plotW / 2 : (i / (data.length - 1)) * plotW)));
  const ys = $derived(data.map((d) => pad.t + plotH - (d.value / top) * plotH));
  const line = $derived(xs.map((x, i) => `${i ? 'L' : 'M'}${x.toFixed(1)},${ys[i].toFixed(1)}`).join(''));
  const area = $derived(data.length ? `${line}L${xs[xs.length - 1].toFixed(1)},${pad.t + plotH}L${xs[0].toFixed(1)},${pad.t + plotH}Z` : '');
  const empty = $derived(data.length === 0 || max === 0);
  const labelIdx = $derived(data.length <= 2 ? data.map((_, i) => i) : [0, Math.floor((data.length - 1) / 2), data.length - 1]);

  function nearest(clientX: number, rect: DOMRect) {
    const x = clientX - rect.left;
    let best = 0;
    let bd = Infinity;
    xs.forEach((px, i) => {
      const d = Math.abs(px - x);
      if (d < bd) {
        bd = d;
        best = i;
      }
    });
    return best;
  }

  function onMove(e: PointerEvent) {
    if (!data.length) return;
    active = nearest(e.clientX, (e.currentTarget as HTMLElement).getBoundingClientRect());
  }

  function onKey(e: KeyboardEvent) {
    if (!data.length) return;
    if (e.key === 'ArrowRight') active = Math.min(data.length - 1, (active ?? -1) + 1);
    else if (e.key === 'ArrowLeft') active = Math.max(0, (active ?? data.length) - 1);
    else return;
    e.preventDefault();
  }
</script>

<!-- The crosshair is a slider over the dates: ←/→ move it, the value text is announced. -->
<div
  class="chart"
  bind:clientWidth={width}
  style:height="{height}px"
  role="slider"
  tabindex="0"
  aria-label="{name}: выбор даты"
  aria-valuemin={0}
  aria-valuemax={Math.max(0, data.length - 1)}
  aria-valuenow={active ?? Math.max(0, data.length - 1)}
  aria-valuetext={data.length ? `${shortDate(data[active ?? data.length - 1].label)}: ${format(data[active ?? data.length - 1].value)}` : 'нет данных'}
  onpointermove={onMove}
  onpointerleave={() => (active = null)}
  onkeydown={onKey}
  onblur={() => (active = null)}
>
  <svg {width} {height} role="img" aria-label="{name}: {data.length} точек">
    {#each ticks as t (t)}
      {@const y = pad.t + plotH - (t / top) * plotH}
      <line class="grid" x1={pad.l} x2={pad.l + plotW} y1={y} y2={y} />
      <text class="tick" x={pad.l - 8} y={y + 3.5} text-anchor="end">{axisLabel(t)}</text>
    {/each}
    {#if !empty}
      {@const last = data.length - 1}
      <path class="area" d={area} />
      <path class="line" d={line} />
      <circle class="end" cx={xs[last]} cy={ys[last]} r="4" />
    {/if}
    {#each labelIdx as i (i)}
      <text class="xlabel" x={xs[i]} y={height - 6} text-anchor={i === 0 && data.length > 1 ? 'start' : i === data.length - 1 && data.length > 1 ? 'end' : 'middle'}>{shortDate(data[i].label)}</text>
    {/each}
    {#if active !== null && !empty}
      <line class="cross" x1={xs[active]} x2={xs[active]} y1={pad.t} y2={pad.t + plotH} />
      <circle class="dot" cx={xs[active]} cy={ys[active]} r="4" />
    {/if}
  </svg>
  {#if empty}
    <div class="nodata">Нет данных за период</div>
  {/if}
  {#if active !== null && !empty}
    <div class="tip" style:left="{Math.min(Math.max(xs[active], 70), width - 70)}px" style:top="{Math.max(0, ys[active] - 52)}px">
      <strong class="num">{format(data[active].value)}</strong>
      <span><i class="key"></i>{name} · {shortDate(data[active].label)}</span>
    </div>
  {/if}
</div>

<style>
  .chart {
    position: relative;
    width: 100%;
    outline: none;
  }
  .chart:focus-visible {
    outline: 1px solid var(--line-strong);
    outline-offset: 4px;
    border-radius: 6px;
  }
  svg {
    display: block;
    overflow: visible;
  }
  .grid {
    stroke: rgba(255, 255, 255, 0.06);
    stroke-width: 1;
  }
  .tick,
  .xlabel {
    fill: var(--fg-3);
    font-size: 10px;
    font-variant-numeric: tabular-nums;
  }
  .area {
    fill: var(--silver);
    opacity: 0.1;
  }
  .line {
    fill: none;
    stroke: var(--silver);
    stroke-width: 2;
    stroke-linejoin: round;
    stroke-linecap: round;
  }
  .end,
  .dot {
    fill: #fff;
    stroke: #07090c;
    stroke-width: 2;
  }
  .cross {
    stroke: rgba(255, 255, 255, 0.28);
    stroke-width: 1;
  }
  .nodata {
    position: absolute;
    inset: 0;
    display: grid;
    place-items: center;
    color: var(--fg-3);
    font-size: 12px;
    pointer-events: none;
  }
  .tip {
    position: absolute;
    transform: translateX(-50%);
    display: flex;
    flex-direction: column;
    gap: 1px;
    padding: 6px 10px;
    border-radius: 8px;
    background: rgba(8, 10, 13, 0.94);
    border: 1px solid var(--line-strong);
    pointer-events: none;
    white-space: nowrap;
    font-size: 11px;
    color: var(--fg-2);
    z-index: 2;
  }
  .tip strong {
    font-size: 13px;
    color: #fff;
    font-weight: 600;
  }
  .key {
    display: inline-block;
    width: 10px;
    height: 2px;
    margin-right: 6px;
    vertical-align: middle;
    background: var(--silver);
  }
</style>
