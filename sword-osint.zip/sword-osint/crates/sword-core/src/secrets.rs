//! Secret storage abstraction.
//!
//! The desktop runtime implements [`SecretStore`] on top of the Windows Credential
//! Manager (DPAPI-protected, bound to the Windows user). Engines only ever see this trait,
//! so secrets are never written to SQLite, logs or exports.

use std::collections::HashMap;
use std::sync::Mutex;

use crate::error::{SwordError, SwordResult};

pub trait SecretStore: Send + Sync {
    fn get(&self, key: &str) -> SwordResult<Option<String>>;
    fn set(&self, key: &str, value: &str) -> SwordResult<()>;
    fn delete(&self, key: &str) -> SwordResult<()>;

    /// Convenience: `true` when a non-empty secret exists.
    fn has(&self, key: &str) -> bool {
        matches!(self.get(key), Ok(Some(v)) if !v.is_empty())
    }
}

/// In-memory store used by tests and as a last-resort fallback when the OS vault is
/// unavailable (secrets then live only for the process lifetime).
#[derive(Default)]
pub struct MemorySecretStore {
    inner: Mutex<HashMap<String, String>>,
}

impl SecretStore for MemorySecretStore {
    fn get(&self, key: &str) -> SwordResult<Option<String>> {
        let map = self.inner.lock().map_err(|_| SwordError::Internal("secret store poisoned".into()))?;
        Ok(map.get(key).cloned())
    }

    fn set(&self, key: &str, value: &str) -> SwordResult<()> {
        let mut map = self.inner.lock().map_err(|_| SwordError::Internal("secret store poisoned".into()))?;
        map.insert(key.to_string(), value.to_string());
        Ok(())
    }

    fn delete(&self, key: &str) -> SwordResult<()> {
        let mut map = self.inner.lock().map_err(|_| SwordError::Internal("secret store poisoned".into()))?;
        map.remove(key);
        Ok(())
    }
}
