//! Organisation's public surface: CT-derived subdomain inventory, dangling CNAMEs that may
//! allow subdomain takeover (passive DNS check, verified domains only) and publicly known
//! security incidents (HIBP breach catalogue).

use sword_connectors::adapters::ct::CertTransparency;
use sword_connectors::adapters::hibp::{breach_severity, breach_title, breach_url, Hibp};
use sword_connectors::doh::{self, RecordType};
use sword_connectors::output::{FindingExt, OutputBuilder};
use sword_connectors::ConnectorContext;
use sword_core::util::strip_html;
use sword_core::{keys, AdapterInfo, AdapterOutput, Category, EntityKind, FindingKind, Severity, SwordError, SwordResult};

/// CNAME targets of services that are known to allow claiming an abandoned name.
const TAKEOVER_SUFFIXES: &[&str] = &[
    "github.io", "herokuapp.com", "herokudns.com", "azurewebsites.net", "cloudapp.net", "cloudapp.azure.com",
    "trafficmanager.net", "blob.core.windows.net", "azureedge.net", "s3.amazonaws.com", "elasticbeanstalk.com",
    "netlify.app", "netlify.com", "surge.sh", "bitbucket.io", "ghost.io", "readthedocs.io", "pantheonsite.io",
    "myshopify.com", "unbouncepages.com", "wpengine.com", "fly.dev", "vercel.app", "webflow.io",
];

pub async fn inventory(ctx: &ConnectorContext, info: &AdapterInfo, domain: &str) -> SwordResult<AdapterOutput> {
    let ct = CertTransparency::new();
    let sum = ct.summary(ctx, domain).await?;
    let mut b = OutputBuilder::new(info);
    let dkey = keys::domain(domain);
    b.entity(&dkey, EntityKind::Domain, domain);
    b.source(&sum.source_url, &format!("{}: {domain}", sum.source_name));
    let interesting: Vec<&String> = sum
        .subdomains
        .iter()
        .filter(|s| {
            ["dev", "test", "stage", "staging", "admin", "vpn", "git", "jenkins", "old", "backup", "beta", "internal", "uat", "demo"]
                .iter()
                .any(|w| s.split('.').next().map(|l| l.contains(w)).unwrap_or(false))
        })
        .collect();
    b.finding(Category::DigitalFootprint, FindingKind::AuditIssue, &format!("{domain}: публичная поверхность по данным CT"), Some(&sum.source_url))
        .severity(Severity::Info)
        .snippet(&format!(
            "Сертификатов: {}; уникальных имён: {}. Имена с признаками служебных/тестовых систем: {}.",
            sum.certificates,
            sum.subdomains.len(),
            if interesting.is_empty() { "нет".to_string() } else { interesting.iter().take(20).map(|s| s.as_str()).collect::<Vec<_>>().join(", ") }
        ))
        .attr("Рекомендация", "Проверьте, что все перечисленные имена используются и обновляются; выведите из эксплуатации забытые системы.")
        .entity(&dkey);
    if !interesting.is_empty() {
        b.finding(Category::DigitalFootprint, FindingKind::AuditIssue, &format!("{domain}: служебные имена видны в журналах CT"), Some(&sum.source_url))
            .severity(Severity::Low)
            .snippet(&interesting.iter().map(|s| s.as_str()).collect::<Vec<_>>().join("\n"))
            .attr("Рекомендация", "Убедитесь, что тестовые и административные системы не доступны из интернета или защищены аутентификацией.")
            .entity(&dkey);
    }
    b.fact("Публичная поверхность", &format!("{domain}: {} имён в CT", sum.subdomains.len()), &sum.source_url);
    Ok(b.finish())
}

pub async fn dangling_dns(ctx: &ConnectorContext, info: &AdapterInfo, domain: &str, verified: bool) -> SwordResult<AdapterOutput> {
    if !verified {
        return Err(SwordError::Forbidden("проверка висячих CNAME выполняется только для доменов с подтверждённым владением".into()));
    }
    let ct = CertTransparency::new();
    let sum = ct.summary(ctx, domain).await?;
    let mut b = OutputBuilder::new(info);
    let dkey = keys::domain(domain);
    b.entity(&dkey, EntityKind::Domain, domain);
    let mut checked = 0;
    let mut risky = 0;
    for sub in sum.subdomains.iter().filter(|s| *s != domain).take(80) {
        if ctx.cancel.is_cancelled() {
            return Err(SwordError::Cancelled);
        }
        checked += 1;
        let Ok(c) = doh::query(ctx, sub, RecordType::Cname).await else { continue };
        let Some(target) = c.data_of(RecordType::Cname).into_iter().next() else { continue };
        let Some(service) = TAKEOVER_SUFFIXES.iter().find(|s| target.ends_with(*s)) else { continue };
        let resolved = doh::query(ctx, &target, RecordType::A).await;
        let dangling = matches!(&resolved, Ok(r) if r.is_nxdomain());
        if dangling {
            risky += 1;
            b.finding(Category::DomainIntel, FindingKind::AuditIssue, &format!("{sub}: возможен захват поддомена"), Some(&c.query_url))
                .severity(Severity::High)
                .snippet(&format!("CNAME указывает на {target} ({service}), но целевое имя не существует (NXDOMAIN)."))
                .attr("Рекомендация", "Удалите CNAME или восстановите ресурс у провайдера, пока имя не занял посторонний.")
                .entity(&dkey);
        }
    }
    if risky == 0 {
        b.finding(Category::DomainIntel, FindingKind::AuditIssue, &format!("{domain}: висячие CNAME не обнаружены"), Some(&sum.source_url))
            .severity(Severity::Pass)
            .snippet(&format!("Проверено имён из журналов CT: {checked}."))
            .entity(&dkey);
    }
    b.source(&sum.source_url, "Certificate Transparency");
    Ok(b.finish())
}

pub async fn incidents(ctx: &ConnectorContext, info: &AdapterInfo, domain: &str) -> SwordResult<AdapterOutput> {
    let hibp = Hibp::new();
    let (url, breaches) = hibp.domain_breaches(ctx, domain).await?;
    let mut b = OutputBuilder::new(info);
    let dkey = keys::domain(domain);
    b.entity(&dkey, EntityKind::Domain, domain);
    b.source(&url, "HIBP: каталог утечек");
    if breaches.is_empty() {
        b.finding(Category::EmailExposure, FindingKind::AuditIssue, &format!("{domain}: публично известных инцидентов не найдено"), Some(&url))
            .severity(Severity::Pass)
            .snippet("Домен не фигурирует в каталоге Have I Been Pwned.")
            .entity(&dkey);
    }
    for br in &breaches {
        let burl = breach_url(br);
        b.finding(Category::EmailExposure, FindingKind::AuditIssue, &format!("{domain}: инцидент {}", breach_title(br)), Some(&burl))
            .severity(breach_severity(br))
            .snippet(&strip_html(&br.get("Description").and_then(|d| d.as_str()).unwrap_or_default()))
            .attr("Рекомендация", "Убедитесь, что затронутые учётные данные сменены, а пользователи уведомлены.")
            .entity(&dkey);
        b.source(&burl, &breach_title(br));
    }
    b.fact("Известные инциденты", &format!("{domain}: {}", breaches.len()), &url);
    Ok(b.finish())
}
