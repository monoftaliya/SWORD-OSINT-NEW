//! Certificate Transparency logs — certificates issued for a domain and the subdomains
//! they reveal (crt.sh, with SSLMate CertSpotter as a fallback).

use std::collections::{BTreeMap, BTreeSet};

use async_trait::async_trait;
use serde_json::Value;
use sword_core::util::{fmt_date, parse_date};
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordError, SwordResult,
};

use super::{arr, cred, fmt_int, info, s};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::http;
use crate::output::{FindingExt, OutputBuilder};

const CERTSPOTTER_KEY: &str = "certspotter.api_key";
const MAX_ENTRIES: usize = 20_000;
const MAX_SUBDOMAIN_NODES: usize = 120;

pub struct CertTransparency {
    info: AdapterInfo,
}

impl Default for CertTransparency {
    fn default() -> Self {
        Self::new()
    }
}

/// Aggregated view of CT log entries.
#[derive(Default)]
pub struct CtSummary {
    pub certificates: usize,
    pub subdomains: BTreeSet<String>,
    pub issuers: BTreeMap<String, usize>,
    pub first_seen: Option<chrono::DateTime<chrono::Utc>>,
    pub last_seen: Option<chrono::DateTime<chrono::Utc>>,
    pub source_url: String,
    pub source_name: &'static str,
}

/// Organisation (`O=`) from an issuer DN, falling back to `CN=`.
fn issuer_org(dn: &str) -> String {
    let parts: Vec<&str> = dn.split(',').map(str::trim).collect();
    parts
        .iter()
        .find_map(|p| p.strip_prefix("O="))
        .or_else(|| parts.iter().find_map(|p| p.strip_prefix("CN=")))
        .unwrap_or(dn)
        .trim_matches('"')
        .to_string()
}

fn add_name(set: &mut BTreeSet<String>, name: &str, domain: &str) {
    let n = name.trim().trim_start_matches("*.").trim_end_matches('.').to_lowercase();
    if n.is_empty() || n.contains(' ') || n.contains('@') {
        return;
    }
    if n == domain || n.ends_with(&format!(".{domain}")) {
        set.insert(n);
    }
}

impl CertTransparency {
    pub fn new() -> Self {
        CertTransparency {
            info: info(
                "ct",
                "Certificate Transparency",
                "crt.sh (Sectigo) / SSLMate CertSpotter",
                "Сертификаты, выпущенные для домена и его поддоменов, по данным публичных журналов Certificate Transparency.",
                "crt.sh JSON (q=%.domain, output=json, exclude=expired не применяется — учитывается история). При недоступности — \
                 CertSpotter API v1 issuances (include_subdomains, expand=dns_names,issuer). Поддомены извлекаются из SAN; \
                 обрабатывается не более 20 000 записей.",
                &[Category::DomainIntel, Category::DigitalFootprint],
                &[InputKind::Domain, InputKind::Url, InputKind::Email],
                vec![cred(
                    CERTSPOTTER_KEY,
                    "Ключ CertSpotter (необязательно)",
                    false,
                    "Без ключа CertSpotter даёт ограниченное число запросов в час. Ключ: sslmate.com/signup → API keys.",
                    Some("https://sslmate.com/ct_search_api/"),
                    None,
                )],
                vec![],
                20,
                "https://certificate.transparency.dev/",
                Some("https://crt.sh/"),
                true,
            ),
        }
    }

    async fn from_crtsh(&self, ctx: &ConnectorContext, domain: &str) -> SwordResult<CtSummary> {
        let pattern = format!("%.{domain}");
        let req = ctx.get("https://crt.sh/").query(&[("q", pattern.as_str()), ("output", "json")]).timeout(std::time::Duration::from_secs(90));
        let resp = ctx.send(&self.info, req).await?;
        let source_url = resp.url().to_string();
        let resp = http::ensure_success(resp).await?;
        let text = http::read_text(resp, 64 * 1024 * 1024).await?;
        let v: Value = serde_json::from_str(&text).map_err(|e| SwordError::Parse(format!("crt.sh: {e}")))?;
        let mut sum = CtSummary { source_url, source_name: "crt.sh", ..Default::default() };
        for e in v.as_array().map(|a| a.as_slice()).unwrap_or(&[]).iter().take(MAX_ENTRIES) {
            sum.certificates += 1;
            if let Some(names) = s(e, "name_value") {
                for n in names.lines() {
                    add_name(&mut sum.subdomains, n, domain);
                }
            }
            if let Some(cn) = s(e, "common_name") {
                add_name(&mut sum.subdomains, &cn, domain);
            }
            if let Some(iss) = s(e, "issuer_name") {
                *sum.issuers.entry(issuer_org(&iss)).or_default() += 1;
            }
            if let Some(d) = s(e, "not_before").and_then(|d| parse_date(&d)) {
                sum.first_seen = Some(sum.first_seen.map_or(d, |f| f.min(d)));
                sum.last_seen = Some(sum.last_seen.map_or(d, |l| l.max(d)));
            }
        }
        Ok(sum)
    }

    async fn from_certspotter(&self, ctx: &ConnectorContext, domain: &str) -> SwordResult<CtSummary> {
        let mut req = ctx.get("https://api.certspotter.com/v1/issuances").query(&[
            ("domain", domain),
            ("include_subdomains", "true"),
            ("expand", "dns_names"),
            ("expand", "issuer"),
        ]);
        if let Some(k) = ctx.secret(CERTSPOTTER_KEY) {
            req = req.bearer_auth(k);
        }
        let resp = ctx.send_with("certspotter", 10, req).await?;
        let source_url = format!("https://sslmate.com/certspotter/?domain={domain}");
        let v: Value = http::read_json(resp).await?;
        let mut sum = CtSummary { source_url, source_name: "CertSpotter", ..Default::default() };
        for e in v.as_array().map(|a| a.as_slice()).unwrap_or(&[]) {
            sum.certificates += 1;
            for n in arr(e, "/dns_names") {
                if let Some(n) = n.as_str() {
                    add_name(&mut sum.subdomains, n, domain);
                }
            }
            let issuer = e.pointer("/issuer/friendly_name").or_else(|| e.pointer("/issuer/name")).and_then(Value::as_str).map(issuer_org);
            if let Some(i) = issuer {
                *sum.issuers.entry(i).or_default() += 1;
            }
            if let Some(d) = s(e, "not_before").and_then(|d| parse_date(&d)) {
                sum.first_seen = Some(sum.first_seen.map_or(d, |f| f.min(d)));
                sum.last_seen = Some(sum.last_seen.map_or(d, |l| l.max(d)));
            }
        }
        Ok(sum)
    }

    /// Public helper reused by the exposure audit (surface inventory, dangling DNS).
    pub async fn summary(&self, ctx: &ConnectorContext, domain: &str) -> SwordResult<CtSummary> {
        match self.from_crtsh(ctx, domain).await {
            Ok(s) => Ok(s),
            Err(SwordError::Cancelled) => Err(SwordError::Cancelled),
            Err(first) => self.from_certspotter(ctx, domain).await.map_err(|second| {
                SwordError::Upstream(format!("crt.sh: {first}; CertSpotter: {second}"))
            }),
        }
    }
}

#[async_trait]
impl SourceAdapter for CertTransparency {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let mut perms = Vec::new();
        let r = ctx.send(&self.info, ctx.get("https://crt.sh/").query(&[("q", "example.com"), ("output", "json")])).await;
        perms.push(match r {
            Ok(resp) if resp.status().is_success() => PermissionCheck::granted("crt.sh", "Отвечает"),
            Ok(resp) => PermissionCheck::denied("crt.sh", format!("HTTP {}", resp.status().as_u16())),
            Err(e) => PermissionCheck::denied("crt.sh", e.to_string()),
        });
        let cs = ctx.send_with("certspotter", 10, ctx.get("https://api.certspotter.com/v1/issuances").query(&[("domain", "example.com")])).await;
        perms.push(match cs {
            Ok(resp) if resp.status().is_success() => PermissionCheck::granted("CertSpotter", "Отвечает"),
            Ok(resp) => PermissionCheck::denied("CertSpotter", format!("HTTP {}", resp.status().as_u16())),
            Err(e) => PermissionCheck::denied("CertSpotter", e.to_string()),
        });
        if perms.iter().all(|p| !p.granted) {
            return Err(SwordError::Network("ни crt.sh, ни CertSpotter недоступны".into()));
        }
        Ok(perms)
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let domain = input.registrable_domain.clone().or_else(|| input.domain.clone()).ok_or_else(|| SwordError::InvalidInput("нужен домен".into()))?;
        let sum = self.summary(ctx, &domain).await?;
        let mut b = OutputBuilder::new(&self.info);
        let dkey = keys::domain(&domain);
        b.entity(&dkey, EntityKind::Domain, &domain);
        b.source(&sum.source_url, &format!("{}: {domain}", sum.source_name));
        if sum.certificates == 0 {
            b.note(format!("{}: сертификаты для {domain} не найдены", sum.source_name));
            return Ok(b.finish());
        }
        let mut issuers: Vec<(&String, &usize)> = sum.issuers.iter().collect();
        issuers.sort_by(|a, b| b.1.cmp(a.1));
        let issuer_text = issuers.iter().take(5).map(|(n, c)| format!("{n} ({c})")).collect::<Vec<_>>().join(", ");
        b.attr(&dkey, "Сертификатов в CT", &fmt_int(sum.certificates as i64), &sum.source_url);
        b.attr(&dkey, "Поддоменов в CT", &fmt_int(sum.subdomains.len() as i64), &sum.source_url);
        b.attr(&dkey, "Удостоверяющие центры", &issuer_text, &sum.source_url);
        b.finding(Category::DomainIntel, FindingKind::Certificate, &format!("Сертификаты {domain} в журналах CT"), Some(&sum.source_url))
            .snippet(&format!(
                "Записей: {}; уникальных имён: {}; период выпуска: {} — {}. УЦ: {issuer_text}.",
                sum.certificates,
                sum.subdomains.len(),
                sum.first_seen.map(|d| fmt_date(&d)).unwrap_or_else(|| "н/д".into()),
                sum.last_seen.map(|d| fmt_date(&d)).unwrap_or_else(|| "н/д".into())
            ))
            .published(sum.last_seen)
            .entity(&dkey);
        b.fact(
            "Certificate Transparency",
            &format!("{} сертификатов, {} уникальных имён в домене", sum.certificates, sum.subdomains.len()),
            &sum.source_url,
        );
        for (issuer, _) in issuers.iter().take(5) {
            let ikey = keys::org("name", issuer);
            b.entity(&ikey, EntityKind::Organization, issuer);
            b.relate(&dkey, &ikey, "certificates_issued_by", 1.0, &sum.source_url, Some("издатель сертификатов по данным CT"));
        }
        for sub in sum.subdomains.iter().filter(|s| *s != &domain).take(MAX_SUBDOMAIN_NODES) {
            let skey = keys::domain(sub);
            b.entity(&skey, EntityKind::Domain, sub);
            b.relate(&skey, &dkey, "subdomain_of", 1.0, &sum.source_url, Some("имя из SAN сертификата"));
            b.finding(Category::DigitalFootprint, FindingKind::Subdomain, sub, Some(&format!("https://{sub}/")))
                .snippet("Имя встречается в сертификатах из публичных журналов Certificate Transparency.")
                .entity(&skey);
        }
        if sum.subdomains.len() > MAX_SUBDOMAIN_NODES {
            b.note(format!("Поддоменов {}, в граф добавлены первые {MAX_SUBDOMAIN_NODES} по алфавиту.", sum.subdomains.len()));
        }
        Ok(b.finish())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn extracts_names_and_issuers() {
        let mut set = BTreeSet::new();
        add_name(&mut set, "*.api.example.com", "example.com");
        add_name(&mut set, "evil-example.com", "example.com");
        add_name(&mut set, "Example.com.", "example.com");
        assert_eq!(set.into_iter().collect::<Vec<_>>(), vec!["api.example.com", "example.com"]);
        assert_eq!(issuer_org("C=US, O=Let's Encrypt, CN=R11"), "Let's Encrypt");
        assert_eq!(issuer_org("CN=Some CA"), "Some CA");
    }
}
