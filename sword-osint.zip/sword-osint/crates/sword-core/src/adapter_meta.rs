//! Self-description of source adapters.
//!
//! The UI renders connection forms (SETTINGS), the source registry (DATABASES) and the
//! methodology section of reports directly from [`AdapterInfo`], so adding an adapter does
//! not require UI changes.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::input::InputKind;
use crate::model::Category;

/// A secret the adapter needs (stored in the OS credential vault, never in SQLite).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CredentialSpec {
    /// Vault key, e.g. `brave.api_key`.
    pub key: String,
    pub label: String,
    pub required: bool,
    /// Where and how to obtain the credential (shown in SETTINGS).
    pub help: String,
    pub help_url: Option<String>,
    pub placeholder: Option<String>,
}

/// A non-secret option (instance URL, language list, API version…).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct OptionSpec {
    pub key: String,
    pub label: String,
    pub required: bool,
    pub default: Option<String>,
    pub help: String,
    pub placeholder: Option<String>,
}

/// Static description of an adapter.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AdapterInfo {
    pub id: String,
    pub name: String,
    pub provider: String,
    pub description: String,
    /// How the source is queried — copied verbatim into the report methodology.
    pub methodology: String,
    pub categories: Vec<Category>,
    pub input_kinds: Vec<InputKind>,
    pub credentials: Vec<CredentialSpec>,
    pub options: Vec<OptionSpec>,
    /// Default request budget enforced by the rate limiter.
    pub rate_limit_per_minute: u32,
    pub homepage: String,
    pub docs_url: Option<String>,
    /// `true` when the adapter uses an official API of the platform.
    pub official_api: bool,
}

impl AdapterInfo {
    pub fn serves_any(&self, categories: &[Category]) -> bool {
        categories.iter().any(|c| self.categories.contains(c))
    }
}

/// Health of a source as last observed.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AdapterHealth {
    Online,
    Degraded,
    Unconfigured,
    Unauthorized,
    RateLimited,
    Offline,
    Disabled,
    Unknown,
}

impl AdapterHealth {
    pub fn as_str(&self) -> &'static str {
        match self {
            AdapterHealth::Online => "online",
            AdapterHealth::Degraded => "degraded",
            AdapterHealth::Unconfigured => "unconfigured",
            AdapterHealth::Unauthorized => "unauthorized",
            AdapterHealth::RateLimited => "rate_limited",
            AdapterHealth::Offline => "offline",
            AdapterHealth::Disabled => "disabled",
            AdapterHealth::Unknown => "unknown",
        }
    }

    pub fn parse(s: &str) -> Self {
        match s {
            "online" => AdapterHealth::Online,
            "degraded" => AdapterHealth::Degraded,
            "unconfigured" => AdapterHealth::Unconfigured,
            "unauthorized" => AdapterHealth::Unauthorized,
            "rate_limited" => AdapterHealth::RateLimited,
            "offline" => AdapterHealth::Offline,
            "disabled" => AdapterHealth::Disabled,
            _ => AdapterHealth::Unknown,
        }
    }
}

/// Result of one API permission probe (e.g. «groups.search requires a user token»).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PermissionCheck {
    pub name: String,
    pub granted: bool,
    pub detail: String,
}

impl PermissionCheck {
    pub fn granted(name: impl Into<String>, detail: impl Into<String>) -> Self {
        PermissionCheck { name: name.into(), granted: true, detail: detail.into() }
    }
    pub fn denied(name: impl Into<String>, detail: impl Into<String>) -> Self {
        PermissionCheck { name: name.into(), granted: false, detail: detail.into() }
    }
}

/// Observed status of an adapter (persisted in `connector_status`).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AdapterStatus {
    pub adapter_id: String,
    pub health: AdapterHealth,
    pub message: String,
    pub checked_at: Option<DateTime<Utc>>,
    /// Last time data was successfully received from the source.
    pub last_success_at: Option<DateTime<Utc>>,
    pub latency_ms: Option<u32>,
    pub permissions: Vec<PermissionCheck>,
}

impl AdapterStatus {
    pub fn unknown(adapter_id: impl Into<String>) -> Self {
        AdapterStatus {
            adapter_id: adapter_id.into(),
            health: AdapterHealth::Unknown,
            message: "Проверка ещё не выполнялась".into(),
            checked_at: None,
            last_success_at: None,
            latency_ms: None,
            permissions: Vec::new(),
        }
    }
}

/// State of one credential as shown to the UI (the secret itself never leaves Rust).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct CredentialState {
    pub key: String,
    pub is_set: bool,
    pub updated_at: Option<DateTime<Utc>>,
    /// First 6 hex chars of SHA-256 of the secret — lets the analyst tell keys apart
    /// without revealing any part of them.
    pub fingerprint: Option<String>,
}

/// Adapter description combined with its runtime state (DATABASES → Sources, SETTINGS).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AdapterView {
    pub info: AdapterInfo,
    pub enabled: bool,
    pub configured: bool,
    pub missing: Vec<String>,
    pub credentials: Vec<CredentialState>,
    pub options: std::collections::BTreeMap<String, String>,
    pub status: AdapterStatus,
}
