//! # sword-core — Core Engine
//!
//! Shared vocabulary of SWORD OSINT. Every other crate speaks in these types:
//!
//! * [`model`] — categories, findings, graph entities/relations with provenance,
//!   adapter runs, investigation records and the event stream sent to the UI;
//! * [`adapter_meta`] — self-description of source adapters (credentials, options,
//!   health and permission checks);
//! * [`input`] — classification of the analyst's query (domain, URL, e-mail, IP,
//!   VK / Telegram reference or free text);
//! * [`settings`] — persisted application settings (non-secret);
//! * [`secrets`] — the secret storage abstraction (OS credential vault in the app);
//! * [`assets`] — the analyst's own assets that unlock self-audit checks;
//! * [`error`] — the unified error type with stable machine-readable kinds;
//! * [`util`] — ids, time, URL canonicalisation, masking and text helpers.
//!
//! The crate has no I/O and no async runtime dependency.

pub mod adapter_meta;
pub mod assets;
pub mod error;
pub mod input;
pub mod keys;
pub mod model;
pub mod secrets;
pub mod settings;
pub mod util;

pub use adapter_meta::*;
pub use assets::OwnedAssets;
pub use error::{ErrorKind, SwordError, SwordResult};
pub use input::{classify, ClassifiedInput, InputKind};
pub use model::*;
pub use secrets::{MemorySecretStore, SecretStore};
pub use settings::*;

/// Product name used in user agents, PDF metadata and UI.
pub const PRODUCT_NAME: &str = "SWORD OSINT";
/// Crate version, shared by the whole workspace.
pub const VERSION: &str = env!("CARGO_PKG_VERSION");
