//! Builder that keeps adapter code short while enforcing provenance: every finding,
//! attribute, relation and fact is stamped with the adapter id and retrieval time, and
//! relations/attributes require a source URL.

use chrono::{DateTime, Utc};
use sword_core::util::{canonical_url, new_id, strip_html, truncate_chars};
use sword_core::{
    AdapterInfo, AdapterOutput, Attr, Category, Entity, EntityKind, Evidence, Finding, FindingKind, KeyFact,
    NodeAttribute, Relation, Severity, SourceRef,
};

pub struct OutputBuilder {
    adapter_id: String,
    now: DateTime<Utc>,
    out: AdapterOutput,
}

impl OutputBuilder {
    pub fn new(info: &AdapterInfo) -> Self {
        OutputBuilder { adapter_id: info.id.clone(), now: sword_core::util::now(), out: AdapterOutput::default() }
    }

    pub fn now(&self) -> DateTime<Utc> {
        self.now
    }

    /// Add a finding and return it for further decoration.
    pub fn finding(&mut self, category: Category, kind: FindingKind, title: &str, url: Option<&str>) -> &mut Finding {
        let title = truncate_chars(&strip_html(title), 300);
        self.out.findings.push(Finding {
            id: new_id(),
            adapter_id: self.adapter_id.clone(),
            category,
            kind,
            title: if title.is_empty() { "(без названия)".into() } else { title },
            url: url.map(|u| u.trim().to_string()).filter(|u| u.starts_with("http")),
            snippet: None,
            published_at: None,
            retrieved_at: self.now,
            confidence: 1.0,
            severity: None,
            attributes: Vec::new(),
            entity_key: None,
        });
        self.out.findings.last_mut().expect("just pushed")
    }

    /// Describe (or extend) a graph entity.
    pub fn entity(&mut self, key: &str, kind: EntityKind, label: &str) {
        if let Some(e) = self.out.entities.iter_mut().find(|e| e.key == key) {
            if e.label.is_empty() {
                e.label = label.to_string();
            }
            return;
        }
        self.out.entities.push(Entity {
            key: key.to_string(),
            kind,
            label: truncate_chars(label.trim(), 120),
            attributes: Vec::new(),
        });
    }

    /// Attach a sourced fact to an entity (the entity must have been added before).
    pub fn attr(&mut self, key: &str, label: &str, value: &str, source_url: &str) {
        let value = value.trim();
        if value.is_empty() || source_url.is_empty() {
            return;
        }
        let adapter_id = self.adapter_id.clone();
        let now = self.now;
        if let Some(e) = self.out.entities.iter_mut().find(|e| e.key == key) {
            if !e.attributes.iter().any(|a| a.label == label && a.value == value) {
                e.attributes.push(NodeAttribute {
                    label: label.to_string(),
                    value: truncate_chars(value, 400),
                    source_url: source_url.to_string(),
                    adapter_id,
                    retrieved_at: now,
                });
            }
        }
    }

    /// Record a confirmed relation. Relations without a source URL are rejected.
    pub fn relate(&mut self, from: &str, to: &str, relation: &str, confidence: f32, source_url: &str, note: Option<&str>) {
        if from == to || source_url.is_empty() {
            return;
        }
        self.out.relations.push(Relation {
            from: from.to_string(),
            to: to.to_string(),
            relation: relation.to_string(),
            confidence: confidence.clamp(0.0, 1.0),
            evidence: Evidence {
                source_url: source_url.to_string(),
                adapter_id: self.adapter_id.clone(),
                retrieved_at: self.now,
                note: note.map(str::to_string),
            },
        });
    }

    /// Register a consulted source document.
    pub fn source(&mut self, url: &str, title: &str) {
        let canon = canonical_url(url);
        if canon.is_empty() || self.out.sources.iter().any(|s| canonical_url(&s.url) == canon) {
            return;
        }
        self.out.sources.push(SourceRef {
            url: url.to_string(),
            title: truncate_chars(title, 200),
            adapter_id: self.adapter_id.clone(),
            retrieved_at: self.now,
        });
    }

    pub fn fact(&mut self, label: &str, value: &str, source_url: &str) {
        if value.trim().is_empty() {
            return;
        }
        self.out.facts.push(KeyFact {
            label: label.to_string(),
            value: truncate_chars(value.trim(), 300),
            adapter_id: self.adapter_id.clone(),
            source_url: source_url.to_string(),
        });
    }

    pub fn note(&mut self, text: impl Into<String>) {
        let t = text.into();
        if !self.out.notes.contains(&t) {
            self.out.notes.push(t);
        }
    }

    pub fn finding_count(&self) -> usize {
        self.out.findings.len()
    }

    pub fn finish(self) -> AdapterOutput {
        self.out
    }
}

/// Fluent helpers on findings.
pub trait FindingExt {
    fn snippet(&mut self, text: &str) -> &mut Self;
    fn published(&mut self, at: Option<DateTime<Utc>>) -> &mut Self;
    fn confidence(&mut self, c: f32) -> &mut Self;
    fn severity(&mut self, s: Severity) -> &mut Self;
    fn attr(&mut self, label: &str, value: impl ToString) -> &mut Self;
    fn entity(&mut self, key: &str) -> &mut Self;
}

impl FindingExt for Finding {
    fn snippet(&mut self, text: &str) -> &mut Self {
        let s = truncate_chars(&strip_html(text), 600);
        self.snippet = if s.is_empty() { None } else { Some(s) };
        self
    }
    fn published(&mut self, at: Option<DateTime<Utc>>) -> &mut Self {
        self.published_at = at;
        self
    }
    fn confidence(&mut self, c: f32) -> &mut Self {
        self.confidence = c.clamp(0.0, 1.0);
        self
    }
    fn severity(&mut self, s: Severity) -> &mut Self {
        self.severity = Some(s);
        self
    }
    fn attr(&mut self, label: &str, value: impl ToString) -> &mut Self {
        let v = value.to_string();
        if !v.trim().is_empty() {
            self.attributes.push(Attr::new(label, truncate_chars(v.trim(), 400)));
        }
        self
    }
    fn entity(&mut self, key: &str) -> &mut Self {
        self.entity_key = Some(key.to_string());
        self
    }
}

/// Domain node + «hosted_on» edge for any public URL (a structural fact of the URL).
pub fn link_url_to_domain(b: &mut OutputBuilder, item_key: &str, url: &str) {
    if let Some(host) = sword_core::util::host_of(url) {
        let reg = sword_core::input::registrable(&host).unwrap_or(host.clone());
        let dkey = sword_core::keys::domain(&reg);
        b.entity(&dkey, EntityKind::Domain, &reg);
        b.relate(item_key, &dkey, "hosted_on", 1.0, url, None);
    }
}
