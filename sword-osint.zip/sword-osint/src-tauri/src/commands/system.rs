//! Application info, settings, metrics and safe opening of links/files.

use serde::Serialize;
use sword_core::AppSettings;
use sword_db::MetricSample;
use tauri::{AppHandle, State};
use tauri_plugin_opener::OpenerExt;

use crate::error::{ApiError, ApiResult};
use crate::state::{blocking, AppState};

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AppInfo {
    pub name: String,
    pub version: String,
    pub data_dir: String,
    pub db_path: String,
    pub reports_dir: String,
    pub logs_dir: String,
    pub os: String,
    pub arch: String,
    pub uptime_secs: u64,
    pub vault_persistent: bool,
    pub adapters: usize,
}

#[tauri::command]
pub fn app_info(state: State<'_, AppState>) -> AppInfo {
    AppInfo {
        name: sword_core::PRODUCT_NAME.into(),
        version: sword_core::VERSION.into(),
        data_dir: state.paths.data_dir.display().to_string(),
        db_path: state.paths.db_path.display().to_string(),
        reports_dir: state.paths.reports_dir.display().to_string(),
        logs_dir: state.paths.logs_dir.display().to_string(),
        os: std::env::consts::OS.into(),
        arch: std::env::consts::ARCH.into(),
        uptime_secs: state.started.elapsed().as_secs(),
        vault_persistent: state.vault_persistent,
        adapters: state.registry().all().len(),
    }
}

#[tauri::command]
pub fn get_settings(state: State<'_, AppState>) -> AppSettings {
    (*state.settings()).clone()
}

#[tauri::command]
pub async fn save_settings(state: State<'_, AppState>, settings: AppSettings) -> ApiResult<AppSettings> {
    let applied = state.apply_settings(settings)?;
    let db = state.db.clone();
    let to_save = (*applied).clone();
    blocking(move || db.save_settings(&to_save)).await?;
    Ok((*applied).clone())
}

/// Performance samples from the UI (fps, heap) — feed the ANALYTICS performance panel.
#[tauri::command]
pub async fn record_metrics(state: State<'_, AppState>, samples: Vec<MetricSample>) -> ApiResult<()> {
    let allowed = ["fps", "js_heap_mb", "particles", "renderer", "frame_ms"];
    let samples: Vec<MetricSample> = samples.into_iter().filter(|s| allowed.contains(&s.name.as_str())).take(64).collect();
    if samples.is_empty() {
        return Ok(());
    }
    let db = state.db.clone();
    blocking(move || db.insert_metrics(&samples)).await
}

/// Open an http(s) link in the default browser.
#[tauri::command]
pub fn open_external(app: AppHandle, url: String) -> ApiResult<()> {
    let parsed = url::Url::parse(url.trim()).map_err(|_| ApiError::invalid("некорректная ссылка"))?;
    if !matches!(parsed.scheme(), "http" | "https") {
        return Err(ApiError::invalid("разрешены только ссылки http и https"));
    }
    app.opener().open_url(parsed.to_string(), None::<&str>).map_err(|e| ApiError::internal(e.to_string()))
}

/// Only files produced by the app (reports, exports) or the data folder may be opened.
async fn ensure_known_path(state: &AppState, path: &str) -> ApiResult<std::path::PathBuf> {
    let p = std::path::PathBuf::from(path);
    if p.starts_with(&state.paths.data_dir) {
        return Ok(p);
    }
    let db = state.db.clone();
    let path_owned = path.to_string();
    let known = blocking(move || db.is_known_output(&path_owned)).await?;
    if known {
        Ok(p)
    } else {
        Err(ApiError::invalid("путь не относится к файлам, созданным SWORD OSINT"))
    }
}

#[tauri::command]
pub async fn open_path(app: AppHandle, state: State<'_, AppState>, path: String) -> ApiResult<()> {
    let p = ensure_known_path(&state, &path).await?;
    if !p.exists() {
        return Err(ApiError::not_found("файл не найден (возможно, перемещён или удалён)"));
    }
    app.opener().open_path(p.display().to_string(), None::<&str>).map_err(|e| ApiError::internal(e.to_string()))
}

#[tauri::command]
pub async fn reveal_path(app: AppHandle, state: State<'_, AppState>, path: String) -> ApiResult<()> {
    let p = ensure_known_path(&state, &path).await?;
    app.opener().reveal_item_in_dir(p).map_err(|e| ApiError::internal(e.to_string()))
}

#[tauri::command]
pub fn open_data_dir(app: AppHandle, state: State<'_, AppState>) -> ApiResult<()> {
    app.opener()
        .open_path(state.paths.data_dir.display().to_string(), None::<&str>)
        .map_err(|e| ApiError::internal(e.to_string()))
}

#[tauri::command]
pub fn open_logs_dir(app: AppHandle, state: State<'_, AppState>) -> ApiResult<()> {
    std::fs::create_dir_all(&state.paths.logs_dir)?;
    app.opener()
        .open_path(state.paths.logs_dir.display().to_string(), None::<&str>)
        .map_err(|e| ApiError::internal(e.to_string()))
}
