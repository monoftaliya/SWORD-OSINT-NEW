//! DISCOVERY: classify, plan, start and cancel investigations.

use std::sync::Arc;

use sword_core::util::{new_id, now};
use sword_core::{
    classify, AdapterHealth, AdapterStatus, ClassifiedInput, ErrorKind, EventSink, InvestigationEvent, InvestigationKind,
    InvestigationRecord, InvestigationRequest, InvestigationStatus, PlannedAdapter, RunStatus,
};
use sword_search::InvestigationOutcome;
use tauri::{AppHandle, Manager, State};
use tokio_util::sync::CancellationToken;

use crate::error::{ApiError, ApiResult};
use crate::events::TauriSink;
use crate::state::{blocking, AppState};

#[tauri::command]
pub fn classify_query(query: String) -> ApiResult<ClassifiedInput> {
    Ok(classify(&query)?)
}

#[tauri::command]
pub fn plan_investigation(state: State<'_, AppState>, request: InvestigationRequest) -> ApiResult<Vec<PlannedAdapter>> {
    let input = classify(&request.query)?;
    let ctx = state.context(CancellationToken::new())?.with_categories(request.categories.clone());
    Ok(state.engine.plan(&input, &request, &ctx))
}

fn running_record(id: &str, kind: InvestigationKind, query: &str, input: &ClassifiedInput, request: &InvestigationRequest) -> InvestigationRecord {
    InvestigationRecord {
        id: id.to_string(),
        kind,
        query: query.trim().to_string(),
        input_kind: input.kind,
        categories: request.categories.clone(),
        status: InvestigationStatus::Running,
        created_at: now(),
        finished_at: None,
        duration_ms: None,
        result_count: 0,
        source_count: 0,
        node_count: 0,
        edge_count: 0,
        adapters: vec![],
        summary: String::new(),
        key_facts: vec![],
        limitations: vec![],
        error: None,
        notes: String::new(),
    }
}

/// Persist an outcome, update connector statuses and (optionally) OpenSearch.
pub async fn persist_outcome(app: &AppHandle, outcome: &InvestigationOutcome) -> ApiResult<()> {
    let state = app.state::<AppState>();
    let store_snippets = state.settings().privacy.store_snippets;
    let db = state.db.clone();
    let o = outcome.clone();
    blocking(move || {
        db.save_investigation(&o.record, &o.runs, &o.findings, &o.sources, &o.graph, store_snippets)?;
        for r in &o.runs {
            let base = r.adapter_id.split('#').next().unwrap_or(&r.adapter_id).to_string();
            if base.starts_with("audit.") {
                continue;
            }
            match (r.status, r.error_kind) {
                (RunStatus::Done, _) => db.mark_adapter_success(&base, &r.finished_at.unwrap_or_else(now))?,
                (_, Some(kind @ (ErrorKind::Unauthorized | ErrorKind::Forbidden | ErrorKind::RateLimited | ErrorKind::Network))) => {
                    db.save_status(&AdapterStatus {
                        adapter_id: base,
                        health: match kind {
                            ErrorKind::Unauthorized | ErrorKind::Forbidden => AdapterHealth::Unauthorized,
                            ErrorKind::RateLimited => AdapterHealth::RateLimited,
                            _ => AdapterHealth::Offline,
                        },
                        message: r.message.clone().unwrap_or_default(),
                        checked_at: r.finished_at,
                        last_success_at: None,
                        latency_ms: r.duration_ms,
                        permissions: vec![],
                    })?;
                }
                _ => {}
            }
        }
        Ok(())
    })
    .await?;

    // Optional OpenSearch indexing
    let settings = state.settings();
    if settings.search.backend == "opensearch" {
        if let Some(url) = settings.search.opensearch_url.clone() {
            let password = state.secrets.get("opensearch.password").ok().flatten();
            match sword_search::opensearch::OpenSearch::new(
                state.http().client().clone(),
                &url,
                &settings.search.opensearch_index,
                settings.search.opensearch_username.clone(),
                password,
            ) {
                Ok(os) => {
                    if let Err(e) = os.index_findings(&outcome.record.id, &outcome.record.query, &outcome.findings).await {
                        tracing::warn!(error = %e, "OpenSearch indexing failed");
                    }
                }
                Err(e) => tracing::warn!(error = %e, "OpenSearch misconfigured"),
            }
        }
    }
    Ok(())
}

/// Record a failure that happened before the engine produced an outcome.
pub async fn persist_failure(app: &AppHandle, mut record: InvestigationRecord, error: String, sink: &dyn EventSink) {
    let state = app.state::<AppState>();
    record.status = if error.contains("отменен") { InvestigationStatus::Cancelled } else { InvestigationStatus::Failed };
    record.finished_at = Some(now());
    record.duration_ms = Some((now() - record.created_at).num_milliseconds().clamp(0, u32::MAX as i64) as u32);
    record.error = Some(error);
    let db = state.db.clone();
    let rec = record.clone();
    if let Err(e) = blocking(move || db.save_investigation(&rec, &[], &[], &[], &sword_graph::Graph::default(), true)).await {
        tracing::error!(error = %e.message, "failed to persist failed investigation");
    }
    sink.emit(InvestigationEvent::Finished { investigation_id: record.id.clone(), record });
}

#[tauri::command]
pub async fn start_investigation(app: AppHandle, state: State<'_, AppState>, request: InvestigationRequest) -> ApiResult<String> {
    if request.categories.is_empty() {
        return Err(ApiError::invalid("выберите хотя бы одну категорию"));
    }
    let input = classify(&request.query)?;
    let id = new_id();
    let cancel = CancellationToken::new();
    let ctx = state.context(cancel.clone())?;
    let record = running_record(&id, InvestigationKind::Discovery, &request.query, &input, &request);
    let db = state.db.clone();
    let rec = record.clone();
    blocking(move || db.insert_running(&rec)).await?;
    state.register_run(&id, cancel);

    let engine = state.engine.clone();
    let app2 = app.clone();
    let id2 = id.clone();
    tauri::async_runtime::spawn(async move {
        let sink: Arc<dyn EventSink> = Arc::new(TauriSink::new(app2.clone()));
        match engine.run(id2.clone(), request, ctx, sink.clone()).await {
            Ok(outcome) => {
                if let Err(e) = persist_outcome(&app2, &outcome).await {
                    tracing::error!(error = %e.message, "failed to persist investigation");
                }
            }
            Err(e) => persist_failure(&app2, record, e.to_string(), sink.as_ref()).await,
        }
        app2.state::<AppState>().finish_run(&id2);
    });
    Ok(id)
}

#[tauri::command]
pub fn cancel_investigation(state: State<'_, AppState>, id: String) -> bool {
    state.cancel_run(&id)
}

#[tauri::command]
pub fn running_investigations(state: State<'_, AppState>) -> Vec<String> {
    state.running.lock().map(|m| m.keys().cloned().collect()).unwrap_or_default()
}
