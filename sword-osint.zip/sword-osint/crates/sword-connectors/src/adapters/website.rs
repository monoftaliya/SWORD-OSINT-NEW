//! Public website profile: page metadata, declared social profiles, robots.txt, sitemap and
//! security.txt (RFC 9116). Only publicly served resources are requested — the same ones
//! a browser or a search crawler fetches.

use async_trait::async_trait;
use scraper::{Html, Selector};
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordError, SwordResult,
};

use super::info;
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::http;
use crate::output::{FindingExt, OutputBuilder};

/// Hosts recognised as public profiles of an organisation.
const PROFILE_HOSTS: &[&str] = &[
    "vk.com", "t.me", "telegram.me", "github.com", "gitlab.com", "youtube.com", "rutube.ru", "dzen.ru", "ok.ru", "x.com",
    "twitter.com", "linkedin.com", "facebook.com", "instagram.com", "habr.com", "medium.com", "tiktok.com",
    "bsky.app", "mastodon.social",
];

pub struct Website {
    info: AdapterInfo,
}

impl Default for Website {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Default)]
struct PageMeta {
    title: Option<String>,
    description: Option<String>,
    site_name: Option<String>,
    generator: Option<String>,
    lang: Option<String>,
    canonical: Option<String>,
    profiles: Vec<String>,
}

fn parse_page(html: &str, base: &url::Url) -> PageMeta {
    let doc = Html::parse_document(html);
    let sel = |q: &str| Selector::parse(q).expect("static selector");
    let meta = |name: &str| -> Option<String> {
        let q = format!("meta[name=\"{name}\"], meta[property=\"{name}\"]");
        let s = Selector::parse(&q).ok()?;
        doc.select(&s).find_map(|m| m.value().attr("content")).map(|c| c.trim().to_string()).filter(|c| !c.is_empty())
    };
    let mut m = PageMeta {
        title: doc
            .select(&sel("title"))
            .next()
            .map(|t| t.text().collect::<String>().split_whitespace().collect::<Vec<_>>().join(" "))
            .filter(|t| !t.is_empty()),
        description: meta("description").or_else(|| meta("og:description")),
        site_name: meta("og:site_name"),
        generator: meta("generator"),
        lang: doc.select(&sel("html")).next().and_then(|h| h.value().attr("lang")).map(str::to_string),
        canonical: doc.select(&sel("link[rel=\"canonical\"]")).next().and_then(|l| l.value().attr("href")).map(str::to_string),
        profiles: Vec::new(),
    };
    for a in doc.select(&sel("a[href]")) {
        let Some(href) = a.value().attr("href") else { continue };
        let Ok(u) = base.join(href) else { continue };
        let Some(host) = u.host_str().map(|h| h.trim_start_matches("www.").trim_start_matches("m.").to_lowercase()) else { continue };
        if PROFILE_HOSTS.contains(&host.as_str()) {
            let path = u.path().trim_end_matches('/');
            // skip share/intent links and bare hosts
            let lower = path.to_lowercase();
            if path.len() > 1 && !lower.contains("share") && !lower.contains("intent") && !lower.starts_with("/sharer") {
                let clean = format!("https://{host}{path}");
                if !m.profiles.contains(&clean) {
                    m.profiles.push(clean);
                }
            }
        }
    }
    m.profiles.truncate(25);
    m
}

impl Website {
    pub fn new() -> Self {
        Website {
            info: info(
                "website",
                "Публичный сайт",
                "HTTP(S) сайта",
                "Профиль публичного сайта: заголовок и описание, заявленные профили в соцсетях, robots.txt, sitemap.xml, security.txt.",
                "HTTPS GET главной страницы (с переходами по редиректам), /robots.txt, /sitemap.xml и /.well-known/security.txt. \
                 Разбираются HTML-метаданные (title, meta description, Open Graph, generator) и ссылки на профили организаций. \
                 Запрашиваются только публично отдаваемые ресурсы.",
                &[Category::PublicWebsites, Category::DigitalFootprint],
                &[InputKind::Domain, InputKind::Url, InputKind::Email],
                vec![],
                vec![],
                30,
                "https://www.rfc-editor.org/rfc/rfc9116",
                None,
                true,
            ),
        }
    }

    async fn fetch_text(&self, ctx: &ConnectorContext, url: &str, max: usize) -> SwordResult<(u16, String, String)> {
        let resp = ctx.send(&self.info, ctx.get(url)).await?;
        let status = resp.status().as_u16();
        let final_url = resp.url().to_string();
        let body = http::read_text(resp, max).await?;
        Ok((status, final_url, body))
    }
}

#[async_trait]
impl SourceAdapter for Website {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let (status, _, _) = self.fetch_text(ctx, "https://www.iana.org/", 4096).await?;
        Ok(vec![PermissionCheck::granted("HTTPS", format!("Исходящие HTTPS-запросы работают (HTTP {status})"))])
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let host = input.domain.clone().ok_or_else(|| SwordError::InvalidInput("нужен домен или URL".into()))?;
        let start = match input.kind {
            InputKind::Url => input.url.clone().unwrap_or_else(|| format!("https://{host}/")),
            _ => format!("https://{host}/"),
        };
        let mut b = OutputBuilder::new(&self.info);
        let resp = ctx.send(&self.info, ctx.get(&start)).await?;
        let status = resp.status();
        let final_url = resp.url().clone();
        let headers = resp.headers().clone();
        let html = http::read_text(resp, 3 * 1024 * 1024).await?;
        if !status.is_success() {
            return Err(http::status_error(status, ""));
        }
        let meta = parse_page(&html, &final_url);
        let final_str = final_url.to_string();
        let site_key = keys::site(&format!("{}://{}", final_url.scheme(), final_url.host_str().unwrap_or(&host)));
        let site_host = final_url.host_str().unwrap_or(&host).to_lowercase();
        let reg = sword_core::input::registrable(&site_host).unwrap_or(site_host.clone());
        let dkey = keys::domain(&reg);
        let label = meta.site_name.clone().or(meta.title.clone()).unwrap_or_else(|| site_host.clone());

        b.entity(&site_key, EntityKind::Website, &label);
        b.entity(&dkey, EntityKind::Domain, &reg);
        b.relate(&site_key, &dkey, "hosted_on", 1.0, &final_str, None);
        b.attr(&site_key, "Итоговый URL", &final_str, &final_str);
        for (label_ru, value) in [
            ("Заголовок", meta.title.clone()),
            ("Описание", meta.description.clone()),
            ("Генератор (CMS)", meta.generator.clone()),
            ("Язык", meta.lang.clone()),
            ("Каноническая ссылка", meta.canonical.clone()),
        ] {
            if let Some(v) = value {
                b.attr(&site_key, label_ru, &v, &final_str);
            }
        }
        for (h, label_ru) in [("server", "Веб-сервер"), ("x-powered-by", "X-Powered-By")] {
            if let Some(v) = headers.get(h).and_then(|v| v.to_str().ok()) {
                b.attr(&site_key, label_ru, v, &final_str);
            }
        }
        {
            let f = b.finding(Category::PublicWebsites, FindingKind::Website, &label, Some(&final_str));
            f.snippet(meta.description.as_deref().unwrap_or_default())
                .attr("HTTP-статус", status.as_u16())
                .attr("Генератор", meta.generator.clone().unwrap_or_default())
                .attr("Сервер", headers.get("server").and_then(|v| v.to_str().ok()).unwrap_or_default())
                .entity(&site_key);
        }
        b.source(&final_str, &label);
        if final_url.scheme() == "https" && final_url.host_str() != Some(host.as_str()) {
            b.note(format!("Главная страница перенаправляет на {final_str}"));
        }

        for p in &meta.profiles {
            let pkey = keys::site(p);
            b.entity(&pkey, EntityKind::Website, p.trim_start_matches("https://"));
            b.relate(&site_key, &pkey, "declares_profile", 0.8, &final_str, Some("ссылка размещена на сайте"));
            b.finding(Category::DigitalFootprint, FindingKind::Website, &format!("Профиль: {}", p.trim_start_matches("https://")), Some(p))
                .snippet("Ссылка на профиль размещена на главной странице сайта (самозаявленная связь).")
                .confidence(0.8)
                .entity(&pkey);
        }
        if !meta.profiles.is_empty() {
            b.fact("Профили, заявленные на сайте", &meta.profiles.iter().map(|p| p.trim_start_matches("https://")).collect::<Vec<_>>().join(", "), &final_str);
        }

        let origin = format!("{}://{}", final_url.scheme(), final_url.host_str().unwrap_or(&host));
        // robots.txt
        if let Ok((200, url, body)) = self.fetch_text(ctx, &format!("{origin}/robots.txt"), 256 * 1024).await {
            if !body.trim_start().starts_with('<') {
                let sitemaps: Vec<&str> = body
                    .lines()
                    .filter_map(|l| {
                        let (k, v) = l.split_once(':')?;
                        k.trim().eq_ignore_ascii_case("sitemap").then(|| v.trim())
                    })
                    .collect();
                let disallow = body.lines().filter(|l| l.trim_start().to_lowercase().starts_with("disallow:")).count();
                b.finding(Category::PublicWebsites, FindingKind::WebPage, "robots.txt", Some(&url))
                    .snippet(&format!("Правил Disallow: {disallow}; карт сайта: {}", sitemaps.len()))
                    .attr("Карты сайта", sitemaps.join(", "));
                b.attr(&site_key, "robots.txt", &format!("{disallow} правил Disallow"), &url);
                b.source(&url, "robots.txt");
            }
        }
        // security.txt (RFC 9116)
        if let Ok((200, url, body)) = self.fetch_text(ctx, &format!("{origin}/.well-known/security.txt"), 64 * 1024).await {
            if body.to_lowercase().contains("contact:") && !body.trim_start().starts_with('<') {
                let contacts: Vec<String> = body
                    .lines()
                    .filter_map(|l| {
                        let (k, v) = l.split_once(':')?;
                        k.trim().eq_ignore_ascii_case("contact").then(|| v.trim().to_string())
                    })
                    .collect();
                let expires = body.lines().find_map(|l| {
                    let (k, v) = l.split_once(':')?;
                    k.trim().eq_ignore_ascii_case("expires").then(|| v.trim().to_string())
                });
                b.finding(Category::PublicWebsites, FindingKind::WebPage, "security.txt (RFC 9116)", Some(&url))
                    .snippet(&format!("Контакты для сообщений об уязвимостях: {}", contacts.join(", ")))
                    .attr("Expires", expires.clone().unwrap_or_default());
                b.attr(&site_key, "security.txt", &contacts.join(", "), &url);
                b.source(&url, "security.txt");
            }
        }
        // sitemap.xml presence
        if let Ok((200, url, body)) = self.fetch_text(ctx, &format!("{origin}/sitemap.xml"), 512 * 1024).await {
            if body.contains("<urlset") || body.contains("<sitemapindex") {
                let urls = body.matches("<loc>").count();
                b.attr(&site_key, "sitemap.xml", &format!("{urls} записей <loc>"), &url);
                b.source(&url, "sitemap.xml");
            }
        }
        Ok(b.finish())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn extracts_metadata_and_profiles() {
        let html = r#"<html lang="ru"><head><title> ООО Пример </title>
            <meta name="description" content="Официальный сайт"><meta property="og:site_name" content="Пример">
            <meta name="generator" content="WordPress 6.5"></head>
            <body><a href="https://vk.com/example">VK</a><a href="https://t.me/example_news/">TG</a>
            <a href="https://vk.com/share.php?url=x">share</a><a href="/about">about</a></body></html>"#;
        let base = url::Url::parse("https://example.ru/").unwrap();
        let m = parse_page(html, &base);
        assert_eq!(m.title.as_deref(), Some("ООО Пример"));
        assert_eq!(m.site_name.as_deref(), Some("Пример"));
        assert_eq!(m.generator.as_deref(), Some("WordPress 6.5"));
        assert_eq!(m.profiles, vec!["https://vk.com/example", "https://t.me/example_news"]);
    }
}
