//! Have I Been Pwned — legal breach notification service by Troy Hunt.
//!
//! * Breaches of an organisation's domain: public `/breaches?Domain=` (no key).
//! * A specific e-mail address: `/breachedAccount` + `/pasteAccount` with an API key, and
//!   **only** for addresses the analyst registered as their own (INTELLIGENCE → «Мои активы»).
//! * Pwned Passwords (k-anonymity) is used by the audit module, never by Discovery.

use async_trait::async_trait;
use serde_json::Value;
use sword_core::util::{fmt_date, mask_email, parse_date, strip_html};
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    Severity, SwordError, SwordResult,
};

use super::{arr, cred, fmt_int, info, num, s};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::http;
use crate::output::{FindingExt, OutputBuilder};

pub const API: &str = "https://haveibeenpwned.com/api/v3";
pub const KEY: &str = "hibp.api_key";

pub struct Hibp {
    info: AdapterInfo,
}

impl Default for Hibp {
    fn default() -> Self {
        Self::new()
    }
}

/// Severity of a breach by its exposed data classes.
pub fn breach_severity(b: &Value) -> Severity {
    let classes: Vec<String> = arr(b, "/DataClasses").iter().filter_map(|c| c.as_str().map(|s| s.to_lowercase())).collect();
    let has = |needle: &str| classes.iter().any(|c| c.contains(needle));
    if has("password") || has("credit card") || has("bank account") || has("security questions") {
        Severity::High
    } else if has("phone") || has("physical address") || has("date of birth") || has("passport") {
        Severity::Medium
    } else {
        Severity::Low
    }
}

pub fn breach_title(b: &Value) -> String {
    format!(
        "{} — {}",
        s(b, "Title").or_else(|| s(b, "Name")).unwrap_or_else(|| "Утечка".into()),
        s(b, "BreachDate").and_then(|d| parse_date(&d)).map(|d| fmt_date(&d)).unwrap_or_else(|| "дата неизвестна".into())
    )
}

pub fn breach_url(b: &Value) -> String {
    format!("https://haveibeenpwned.com/Breach/{}", s(b, "Name").unwrap_or_default())
}

impl Hibp {
    pub fn new() -> Self {
        Hibp {
            info: info(
                "hibp",
                "Have I Been Pwned",
                "Troy Hunt / HIBP",
                "Известные утечки данных: инциденты, затронувшие домен организации, и (для ваших собственных адресов) — учётные записи в утечках.",
                "HIBP API v3: GET /breaches?Domain= (без ключа) для домена; GET /breachedAccount/{e-mail}?truncateResponse=false и \
                 /pasteAccount/{e-mail} с заголовком hibp-api-key — только для адресов, добавленных аналитиком как собственные. \
                 Сервис агрегирует сведения о публично известных инцидентах; украденные базы не используются.",
                &[Category::EmailExposure],
                &[InputKind::Email, InputKind::Domain, InputKind::Url],
                vec![cred(
                    KEY,
                    "API-ключ HIBP",
                    false,
                    "Нужен только для проверки ваших адресов e-mail. Оформите подписку на haveibeenpwned.com/API/Key — ключ придёт на почту. \
                     Проверка инцидентов по домену работает без ключа.",
                    Some("https://haveibeenpwned.com/API/Key"),
                    Some("32 hex-символа"),
                )],
                vec![],
                10,
                "https://haveibeenpwned.com/",
                Some("https://haveibeenpwned.com/API/v3"),
                true,
            ),
        }
    }

    /// Breaches of a domain (public endpoint).
    pub async fn domain_breaches(&self, ctx: &ConnectorContext, domain: &str) -> SwordResult<(String, Vec<Value>)> {
        let url = format!("{API}/breaches?Domain={domain}");
        let v: Value = ctx.json(&self.info, ctx.get(&url)).await?;
        Ok((url, v.as_array().cloned().unwrap_or_default()))
    }

    /// Breaches and pastes of an own e-mail address (API key required).
    pub async fn account(&self, ctx: &ConnectorContext, email: &str) -> SwordResult<(Vec<Value>, Vec<Value>)> {
        let key = ctx.secret(KEY).ok_or_else(|| SwordError::NotConfigured("API-ключ HIBP".into()))?;
        let enc = url::form_urlencoded::byte_serialize(email.as_bytes()).collect::<String>();
        let breaches = match ctx
            .send(&self.info, ctx.get(&format!("{API}/breachedAccount/{enc}")).query(&[("truncateResponse", "false")]).header("hibp-api-key", &key))
            .await
        {
            Ok(resp) if resp.status().as_u16() == 404 => Vec::new(),
            Ok(resp) => http::read_json::<Value>(resp).await?.as_array().cloned().unwrap_or_default(),
            Err(e) => return Err(e),
        };
        let pastes = match ctx.send(&self.info, ctx.get(&format!("{API}/pasteAccount/{enc}")).header("hibp-api-key", &key)).await {
            Ok(resp) if resp.status().as_u16() == 404 => Vec::new(),
            Ok(resp) => http::read_json::<Value>(resp).await.ok().and_then(|v| v.as_array().cloned()).unwrap_or_default(),
            Err(_) => Vec::new(),
        };
        Ok((breaches, pastes))
    }
}

#[async_trait]
impl SourceAdapter for Hibp {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let mut perms = Vec::new();
        self.domain_breaches(ctx, "adobe.com").await?;
        perms.push(PermissionCheck::granted("Инциденты по домену", "Публичный эндпоинт /breaches доступен"));
        match ctx.secret(KEY) {
            Some(key) => {
                let r: SwordResult<Value> = ctx.json(&self.info, ctx.get(&format!("{API}/subscription/status")).header("hibp-api-key", key)).await;
                perms.push(match r {
                    Ok(v) => {
                        if let Some(rpm) = num(&v, "Rpm") {
                            ctx.http.limiter(&self.info.id, self.info.rate_limit_per_minute).set_rate(rpm.clamp(1, 1000) as u32).await;
                        }
                        PermissionCheck::granted(
                            "Проверка адресов",
                            format!("Подписка {} до {}, лимит {} запр./мин", s(&v, "SubscriptionName").unwrap_or_default(), s(&v, "SubscribedUntil").unwrap_or_default(), num(&v, "Rpm").unwrap_or(0)),
                        )
                    }
                    Err(e) => PermissionCheck::denied("Проверка адресов", e.to_string()),
                });
            }
            None => perms.push(PermissionCheck::denied("Проверка адресов", "API-ключ не задан — доступна только проверка домена")),
        }
        Ok(perms)
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let mut b = OutputBuilder::new(&self.info);
        if let Some(domain) = input.registrable_domain.clone() {
            let (url, breaches) = self.domain_breaches(ctx, &domain).await?;
            let dkey = keys::domain(&domain);
            b.source(&url, &format!("HIBP: инциденты домена {domain}"));
            if breaches.is_empty() {
                b.finding(Category::EmailExposure, FindingKind::Breach, &format!("{domain}: публично известных утечек не найдено"), Some(&url))
                    .severity(Severity::Pass)
                    .snippet("По данным HIBP домен не фигурирует в каталоге известных утечек.");
                b.fact("Известные утечки (HIBP)", "не найдены", &url);
            } else {
                b.entity(&dkey, EntityKind::Domain, &domain);
                for br in &breaches {
                    let burl = breach_url(br);
                    b.finding(Category::EmailExposure, FindingKind::Breach, &breach_title(br), Some(&burl))
                        .snippet(&strip_html(&s(br, "Description").unwrap_or_default()))
                        .severity(breach_severity(br))
                        .published(s(br, "BreachDate").and_then(|d| parse_date(&d)))
                        .attr("Затронуто записей", num(br, "PwnCount").map(fmt_int).unwrap_or_default())
                        .attr("Типы данных", arr(br, "/DataClasses").iter().filter_map(Value::as_str).collect::<Vec<_>>().join(", "))
                        .attr("Подтверждена", if br.get("IsVerified").and_then(Value::as_bool).unwrap_or(false) { "да" } else { "нет" })
                        .entity(&dkey);
                    b.attr(&dkey, "Известная утечка", &breach_title(br), &burl);
                    b.source(&burl, &breach_title(br));
                }
                b.fact("Известные утечки (HIBP)", &breaches.iter().map(breach_title).collect::<Vec<_>>().join("; "), &url);
            }
        }
        if let Some(email) = &input.email {
            let masked = mask_email(email);
            if !ctx.assets.owns_email(email) {
                b.note(format!(
                    "Проверка адреса {masked} в утечках не выполнялась: она доступна только для ваших адресов, добавленных в INTELLIGENCE → «Мои активы»."
                ));
            } else if ctx.secret(KEY).is_none() {
                b.note("Для проверки собственного адреса задайте API-ключ HIBP в настройках.");
            } else {
                let (breaches, pastes) = self.account(ctx, email).await?;
                let profile = "https://haveibeenpwned.com/";
                if breaches.is_empty() && pastes.is_empty() {
                    b.finding(Category::EmailExposure, FindingKind::Breach, &format!("{masked}: в известных утечках не найден"), Some(profile))
                        .severity(Severity::Pass);
                }
                for br in &breaches {
                    let burl = breach_url(br);
                    b.finding(Category::EmailExposure, FindingKind::Breach, &format!("{masked} — {}", breach_title(br)), Some(&burl))
                        .snippet(&strip_html(&s(br, "Description").unwrap_or_default()))
                        .severity(breach_severity(br))
                        .attr("Типы данных", arr(br, "/DataClasses").iter().filter_map(Value::as_str).collect::<Vec<_>>().join(", "));
                    b.source(&burl, &breach_title(br));
                }
                for p in &pastes {
                    b.finding(Category::EmailExposure, FindingKind::Breach, &format!("{masked} — публикация в paste-сервисе {}", s(p, "Source").unwrap_or_default()), None)
                        .severity(Severity::Medium)
                        .published(s(p, "Date").and_then(|d| parse_date(&d)))
                        .attr("Записей в публикации", num(p, "EmailCount").unwrap_or(0));
                }
                b.fact("Собственный адрес в утечках", &format!("{masked}: утечек {}, публикаций {}", breaches.len(), pastes.len()), profile);
            }
        }
        Ok(b.finish())
    }
}
