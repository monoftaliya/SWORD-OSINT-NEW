//! # sword-analytics — Analytics Engine
//!
//! Every number shown in ANALYTICS is computed here from the local database: investigation
//! history, adapter runs, findings, sources and performance metrics reported by the UI
//! (frame rate, JS heap) and the backend (report generation time). Nothing is estimated.

use std::collections::{BTreeMap, HashMap};

use chrono::{Duration, NaiveDate, Utc};
use rusqlite::params;
use serde::{Deserialize, Serialize};
use sword_core::{SwordResult, VERSION};
use sword_db::Database;

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Totals {
    pub investigations: u32,
    pub audits: u32,
    pub completed: u32,
    pub partial: u32,
    pub failed: u32,
    pub cancelled: u32,
    pub findings: u32,
    pub unique_sources: u32,
    pub adapter_runs: u32,
    pub success_rate: f64,
    pub avg_duration_ms: f64,
    pub graph_nodes: u32,
    pub graph_edges: u32,
    pub reports: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DayPoint {
    pub date: String,
    pub investigations: u32,
    pub findings: u32,
    pub errors: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AdapterActivity {
    pub adapter_id: String,
    pub adapter_name: String,
    pub runs: u32,
    pub done: u32,
    pub failed: u32,
    pub skipped: u32,
    pub results: u32,
    pub avg_ms: f64,
    pub p95_ms: f64,
    pub last_run: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Bucket {
    pub key: String,
    pub count: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ErrorStat {
    pub kind: String,
    pub count: u32,
    pub adapters: Vec<Bucket>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Performance {
    pub avg_investigation_ms: f64,
    pub p95_investigation_ms: f64,
    pub fps_avg: Option<f64>,
    pub fps_min: Option<f64>,
    pub fps_series: Vec<f64>,
    pub heap_mb_avg: Option<f64>,
    pub report_ms_avg: Option<f64>,
    pub renderer: Option<String>,
    pub particles_avg: Option<f64>,
    pub db_size_bytes: u64,
    pub app_version: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AnalyticsReport {
    pub range_days: u32,
    pub generated_at: String,
    pub totals: Totals,
    pub per_day: Vec<DayPoint>,
    pub adapters: Vec<AdapterActivity>,
    pub categories: Vec<Bucket>,
    pub finding_kinds: Vec<Bucket>,
    pub top_source_hosts: Vec<Bucket>,
    pub statuses: Vec<Bucket>,
    pub severities: Vec<Bucket>,
    pub errors: Vec<ErrorStat>,
    pub performance: Performance,
}

fn percentile(sorted: &[f64], p: f64) -> f64 {
    if sorted.is_empty() {
        return 0.0;
    }
    let idx = ((sorted.len() as f64 - 1.0) * p).round() as usize;
    sorted[idx.min(sorted.len() - 1)]
}

fn base_adapter(id: &str) -> String {
    id.split('#').next().unwrap_or(id).to_string()
}

/// Compute the analytics report for the last `range_days` days (0 = all time).
pub fn compute(db: &Database, range_days: u32, adapter_names: &HashMap<String, String>) -> SwordResult<AnalyticsReport> {
    let since = if range_days == 0 {
        "0000".to_string()
    } else {
        (Utc::now() - Duration::days(range_days as i64)).format("%Y-%m-%dT%H:%M:%S%.3fZ").to_string()
    };
    let db_size = db.stats().map(|s| s.size_bytes + s.wal_bytes).unwrap_or(0);

    db.with(|c| {
        let mut t = Totals::default();
        // Investigation totals
        {
            let mut st = c.prepare("SELECT kind, status, COUNT(*), COALESCE(AVG(duration_ms), 0) FROM investigations WHERE created_at >= ?1 GROUP BY kind, status")?;
            let rows = st.query_map(params![since], |r| Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?, r.get::<_, i64>(2)?, r.get::<_, f64>(3)?)))?;
            for row in rows {
                let (kind, status, n, _) = row?;
                let n = n.max(0) as u32;
                if kind == "exposure_audit" {
                    t.audits += n;
                } else {
                    t.investigations += n;
                }
                match status.as_str() {
                    "completed" => t.completed += n,
                    "partial" => t.partial += n,
                    "failed" => t.failed += n,
                    "cancelled" => t.cancelled += n,
                    _ => {}
                }
            }
        }
        let (findings, nodes, edges, avg_ms): (i64, i64, i64, f64) = c.query_row(
            "SELECT COALESCE(SUM(result_count),0), COALESCE(SUM(node_count),0), COALESCE(SUM(edge_count),0), COALESCE(AVG(duration_ms),0) \
             FROM investigations WHERE created_at >= ?1 AND status != 'running'",
            params![since],
            |r| Ok((r.get(0)?, r.get(1)?, r.get(2)?, r.get(3)?)),
        )?;
        t.findings = findings.max(0) as u32;
        t.graph_nodes = nodes.max(0) as u32;
        t.graph_edges = edges.max(0) as u32;
        t.avg_duration_ms = avg_ms;
        t.unique_sources = c.query_row(
            "SELECT COUNT(DISTINCT s.url) FROM sources s JOIN investigations i ON i.id = s.investigation_id WHERE i.created_at >= ?1",
            params![since],
            |r| r.get::<_, i64>(0),
        )?.max(0) as u32;
        t.reports = c.query_row("SELECT COUNT(*) FROM reports WHERE created_at >= ?1", params![since], |r| r.get::<_, i64>(0))?.max(0) as u32;

        // Per-day series (fill gaps with zeros)
        let mut per_day_map: BTreeMap<String, DayPoint> = BTreeMap::new();
        {
            let mut st = c.prepare(
                "SELECT substr(created_at, 1, 10) AS d, COUNT(*), COALESCE(SUM(result_count), 0), \
                        SUM(CASE WHEN status IN ('failed','partial') THEN 1 ELSE 0 END) \
                 FROM investigations WHERE created_at >= ?1 GROUP BY d ORDER BY d",
            )?;
            let rows = st.query_map(params![since], |r| Ok((r.get::<_, String>(0)?, r.get::<_, i64>(1)?, r.get::<_, i64>(2)?, r.get::<_, i64>(3)?)))?;
            for row in rows {
                let (d, n, f, e) = row?;
                per_day_map.insert(d.clone(), DayPoint { date: d, investigations: n.max(0) as u32, findings: f.max(0) as u32, errors: e.max(0) as u32 });
            }
        }
        let span = if range_days == 0 {
            per_day_map.keys().next().and_then(|d| NaiveDate::parse_from_str(d, "%Y-%m-%d").ok()).map(|first| (Utc::now().date_naive() - first).num_days().max(0) as u32 + 1).unwrap_or(1).min(366)
        } else {
            range_days
        };
        let today = Utc::now().date_naive();
        let per_day: Vec<DayPoint> = (0..span)
            .rev()
            .map(|back| {
                let d = (today - Duration::days(back as i64)).format("%Y-%m-%d").to_string();
                per_day_map.remove(&d).unwrap_or(DayPoint { date: d, investigations: 0, findings: 0, errors: 0 })
            })
            .collect();

        // Adapter activity
        let mut durations: HashMap<String, Vec<f64>> = HashMap::new();
        let mut acts: BTreeMap<String, AdapterActivity> = BTreeMap::new();
        {
            let mut st = c.prepare(
                "SELECT r.adapter_id, r.adapter_name, r.status, r.duration_ms, r.result_count, r.started_at, r.error_kind \
                 FROM adapter_runs r JOIN investigations i ON i.id = r.investigation_id WHERE i.created_at >= ?1",
            )?;
            let rows = st.query_map(params![since], |r| {
                Ok((
                    r.get::<_, String>(0)?,
                    r.get::<_, String>(1)?,
                    r.get::<_, String>(2)?,
                    r.get::<_, Option<i64>>(3)?,
                    r.get::<_, i64>(4)?,
                    r.get::<_, Option<String>>(5)?,
                ))
            })?;
            for row in rows {
                let (id, name, status, dur, results, started) = row?;
                let key = base_adapter(&id);
                let display = adapter_names.get(&key).cloned().unwrap_or_else(|| name.split(" — ").next().unwrap_or(&name).to_string());
                let a = acts.entry(key.clone()).or_insert_with(|| AdapterActivity {
                    adapter_id: key.clone(),
                    adapter_name: display,
                    runs: 0,
                    done: 0,
                    failed: 0,
                    skipped: 0,
                    results: 0,
                    avg_ms: 0.0,
                    p95_ms: 0.0,
                    last_run: None,
                });
                a.runs += 1;
                match status.as_str() {
                    "done" => a.done += 1,
                    "skipped" => a.skipped += 1,
                    "failed" | "timed_out" => a.failed += 1,
                    _ => {}
                }
                a.results += results.max(0) as u32;
                if let Some(s) = started {
                    if a.last_run.as_deref().map(|l| s.as_str() > l).unwrap_or(true) {
                        a.last_run = Some(s);
                    }
                }
                if let (Some(ms), true) = (dur, status != "skipped") {
                    durations.entry(key).or_default().push(ms as f64);
                }
            }
        }
        for (k, a) in acts.iter_mut() {
            if let Some(ds) = durations.get_mut(k) {
                ds.sort_by(|x, y| x.partial_cmp(y).unwrap_or(std::cmp::Ordering::Equal));
                a.avg_ms = ds.iter().sum::<f64>() / ds.len() as f64;
                a.p95_ms = percentile(ds, 0.95);
            }
        }
        let executed: u32 = acts.values().map(|a| a.done + a.failed).sum();
        let ok: u32 = acts.values().map(|a| a.done).sum();
        t.adapter_runs = executed;
        t.success_rate = if executed == 0 { 0.0 } else { ok as f64 / executed as f64 };
        let mut adapters: Vec<AdapterActivity> = acts.into_values().collect();
        adapters.sort_by(|a, b| b.runs.cmp(&a.runs).then(a.adapter_name.cmp(&b.adapter_name)));

        // Distributions
        let bucket_query = |sql: &str| -> rusqlite::Result<Vec<Bucket>> {
            let mut st = c.prepare(sql)?;
            let rows = st.query_map(params![since], |r| Ok(Bucket { key: r.get::<_, Option<String>>(0)?.unwrap_or_default(), count: r.get::<_, i64>(1)?.max(0) as u32 }))?;
            rows.collect()
        };
        let categories = bucket_query(
            "SELECT f.category, COUNT(*) FROM findings f JOIN investigations i ON i.id = f.investigation_id WHERE i.created_at >= ?1 GROUP BY f.category ORDER BY 2 DESC",
        )?;
        let finding_kinds = bucket_query(
            "SELECT f.kind, COUNT(*) FROM findings f JOIN investigations i ON i.id = f.investigation_id WHERE i.created_at >= ?1 GROUP BY f.kind ORDER BY 2 DESC",
        )?;
        let statuses = bucket_query("SELECT status, COUNT(*) FROM investigations WHERE created_at >= ?1 GROUP BY status ORDER BY 2 DESC")?;
        let severities = bucket_query(
            "SELECT f.severity, COUNT(*) FROM findings f JOIN investigations i ON i.id = f.investigation_id \
             WHERE i.created_at >= ?1 AND f.severity IS NOT NULL GROUP BY f.severity ORDER BY 2 DESC",
        )?;

        // Source hosts
        let mut hosts: HashMap<String, u32> = HashMap::new();
        {
            let mut st = c.prepare("SELECT s.url FROM sources s JOIN investigations i ON i.id = s.investigation_id WHERE i.created_at >= ?1")?;
            let rows = st.query_map(params![since], |r| r.get::<_, String>(0))?;
            for u in rows {
                let u = u?;
                if let Some(h) = url::Url::parse(&u).ok().and_then(|x| x.host_str().map(|h| h.trim_start_matches("www.").to_string())) {
                    *hosts.entry(h).or_default() += 1;
                }
            }
        }
        let mut top_source_hosts: Vec<Bucket> = hosts.into_iter().map(|(key, count)| Bucket { key, count }).collect();
        top_source_hosts.sort_by(|a, b| b.count.cmp(&a.count).then(a.key.cmp(&b.key)));
        top_source_hosts.truncate(12);

        // Errors
        let mut err_map: BTreeMap<String, (u32, HashMap<String, u32>)> = BTreeMap::new();
        {
            let mut st = c.prepare(
                "SELECT r.error_kind, r.adapter_id FROM adapter_runs r JOIN investigations i ON i.id = r.investigation_id \
                 WHERE i.created_at >= ?1 AND r.error_kind IS NOT NULL",
            )?;
            let rows = st.query_map(params![since], |r| Ok((r.get::<_, String>(0)?, r.get::<_, String>(1)?)))?;
            for row in rows {
                let (kind, adapter) = row?;
                let e = err_map.entry(kind).or_default();
                e.0 += 1;
                *e.1.entry(base_adapter(&adapter)).or_default() += 1;
            }
        }
        let mut errors: Vec<ErrorStat> = err_map
            .into_iter()
            .map(|(kind, (count, by))| {
                let mut adapters: Vec<Bucket> = by.into_iter().map(|(k, c)| Bucket { key: adapter_names.get(&k).cloned().unwrap_or(k), count: c }).collect();
                adapters.sort_by(|a, b| b.count.cmp(&a.count));
                ErrorStat { kind, count, adapters }
            })
            .collect();
        errors.sort_by(|a, b| b.count.cmp(&a.count));

        // Performance
        let mut inv_durations: Vec<f64> = {
            let mut st = c.prepare("SELECT duration_ms FROM investigations WHERE created_at >= ?1 AND duration_ms IS NOT NULL")?;
            let rows = st.query_map(params![since], |r| r.get::<_, i64>(0))?;
            rows.filter_map(|r| r.ok()).map(|v| v as f64).collect()
        };
        inv_durations.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        let metric_avg = |name: &str| -> rusqlite::Result<Option<f64>> {
            c.query_row("SELECT AVG(value) FROM metrics WHERE name = ?1 AND ts >= ?2", params![name, since], |r| r.get::<_, Option<f64>>(0))
        };
        let fps_min: Option<f64> =
            c.query_row("SELECT MIN(value) FROM metrics WHERE name = 'fps' AND ts >= ?1", params![since], |r| r.get(0))?;
        let fps_series: Vec<f64> = {
            let mut st = c.prepare("SELECT value FROM metrics WHERE name = 'fps' ORDER BY id DESC LIMIT 120")?;
            let mut v: Vec<f64> = st.query_map([], |r| r.get::<_, f64>(0))?.filter_map(|r| r.ok()).collect();
            v.reverse();
            v
        };
        let renderer: Option<String> = c
            .query_row("SELECT labels FROM metrics WHERE name = 'renderer' ORDER BY id DESC LIMIT 1", [], |r| r.get(0))
            .ok()
            .flatten();
        let performance = Performance {
            avg_investigation_ms: if inv_durations.is_empty() { 0.0 } else { inv_durations.iter().sum::<f64>() / inv_durations.len() as f64 },
            p95_investigation_ms: percentile(&inv_durations, 0.95),
            fps_avg: metric_avg("fps")?,
            fps_min,
            fps_series,
            heap_mb_avg: metric_avg("js_heap_mb")?,
            report_ms_avg: metric_avg("report_ms")?,
            renderer,
            particles_avg: metric_avg("particles")?,
            db_size_bytes: db_size,
            app_version: VERSION.to_string(),
        };

        Ok(AnalyticsReport {
            range_days,
            generated_at: Utc::now().to_rfc3339(),
            totals: t,
            per_day,
            adapters,
            categories,
            finding_kinds,
            top_source_hosts,
            statuses,
            severities,
            errors,
            performance,
        })
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn computes_on_empty_database() {
        let db = Database::open_in_memory().unwrap();
        let r = compute(&db, 30, &HashMap::new()).unwrap();
        assert_eq!(r.per_day.len(), 30);
        assert_eq!(r.totals.investigations, 0);
        assert!(r.performance.fps_avg.is_none());
    }

    #[test]
    fn percentiles() {
        assert_eq!(percentile(&[1.0, 2.0, 3.0, 4.0, 5.0], 0.5), 3.0);
        assert_eq!(percentile(&[], 0.95), 0.0);
    }
}
