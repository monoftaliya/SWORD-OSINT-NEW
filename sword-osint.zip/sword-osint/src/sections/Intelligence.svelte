<!--
  INTELLIGENCE — Privacy & Exposure Audit of the analyst's OWN assets: e-mail addresses,
  domains (active checks only after DNS ownership proof), local repositories and GitHub
  repositories. Breach data comes only from Have I Been Pwned's official API; passwords
  are checked with k-anonymity and never leave the machine in clear text.
-->
<script lang="ts">
  import { onMount } from 'svelte';
  import Icon from '../lib/components/Icon.svelte';
  import Bits from '../lib/components/Bits.svelte';
  import Panel from '../lib/components/Panel.svelte';
  import Segmented from '../lib/components/Segmented.svelte';
  import Modal from '../lib/components/Modal.svelte';
  import FindingList from '../lib/components/FindingList.svelte';
  import FindingDrawer from '../lib/components/FindingDrawer.svelte';
  import RunTimeline from '../lib/components/RunTimeline.svelte';
  import type { IconName } from '../lib/components/icons';
  import { api, desktop } from '../lib/api/client';
  import type { Asset, AssetKind, AuditCheck, Finding, PasswordExposure, Severity } from '../lib/api/types';
  import { app } from '../lib/stores/app.svelte';
  import { run, runProgress } from '../lib/stores/run.svelte';
  import { ui } from '../lib/stores/ui.svelte';
  import { AUDIT_CHECKS, SEVERITY_META } from '../lib/util/labels';
  import { fmtDateTime, fmtNum, plural } from '../lib/util/format';
  import { copyText, guarded } from '../lib/components/ui';

  const KIND_META: Record<AssetKind, { label: string; icon: IconName; placeholder: string; attest: string }> = {
    email: { label: 'E-mail', icon: 'mail', placeholder: 'you@company.com', attest: 'Это мой адрес или адрес моей организации, и я уполномочен(а) его проверять.' },
    domain: { label: 'Домен', icon: 'domain', placeholder: 'company.com', attest: 'Это домен моей организации, и я уполномочен(а) проводить его аудит.' },
    repo_local: { label: 'Репозиторий', icon: 'folder', placeholder: 'C:\\Projects\\my-repo', attest: 'Это мой репозиторий (рабочая копия), и я уполномочен(а) его проверять.' },
    repo_github: { label: 'GitHub', icon: 'link', placeholder: 'owner/repo', attest: 'Это репозиторий моей организации, и у меня есть доступ к его оповещениям безопасности.' },
  };

  const SEVERITIES: Severity[] = ['critical', 'high', 'medium', 'low', 'info', 'pass'];

  let assets = $state<Asset[]>([]);
  let loading = $state(false);
  let newKind = $state<AssetKind>('email');
  let newValue = $state('');
  let attested = $state(false);
  let adding = $state(false);
  let verifying = $state<string | null>(null);
  let removeTarget = $state<Asset | null>(null);
  let removeOpen = $state(false);
  let expanded = $state<string | null>(null);
  let tab = $state<'results' | 'password' | 'publication'>('results');
  let selectedFinding = $state<string | null>(null);

  // tools
  let password = $state('');
  let pwResult = $state<PasswordExposure | null>(null);
  let pwBusy = $state(false);
  let scanTextValue = $state('');
  let scanUrlValue = $state('');
  let scanBusy = $state(false);
  let scanFindings = $state<Finding[] | null>(null);

  const audit = $derived(run.audit);
  const live = $derived(!!audit?.live);
  const progress = $derived(runProgress(audit));
  const chosen = $derived(assets.filter((a) => ui.auditAssets.includes(a.id)));
  const chosenKinds = $derived(new Set(chosen.map((a) => a.kind)));
  const applicable = $derived(AUDIT_CHECKS.filter((c) => chosenKinds.has(c.target)));
  const activeChecks = $derived(applicable.filter((c) => ui.auditChecks.includes(c.id)).map((c) => c.id));
  const canAudit = $derived(desktop() && app.backend === 'ready' && chosen.length > 0 && activeChecks.length > 0 && !live && !run.starting);
  const sevCounts = $derived.by(() => {
    const c: Partial<Record<Severity, number>> = {};
    for (const f of audit?.findings ?? []) {
      const s = f.severity ?? 'info';
      c[s] = (c[s] ?? 0) + 1;
    }
    return c;
  });
  const findingShown = $derived(
    tab === 'results' ? (audit?.findings.find((f) => f.id === selectedFinding) ?? null) : (scanFindings?.find((f) => f.id === selectedFinding) ?? null),
  );
  const verifiedDomains = $derived(assets.filter((a) => a.kind === 'domain' && a.verified).map((a) => a.display));

  async function load() {
    if (!desktop()) return;
    loading = true;
    const list = await guarded(() => api.listAssets(), 'Активы');
    loading = false;
    if (!list) return;
    assets = list;
    ui.auditAssets = ui.auditAssets.filter((id) => list.some((a) => a.id === id));
  }

  async function pickFolder() {
    const p = await guarded(() => api.pickFolder(), 'Выбор каталога');
    if (p) newValue = p;
  }

  async function add() {
    if (!newValue.trim() || !attested) return;
    adding = true;
    const a = await guarded(() => api.addAsset({ kind: newKind, value: newValue.trim(), attested }), 'Добавление актива');
    adding = false;
    if (!a) return;
    newValue = '';
    attested = false;
    await load();
    ui.auditAssets = [...ui.auditAssets, a.id];
    if (a.kind === 'domain') expanded = a.id;
    app.toast('ok', `Актив добавлен: ${a.display}`);
  }

  async function verify(a: Asset) {
    verifying = a.id;
    const res = await guarded(() => api.verifyAsset(a.id), 'Подтверждение домена');
    verifying = null;
    if (res) {
      app.toast('ok', `Владение доменом ${res.display} подтверждено`);
      expanded = null;
      await load();
    }
  }

  async function remove() {
    const a = removeTarget;
    removeOpen = false;
    if (!a) return;
    const ok = await guarded(() => api.removeAsset(a.id).then(() => true), 'Удаление актива');
    if (ok) {
      ui.auditAssets = ui.auditAssets.filter((id) => id !== a.id);
      await load();
    }
    removeTarget = null;
  }

  function toggleAsset(id: string) {
    ui.auditAssets = ui.auditAssets.includes(id) ? ui.auditAssets.filter((x) => x !== id) : [...ui.auditAssets, id];
  }

  function toggleCheck(id: AuditCheck) {
    ui.auditChecks = ui.auditChecks.includes(id) ? ui.auditChecks.filter((x) => x !== id) : [...ui.auditChecks, id];
  }

  async function startAudit() {
    if (!canAudit) return;
    tab = 'results';
    selectedFinding = null;
    await run.startAudit(
      chosen.map((a) => a.id),
      activeChecks,
    );
  }

  async function checkPassword() {
    if (!password) return;
    pwBusy = true;
    pwResult = await guarded(() => api.checkPassword(password), 'Проверка пароля');
    pwBusy = false;
    password = '';
  }

  async function scanText() {
    if (!scanTextValue.trim()) return;
    scanBusy = true;
    scanFindings = await guarded(() => api.scanText(scanTextValue, 'Текст публикации'), 'Проверка текста');
    scanBusy = false;
    selectedFinding = null;
  }

  async function scanUrl() {
    if (!scanUrlValue.trim()) return;
    scanBusy = true;
    scanFindings = await guarded(() => api.scanUrl(scanUrlValue.trim()), 'Проверка страницы');
    scanBusy = false;
    selectedFinding = null;
  }

  async function exportAudit(format: 'json' | 'csv' | 'md') {
    if (!audit) return;
    const p = await guarded(() => api.exportInvestigation(audit.id, format), 'Экспорт');
    if (p) app.toast('ok', `Сохранено: ${p}`, 6000);
  }

  onMount(load);
</script>

<div class="section-root intel enter">
  <div class="cols">
    <!-- assets -->
    <Panel title="Ваши активы" subtitle="Аудит проводится только для ваших адресов, доменов и репозиториев" class="assets">
      <div class="col">
        <Segmented
          size="sm"
          bind:value={newKind}
          options={(Object.keys(KIND_META) as AssetKind[]).map((k) => ({ value: k, label: KIND_META[k].label }))}
          onchange={() => {
            newValue = '';
            attested = false;
          }}
        />
        <div class="row">
          <input class="input" placeholder={KIND_META[newKind].placeholder} bind:value={newValue} onkeydown={(e) => e.key === 'Enter' && add()} />
          {#if newKind === 'repo_local'}
            <button class="btn sm icon" title="Выбрать каталог" onclick={pickFolder}><Icon name="folder" size={14} /></button>
          {/if}
        </div>
        <label class="attest">
          <input type="checkbox" bind:checked={attested} />
          <span>{KIND_META[newKind].attest}</span>
        </label>
        <button class="btn sm" onclick={add} disabled={!desktop() || adding || !newValue.trim() || !attested}>
          {#if adding}<Bits kind="spinner" />{:else}<Icon name="plus" size={14} />{/if}Добавить актив
        </button>
        {#if newKind === 'email'}
          <p class="help">Адрес хранится в хранилище учётных данных Windows; в базе — только маска и хеш.</p>
        {:else if newKind === 'domain'}
          <p class="help">Пассивные проверки доступны сразу. Активные (служебные файлы, висячие CNAME, проверка страниц) — после подтверждения владения через DNS TXT.</p>
        {/if}

        <div class="hairline"></div>

        {#if loading && !assets.length}
          <div class="empty small"><Bits kind="spinner" /></div>
        {:else if !assets.length}
          <div class="empty small">Добавьте свой e-mail, домен или репозиторий, чтобы проверить их цифровую экспозицию.</div>
        {/if}
        <ul class="alist">
          {#each assets as a (a.id)}
            {@const on = ui.auditAssets.includes(a.id)}
            <li class:on>
              <div class="arow">
                <input type="checkbox" checked={on} onchange={() => toggleAsset(a.id)} aria-label="Включить в аудит" />
                <Icon name={KIND_META[a.kind].icon} size={15} />
                <span class="ad" title={a.display}>{a.display}</span>
                <span class="spacer"></span>
                {#if a.kind === 'domain'}
                  {#if a.verified}
                    <span class="badge ok" title="Подтверждено {fmtDateTime(a.verifiedAt)}"><Icon name="check" size={11} />DNS</span>
                  {:else}
                    <button class="badge warn" onclick={() => (expanded = expanded === a.id ? null : a.id)}>не подтверждён</button>
                  {/if}
                {/if}
                <button class="btn ghost sm icon" title="Удалить" onclick={() => ((removeTarget = a), (removeOpen = true))}><Icon name="trash" size={13} /></button>
              </div>
              {#if a.kind === 'domain' && !a.verified && expanded === a.id && a.verificationToken}
                {@const record = `sword-osint-verification=${a.verificationToken}`}
                <div class="verify">
                  <p>Добавьте TXT-запись в DNS домена <b>{a.display}</b> (на сам домен или на <span class="mono">_sword-osint.{a.display}</span>):</p>
                  <button class="record mono" onclick={() => copyText(record, 'Запись скопирована')} title="Копировать">{record}<Icon name="copy" size={12} /></button>
                  <button class="btn sm" onclick={() => verify(a)} disabled={verifying === a.id}>
                    {#if verifying === a.id}<Bits kind="spinner" />{:else}<Icon name="check" size={13} />{/if}Проверить запись
                  </button>
                </div>
              {/if}
            </li>
          {/each}
        </ul>
      </div>
    </Panel>

    <!-- checks + run -->
    <Panel title="Проверки" subtitle={chosen.length ? `${plural(chosen.length, 'актив', 'актива', 'активов')} · ${plural(activeChecks.length, 'проверка', 'проверки', 'проверок')}` : 'Отметьте активы слева'} class="checks">
      {#snippet actions()}
        {#if live}
          <button class="btn sm danger" onclick={() => run.cancel('audit')}><Icon name="stop" size={13} />Остановить</button>
        {:else}
          <button class="btn sm primary" onclick={startAudit} disabled={!canAudit}>
            {#if run.starting}<Bits kind="spinner" />{:else}<Icon name="intelligence" size={14} />{/if}Запустить аудит
          </button>
        {/if}
      {/snippet}
      <div class="col">
        <ul class="clist">
          {#each AUDIT_CHECKS as c (c.id)}
            {@const usable = chosenKinds.has(c.target)}
            {@const on = ui.auditChecks.includes(c.id)}
            {@const needsVerified = !!c.verified && chosen.some((a) => a.kind === 'domain' && !a.verified)}
            <li class:dim={!usable}>
              <label>
                <input type="checkbox" checked={on} disabled={!usable || live} onchange={() => toggleCheck(c.id)} />
                <span class="cl">
                  <span class="cn">{c.label}</span>
                  <span class="ch">{c.hint}</span>
                  {#if usable && on && needsVerified}
                    <span class="cw">Будет выполнена только для доменов с подтверждённым владением.</span>
                  {/if}
                </span>
                <span class="ct">{KIND_META[c.target].label}</span>
              </label>
            </li>
          {/each}
        </ul>

        {#if audit}
          <div class="hairline"></div>
          <div class="row">
            <span class="eyebrow">Ход аудита</span>
            <span class="spacer"></span>
            <span class="faint small">{progress.done} из {progress.total}{audit.record ? ` · ${fmtDateTime(audit.record.createdAt)}` : ''}</span>
          </div>
          <div class="progress"><span style:width="{Math.round(progress.ratio * 100)}%"></span></div>
          <RunTimeline run={audit} />
        {/if}
      </div>
    </Panel>

    <!-- results & tools -->
    <Panel title="Экспозиция" class="results" pad={false}>
      {#snippet actions()}
        <Segmented
          size="sm"
          bind:value={tab}
          onchange={() => (selectedFinding = null)}
          options={[
            { value: 'results', label: 'Результаты' },
            { value: 'password', label: 'Пароль' },
            { value: 'publication', label: 'Публикация' },
          ]}
        />
      {/snippet}
      {#if tab === 'results'}
        {#if audit}
          <div class="sevbar">
            {#each SEVERITIES as s (s)}
              <span class="sev" title={SEVERITY_META[s].label}><i style:background={SEVERITY_META[s].color}></i>{SEVERITY_META[s].label}<b class="num">{fmtNum(sevCounts[s] ?? 0)}</b></span>
            {/each}
          </div>
          <div class="list scroll">
            <FindingList
              findings={audit.findings}
              groupBy="severity"
              selected={selectedFinding}
              onselect={(f) => (selectedFinding = selectedFinding === f.id ? null : f.id)}
              empty={live ? 'Проверки выполняются…' : 'Проверки не вернули результатов.'}
            />
          </div>
          {#if !live && audit.record}
            <div class="foot">
              <button class="btn sm" onclick={() => app.navigate('report', audit.id)}><Icon name="report" size={14} />Отчёт PDF</button>
              <button class="btn sm ghost" onclick={() => exportAudit('json')}>JSON</button>
              <button class="btn sm ghost" onclick={() => exportAudit('csv')}>CSV</button>
              <button class="btn sm ghost" onclick={() => exportAudit('md')}>Markdown</button>
            </div>
          {/if}
        {:else}
          <div class="empty small">Выберите активы и проверки, затем запустите аудит. Результаты сортируются по критичности, у каждого — рекомендация по исправлению.</div>
        {/if}
      {:else if tab === 'password'}
        <div class="tool">
          <p class="help">
            Проверка по базе Pwned Passwords (Have I Been Pwned) по модели k-анонимности: на сервер уходят только первые 5 символов
            SHA-1-хеша, ответ дополняется фиктивными записями. Пароль не сохраняется и не передаётся.
          </p>
          <div class="row">
            <input class="input" type="password" autocomplete="off" placeholder="Пароль для проверки" bind:value={password} onkeydown={(e) => e.key === 'Enter' && checkPassword()} />
            <button class="btn sm" onclick={checkPassword} disabled={!desktop() || !password || pwBusy}>{#if pwBusy}<Bits kind="spinner" />{/if}Проверить</button>
          </div>
          {#if pwResult}
            <div class="verdict" class:bad={pwResult.exposed}>
              <Icon name={pwResult.exposed ? 'alert' : 'check'} size={18} />
              <div>
                {#if pwResult.exposed}
                  <b>Пароль встречается в утечках: {fmtNum(pwResult.count)} раз.</b>
                  <span>Не используйте его. Смените пароль везде, где он применялся, и включите двухфакторную аутентификацию.</span>
                {:else}
                  <b>В известных утечках не найден.</b>
                  <span>Это не гарантия стойкости: используйте уникальные длинные пароли и менеджер паролей.</span>
                {/if}
                <span class="faint tiny">Сравнено с {fmtNum(pwResult.bucketSize)} хешами из диапазона.</span>
              </div>
            </div>
          {/if}
        </div>
      {:else}
        <div class="tool">
          <p class="help">
            Поиск персональных данных и секретов в тексте перед публикацией: e-mail, телефоны, номера карт (проверка Луна), ИНН и
            СНИЛС (контрольные суммы), IBAN, паспортные данные, даты рождения, координаты, ключи API. Найденные значения маскируются.
          </p>
          <textarea class="textarea" rows="5" placeholder="Вставьте текст пресс-релиза, поста или документа" bind:value={scanTextValue}></textarea>
          <button class="btn sm" onclick={scanText} disabled={!desktop() || scanBusy || !scanTextValue.trim()}>Проверить текст</button>
          <div class="hairline"></div>
          <p class="help">
            Проверка опубликованной страницы — только на ваших доменах с подтверждённым владением{verifiedDomains.length ? `: ${verifiedDomains.join(', ')}` : ' (пока нет подтверждённых доменов)'}.
          </p>
          <div class="row">
            <input class="input" placeholder="https://company.com/about" bind:value={scanUrlValue} onkeydown={(e) => e.key === 'Enter' && scanUrl()} />
            <button class="btn sm" onclick={scanUrl} disabled={!desktop() || scanBusy || !scanUrlValue.trim() || !verifiedDomains.length}>Проверить</button>
          </div>
          {#if scanBusy}<Bits kind="spinner" />{/if}
          {#if scanFindings}
            <FindingList findings={scanFindings} groupBy="severity" selected={selectedFinding} onselect={(f) => (selectedFinding = selectedFinding === f.id ? null : f.id)} />
          {/if}
        </div>
      {/if}
    </Panel>

    {#if findingShown}
      <div class="drawer-float">
        <FindingDrawer finding={findingShown} onclose={() => (selectedFinding = null)} />
      </div>
    {/if}
  </div>
</div>

<Modal bind:open={removeOpen} title="Удалить актив" onclose={() => (removeTarget = null)}>
  <p class="muted">
    Удалить «{removeTarget?.display}»? Сохранённые результаты аудитов останутся в истории; адрес e-mail будет удалён из
    хранилища учётных данных Windows.
  </p>
  {#snippet footer()}
    <button class="btn sm ghost" onclick={() => (removeOpen = false)}>Отмена</button>
    <button class="btn sm danger" onclick={remove}><Icon name="trash" size={13} />Удалить</button>
  {/snippet}
</Modal>

<style>
  .cols {
    flex: 1;
    min-height: 0;
    display: grid;
    grid-template-columns: 330px minmax(360px, 1fr) 430px;
    gap: 14px;
    position: relative;
  }
  .attest {
    display: flex;
    gap: 9px;
    align-items: flex-start;
    font-size: 11.5px;
    color: var(--fg-2);
    line-height: 1.45;
    cursor: pointer;
  }
  .attest input,
  .arow input,
  .clist input {
    accent-color: #e9eef6;
    margin-top: 2px;
  }
  .alist {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
  .alist li {
    border-radius: 10px;
    border: 1px solid var(--line);
    background: rgba(255, 255, 255, 0.015);
    transition: border-color 0.2s, background 0.2s;
  }
  .alist li.on {
    border-color: var(--line-strong);
    background: rgba(255, 255, 255, 0.04);
  }
  .arow {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 6px 6px 6px 10px;
    color: var(--fg-2);
  }
  .ad {
    color: var(--fg);
    font-size: 12.5px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
  }
  .badge.ok {
    color: var(--ok);
    border-color: rgba(143, 211, 176, 0.35);
  }
  .badge.warn {
    color: var(--warn);
    border-color: rgba(232, 212, 139, 0.35);
    cursor: pointer;
    background: none;
  }
  .verify {
    padding: 4px 12px 12px;
    display: flex;
    flex-direction: column;
    gap: 8px;
    font-size: 11.5px;
    color: var(--fg-2);
  }
  .verify p {
    margin: 0;
    line-height: 1.5;
  }
  .record {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
    padding: 7px 10px;
    border-radius: 8px;
    border: 1px dashed var(--line-strong);
    background: rgba(0, 0, 0, 0.35);
    color: #fff;
    font-size: 11px;
    word-break: break-all;
    text-align: left;
    cursor: pointer;
  }
  .clist {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .clist label {
    display: grid;
    grid-template-columns: 16px 1fr auto;
    gap: 10px;
    padding: 8px 6px;
    border-radius: 8px;
    cursor: pointer;
  }
  .clist label:hover {
    background: rgba(255, 255, 255, 0.03);
  }
  .clist li.dim {
    opacity: 0.42;
  }
  .cl {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .cn {
    font-size: 12.5px;
    color: var(--fg);
  }
  .ch {
    font-size: 11px;
    color: var(--fg-3);
    line-height: 1.4;
  }
  .cw {
    font-size: 11px;
    color: var(--warn);
  }
  .ct {
    font-size: 10.5px;
    color: var(--fg-3);
    white-space: nowrap;
  }
  .progress {
    height: 2px;
    border-radius: 2px;
    background: rgba(255, 255, 255, 0.06);
    overflow: hidden;
  }
  .progress span {
    display: block;
    height: 100%;
    background: #fff;
    box-shadow: 0 0 10px #fff;
    transition: width 0.6s var(--ease-out);
  }
  .sevbar {
    display: flex;
    flex-wrap: wrap;
    gap: 6px 12px;
    padding: 10px 14px;
    border-bottom: 1px solid var(--line);
  }
  .sev {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    color: var(--fg-3);
  }
  .sev i {
    width: 7px;
    height: 7px;
    border-radius: 50%;
  }
  .sev b {
    color: var(--fg);
    font-weight: 500;
  }
  .list {
    flex: 1;
    padding: 8px;
  }
  .foot {
    display: flex;
    gap: 6px;
    padding: 10px 12px;
    border-top: 1px solid var(--line);
  }
  .tool {
    padding: 14px 16px;
    display: flex;
    flex-direction: column;
    gap: 10px;
    overflow: auto;
  }
  .help {
    margin: 0;
  }
  .verdict {
    display: flex;
    gap: 12px;
    padding: 12px;
    border-radius: 10px;
    border: 1px solid rgba(143, 211, 176, 0.3);
    color: var(--ok);
  }
  .verdict.bad {
    border-color: rgba(240, 138, 138, 0.35);
    color: var(--err);
  }
  .verdict div {
    display: flex;
    flex-direction: column;
    gap: 4px;
    color: var(--fg-2);
    font-size: 12px;
  }
  .verdict b {
    color: #fff;
    font-weight: 500;
  }
  .drawer-float {
    position: absolute;
    right: 444px;
    top: 0;
    bottom: 0;
    width: 380px;
    display: flex;
    flex-direction: column;
    z-index: 4;
  }
</style>
