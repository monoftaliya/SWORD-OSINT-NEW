//! REPORT STUDIO: report options (drafts), PDF generation and report files.

use std::time::Instant;

use sword_core::util::now;
use sword_db::{MetricSample, ReportRecord};
use sword_report::{ReportData, ReportOptions};
use tauri::{AppHandle, State};
use tauri_plugin_opener::OpenerExt;

use super::{sanitize_filename, save_dialog};
use crate::error::{ApiError, ApiResult};
use crate::state::{blocking, AppState};

fn defaults(state: &AppState) -> ReportOptions {
    let s = state.settings();
    ReportOptions {
        theme: s.report.theme.clone(),
        paper: s.report.paper.clone(),
        author: s.report.author.clone(),
        organization: s.report.organization.clone(),
        classification: s.report.classification.clone(),
        ..Default::default()
    }
}

#[tauri::command]
pub async fn get_report_options(state: State<'_, AppState>, investigation_id: String) -> ApiResult<ReportOptions> {
    let db = state.db.clone();
    let draft = blocking(move || db.load_report_draft(&investigation_id)).await?;
    Ok(draft.and_then(|j| serde_json::from_str::<ReportOptions>(&j).ok()).unwrap_or_else(|| defaults(&state)))
}

#[tauri::command]
pub async fn save_report_options(state: State<'_, AppState>, investigation_id: String, options: ReportOptions) -> ApiResult<()> {
    let json = serde_json::to_string(&options).map_err(|e| ApiError::internal(e.to_string()))?;
    let db = state.db.clone();
    blocking(move || db.save_report_draft(&investigation_id, &json)).await
}

#[tauri::command]
pub async fn generate_report(state: State<'_, AppState>, investigation_id: String, options: ReportOptions) -> ApiResult<ReportRecord> {
    if options.sections.is_empty() {
        return Err(ApiError::invalid("выберите хотя бы один раздел отчёта"));
    }
    let db = state.db.clone();
    let id = investigation_id.clone();
    let (detail, graph) = blocking(move || Ok((db.get_detail(&id)?, db.graph_of(&id)?))).await?;
    if detail.record.status == sword_core::InvestigationStatus::Running {
        return Err(ApiError::invalid("исследование ещё выполняется"));
    }
    let mut adapters = state.registry().infos();
    adapters.extend(sword_audit::AuditCheck::ALL.iter().map(|c| c.module_info()));
    let report_id = sword_report::new_report_id();
    let data = ReportData {
        report_id: report_id.clone(),
        generated_at: now(),
        record: detail.record.clone(),
        runs: detail.runs,
        adapters,
        findings: detail.findings,
        sources: detail.sources,
        graph,
    };
    let file_name = format!("{report_id} {}.pdf", sanitize_filename(&detail.record.query));
    let path = state.paths.reports_dir.join(&file_name);
    let opts = options.clone();
    let started = Instant::now();
    let rendered = blocking(move || sword_report::render(&data, &opts)).await?;
    let elapsed = started.elapsed().as_millis() as u32;
    std::fs::write(&path, &rendered.bytes)?;
    if !rendered.warnings.is_empty() {
        tracing::debug!(warnings = ?rendered.warnings, "pdf warnings");
    }
    let record = ReportRecord {
        id: report_id,
        investigation_id: Some(investigation_id.clone()),
        title: options.title.clone().filter(|t| !t.trim().is_empty()).unwrap_or_else(|| detail.record.query.clone()),
        created_at: now(),
        path: path.display().to_string(),
        pages: rendered.pages,
        bytes: rendered.bytes.len() as u64,
        duration_ms: elapsed,
        exists: true,
    };
    let db = state.db.clone();
    let rec = record.clone();
    let json = serde_json::to_string(&options).unwrap_or_default();
    blocking(move || {
        db.insert_report(&rec, &json)?;
        db.save_report_draft(&investigation_id, &json)?;
        db.insert_metrics(&[MetricSample { name: "report_ms".into(), value: elapsed as f64, labels: None }])
    })
    .await?;
    Ok(record)
}

#[tauri::command]
pub async fn list_reports(state: State<'_, AppState>, investigation_id: Option<String>) -> ApiResult<Vec<ReportRecord>> {
    let db = state.db.clone();
    blocking(move || db.list_reports(investigation_id.as_deref())).await
}

async fn report(state: &AppState, id: &str) -> ApiResult<ReportRecord> {
    let db = state.db.clone();
    let id = id.to_string();
    blocking(move || db.get_report(&id)).await
}

#[tauri::command]
pub async fn open_report(app: AppHandle, state: State<'_, AppState>, id: String) -> ApiResult<()> {
    let r = report(&state, &id).await?;
    if !r.exists {
        return Err(ApiError::not_found("файл отчёта не найден"));
    }
    app.opener().open_path(r.path, None::<&str>).map_err(|e| ApiError::internal(e.to_string()))
}

#[tauri::command]
pub async fn reveal_report(app: AppHandle, state: State<'_, AppState>, id: String) -> ApiResult<()> {
    let r = report(&state, &id).await?;
    app.opener().reveal_item_in_dir(r.path).map_err(|e| ApiError::internal(e.to_string()))
}

#[tauri::command]
pub async fn save_report_as(app: AppHandle, state: State<'_, AppState>, id: String) -> ApiResult<Option<String>> {
    let r = report(&state, &id).await?;
    let name = std::path::Path::new(&r.path).file_name().map(|n| n.to_string_lossy().to_string()).unwrap_or_else(|| format!("{}.pdf", r.id));
    let Some(target) = save_dialog(&app, "Сохранить отчёт", &name, "PDF", &["pdf"]).await? else { return Ok(None) };
    std::fs::copy(&r.path, &target)?;
    let p = target.display().to_string();
    let db = state.db.clone();
    let p2 = p.clone();
    blocking(move || db.record_export("report", &p2)).await?;
    Ok(Some(p))
}

#[tauri::command]
pub async fn delete_report(state: State<'_, AppState>, id: String) -> ApiResult<()> {
    let db = state.db.clone();
    let path = blocking(move || db.delete_report(&id)).await?;
    if let Some(p) = path {
        let p = std::path::PathBuf::from(p);
        if p.starts_with(&state.paths.reports_dir) && p.exists() {
            std::fs::remove_file(p)?;
        }
    }
    Ok(())
}
