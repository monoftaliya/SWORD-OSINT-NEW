//! GitHub — public organisations and projects (REST API v3).
//!
//! Only accounts of type `Organization` are described as organisations; repositories owned
//! by personal accounts appear as projects without profiling their owners.

use async_trait::async_trait;
use serde_json::Value;
use sword_core::util::parse_date;
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordResult,
};

use super::{arr, cred, fmt_int, info, num, s, sp};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::output::{FindingExt, OutputBuilder};

const API: &str = "https://api.github.com";
pub const TOKEN: &str = "github.token";

pub struct GitHub {
    info: AdapterInfo,
}

impl Default for GitHub {
    fn default() -> Self {
        Self::new()
    }
}

impl GitHub {
    pub fn new() -> Self {
        GitHub {
            info: info(
                "github",
                "GitHub",
                "GitHub, Inc.",
                "Публичные организации и проекты GitHub: репозитории по запросу или домену, профили организаций и заявленные ими сайты.",
                "GitHub REST API: /search/repositories, /search/users (type:org), /orgs/{org}. Без токена — 10 поисковых запросов в минуту, \
                 с токеном — 30. Профили личных аккаунтов не анализируются.",
                &[Category::OrgIntel, Category::DigitalFootprint],
                &[InputKind::Text, InputKind::Domain, InputKind::Url],
                vec![cred(
                    TOKEN,
                    "Токен GitHub (необязательно)",
                    false,
                    "Fine-grained personal access token без дополнительных прав (Public repositories, read-only) повышает лимиты. \
                     Для проверки secret scanning собственных репозиториев нужен доступ «Secret scanning alerts: read».",
                    Some("https://github.com/settings/personal-access-tokens/new"),
                    Some("github_pat_…"),
                )],
                vec![],
                25,
                "https://github.com/",
                Some("https://docs.github.com/en/rest"),
                true,
            ),
        }
    }

    fn request(&self, ctx: &ConnectorContext, url: &str) -> reqwest::RequestBuilder {
        let mut r = ctx.get(url).header("accept", "application/vnd.github+json").header("x-github-api-version", "2022-11-28");
        if let Some(t) = ctx.secret(TOKEN) {
            r = r.bearer_auth(t);
        }
        r
    }

    /// Search endpoints have their own (stricter) budget.
    async fn search_api(&self, ctx: &ConnectorContext, url: &str, params: &[(&str, &str)]) -> SwordResult<Value> {
        let budget = if ctx.secret(TOKEN).is_some() { 28 } else { 9 };
        let resp = ctx.send_with("github-search", budget, self.request(ctx, url).query(params)).await?;
        crate::http::read_json(resp).await
    }
}

#[async_trait]
impl SourceAdapter for GitHub {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let v: Value = ctx.json(&self.info, self.request(ctx, &format!("{API}/rate_limit"))).await?;
        let core = v.pointer("/resources/core/limit").and_then(Value::as_i64).unwrap_or(0);
        let search = v.pointer("/resources/search/limit").and_then(Value::as_i64).unwrap_or(0);
        let mut perms = vec![PermissionCheck::granted("REST API", format!("Лимит: {core} запросов/ч, поиск: {search} в минуту"))];
        if ctx.secret(TOKEN).is_some() && core <= 60 {
            perms.push(PermissionCheck::denied("Токен", "Токен задан, но GitHub применил анонимный лимит — проверьте токен"));
        }
        Ok(perms)
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let mut b = OutputBuilder::new(&self.info);
        let q = input.registrable_domain.clone().unwrap_or_else(|| input.text.clone());
        let per_page = ctx.max_results.clamp(5, 30).to_string();

        // Organisations
        let org_query = format!("{q} type:org");
        let users = self
            .search_api(ctx, &format!("{API}/search/users"), &[("q", org_query.as_str()), ("per_page", "5")])
            .await?;
        let logins: Vec<String> = arr(&users, "/items").iter().filter_map(|u| s(u, "login")).take(3).collect();
        for login in &logins {
            let org: Value = match ctx.json(&self.info, self.request(ctx, &format!("{API}/orgs/{login}"))).await {
                Ok(v) => v,
                Err(e) => {
                    b.note(format!("GitHub /orgs/{login}: {e}"));
                    continue;
                }
            };
            let html = s(&org, "html_url").unwrap_or_else(|| format!("https://github.com/{login}"));
            let name = s(&org, "name").unwrap_or_else(|| login.clone());
            let okey = keys::org("github", login);
            b.entity(&okey, EntityKind::Organization, &name);
            for (label, value) in [
                ("GitHub", Some(html.clone())),
                ("Описание", s(&org, "description")),
                ("Местоположение (профиль)", s(&org, "location")),
                ("Публичных репозиториев", num(&org, "public_repos").map(fmt_int)),
                ("Создана", s(&org, "created_at").and_then(|d| parse_date(&d)).map(|d| sword_core::util::fmt_date(&d))),
                ("Домен подтверждён GitHub", org.get("is_verified").and_then(Value::as_bool).map(|v| if v { "да".to_string() } else { "нет".to_string() })),
            ] {
                if let Some(v) = value {
                    b.attr(&okey, label, &v, &html);
                }
            }
            if let Some(blog) = s(&org, "blog") {
                let blog = if blog.starts_with("http") { blog } else { format!("https://{blog}") };
                if let Some(host) = sword_core::util::host_of(&blog) {
                    let reg = sword_core::input::registrable(&host).unwrap_or(host);
                    let dkey = keys::domain(&reg);
                    b.entity(&dkey, EntityKind::Domain, &reg);
                    let verified = org.get("is_verified").and_then(Value::as_bool).unwrap_or(false);
                    b.relate(&okey, &dkey, "declares_website", if verified { 0.95 } else { 0.8 }, &html, Some(if verified {
                        "сайт в профиле; домен подтверждён GitHub"
                    } else {
                        "сайт указан в профиле организации"
                    }));
                }
            }
            b.finding(Category::OrgIntel, FindingKind::Organization, &format!("GitHub: {name}"), Some(&html))
                .snippet(&s(&org, "description").unwrap_or_default())
                .confidence(0.9)
                .attr("Репозиториев", num(&org, "public_repos").unwrap_or(0))
                .entity(&okey);
            b.source(&html, &format!("GitHub: {name}"));
        }

        // Repositories
        let repos = self
            .search_api(ctx, &format!("{API}/search/repositories"), &[("q", q.as_str()), ("sort", "stars"), ("order", "desc"), ("per_page", per_page.as_str())])
            .await?;
        for r in arr(&repos, "/items") {
            let Some(full) = s(r, "full_name") else { continue };
            let html = s(r, "html_url").unwrap_or_else(|| format!("https://github.com/{full}"));
            let pkey = keys::project("github", &full);
            b.entity(&pkey, EntityKind::Project, &full);
            for (label, value) in [
                ("Звёзды", num(r, "stargazers_count").map(fmt_int)),
                ("Язык", s(r, "language")),
                ("Лицензия", sp(r, "/license/spdx_id")),
                ("Последний push", s(r, "pushed_at").and_then(|d| parse_date(&d)).map(|d| sword_core::util::fmt_date(&d))),
            ] {
                if let Some(v) = value {
                    b.attr(&pkey, label, &v, &html);
                }
            }
            if sp(r, "/owner/type").as_deref() == Some("Organization") {
                if let Some(owner) = sp(r, "/owner/login") {
                    let okey = keys::org("github", &owner);
                    b.entity(&okey, EntityKind::Organization, &owner);
                    b.relate(&pkey, &okey, "maintained_by", 1.0, &html, Some("владелец репозитория — организация"));
                }
            }
            if let Some(home) = s(r, "homepage").filter(|h| h.starts_with("http")) {
                if let Some(host) = sword_core::util::host_of(&home) {
                    let reg = sword_core::input::registrable(&host).unwrap_or(host);
                    if reg != "github.com" && reg != "github.io" {
                        let dkey = keys::domain(&reg);
                        b.entity(&dkey, EntityKind::Domain, &reg);
                        b.relate(&pkey, &dkey, "declares_website", 0.8, &html, Some("homepage репозитория"));
                    }
                }
            }
            b.finding(Category::DigitalFootprint, FindingKind::Project, &full, Some(&html))
                .snippet(&s(r, "description").unwrap_or_default())
                .published(s(r, "created_at").and_then(|d| parse_date(&d)))
                .confidence(0.9)
                .attr("Звёзды", num(r, "stargazers_count").unwrap_or(0))
                .attr("Язык", s(r, "language").unwrap_or_default())
                .attr("Архивирован", if r.get("archived").and_then(Value::as_bool).unwrap_or(false) { "да" } else { "нет" })
                .entity(&pkey);
            b.source(&html, &full);
        }
        Ok(b.finish())
    }
}
