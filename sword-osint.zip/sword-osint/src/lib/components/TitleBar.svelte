<script lang="ts">
  import { onMount } from 'svelte';
  import { getCurrentWindow } from '@tauri-apps/api/window';
  import Icon from './Icon.svelte';
  import { desktop } from '../api/client';
  import { app, SECTIONS } from '../stores/app.svelte';
  import { SIMPLIFY_STEPS } from '../engine/quality';
  import { run, runProgress } from '../stores/run.svelte';

  let maximized = $state(false);
  const section = $derived(SECTIONS.find((s) => s.id === app.section));
  const live = $derived(run.discovery?.live || run.audit?.live);
  const progress = $derived(runProgress(run.discovery?.live ? run.discovery : run.audit));
  const showFps = $derived(app.settings?.graphics.showFps ?? false);
  const perfText = $derived.by(() => {
    const p = app.perf;
    if (!showFps) return 'графика упрощена';
    const k = `${Math.round(p.particles / 1000)}k`;
    return p.simplified >= 3 ? `статичный кадр · ${k}` : `${p.fps} FPS · ${k}`;
  });
  const perfTitle = $derived(
    app.perf.simplified > 0
      ? `Графика упрощена автоматически (${SIMPLIFY_STEPS.slice(1, app.perf.simplified + 1).join(', ')}): устройство не успевает отрисовывать сцену. Вернуть полное качество — Настройки → Графика.`
      : 'Частота кадров и число частиц',
  );

  onMount(() => {
    if (!desktop()) return;
    const w = getCurrentWindow();
    let unlisten: (() => void) | undefined;
    w.isMaximized().then((m) => (maximized = m)).catch(() => {});
    w.onResized(async () => {
      maximized = await w.isMaximized().catch(() => false);
    }).then((u) => (unlisten = u)).catch(() => {});
    return () => unlisten?.();
  });

  const win = () => (desktop() ? getCurrentWindow() : null);
  const minimize = () => win()?.minimize();
  const toggle = () => win()?.toggleMaximize();
  const close = () => win()?.close();
</script>

<header class="titlebar" data-tauri-drag-region>
  <div class="brand" data-tauri-drag-region>
    <span class="mark"><Icon name="sword" size={15} stroke={1.4} /></span>
    <span class="word" data-tauri-drag-region>SWORD</span><span class="word dim" data-tauri-drag-region>OSINT</span>
  </div>
  <div class="center" data-tauri-drag-region>
    <span class="eyebrow" data-tauri-drag-region>{section?.title}</span>
    {#if live}
      <span class="live" data-tauri-drag-region>
        <span class="dot"></span>
        анализ · {progress.done}/{progress.total}
      </span>
    {/if}
  </div>
  <div class="right">
    {#if showFps || app.perf.simplified > 0}
      <span class="perf mono" class:simplified={app.perf.simplified > 0} title={perfTitle}>{perfText}</span>
    {/if}
    <span class="badge" title={app.perf.gpu || 'Графический ускоритель'}>{app.perf.backend}</span>
    <span class="sep"></span>
    <button class="wbtn" onclick={minimize} aria-label="Свернуть"><Icon name="minimize" size={14} /></button>
    <button class="wbtn" onclick={toggle} aria-label="Развернуть"><Icon name={maximized ? 'restore' : 'maximize'} size={13} /></button>
    <button class="wbtn close" onclick={close} aria-label="Закрыть"><Icon name="close" size={14} /></button>
  </div>
</header>

<style>
  .titlebar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    height: var(--titlebar);
    display: flex;
    align-items: center;
    z-index: 50;
    background: linear-gradient(180deg, rgba(0, 0, 0, 0.72), rgba(0, 0, 0, 0.18));
    border-bottom: 1px solid rgba(255, 255, 255, 0.04);
    -webkit-app-region: drag;
  }
  .brand {
    display: flex;
    align-items: center;
    gap: 8px;
    width: 240px;
    padding-left: 22px;
    color: var(--fg);
  }
  .mark {
    color: #fff;
    filter: drop-shadow(0 0 6px rgba(220, 232, 248, 0.6));
  }
  .word {
    font-family: var(--font-display);
    font-size: 10.5px;
    letter-spacing: 0.34em;
    font-weight: 500;
  }
  .word.dim {
    font-weight: 300;
    color: var(--fg-3);
    margin-left: -2px;
  }
  .center {
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 16px;
    height: 100%;
  }
  .live {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    font-size: 11px;
    color: var(--fg-2);
  }
  .live .dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #fff;
    box-shadow: 0 0 10px #fff;
    animation: pulse 1.4s ease-in-out infinite;
  }
  .right {
    display: flex;
    align-items: center;
    gap: 8px;
    height: 100%;
    -webkit-app-region: no-drag;
  }
  .perf {
    font-size: 10.5px;
    color: var(--fg-3);
  }
  .perf.simplified {
    color: var(--warn);
  }
  .sep {
    width: 1px;
    height: 16px;
    background: var(--line);
    margin: 0 2px;
  }
  .wbtn {
    width: 46px;
    height: 100%;
    display: grid;
    place-items: center;
    border: none;
    background: transparent;
    color: var(--fg-2);
    cursor: pointer;
    transition: background 0.18s, color 0.18s;
  }
  .wbtn:hover {
    background: rgba(255, 255, 255, 0.07);
    color: #fff;
  }
  .wbtn.close:hover {
    background: rgba(232, 17, 35, 0.85);
    color: #fff;
  }
</style>
