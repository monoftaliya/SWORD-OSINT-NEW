//! Optional OpenSearch backend for full-text search over findings.
//!
//! SQLite FTS5 is the embedded default. Teams that already run an OpenSearch cluster can
//! point SWORD OSINT at it (SETTINGS → Поиск): findings are bulk-indexed after every
//! investigation and the knowledge-base search is served by OpenSearch.

use serde_json::{json, Value};
use sword_core::{Finding, SwordError, SwordResult};

pub struct OpenSearch {
    client: reqwest::Client,
    base: String,
    index: String,
    username: Option<String>,
    password: Option<String>,
}

impl OpenSearch {
    pub fn new(client: reqwest::Client, url: &str, index: &str, username: Option<String>, password: Option<String>) -> SwordResult<Self> {
        let base = url.trim().trim_end_matches('/').to_string();
        if !(base.starts_with("http://") || base.starts_with("https://")) {
            return Err(SwordError::InvalidInput("адрес OpenSearch должен начинаться с http:// или https://".into()));
        }
        let index = index.trim().to_lowercase();
        if index.is_empty() || index.contains(['/', ' ', '*', '?', '"', '<', '>', '|', ',', '#']) {
            return Err(SwordError::InvalidInput("недопустимое имя индекса OpenSearch".into()));
        }
        Ok(OpenSearch { client, base, index, username, password })
    }

    fn req(&self, method: reqwest::Method, path: &str) -> reqwest::RequestBuilder {
        let r = self.client.request(method, format!("{}{}", self.base, path));
        match &self.username {
            Some(u) => r.basic_auth(u, self.password.clone()),
            None => r,
        }
    }

    async fn send(&self, rb: reqwest::RequestBuilder) -> SwordResult<Value> {
        let resp = rb.send().await.map_err(|e| sword_connectors::http::map_reqwest_error(&e))?;
        sword_connectors::http::read_json(resp).await
    }

    /// Cluster name and version.
    pub async fn ping(&self) -> SwordResult<String> {
        let v = self.send(self.req(reqwest::Method::GET, "/")).await?;
        Ok(format!(
            "{} {}",
            v.pointer("/cluster_name").and_then(Value::as_str).unwrap_or("кластер"),
            v.pointer("/version/number").and_then(Value::as_str).unwrap_or("")
        ))
    }

    pub async fn ensure_index(&self) -> SwordResult<()> {
        let path = format!("/{}", self.index);
        let exists = self.req(reqwest::Method::HEAD, &path).send().await.map_err(|e| sword_connectors::http::map_reqwest_error(&e))?;
        if exists.status().is_success() {
            return Ok(());
        }
        let mapping = json!({
            "mappings": { "properties": {
                "investigationId": { "type": "keyword" },
                "investigationQuery": { "type": "text" },
                "adapterId": { "type": "keyword" },
                "category": { "type": "keyword" },
                "kind": { "type": "keyword" },
                "title": { "type": "text" },
                "snippet": { "type": "text" },
                "url": { "type": "keyword" },
                "retrievedAt": { "type": "date" }
            }}
        });
        self.send(self.req(reqwest::Method::PUT, &path).json(&mapping)).await?;
        Ok(())
    }

    /// Bulk-index findings of one investigation. Returns the number of indexed documents.
    pub async fn index_findings(&self, investigation_id: &str, query: &str, findings: &[Finding]) -> SwordResult<usize> {
        if findings.is_empty() {
            return Ok(0);
        }
        self.ensure_index().await?;
        let mut body = String::new();
        for f in findings {
            body.push_str(&json!({ "index": { "_index": self.index, "_id": f.id } }).to_string());
            body.push('\n');
            body.push_str(
                &json!({
                    "investigationId": investigation_id,
                    "investigationQuery": query,
                    "adapterId": f.adapter_id,
                    "category": f.category.as_str(),
                    "kind": f.kind.as_str(),
                    "title": f.title,
                    "snippet": f.snippet,
                    "url": f.url,
                    "retrievedAt": f.retrieved_at,
                })
                .to_string(),
            );
            body.push('\n');
        }
        let v = self
            .send(self.req(reqwest::Method::POST, "/_bulk").header("content-type", "application/x-ndjson").body(body))
            .await?;
        if v.get("errors").and_then(Value::as_bool) == Some(true) {
            let first = v
                .pointer("/items/0/index/error/reason")
                .and_then(Value::as_str)
                .unwrap_or("часть документов не проиндексирована");
            return Err(SwordError::Upstream(format!("OpenSearch bulk: {first}")));
        }
        Ok(findings.len())
    }

    /// Full-text search; returns finding ids ordered by relevance.
    pub async fn search(&self, text: &str, limit: usize) -> SwordResult<Vec<String>> {
        let q = json!({
            "size": limit.clamp(1, 500),
            "_source": false,
            "query": { "multi_match": { "query": text, "fields": ["title^3", "snippet", "investigationQuery", "url"] } }
        });
        let v = self.send(self.req(reqwest::Method::POST, &format!("/{}/_search", self.index)).json(&q)).await?;
        Ok(v.pointer("/hits/hits")
            .and_then(Value::as_array)
            .map(|hits| hits.iter().filter_map(|h| h.get("_id").and_then(Value::as_str).map(str::to_string)).collect())
            .unwrap_or_default())
    }

    /// Remove documents of deleted investigations.
    pub async fn delete_investigation(&self, investigation_id: &str) -> SwordResult<()> {
        let q = json!({ "query": { "term": { "investigationId": investigation_id } } });
        self.send(self.req(reqwest::Method::POST, &format!("/{}/_delete_by_query", self.index)).json(&q)).await?;
        Ok(())
    }
}
