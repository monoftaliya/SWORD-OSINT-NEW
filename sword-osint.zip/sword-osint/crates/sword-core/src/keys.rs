//! Stable entity keys.
//!
//! The same real-world object must get the same key no matter which adapter reports it,
//! so that graphs from different sources and different investigations merge cleanly.

use crate::model::EntityKind;
use crate::util::canonical_url;

pub fn domain(host: &str) -> String {
    format!("domain:{}", host.trim().trim_end_matches('.').to_lowercase())
}

/// Website / public profile key: scheme-less host + path, lower-cased host.
pub fn site(url_or_host: &str) -> String {
    let raw = url_or_host.trim();
    let with_scheme = if raw.contains("://") { raw.to_string() } else { format!("https://{raw}") };
    let canon = canonical_url(&with_scheme);
    let without_scheme = canon.split_once("://").map(|(_, rest)| rest.to_string()).unwrap_or(canon);
    format!("site:{}", without_scheme.trim_end_matches('/'))
}

/// Organization key within a namespace: `org:lei:…`, `org:wikidata:Q…`, `org:github:login`,
/// `org:name:normalized name` (registry-provided names only).
pub fn org(namespace: &str, id: &str) -> String {
    let id = if namespace == "name" { normalize_name(id) } else { id.trim().to_string() };
    format!("org:{namespace}:{id}")
}

pub fn project(namespace: &str, id: &str) -> String {
    format!("project:{namespace}:{}", id.trim().to_lowercase())
}

pub fn document(url: &str) -> String {
    format!("doc:{}", canonical_url(url))
}

pub fn publication(namespace: &str, id: &str) -> String {
    format!("pub:{namespace}:{}", id.trim())
}

pub fn source(adapter_id: &str) -> String {
    format!("source:{adapter_id}")
}

/// Kind implied by a key prefix (used when a relation references an entity that was not
/// described explicitly).
pub fn kind_of(key: &str) -> Option<EntityKind> {
    let prefix = key.split(':').next()?;
    Some(match prefix {
        "domain" => EntityKind::Domain,
        "org" => EntityKind::Organization,
        "site" => EntityKind::Website,
        "project" => EntityKind::Project,
        "doc" => EntityKind::Document,
        "pub" => EntityKind::Publication,
        "source" => EntityKind::Source,
        _ => return None,
    })
}

/// Fallback label from a key: the part after the last namespace separator.
pub fn label_of(key: &str) -> String {
    match key.split_once(':') {
        Some((prefix, rest)) if prefix == "org" || prefix == "project" || prefix == "pub" => {
            rest.split_once(':').map(|(_, r)| r.to_string()).unwrap_or_else(|| rest.to_string())
        }
        Some((_, rest)) => rest.to_string(),
        None => key.to_string(),
    }
}

/// Normalise organisation names: lower case, collapse whitespace, strip quotes and
/// common legal-form noise characters.
pub fn normalize_name(name: &str) -> String {
    let cleaned: String = name
        .chars()
        .map(|c| if c.is_alphanumeric() || c.is_whitespace() || c == '&' || c == '-' { c } else { ' ' })
        .collect();
    cleaned.split_whitespace().collect::<Vec<_>>().join(" ").to_lowercase()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn keys_are_stable() {
        assert_eq!(domain("Example.COM."), "domain:example.com");
        assert_eq!(site("https://vk.com/Team/"), "site:vk.com/Team");
        assert_eq!(site("example.org"), "site:example.org");
        assert_eq!(org("name", "ООО «Ромашка»"), "org:name:ооо ромашка");
        assert_eq!(kind_of("org:lei:123"), Some(EntityKind::Organization));
        assert_eq!(label_of("org:github:tauri-apps"), "tauri-apps");
        assert_eq!(label_of("domain:example.com"), "example.com");
    }
}
