//! DATABASES → Storage: statistics, maintenance, backups, exports and OpenSearch.

use sword_db::DbStats;
use tauri::{AppHandle, State};

use super::save_dialog;
use crate::error::{ApiError, ApiResult};
use crate::state::{blocking, AppState};

#[tauri::command]
pub async fn db_stats(state: State<'_, AppState>) -> ApiResult<DbStats> {
    let db = state.db.clone();
    blocking(move || db.stats()).await
}

#[tauri::command]
pub async fn db_integrity_check(state: State<'_, AppState>) -> ApiResult<Vec<String>> {
    let db = state.db.clone();
    blocking(move || db.integrity_check()).await
}

#[tauri::command]
pub async fn db_vacuum(state: State<'_, AppState>) -> ApiResult<DbStats> {
    let db = state.db.clone();
    blocking(move || {
        db.vacuum()?;
        db.stats()
    })
    .await
}

#[tauri::command]
pub async fn db_backup(app: AppHandle, state: State<'_, AppState>) -> ApiResult<Option<String>> {
    let name = format!("sword-osint-backup-{}.db", chrono::Utc::now().format("%Y%m%d-%H%M"));
    let Some(path) = save_dialog(&app, "Резервная копия базы данных", &name, "SQLite", &["db"]).await? else { return Ok(None) };
    let db = state.db.clone();
    let target = path.clone();
    blocking(move || db.backup_to(&target)).await?;
    let p = path.display().to_string();
    let db = state.db.clone();
    let p2 = p.clone();
    blocking(move || db.record_export("backup", &p2)).await?;
    Ok(Some(p))
}

#[tauri::command]
pub async fn db_export_all(app: AppHandle, state: State<'_, AppState>) -> ApiResult<Option<String>> {
    let db = state.db.clone();
    let json = blocking(move || db.export_all_json()).await?;
    let name = format!("sword-osint-export-{}.json", chrono::Utc::now().format("%Y%m%d-%H%M"));
    let Some(path) = save_dialog(&app, "Экспорт всех исследований", &name, "JSON", &["json"]).await? else { return Ok(None) };
    std::fs::write(&path, json)?;
    let p = path.display().to_string();
    let db = state.db.clone();
    let p2 = p.clone();
    blocking(move || db.record_export("export", &p2)).await?;
    Ok(Some(p))
}

#[tauri::command]
pub async fn db_purge(state: State<'_, AppState>, older_than_days: u32) -> ApiResult<u32> {
    if older_than_days == 0 {
        return Err(ApiError::invalid("укажите срок в днях"));
    }
    let db = state.db.clone();
    blocking(move || db.purge_older_than(older_than_days)).await
}

#[tauri::command]
pub async fn db_clear_history(state: State<'_, AppState>) -> ApiResult<()> {
    if state.running.lock().map(|m| !m.is_empty()).unwrap_or(false) {
        return Err(ApiError::invalid("дождитесь завершения выполняющихся исследований"));
    }
    let db = state.db.clone();
    blocking(move || db.clear_history()).await
}

fn opensearch(state: &AppState) -> ApiResult<sword_search::opensearch::OpenSearch> {
    let s = state.settings();
    let url = s.search.opensearch_url.clone().ok_or_else(|| ApiError::invalid("адрес OpenSearch не задан"))?;
    let password = state.secrets.get("opensearch.password").ok().flatten();
    Ok(sword_search::opensearch::OpenSearch::new(state.http().client().clone(), &url, &s.search.opensearch_index, s.search.opensearch_username.clone(), password)?)
}

#[tauri::command]
pub async fn opensearch_test(state: State<'_, AppState>) -> ApiResult<String> {
    let os = opensearch(&state)?;
    let info = os.ping().await?;
    os.ensure_index().await?;
    Ok(info)
}

/// Re-index all stored findings into OpenSearch.
#[tauri::command]
pub async fn opensearch_reindex(state: State<'_, AppState>) -> ApiResult<u32> {
    let os = opensearch(&state)?;
    let db = state.db.clone();
    let page = blocking(move || db.list_history(&sword_db::HistoryQuery { limit: Some(500), ..Default::default() })).await?;
    let mut total = 0u32;
    for rec in page.items {
        let db = state.db.clone();
        let id = rec.id.clone();
        let findings = blocking(move || db.findings_of(&id)).await?;
        total += os.index_findings(&rec.id, &rec.query, &findings).await? as u32;
    }
    Ok(total)
}
