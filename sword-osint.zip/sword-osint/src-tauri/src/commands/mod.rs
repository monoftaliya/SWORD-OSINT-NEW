//! Tauri commands, grouped by application section.

pub mod analytics;
pub mod connectors;
pub mod databases;
pub mod discovery;
pub mod graph;
pub mod history;
pub mod intelligence;
pub mod reports;
pub mod system;

use std::path::PathBuf;

use tauri::AppHandle;
use tauri_plugin_dialog::DialogExt;

use crate::error::{ApiError, ApiResult};

/// Native «Save as…» dialog (runs on a blocking thread). Returns `None` when cancelled.
pub async fn save_dialog(app: &AppHandle, title: &str, default_name: &str, filter_name: &str, extensions: &[&str]) -> ApiResult<Option<PathBuf>> {
    let app = app.clone();
    let title = title.to_string();
    let name = sanitize_filename(default_name);
    let filter = filter_name.to_string();
    let exts: Vec<String> = extensions.iter().map(|s| s.to_string()).collect();
    tauri::async_runtime::spawn_blocking(move || {
        let ext_refs: Vec<&str> = exts.iter().map(String::as_str).collect();
        let mut builder = app.dialog().file().set_title(title).set_file_name(name).add_filter(filter, &ext_refs);
        if let Ok(docs) = tauri::Manager::path(&app).document_dir() {
            builder = builder.set_directory(docs);
        }
        builder.blocking_save_file()
    })
    .await
    .map_err(|e| ApiError::internal(e.to_string()))?
    .map(|p| p.into_path().map_err(|e| ApiError::internal(e.to_string())))
    .transpose()
}

/// Replace characters that are not allowed in Windows file names.
pub fn sanitize_filename(name: &str) -> String {
    let cleaned: String = name
        .chars()
        .map(|c| if matches!(c, '<' | '>' | ':' | '"' | '/' | '\\' | '|' | '?' | '*') || c.is_control() { '_' } else { c })
        .collect();
    let trimmed = cleaned.trim().trim_end_matches('.').to_string();
    let short: String = trimmed.chars().take(120).collect();
    if short.is_empty() {
        "sword-osint".into()
    } else {
        short
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn filenames() {
        assert_eq!(sanitize_filename("a/b:c?.pdf"), "a_b_c_.pdf");
        assert_eq!(sanitize_filename("  "), "sword-osint");
    }
}
