//! DNS-over-HTTPS (JSON API) resolver: Cloudflare or Google Public DNS.
//!
//! DoH works through corporate HTTP proxies, exposes the DNSSEC `AD` bit and gives every
//! answer a citable URL, which is why it is used instead of the system resolver.

use serde_json::Value;
use sword_core::{SwordError, SwordResult};

use crate::context::ConnectorContext;
use crate::http;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RecordType {
    A,
    Aaaa,
    Cname,
    Mx,
    Ns,
    Txt,
    Soa,
    Caa,
}

impl RecordType {
    pub fn as_str(&self) -> &'static str {
        match self {
            RecordType::A => "A",
            RecordType::Aaaa => "AAAA",
            RecordType::Cname => "CNAME",
            RecordType::Mx => "MX",
            RecordType::Ns => "NS",
            RecordType::Txt => "TXT",
            RecordType::Soa => "SOA",
            RecordType::Caa => "CAA",
        }
    }

    pub fn code(&self) -> u64 {
        match self {
            RecordType::A => 1,
            RecordType::Ns => 2,
            RecordType::Cname => 5,
            RecordType::Soa => 6,
            RecordType::Mx => 15,
            RecordType::Txt => 16,
            RecordType::Aaaa => 28,
            RecordType::Caa => 257,
        }
    }
}

#[derive(Debug, Clone)]
pub struct DnsAnswer {
    pub name: String,
    pub rtype: u64,
    pub ttl: u64,
    pub data: String,
}

#[derive(Debug, Clone)]
pub struct DnsResponse {
    /// DNS RCODE: 0 NOERROR, 2 SERVFAIL, 3 NXDOMAIN.
    pub status: u64,
    /// DNSSEC «authenticated data» bit.
    pub ad: bool,
    pub answers: Vec<DnsAnswer>,
    /// Citable URL of the query.
    pub query_url: String,
}

impl DnsResponse {
    /// Answers of the requested type only (CNAME chains are skipped).
    pub fn data_of(&self, rt: RecordType) -> Vec<String> {
        self.answers.iter().filter(|a| a.rtype == rt.code()).map(|a| a.data.clone()).collect()
    }

    pub fn is_nxdomain(&self) -> bool {
        self.status == 3
    }
}

const RATE_KEY: &str = "doh";
const RATE_PER_MINUTE: u32 = 600;

pub async fn query(ctx: &ConnectorContext, name: &str, rt: RecordType) -> SwordResult<DnsResponse> {
    let name = name.trim().trim_end_matches('.');
    let google = ctx.settings.network.doh_provider == "google";
    let base = if google { "https://dns.google/resolve" } else { "https://cloudflare-dns.com/dns-query" };
    let mut url = url::Url::parse(base).map_err(|e| SwordError::Internal(e.to_string()))?;
    url.query_pairs_mut().append_pair("name", name).append_pair("type", rt.as_str());
    let req = ctx.http.client().get(url.as_str()).header("accept", "application/dns-json");
    let resp = ctx.send_with(RATE_KEY, RATE_PER_MINUTE, req).await?;
    let v: Value = http::read_json(resp).await?;
    let status = v.get("Status").and_then(Value::as_u64).unwrap_or(2);
    let ad = v.get("AD").and_then(Value::as_bool).unwrap_or(false);
    let answers = v
        .get("Answer")
        .and_then(Value::as_array)
        .map(|arr| {
            arr.iter()
                .filter_map(|a| {
                    let rtype = a.get("type").and_then(Value::as_u64)?;
                    let raw = a.get("data").and_then(Value::as_str)?.to_string();
                    let data = normalize_data(rtype, &raw);
                    Some(DnsAnswer {
                        name: a.get("name").and_then(Value::as_str).unwrap_or_default().trim_end_matches('.').to_string(),
                        rtype,
                        ttl: a.get("TTL").and_then(Value::as_u64).unwrap_or(0),
                        data,
                    })
                })
                .collect()
        })
        .unwrap_or_default();
    Ok(DnsResponse { status, ad, answers, query_url: url.to_string() })
}

fn normalize_data(rtype: u64, raw: &str) -> String {
    match rtype {
        16 => txt_value(raw),
        257 if raw.trim_start().starts_with("\\#") => decode_generic_caa(raw).unwrap_or_else(|| raw.to_string()),
        2 | 5 | 12 => raw.trim_end_matches('.').to_lowercase(),
        15 => raw.trim_end_matches('.').to_lowercase(),
        _ => raw.to_string(),
    }
}

/// Join the quoted character-strings of a TXT record: `"v=spf1 " "include:x -all"`.
pub fn txt_value(raw: &str) -> String {
    let raw = raw.trim();
    if !raw.starts_with('"') {
        return raw.to_string();
    }
    let mut out = String::new();
    let mut in_q = false;
    let mut escaped = false;
    for c in raw.chars() {
        if escaped {
            out.push(c);
            escaped = false;
            continue;
        }
        match c {
            '\\' if in_q => escaped = true,
            '"' => in_q = !in_q,
            _ if in_q => out.push(c),
            _ => {}
        }
    }
    out
}

/// Decode RFC 3597 generic CAA data (`\# 19 00 05 69 73 73 75 65 …`) to `0 issue "ca"`.
fn decode_generic_caa(raw: &str) -> Option<String> {
    let bytes: Vec<u8> = raw
        .trim_start_matches("\\#")
        .split_whitespace()
        .skip(1)
        .flat_map(|chunk| {
            chunk.as_bytes().chunks(2).filter_map(|p| u8::from_str_radix(std::str::from_utf8(p).ok()?, 16).ok()).collect::<Vec<_>>()
        })
        .collect();
    if bytes.len() < 2 {
        return None;
    }
    let flags = bytes[0];
    let tag_len = bytes[1] as usize;
    if bytes.len() < 2 + tag_len {
        return None;
    }
    let tag = String::from_utf8_lossy(&bytes[2..2 + tag_len]);
    let value = String::from_utf8_lossy(&bytes[2 + tag_len..]);
    Some(format!("{flags} {tag} \"{value}\""))
}

/// Parse `10 mx.example.com` into (priority, host).
pub fn parse_mx(data: &str) -> Option<(u16, String)> {
    let mut it = data.split_whitespace();
    let pr = it.next()?.parse().ok()?;
    let host = it.next()?.trim_end_matches('.').to_lowercase();
    Some((pr, host))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_txt_and_caa() {
        assert_eq!(txt_value("\"v=spf1 \" \"include:_spf.google.com ~all\""), "v=spf1 include:_spf.google.com ~all");
        assert_eq!(txt_value("plain"), "plain");
        assert_eq!(
            decode_generic_caa("\\# 22 00 05 69 73 73 75 65 6c 65 74 73 65 6e 63 72 79 70 74 2e 6f 72 67").as_deref(),
            Some("0 issue \"letsencrypt.org\"")
        );
        assert_eq!(parse_mx("10 Mail.Example.com."), Some((10, "mail.example.com".into())));
    }
}
