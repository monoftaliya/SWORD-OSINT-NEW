import type {
  AdapterHealth,
  AuditCheck,
  Category,
  EntityKind,
  FindingKind,
  InputKind,
  InvestigationStatus,
  RunStatus,
  SectionId,
  Severity,
} from '../api/types';
import type { IconName } from '../components/icons';

export interface CategoryMeta {
  id: Category;
  title: string;
  label: string;
  short: string;
  icon: IconName;
  hint: string;
}

export const CATEGORIES: CategoryMeta[] = [
  { id: 'web_search', title: 'WEB SEARCH', label: 'Веб-поиск', short: 'WEB', icon: 'search', hint: 'Независимые поисковые индексы и энциклопедии' },
  { id: 'social_networks', title: 'SOCIAL NETWORKS', label: 'Социальные сети', short: 'SOCIAL', icon: 'nodes', hint: 'Публичные посты и обсуждения' },
  { id: 'vk', title: 'VK', label: 'ВКонтакте', short: 'VK', icon: 'vk', hint: 'Сообщества и публичные публикации через официальный VK API' },
  { id: 'telegram', title: 'TELEGRAM PUBLIC SOURCES', label: 'Telegram', short: 'TG', icon: 'send', hint: 'Публичные каналы: предпросмотр и Bot API' },
  { id: 'public_websites', title: 'PUBLIC WEBSITES', label: 'Публичные сайты', short: 'SITES', icon: 'globe', hint: 'Метаданные сайта, профили, архив' },
  { id: 'domain_intel', title: 'DOMAIN INTELLIGENCE', label: 'Разведка по домену', short: 'DOMAIN', icon: 'domain', hint: 'DNS, RDAP/WHOIS, журналы сертификатов' },
  { id: 'email_exposure', title: 'EMAIL EXPOSURE CHECK', label: 'Раскрытие e-mail', short: 'EMAIL', icon: 'mail', hint: 'Известные утечки (HIBP) и почтовая конфигурация' },
  { id: 'public_documents', title: 'PUBLIC DOCUMENTS', label: 'Публичные документы', short: 'DOCS', icon: 'file', hint: 'PDF и офисные документы, научные публикации' },
  { id: 'org_intel', title: 'ORGANIZATION INTELLIGENCE', label: 'Организации', short: 'ORG', icon: 'building', hint: 'Wikidata, GLEIF (LEI), GitHub, OpenAlex' },
  { id: 'digital_footprint', title: 'DIGITAL FOOTPRINT', label: 'Цифровой след', short: 'TRACE', icon: 'footprint', hint: 'Поддомены, архив, проекты, заявленные профили' },
];

export const categoryMeta = (c: Category): CategoryMeta => CATEGORIES.find((x) => x.id === c) ?? CATEGORIES[0];

export const INPUT_KIND_LABEL: Record<InputKind, string> = {
  domain: 'домен',
  url: 'URL',
  email: 'e-mail',
  ip: 'IP-адрес',
  vk_ref: 'VK',
  telegram_ref: 'Telegram-канал',
  text: 'текст / организация',
};

export const FINDING_KIND_LABEL: Record<FindingKind, string> = {
  web_page: 'Веб-страница',
  document: 'Документ',
  publication: 'Публикация',
  social_post: 'Пост',
  community: 'Сообщество',
  channel: 'Канал',
  organization: 'Организация',
  domain: 'Домен',
  dns_record: 'DNS',
  registration: 'Регистрация',
  certificate: 'Сертификаты',
  subdomain: 'Поддомен',
  archive: 'Архив',
  breach: 'Утечка',
  project: 'Проект',
  website: 'Сайт / профиль',
  network: 'Сеть',
  encyclopedia: 'Энциклопедия',
  audit_issue: 'Проверка',
};

export const ENTITY_META: Record<EntityKind, { label: string; color: string; shape: string }> = {
  organization: { label: 'Организации', color: '#f2f5f9', shape: 'октаэдр' },
  domain: { label: 'Домены', color: '#9ec9ea', shape: 'икосаэдр' },
  website: { label: 'Публичные сайты', color: '#c7d0dc', shape: 'сфера' },
  project: { label: 'Публичные проекты', color: '#d8cfc0', shape: 'куб' },
  document: { label: 'Публичные документы', color: '#e3d6b5', shape: 'тетраэдр' },
  publication: { label: 'Публикации', color: '#a8b0bc', shape: 'додекаэдр' },
  source: { label: 'Проверенные источники', color: '#6e7682', shape: 'кольцо' },
};

export const SEVERITY_META: Record<Severity, { label: string; color: string; rank: number }> = {
  critical: { label: 'Критично', color: 'var(--sev-critical)', rank: 0 },
  high: { label: 'Высокий', color: 'var(--sev-high)', rank: 1 },
  medium: { label: 'Средний', color: 'var(--sev-medium)', rank: 2 },
  low: { label: 'Низкий', color: 'var(--sev-low)', rank: 3 },
  info: { label: 'Инфо', color: 'var(--sev-info)', rank: 4 },
  pass: { label: 'В норме', color: 'var(--sev-pass)', rank: 5 },
};

export const RUN_STATUS_LABEL: Record<RunStatus, string> = {
  queued: 'в очереди',
  running: 'выполняется',
  done: 'готово',
  failed: 'ошибка',
  skipped: 'пропущен',
  cancelled: 'отменён',
  timed_out: 'тайм-аут',
};

export const STATUS_LABEL: Record<InvestigationStatus, string> = {
  running: 'выполняется',
  completed: 'завершено',
  partial: 'частично',
  failed: 'ошибка',
  cancelled: 'отменено',
};

export const HEALTH_META: Record<AdapterHealth, { label: string; tone: 'ok' | 'warn' | 'err' | 'idle' }> = {
  online: { label: 'доступен', tone: 'ok' },
  degraded: { label: 'ограничен', tone: 'warn' },
  unconfigured: { label: 'не настроен', tone: 'idle' },
  unauthorized: { label: 'нет доступа', tone: 'err' },
  rate_limited: { label: 'лимит запросов', tone: 'warn' },
  offline: { label: 'недоступен', tone: 'err' },
  disabled: { label: 'отключён', tone: 'idle' },
  unknown: { label: 'не проверялся', tone: 'idle' },
};

export const AUDIT_CHECKS: { id: AuditCheck; label: string; target: 'email' | 'domain' | 'repo_local' | 'repo_github'; verified?: boolean; hint: string }[] = [
  { id: 'email_breaches', label: 'Утечки адреса', target: 'email', hint: 'Have I Been Pwned: утечки и публикации вашего адреса (нужен API-ключ).' },
  { id: 'dns_hygiene', label: 'DNS и почтовая гигиена', target: 'domain', hint: 'SPF, DMARC, DKIM, MTA-STS, CAA, DNSSEC, резервирование NS.' },
  { id: 'web_config', label: 'Конфигурация веб-сервера', target: 'domain', hint: 'HTTPS-редирект, HSTS, CSP, флаги cookie, раскрытие версий, security.txt.' },
  { id: 'tls', label: 'TLS-сертификат', target: 'domain', hint: 'Цепочка доверия, срок действия, имена, версия протокола.' },
  { id: 'incidents', label: 'Известные инциденты', target: 'domain', hint: 'Каталог утечек HIBP по домену организации.' },
  { id: 'surface', label: 'Публичная поверхность', target: 'domain', hint: 'Имена из журналов Certificate Transparency, служебные системы.' },
  { id: 'exposed_files', label: 'Опубликованные служебные файлы', target: 'domain', verified: true, hint: '.git, .env, резервные копии, служебные страницы. Только для подтверждённых доменов.' },
  { id: 'dangling_dns', label: 'Висячие CNAME', target: 'domain', verified: true, hint: 'Поддомены, которые можно захватить у облачных провайдеров.' },
  { id: 'secrets_local', label: 'Секреты в репозитории', target: 'repo_local', hint: 'Токены, ключи и пароли в рабочей копии (учитывается .gitignore).' },
  { id: 'secrets_github', label: 'GitHub secret scanning', target: 'repo_github', hint: 'Открытые оповещения GitHub по вашему репозиторию (нужен токен).' },
];

export const SECTION_META: Record<SectionId, { title: string; hint: string }> = {
  query: { title: 'Исходный запрос', hint: 'Запрос, тип, категории, время и статус' },
  methodology: { title: 'Методология', hint: 'Принципы, шкала достоверности, задействованные источники' },
  sources: { title: 'Проверенные источники', hint: 'Статус и результат каждого источника' },
  findings: { title: 'Найденные результаты', hint: 'Результаты по категориям со ссылками' },
  summary: { title: 'Аналитическая сводка', hint: 'Сводка, ключевые факты, заключение аналитика' },
  graph: { title: 'Граф подтверждённых связей', hint: 'Векторная схема и таблица происхождения связей' },
  references: { title: 'Ссылки на первоисточники', hint: 'Нумерованный список кликабельных ссылок' },
  limitations: { title: 'Ограничения', hint: 'Что не удалось проверить и почему' },
};

export const RELATION_LABEL: Record<string, string> = {
  hosted_on: 'размещено на домене',
  subdomain_of: 'поддомен',
  official_website: 'официальный сайт',
  official_account: 'официальный аккаунт',
  declares_website: 'указывает сайт',
  declares_profile: 'ссылается на профиль',
  registered_via: 'зарегистрирован через',
  hosted_on_network: 'сеть размещения',
  mail_handled_by: 'почта обслуживается',
  dns_hosted_by: 'DNS обслуживается',
  certificates_issued_by: 'сертификаты выданы',
  subsidiary_of: 'дочерняя организация',
  parent_of: 'материнская организация',
  maintained_by: 'поддерживается',
  affiliated_with: 'аффилиация',
  published_on: 'опубликовано на',
  same_as: 'тот же объект',
  documented_by: 'подтверждено источником',
};

export function confidenceLabel(c: number): string {
  if (c >= 0.95) return 'подтверждено';
  if (c >= 0.8) return 'высокая';
  if (c >= 0.6) return 'средняя';
  return 'низкая';
}
