//! Minimal WHOIS (RFC 3912) client — fallback for TLDs without RDAP (e.g. .ru, .su, .рф).

use std::time::Duration;

use sword_core::{SwordError, SwordResult};
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpStream;
use tokio_util::sync::CancellationToken;

const MAX_RESPONSE: usize = 256 * 1024;

pub async fn query(server: &str, q: &str, cancel: &CancellationToken) -> SwordResult<String> {
    let fut = async {
        let mut stream = tokio::time::timeout(Duration::from_secs(10), TcpStream::connect((server, 43)))
            .await
            .map_err(|_| SwordError::Timeout)?
            .map_err(|e| SwordError::Network(format!("WHOIS {server}: {e}")))?;
        stream.write_all(format!("{q}\r\n").as_bytes()).await.map_err(|e| SwordError::Network(e.to_string()))?;
        let mut buf = Vec::new();
        let mut chunk = [0u8; 8192];
        loop {
            let n = tokio::time::timeout(Duration::from_secs(15), stream.read(&mut chunk))
                .await
                .map_err(|_| SwordError::Timeout)?
                .map_err(|e| SwordError::Network(e.to_string()))?;
            if n == 0 || buf.len() >= MAX_RESPONSE {
                break;
            }
            buf.extend_from_slice(&chunk[..n]);
        }
        Ok::<String, SwordError>(String::from_utf8_lossy(&buf).into_owned())
    };
    tokio::select! {
        _ = cancel.cancelled() => Err(SwordError::Cancelled),
        r = fut => r,
    }
}

/// Find the authoritative WHOIS server of a TLD via IANA.
pub async fn server_for(domain: &str, cancel: &CancellationToken) -> SwordResult<String> {
    let tld = domain.trim_end_matches('.').rsplit('.').next().unwrap_or_default().to_lowercase();
    match tld.as_str() {
        "ru" | "su" | "xn--p1ai" => return Ok("whois.tcinet.ru".into()),
        _ => {}
    }
    let iana = query("whois.iana.org", &tld, cancel).await?;
    iana.lines()
        .find_map(|l| {
            let l = l.trim();
            l.strip_prefix("whois:").or_else(|| l.strip_prefix("refer:")).map(|s| s.trim().to_string())
        })
        .filter(|s| !s.is_empty())
        .ok_or_else(|| SwordError::NotFound(format!("WHOIS-сервер для .{tld}")))
}

#[derive(Debug, Default, Clone)]
pub struct WhoisInfo {
    pub registrar: Option<String>,
    pub created: Option<String>,
    pub expires: Option<String>,
    pub updated: Option<String>,
    pub status: Vec<String>,
    pub nameservers: Vec<String>,
    /// Registrant organisation (legal entities only; .ru publishes it for organisations).
    pub org: Option<String>,
}

pub fn parse(text: &str) -> WhoisInfo {
    let mut info = WhoisInfo::default();
    for line in text.lines() {
        let Some((k, v)) = line.split_once(':') else { continue };
        let key = k.trim().to_lowercase();
        let val = v.trim();
        if val.is_empty() {
            continue;
        }
        match key.as_str() {
            "registrar" | "sponsoring registrar" | "registrar name" => {
                info.registrar.get_or_insert_with(|| val.to_string());
            }
            "created" | "creation date" | "registered on" | "registration time" | "domain registration date" => {
                info.created.get_or_insert_with(|| val.to_string());
            }
            "paid-till" | "registry expiry date" | "expiry date" | "expiration date" | "registrar registration expiration date"
            | "free-date" => {
                if key != "free-date" {
                    info.expires.get_or_insert_with(|| val.to_string());
                }
            }
            "updated date" | "last updated" | "last-update" => {
                info.updated.get_or_insert_with(|| val.to_string());
            }
            "state" | "domain status" | "status" => {
                for s in val.split(',') {
                    let s = s.split_whitespace().next().unwrap_or_default().to_string();
                    if !s.is_empty() && !info.status.contains(&s) {
                        info.status.push(s);
                    }
                }
            }
            "nserver" | "name server" => {
                let ns = val.split_whitespace().next().unwrap_or_default().trim_end_matches('.').to_lowercase();
                if !ns.is_empty() && !info.nameservers.contains(&ns) {
                    info.nameservers.push(ns);
                }
            }
            "org" | "registrant organization" => {
                info.org.get_or_insert_with(|| val.to_string());
            }
            _ => {}
        }
    }
    info
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_ru_whois() {
        let text = "domain:        EXAMPLE.RU\nnserver:       ns1.example.ru.\nnserver:       ns2.example.ru.\nstate:         REGISTERED, DELEGATED, VERIFIED\norg:           LLC Example\nregistrar:     RU-CENTER-RU\ncreated:       2001-07-09T20:00:00Z\npaid-till:     2026-07-31T21:00:00Z\nfree-date:     2026-09-01\n";
        let w = parse(text);
        assert_eq!(w.registrar.as_deref(), Some("RU-CENTER-RU"));
        assert_eq!(w.nameservers.len(), 2);
        assert_eq!(w.status, vec!["REGISTERED", "DELEGATED", "VERIFIED"]);
        assert_eq!(w.expires.as_deref(), Some("2026-07-31T21:00:00Z"));
        assert_eq!(w.org.as_deref(), Some("LLC Example"));
    }
}
