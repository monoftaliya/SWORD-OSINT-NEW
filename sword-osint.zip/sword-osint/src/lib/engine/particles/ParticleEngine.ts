/**
 * SWORD OSINT Particle Engine.
 *
 * GPU particle simulation written in TSL (Three Shading Language): it compiles to WGSL on
 * the WebGPU backend and to GLSL on the WebGL 2 fallback. Particle state lives in GPU
 * storage buffers (position, velocity, home anchor + seed, structure target + group) and
 * is advanced every frame by a compute pass:
 *
 *  • ambient motion — a slowly evolving flow field and a spring to each particle's home
 *    anchor; the anchors rotate differentially, so the whole universe turns like a galaxy;
 *  • pointer interaction — repulsion and curl around the 3D ray under the mouse cursor;
 *  • analysis — particles converge into a central structure (shell, orbital rings, the
 *    blade and the core) as the sources of each selected category finish; completion
 *    sends a radial light pulse through the field.
 *
 * Rendering: instanced, size-attenuated sprites with soft radial falloff, additive
 * blending, near/far depth fade and twinkle; optional after-image trails and bloom.
 */
import * as THREE from 'three/webgpu';
import {
  Fn,
  If,
  abs,
  acos,
  cameraPosition,
  cos,
  cross,
  dot,
  exp,
  float,
  floor,
  hash,
  instanceIndex,
  instancedArray,
  int,
  length,
  max,
  mix,
  pass,
  pow,
  sin,
  smoothstep,
  step,
  uniform,
  uniformArray,
  uv,
  vec3,
  vec4,
} from 'three/tsl';
import { bloom } from 'three/addons/tsl/display/BloomNode.js';
import { afterImage } from 'three/addons/tsl/display/AfterImageNode.js';
import { CameraRig } from '../CameraRig';
import { FramePacer, Governor, PARTICLES, autoTier, detectGpu, settle, silenceDeviceLossEchoes, type GpuInfo, type Tier } from '../quality';

export interface EngineOptions {
  renderer: 'auto' | 'webgpu' | 'webgl2';
  quality: 'auto' | Tier;
  bloom: boolean;
  trails: boolean;
  /** 0 = display refresh rate. */
  fpsLimit: number;
  reduceMotion: boolean;
  maxPixelRatio: number;
}

export interface EngineStats {
  /** Measured frame rate; 0 in still-frame mode. */
  fps: number;
  particles: number;
  backend: string;
  gpu: string;
  /** Automatic simplification step, an index into SIMPLIFY_STEPS (0 = none). */
  simplified: number;
}

export interface Beacon {
  id: string;
  title: string;
  short: string;
  detail: string;
  selected: boolean;
  ready: boolean;
}

export interface RunVisual {
  /** An analysis is running. */
  active: boolean;
  /** The last analysis finished successfully and its structure stays on screen. */
  complete: boolean;
  /** Convergence 0…1 per category, indexed like the beacons. */
  levels: number[];
  /** Beacon indexes of the categories taking part in the analysis. */
  participating: number[];
}

export interface EngineCallbacks {
  onStats?: (s: EngineStats) => void;
  onBeaconClick?: (id: string) => void;
  onLost?: (message: string) => void;
}

const GROUPS = 10;
const BEACON_RING = 19;
const BEACON_PICK_RADIUS = 1.7;
/** Largest share of particles that converge into the analysis structure. */
const STRUCTURE_SHARE = 0.72;

interface BeaconObj {
  id: string;
  group: THREE.Group;
  core: THREE.Mesh;
  coreMat: THREE.MeshBasicNodeMaterial;
  halo: THREE.Sprite;
  haloOpacity: { value: number };
  label: HTMLDivElement;
  title: HTMLSpanElement;
  detail: HTMLSpanElement;
  selected: boolean;
  ready: boolean;
  hover: number;
}

export class ParticleEngine {
  private renderer: THREE.WebGPURenderer | null = null;
  private readonly scene = new THREE.Scene();
  private readonly camera = new THREE.PerspectiveCamera(55, 1, 0.1, 600);
  private rig: CameraRig | null = null;
  private pipeline: THREE.RenderPipeline | null = null;
  private fx: { dispose(): void }[] = [];
  private sprite: THREE.Sprite | null = null;
  private computeUpdate: THREE.ComputeNode | null = null;
  private governor: Governor | null = null;
  private gpu: GpuInfo | null = null;
  private backendName = '';
  private disposed = false;
  private paused = false;
  private lost = false;
  private frameErrors = 0;
  private interactive = true;
  private throttleFps = 0;
  private readonly pacer = new FramePacer();
  private looping = false;
  /** Still-frame mode: animate until this time (after input or a state change), then stop. */
  private stillUntil = 0;
  private readonly unlisten: (() => void)[] = [];
  private statsTimer = 0;
  private width = 1;
  private height = 1;
  private ro: ResizeObserver | null = null;
  private readonly raycaster = new THREE.Raycaster();
  private readonly beacons: BeaconObj[] = [];
  private hovered = -1;
  private readonly disposables: { dispose(): void }[] = [];
  private readonly tmp = new THREE.Vector3();

  // simulation uniforms
  private readonly uTime = uniform(0);
  private readonly uDelta = uniform(0.016);
  private readonly uAssemble = uniform(0);
  private readonly uPulse = uniform(0);
  private readonly uRotation = uniform(0);
  private readonly uSpin = uniform(0);
  private readonly uActivity = uniform(1);
  private readonly uFlow = uniform(1);
  private readonly uSize = uniform(0.21);
  private readonly uPointerOrigin = uniform(new THREE.Vector3());
  private readonly uPointerDir = uniform(new THREE.Vector3(0, 0, -1));
  private readonly uPointerActive = uniform(0);
  // Per-group convergence. The compute pass and the sprite material each get their own
  // uniform array: a uniform-array node shared between a compute and a render pipeline is
  // set up twice and only one of the copies would receive updates.
  private readonly uLevels = uniformArray<'float'>(new Array<number>(GROUPS).fill(0), 'float');
  private readonly uLevelsDraw = uniformArray<'float'>(new Array<number>(GROUPS).fill(0), 'float');

  // animation state
  private assembleGoal = 0;
  private pulseClock = -1;
  private wasActive = false;
  private activityGoal = 1;
  private readonly groupGoals = new Array<number>(GROUPS).fill(0);
  private readonly groupLevels = new Array<number>(GROUPS).fill(0);
  private readonly beaconLevels = new Array<number>(GROUPS).fill(0);

  constructor(
    private readonly canvas: HTMLCanvasElement,
    private readonly labelLayer: HTMLElement,
    private opts: EngineOptions,
    private readonly cb: EngineCallbacks = {},
  ) {}

  /** Create the renderer (WebGPU, or WebGL 2 as fallback), the buffers and the passes. */
  async init(): Promise<void> {
    silenceDeviceLossEchoes();
    this.gpu = await detectGpu();
    if (this.disposed) return;
    const forceWebGL = this.opts.renderer === 'webgl2' || (this.opts.renderer === 'auto' && !this.gpu.webgpu);
    const renderer = new THREE.WebGPURenderer({
      canvas: this.canvas,
      antialias: false,
      alpha: false,
      powerPreference: 'high-performance',
      forceWebGL,
    });
    this.renderer = renderer;
    await renderer.init();
    if (this.disposed) return;
    const backend = renderer.backend as unknown as { isWebGPUBackend?: boolean };
    this.backendName = backend.isWebGPUBackend ? 'WebGPU' : 'WebGL 2';
    const defaultLost = renderer.onDeviceLost.bind(renderer);
    renderer.onDeviceLost = (info) => {
      defaultLost(info);
      this.lost = true;
      settle(renderer.setAnimationLoop(null));
      this.cb.onLost?.(info.message || 'графическое устройство потеряно');
    };
    renderer.setClearColor(0x000000, 1);

    const tier: Tier = this.opts.quality === 'auto' ? autoTier(this.gpu) : this.opts.quality;
    const max = PARTICLES[tier];
    this.governor = new Governor(max, max, Math.min(8000, max));

    this.buildParticles(renderer, max);
    this.buildBeacons();
    this.buildPipeline();

    const rig = new CameraRig(this.camera, this.canvas, {
      distance: 46,
      minDistance: 8,
      maxDistance: 150,
      phi: Math.PI / 2.32,
      theta: 0.35,
      parallax: 0.08,
      autoRotate: 0.012,
      reduceMotion: this.opts.reduceMotion,
    });
    rig.onClick = (ndc) => {
      const i = this.pick(ndc);
      if (i >= 0 && this.beacons[i].id) this.cb.onBeaconClick?.(this.beacons[i].id);
    };
    rig.onDoubleClick = (ndc) => this.pick(ndc) >= 0;
    this.rig = rig;
    rig.enabled = this.interactive;

    // in still-frame mode, direct manipulation of the scene animates it briefly
    const nudge = () => this.wake(1200);
    const drag = (e: PointerEvent) => {
      if (e.buttons) nudge();
    };
    this.canvas.addEventListener('pointerdown', nudge);
    this.canvas.addEventListener('pointermove', drag);
    this.canvas.addEventListener('wheel', nudge, { passive: true });
    this.unlisten.push(
      () => this.canvas.removeEventListener('pointerdown', nudge),
      () => this.canvas.removeEventListener('pointermove', drag),
      () => this.canvas.removeEventListener('wheel', nudge),
    );

    this.ro = new ResizeObserver(() => this.resize());
    this.ro.observe(this.canvas.parentElement ?? this.canvas);
    this.resize();
    if (!this.paused) this.startLoop();
  }

  // ------------------------------------------------------------------ construction

  private buildParticles(renderer: THREE.WebGPURenderer, count: number) {
    const pos = instancedArray(count, 'vec3');
    const vel = instancedArray(count, 'vec3');
    const home = instancedArray(count, 'vec4');
    const target = instancedArray(count, 'vec4');

    const computeInit = Fn(() => {
      const i = instanceIndex;
      const r1 = hash(i);
      const r2 = hash(i.add(7919));
      const r3 = hash(i.add(104729));
      const r4 = hash(i.add(1299709));
      const r5 = hash(i.add(15485863));
      const r6 = hash(i.add(32452843));

      // Home anchors: a deep, flattened volume — dense near the core, sparse far away.
      const theta = r1.mul(Math.PI * 2);
      const phi = acos(r2.mul(2).sub(1));
      const radius = mix(float(5), float(80), pow(r3, 0.62));
      const hx = sin(phi).mul(cos(theta)).mul(radius);
      const hy = cos(phi).mul(radius).mul(0.56);
      const hz = sin(phi).mul(sin(theta)).mul(radius);
      home.element(i).assign(vec4(hx, hy, hz, r4));
      pos.element(i).assign(vec3(hx, hy, hz));
      vel.element(i).assign(vec3(0, 0, 0));

      // Structure targets: shell · orbital rings · blade with crossguard · core.
      const group = floor(r6.mul(GROUPS));
      const t = vec3(0, 0, 0).toVar();
      If(r5.lessThan(0.4), () => {
        const sr = float(7.2).add(r3.mul(0.5));
        t.assign(vec3(sin(phi).mul(cos(theta)).mul(sr), cos(phi).mul(sr), sin(phi).mul(sin(theta)).mul(sr)));
      })
        .ElseIf(r5.lessThan(0.7), () => {
          const ring = floor(r3.mul(3));
          const rr = float(10.5).add(ring.mul(2.6)).add(r2.mul(0.25));
          const tilt = ring.mul(0.55).sub(0.55);
          const az = sin(theta).mul(rr);
          t.assign(vec3(cos(theta).mul(rr), az.mul(sin(tilt)), az.mul(cos(tilt))));
        })
        .ElseIf(r5.lessThan(0.86), () => {
          const y = mix(float(-12), float(14), r1);
          const width = smoothstep(9, 14, y).oneMinus().mul(0.55).add(0.05);
          const guard = step(r2, 0.16);
          const bx = mix(r3.sub(0.5).mul(width).mul(2), r1.sub(0.5).mul(7.5), guard);
          const by = mix(y, float(-6.5).add(r3.sub(0.5).mul(0.5)), guard);
          t.assign(vec3(bx, by, r4.sub(0.5).mul(0.25)));
        })
        .Else(() => {
          const cr = pow(r3, 0.34).mul(2.3);
          t.assign(vec3(sin(phi).mul(cos(theta)).mul(cr), cos(phi).mul(cr), sin(phi).mul(sin(theta)).mul(cr)));
        });
      target.element(i).assign(vec4(t, group));
    })().compute(count);

    const { uTime, uDelta, uAssemble, uPulse, uRotation, uSpin, uFlow, uPointerOrigin, uPointerDir, uPointerActive, uLevels } = this;

    const computeUpdate = Fn(() => {
      const i = instanceIndex;
      const p = pos.element(i);
      const v = vel.element(i);
      const h = home.element(i);
      const tg = target.element(i);
      const seed = h.w;
      const dt = uDelta;

      // galactic rotation of the anchors: inner regions turn faster
      const hr = length(h.xz);
      const ang = uSpin.mul(mix(float(1.7), float(0.35), smoothstep(5, 80, hr)));
      const ch = cos(ang);
      const sh = sin(ang);
      const anchor = vec3(h.x.mul(ch).sub(h.z.mul(sh)), h.y, h.x.mul(sh).add(h.z.mul(ch)));

      // analysis: this particle's category convergence
      // at most ~72 % of the particles join the structure; the rest stays as the starfield
      const level = uLevels.element(int(tg.w)).mul(uAssemble).mul(STRUCTURE_SHARE);
      const lock = smoothstep(seed.sub(0.12), seed.add(0.02), level);
      const free = lock.oneMinus();
      const cr = cos(uRotation);
      const sr = sin(uRotation);
      const goal = vec3(tg.x.mul(cr).sub(tg.z.mul(sr)), tg.y, tg.x.mul(sr).add(tg.z.mul(cr)));

      // ambient flow field (smooth, slowly changing)
      const tt = uTime.mul(0.05);
      const q = p.mul(0.045);
      const flow = vec3(
        sin(q.y.mul(1.7).add(tt).add(seed.mul(6.283))).add(cos(q.z.mul(1.3).sub(tt.mul(0.7)))),
        sin(q.z.mul(1.5).add(tt.mul(0.8)).add(seed.mul(3.1))).add(cos(q.x.mul(1.1).add(tt.mul(0.5)))),
        sin(q.x.mul(1.6).sub(tt.mul(0.9)).add(seed.mul(1.7))).add(cos(q.y.mul(1.2).add(tt.mul(0.6)))),
      )
        .mul(uFlow)
        .mul(seed.mul(0.45).add(0.25))
        .mul(uAssemble.mul(0.6).add(1));

      // pointer: repel and curl around the 3D ray under the mouse
      const rel = p.sub(uPointerOrigin);
      const along = dot(rel, uPointerDir);
      const away = rel.sub(uPointerDir.mul(along));
      const dist = max(length(away), 0.001);
      const influence = smoothstep(0, 8, dist).oneMinus().mul(uPointerActive).mul(step(0, along));
      const dir = away.div(dist);
      const pointerForce = dir.mul(10).add(cross(uPointerDir, dir).mul(5.5)).mul(influence).mul(lock.mul(0.75).oneMinus());

      // completion pulse: an expanding spherical wave
      const radial = max(length(p), 0.001);
      const front = smoothstep(0, 3, abs(radial.sub(uPulse.mul(22)))).oneMinus();
      const life = step(0.0001, uPulse).mul(smoothstep(2.5, 4.5, uPulse).oneMinus());
      const pulseForce = p.div(radial).mul(front).mul(life).mul(16);

      const accel = flow
        .mul(free)
        .add(anchor.sub(p).mul(0.12).mul(free))
        .add(goal.sub(p).mul(4.2).mul(lock))
        .add(pointerForce)
        .add(pulseForce);
      const damping = exp(dt.negate().mul(mix(float(1.4), float(3.6), lock)));
      v.assign(v.add(accel.mul(dt)).mul(damping));
      p.addAssign(v.mul(dt));
    })().compute(count);

    // ---- material: soft additive sprites
    const material = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
    const pAttr = pos.toAttribute();
    const hAttr = home.toAttribute();
    const tAttr = target.toAttribute();
    const seed = hAttr.w;
    const lockR = smoothstep(seed.sub(0.12), seed.add(0.02), this.uLevelsDraw.element(int(tAttr.w)).mul(uAssemble).mul(STRUCTURE_SHARE));
    material.positionNode = pAttr;
    material.scaleNode = this.uSize.mul(seed.mul(0.85).add(0.35)).mul(lockR.mul(0.6).add(1));
    const d = uv().sub(0.5).length().mul(2);
    const falloff = pow(smoothstep(0, 1, d).oneMinus(), 2.4);
    const camDist = length(cameraPosition.sub(pAttr));
    const depthFade = smoothstep(12, 160, camDist).oneMinus().mul(smoothstep(1.5, 9, camDist));
    const twinkle = sin(uTime.mul(seed.mul(1.8).add(0.4)).add(seed.mul(97))).mul(0.22).add(0.78);
    const silver = mix(vec3(0.62, 0.69, 0.8), vec3(1, 1, 1), seed);
    material.colorNode = vec4(mix(silver, vec3(0.86, 0.94, 1.0), lockR), 1);
    material.opacityNode = falloff
      .mul(depthFade)
      .mul(twinkle)
      .mul(mix(float(0.4), float(1.0), lockR))
      .mul(seed.mul(0.6).add(0.35))
      .mul(this.uActivity);

    const sprite = new THREE.Sprite(material);
    sprite.count = count;
    sprite.frustumCulled = false;
    this.scene.add(sprite);
    this.sprite = sprite;
    this.computeUpdate = computeUpdate;
    this.disposables.push(material, computeInit, computeUpdate);
    settle(renderer.compute(computeInit));
  }

  private buildBeacons() {
    const coreGeo = new THREE.IcosahedronGeometry(0.42, 2);
    this.disposables.push(coreGeo);

    // faint orbit path the category beacons travel along
    const pts: THREE.Vector3[] = [];
    for (let k = 0; k <= 256; k++) {
      const a = (k / 256) * Math.PI * 2;
      pts.push(new THREE.Vector3(Math.cos(a) * BEACON_RING, Math.sin(a) * BEACON_RING * 0.32, Math.sin(a) * BEACON_RING * 0.95));
    }
    const orbitGeo = new THREE.BufferGeometry().setFromPoints(pts);
    const orbitMat = new THREE.LineBasicNodeMaterial({ color: 0xc7d0dc, transparent: true, opacity: 0.07, depthWrite: false, blending: THREE.AdditiveBlending });
    this.scene.add(new THREE.Line(orbitGeo, orbitMat));
    this.disposables.push(orbitGeo, orbitMat);

    for (let i = 0; i < GROUPS; i++) {
      const coreMat = new THREE.MeshBasicNodeMaterial({ color: 0xffffff, transparent: true, opacity: 0.5, depthWrite: false });
      const core = new THREE.Mesh(coreGeo, coreMat);
      const haloMat = new THREE.SpriteNodeMaterial({ transparent: true, depthWrite: false, blending: THREE.AdditiveBlending });
      const haloOpacity = uniform(0.2);
      haloMat.colorNode = vec4(0.86, 0.92, 1.0, 1);
      haloMat.opacityNode = pow(smoothstep(0, 1, uv().sub(0.5).length().mul(2)).oneMinus(), 3).mul(haloOpacity).mul(this.uActivity);
      const halo = new THREE.Sprite(haloMat);
      halo.scale.setScalar(4);
      const group = new THREE.Group();
      group.add(core, halo);
      this.scene.add(group);

      const label = document.createElement('div');
      label.className = 'beacon-label';
      const title = document.createElement('span');
      title.className = 'bl-title';
      const detail = document.createElement('span');
      detail.className = 'bl-detail';
      label.append(title, detail);
      this.labelLayer.appendChild(label);

      this.beacons.push({ id: '', group, core, coreMat, halo, haloOpacity, label, title, detail, selected: false, ready: false, hover: 0 });
      this.disposables.push(coreMat, haloMat);
    }
  }

  private buildPipeline() {
    const renderer = this.renderer;
    if (!renderer || this.lost) return;
    this.pipeline?.dispose();
    for (const n of this.fx) n.dispose();
    this.fx = [];
    this.pipeline = null;
    const lite = (this.governor?.simplify ?? 0) >= 1;
    const useTrails = this.opts.trails && !this.opts.reduceMotion && !lite;
    const useBloom = this.opts.bloom && !lite;
    if (!useBloom && !useTrails) return;
    const pipeline = new THREE.RenderPipeline(renderer);
    const scenePass = pass(this.scene, this.camera);
    this.fx.push(scenePass);
    let out = scenePass.getTextureNode('output');
    if (useTrails) {
      const trails = afterImage(out, 0.8);
      this.fx.push(trails);
      out = trails.getTextureNode();
    }
    if (useBloom) {
      // threshold keeps the faint starfield out of the glow, so the background stays black
      const glow = bloom(out, 0.55, 0.3, 0.12);
      this.fx.push(glow);
      pipeline.outputNode = out.add(glow);
    } else {
      pipeline.outputNode = out;
    }
    this.pipeline = pipeline;
  }

  // ------------------------------------------------------------------ public API

  stats(): EngineStats {
    const simplified = this.governor?.simplify ?? 0;
    return {
      fps: simplified >= 3 ? 0 : (this.governor?.fps ?? 0),
      particles: this.governor?.active ?? 0,
      backend: this.backendName,
      gpu: this.gpu?.description ?? '',
      simplified,
    };
  }

  setBeacons(list: Beacon[]) {
    list.slice(0, GROUPS).forEach((b, i) => {
      const o = this.beacons[i];
      if (!o) return;
      o.id = b.id;
      o.selected = b.selected;
      o.ready = b.ready;
      o.title.textContent = b.short;
      o.detail.textContent = b.detail;
      o.label.title = b.title;
      o.label.classList.toggle('selected', b.selected);
      o.label.classList.toggle('unready', !b.ready);
    });
    this.wake(600);
  }

  setRun(v: RunVisual) {
    this.assembleGoal = v.active ? 1 : v.complete ? 0.88 : 0;
    const n = v.participating.length;
    for (let g = 0; g < GROUPS; g++) {
      const level = n === 0 ? 0 : (v.levels[v.participating[g % n]] ?? 0);
      this.groupGoals[g] = Math.max(0, Math.min(1, level));
      this.beaconLevels[g] = Math.max(0, Math.min(1, v.levels[g] ?? 0));
    }
    if (this.wasActive && !v.active && v.complete) this.pulseClock = 0;
    if (this.wasActive !== v.active) this.wake(2500);
    this.wasActive = v.active;
  }

  /** DISCOVERY is the only screen where the universe takes pointer input. */
  setInteractive(on: boolean) {
    this.interactive = on;
    if (this.rig) this.rig.enabled = on;
    this.labelLayer.classList.toggle('hidden', !on);
    if (!on) this.setHover(-1);
    this.wake(600);
  }

  /** Overall brightness (dimmed behind other sections). */
  setActivity(level: number) {
    if (level === this.activityGoal) return;
    this.activityGoal = level;
    this.wake(600);
  }

  /** Extra frame cap while the universe is only a backdrop (0 = none). */
  setThrottle(fps: number) {
    this.throttleFps = fps;
  }

  setPaused(p: boolean) {
    if (this.paused === p) return;
    this.paused = p;
    if (!this.renderer || this.lost) return;
    if (p) {
      this.stopLoop();
    } else {
      this.stillUntil = performance.now() + 1500;
      this.startLoop();
    }
  }

  resetCamera() {
    this.rig?.reset();
  }

  /** Apply settings that do not require a new renderer (bloom, trails, frame cap, motion, DPR). */
  updateOptions(next: Partial<EngineOptions>) {
    const prev = this.opts;
    this.opts = { ...prev, ...next };
    const o = this.opts;
    if (o.reduceMotion !== prev.reduceMotion) this.rig?.setReduceMotion(o.reduceMotion);
    if (o.bloom !== prev.bloom || o.trails !== prev.trails || o.reduceMotion !== prev.reduceMotion) this.buildPipeline();
    if (o.maxPixelRatio !== prev.maxPixelRatio) this.resize();
    this.wake(600);
  }

  dispose() {
    this.disposed = true;
    // Every step is isolated: after a device loss three.js may throw while releasing
    // GPU objects, and teardown must still complete (DOM, listeners, remaining resources).
    const safe = (fn: () => void) => {
      try {
        fn();
      } catch {
        /* resource already gone with the lost device */
      }
    };
    safe(() => settle(this.renderer?.setAnimationLoop(null)));
    this.looping = false;
    for (const off of this.unlisten) safe(off);
    safe(() => this.ro?.disconnect());
    safe(() => this.rig?.dispose());
    for (const b of this.beacons) b.label.remove();
    safe(() => this.pipeline?.dispose());
    for (const n of this.fx) safe(() => n.dispose());
    for (const d of this.disposables) safe(() => d.dispose());
    safe(() => settle(this.renderer?.dispose()));
    this.renderer = null;
  }

  // ------------------------------------------------------------------ frame

  private startLoop() {
    this.pacer.reset(performance.now());
    this.looping = true;
    settle(this.renderer?.setAnimationLoop((t) => this.frame(t)));
  }

  private stopLoop() {
    this.looping = false;
    settle(this.renderer?.setAnimationLoop(null));
  }

  /** In still-frame mode, animate for a moment so a change or an input becomes visible. */
  private wake(ms: number) {
    if ((this.governor?.simplify ?? 0) < 3 || this.disposed || this.lost || this.paused || !this.renderer) return;
    this.stillUntil = Math.max(this.stillUntil, performance.now() + ms);
    if (!this.looping) this.startLoop();
  }

  /** One automatic step down the SIMPLIFY_STEPS ladder, reported to the interface at once. */
  private applySimplification() {
    const level = this.governor?.simplify ?? 0;
    if (level === 1) this.buildPipeline();
    else if (level === 2) this.resize();
    else if (level >= 3) this.stillUntil = 0;
    this.cb.onStats?.(this.stats());
  }

  private resize() {
    const renderer = this.renderer;
    if (!renderer) return;
    const host = this.canvas.parentElement ?? this.canvas;
    this.width = Math.max(1, host.clientWidth);
    this.height = Math.max(1, host.clientHeight);
    const ratio = Math.min(window.devicePixelRatio || 1, Math.max(0.5, this.opts.maxPixelRatio));
    renderer.setPixelRatio((this.governor?.simplify ?? 0) >= 2 ? Math.max(0.5, ratio * 0.5) : ratio);
    renderer.setSize(this.width, this.height, false);
    this.camera.aspect = this.width / this.height;
    this.camera.updateProjectionMatrix();
    this.wake(300);
  }

  /** Beacon under the pointer: analytic ray–sphere test, nearest along the ray. */
  private pick(ndc: THREE.Vector2): number {
    if (!this.interactive) return -1;
    this.raycaster.setFromCamera(ndc, this.camera);
    const ray = this.raycaster.ray;
    let best = -1;
    let bestDist = Infinity;
    this.beacons.forEach((b, i) => {
      if (!b.id) return;
      const p = b.group.position;
      if (this.tmp.subVectors(p, ray.origin).dot(ray.direction) <= 0) return;
      if (ray.distanceSqToPoint(p) > BEACON_PICK_RADIUS * BEACON_PICK_RADIUS) return;
      const d = ray.origin.distanceTo(p);
      if (d < bestDist) {
        bestDist = d;
        best = i;
      }
    });
    return best;
  }

  private setHover(i: number) {
    if (i === this.hovered) return;
    this.hovered = i;
    this.beacons.forEach((b, j) => b.label.classList.toggle('hover', j === i));
    this.canvas.style.cursor = i >= 0 ? 'pointer' : '';
  }

  /**
   * Animation-loop entry. A GPU failure that is not reported as a device loss (e.g. errors
   * thrown by a broken device after a driver reset) is detected here and escalated to the
   * owner, which rebuilds the scene in a safer mode.
   */
  private frame(now: number) {
    try {
      this.drawFrame(now);
      this.frameErrors = 0;
    } catch (e) {
      if (++this.frameErrors < 3 || this.lost) return;
      this.lost = true;
      settle(this.renderer?.setAnimationLoop(null));
      this.cb.onLost?.(e instanceof Error ? e.message : String(e));
    }
  }

  private drawFrame(now: number) {
    const renderer = this.renderer;
    const rig = this.rig;
    const governor = this.governor;
    if (this.disposed || !renderer || !rig || !governor || !this.sprite || !this.computeUpdate) return;
    const caps = [this.opts.fpsLimit, this.throttleFps].filter((f) => f > 0);
    const cap = caps.length ? Math.min(...caps) : 0;
    const frameDt = this.pacer.tick(now, cap);
    if (frameDt === null) return;
    const dt = Math.min(0.05, Math.max(0.0005, frameDt));
    const k = (rate: number) => 1 - Math.exp(-dt * rate);

    // particle budget, then simplification, follow the measured frame rate
    const change = governor.sample(frameDt, cap);
    if (change === 'budget') {
      this.sprite.count = governor.active;
      this.computeUpdate.count = governor.active;
    } else if (change === 'simplify') {
      this.applySimplification();
    }

    // camera & pointer ray
    rig.update(dt);
    this.raycaster.setFromCamera(rig.pointer, this.camera);
    this.uPointerOrigin.value.copy(this.raycaster.ray.origin);
    this.uPointerDir.value.copy(this.raycaster.ray.direction);
    const pointerGoal = this.interactive && rig.pointerInside && !this.opts.reduceMotion ? 1 : 0;
    this.uPointerActive.value += (pointerGoal - this.uPointerActive.value) * k(4);

    // analysis state
    const a = this.uAssemble.value;
    this.uAssemble.value = a + (this.assembleGoal - a) * k(this.assembleGoal > a ? 1.6 : 0.55);
    const levels = this.uLevels.array as number[];
    const levelsDraw = this.uLevelsDraw.array as number[];
    for (let g = 0; g < GROUPS; g++) {
      this.groupLevels[g] += (this.groupGoals[g] - this.groupLevels[g]) * k(1.8);
      levels[g] = this.groupLevels[g];
      levelsDraw[g] = this.groupLevels[g];
    }
    if (this.pulseClock >= 0) {
      this.pulseClock += dt;
      this.uPulse.value = this.pulseClock;
      if (this.pulseClock > 5) {
        this.pulseClock = -1;
        this.uPulse.value = 0;
      }
    }
    const calm = this.opts.reduceMotion;
    this.uRotation.value += dt * (calm ? 0.03 : 0.12 + this.uAssemble.value * 0.1);
    this.uSpin.value += dt * (calm ? 0.004 : 0.018);
    this.uActivity.value += (this.activityGoal - this.uActivity.value) * k(3);
    this.uFlow.value = calm ? 0.3 : 1;
    this.uTime.value += dt;
    this.uDelta.value = dt;

    // beacons orbit on a tilted ring and react to hover/selection
    const t = this.uTime.value;
    this.setHover(this.interactive && rig.pointerInside ? this.pick(rig.pointer) : -1);
    const drift = calm ? 0 : t * 0.025;
    this.beacons.forEach((b, i) => {
      const ang = (i / GROUPS) * Math.PI * 2 + drift;
      b.group.position.set(
        Math.cos(ang) * BEACON_RING,
        Math.sin(ang) * BEACON_RING * 0.32 + (calm ? 0 : Math.sin(t * 0.4 + i) * 0.4),
        Math.sin(ang) * BEACON_RING * 0.95,
      );
      b.hover += ((i === this.hovered ? 1 : 0) - b.hover) * k(10);
      const lvl = this.beaconLevels[i] * this.uAssemble.value;
      b.core.scale.setScalar((b.selected ? 1.1 : 0.78) + b.hover * 0.55 + lvl * 0.25);
      b.coreMat.opacity = Math.min(1, ((b.selected ? 0.95 : 0.34) * (b.ready ? 1 : 0.55) + b.hover * 0.4) * this.uActivity.value);
      b.haloOpacity.value = (b.selected ? 0.3 : 0.08) + b.hover * 0.45 + lvl * 0.35;
      b.halo.scale.setScalar(3.6 + b.hover * 2.2 + (b.selected ? 0.8 : 0) + lvl * 1.5);

      // HTML label below the orb
      this.tmp.copy(b.group.position).project(this.camera);
      const visible = this.tmp.z < 1 && this.interactive && b.id !== '';
      const x = (this.tmp.x * 0.5 + 0.5) * this.width;
      const y = (-this.tmp.y * 0.5 + 0.5) * this.height;
      b.label.style.transform = `translate(${x.toFixed(1)}px, ${(y + 18).toFixed(1)}px) translate(-50%, 0)`;
      b.label.style.opacity = visible ? Math.min(1, 0.5 + b.hover * 0.5 + (b.selected ? 0.3 : 0)).toFixed(2) : '0';
    });

    // simulate + render
    settle(renderer.compute(this.computeUpdate));
    if (this.pipeline) this.pipeline.render();
    else renderer.render(this.scene, this.camera);

    this.statsTimer += frameDt;
    if (this.statsTimer > 1) {
      this.statsTimer = 0;
      this.cb.onStats?.(this.stats());
    }
    if (governor.simplify >= 3 && now >= this.stillUntil) this.stopLoop();
  }
}
