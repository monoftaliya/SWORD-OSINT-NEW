//! VK — full adapter on top of the official VK API (api.vk.com).
//!
//! Scope (public objects only):
//! * screen name / link → `utils.resolveScreenName`; communities (`group`/`page`/`event`)
//!   are described via `groups.getById` and their public wall via `wall.get`;
//! * free text / domain → public posts via `newsfeed.search` (service or user key) and
//!   communities via `groups.search` (user key only);
//! * personal profiles are not analysed — the adapter works with communities and
//!   publications, in line with the platform rules and the project's privacy policy.
//!
//! Access errors (codes 5, 15, 18, 27, 28, 30…) are reported honestly with the reason; the
//! adapter never tries to work around platform restrictions or closed communities.

use async_trait::async_trait;
use chrono::{TimeZone, Utc};
use serde_json::Value;
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordError, SwordResult,
};

use super::{arr, cred, fmt_int, info, num, opt, s};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::output::{FindingExt, OutputBuilder};

const SERVICE_TOKEN: &str = "vk.service_token";
const USER_TOKEN: &str = "vk.user_token";
const DEFAULT_VERSION: &str = "5.199";
const GROUP_FIELDS: &str = "description,site,members_count,verified,activity,status,screen_name,is_closed,type,city,country,start_date";

pub struct Vk {
    info: AdapterInfo,
}

impl Default for Vk {
    fn default() -> Self {
        Self::new()
    }
}

/// Which key a method call should use.
#[derive(Clone, Copy, PartialEq)]
enum KeyPref {
    /// Service key if present, otherwise user key.
    Any,
    /// Method available only with a user key.
    User,
}

impl Vk {
    pub fn new() -> Self {
        Vk {
            info: info(
                "vk",
                "VK API",
                "ВКонтакте (официальный API)",
                "Публичные сообщества и публикации ВКонтакте: сведения о сообществе, публичная стена, поиск публичных постов и сообществ.",
                "Официальный VK API (api.vk.com/method, версия задаётся в настройках): utils.resolveScreenName, groups.getById, \
                 wall.get, newsfeed.search — с сервисным ключом приложения; groups.search — только с пользовательским ключом. \
                 Ограничение частоты — не более 3 запросов в секунду. Закрытые сообщества и личные профили не анализируются.",
                &[Category::Vk, Category::SocialNetworks],
                &[InputKind::VkRef, InputKind::Text, InputKind::Domain, InputKind::Url],
                vec![
                    cred(
                        SERVICE_TOKEN,
                        "Сервисный ключ доступа",
                        true,
                        "Создайте приложение на платформе VK ID (id.vk.com/about/business/go → «Мои приложения»). \
                         В карточке приложения в разделе «Ключи доступа» скопируйте «Сервисный ключ доступа».",
                        Some("https://id.vk.com/about/business/go"),
                        Some("сервисный ключ приложения"),
                    ),
                    cred(
                        USER_TOKEN,
                        "Пользовательский ключ (необязательно)",
                        false,
                        "Нужен только для поиска сообществ (groups.search). Получите ключ доступа пользователя через авторизацию VK ID \
                         для вашего приложения. Храните его как пароль.",
                        Some("https://dev.vk.com/ru/api/access-token/getting-started"),
                        None,
                    ),
                ],
                vec![opt("api_version", "Версия API", false, Some(DEFAULT_VERSION), "Версия VK API, передаваемая в параметре v.", Some(DEFAULT_VERSION))],
                170,
                "https://vk.com/",
                Some("https://dev.vk.com/ru/reference"),
                true,
            ),
        }
    }

    fn version(&self, ctx: &ConnectorContext) -> String {
        ctx.option(&self.info, "api_version").unwrap_or_else(|| DEFAULT_VERSION.into())
    }

    fn token(&self, ctx: &ConnectorContext, pref: KeyPref) -> SwordResult<String> {
        match pref {
            KeyPref::User => ctx.secret(USER_TOKEN).ok_or_else(|| SwordError::NotConfigured("пользовательский ключ VK".into())),
            KeyPref::Any => ctx
                .secret(SERVICE_TOKEN)
                .or_else(|| ctx.secret(USER_TOKEN))
                .ok_or_else(|| SwordError::NotConfigured("сервисный ключ VK".into())),
        }
    }

    /// Call a VK API method and unwrap `response` / map `error`.
    async fn call(&self, ctx: &ConnectorContext, method: &str, params: &[(&str, String)], pref: KeyPref) -> SwordResult<Value> {
        let token = self.token(ctx, pref)?;
        let version = self.version(ctx);
        let mut form: Vec<(&str, String)> = params.to_vec();
        form.push(("access_token", token));
        form.push(("v", version));
        form.push(("lang", "ru".into()));
        // POST keeps the token out of URLs and logs.
        let req = ctx.post(&format!("https://api.vk.com/method/{method}")).form(&form);
        let v: Value = ctx.json(&self.info, req).await?;
        if let Some(err) = v.get("error") {
            let code = num(err, "error_code").unwrap_or(0);
            let msg = s(err, "error_msg").unwrap_or_default();
            return Err(map_vk_error(method, code, &msg));
        }
        v.get("response").cloned().ok_or_else(|| SwordError::Parse("в ответе VK нет поля response".into()))
    }

    fn group_url(g: &Value) -> String {
        match s(g, "screen_name") {
            Some(sn) => format!("https://vk.com/{sn}"),
            None => format!("https://vk.com/club{}", num(g, "id").unwrap_or(0)),
        }
    }

    /// Describe a community as a website/profile node with sourced attributes.
    fn add_group(&self, b: &mut OutputBuilder, g: &Value, category: Category) -> String {
        let url = Self::group_url(g);
        let key = keys::site(&url);
        let name = s(g, "name").unwrap_or_else(|| url.clone());
        let closed = num(g, "is_closed").unwrap_or(0) != 0;
        b.entity(&key, EntityKind::Website, &format!("VK: {name}"));
        let members = num(g, "members_count");
        b.attr(&key, "Тип", &match s(g, "type").as_deref() {
            Some("page") => "публичная страница".to_string(),
            Some("event") => "мероприятие".to_string(),
            _ => "группа".to_string(),
        }, &url);
        if let Some(m) = members {
            b.attr(&key, "Участники", &fmt_int(m), &url);
        }
        if num(g, "verified").unwrap_or(0) == 1 {
            b.attr(&key, "Верификация", "подтверждённое сообщество", &url);
        }
        if let Some(a) = s(g, "activity") {
            b.attr(&key, "Тематика", &a, &url);
        }
        if let Some(city) = g.pointer("/city/title").and_then(Value::as_str) {
            b.attr(&key, "Город", city, &url);
        }
        {
            let f = b.finding(category, FindingKind::Community, &name, Some(&url));
            f.snippet(&s(g, "description").or_else(|| s(g, "status")).unwrap_or_default())
                .confidence(0.95)
                .attr("Участники", members.map(fmt_int).unwrap_or_default())
                .attr("Доступ", if closed { "закрытое сообщество" } else { "открытое" })
                .entity(&key);
        }
        if let Some(site) = s(g, "site") {
            let site = if site.starts_with("http") { site } else { format!("https://{site}") };
            if let Some(host) = sword_core::util::host_of(&site) {
                let reg = sword_core::input::registrable(&host).unwrap_or(host);
                let dkey = keys::domain(&reg);
                b.entity(&dkey, EntityKind::Domain, &reg);
                b.relate(&key, &dkey, "declares_website", 0.8, &url, Some("сайт указан в профиле сообщества"));
            }
        }
        b.source(&url, &format!("VK: {name}"));
        key
    }

    fn add_post(&self, b: &mut OutputBuilder, p: &Value, owner_key: Option<&str>, category: Category) {
        let owner = num(p, "owner_id").unwrap_or(0);
        let id = num(p, "id").unwrap_or(0);
        if owner == 0 || id == 0 {
            return;
        }
        let url = format!("https://vk.com/wall{owner}_{id}");
        let text = s(p, "text").unwrap_or_default();
        let title: String = if text.is_empty() { "Публикация VK".into() } else { text.chars().take(90).collect() };
        let date = num(p, "date").and_then(|t| Utc.timestamp_opt(t, 0).single());
        let pub_key = keys::publication("vk", &format!("wall{owner}_{id}"));
        b.finding(category, FindingKind::SocialPost, &title, Some(&url))
            .snippet(&text)
            .published(date)
            .confidence(0.9)
            .attr("Просмотры", p.pointer("/views/count").and_then(Value::as_i64).map(fmt_int).unwrap_or_default())
            .attr("Отметки «Мне нравится»", p.pointer("/likes/count").and_then(Value::as_i64).map(fmt_int).unwrap_or_default())
            .attr("Репосты", p.pointer("/reposts/count").and_then(Value::as_i64).map(fmt_int).unwrap_or_default())
            .attr("Автор", if owner < 0 { "сообщество" } else { "пользователь (профиль не анализируется)" })
            .entity(&pub_key);
        b.entity(&pub_key, EntityKind::Publication, &title);
        if let Some(d) = date {
            b.attr(&pub_key, "Дата публикации", &sword_core::util::fmt_datetime(&d), &url);
        }
        if let Some(owner_key) = owner_key {
            b.relate(&pub_key, owner_key, "published_on", 1.0, &url, None);
        }
        b.source(&url, "Публикация VK");
    }
}

fn map_vk_error(method: &str, code: i64, msg: &str) -> SwordError {
    let detail = format!("{method}: код {code} — {msg}");
    match code {
        5 => SwordError::Unauthorized(format!("ключ VK недействителен или отозван ({detail})")),
        6 | 9 | 29 => SwordError::RateLimited { retry_after_secs: Some(2) },
        15 | 30 => SwordError::Forbidden(format!("сообщество или данные закрыты ({detail})")),
        18 | 113 => SwordError::NotFound(detail),
        27 | 28 => SwordError::Forbidden(format!("метод недоступен с этим типом ключа ({detail})")),
        100 => SwordError::InvalidInput(detail),
        _ => SwordError::Upstream(detail),
    }
}

#[async_trait]
impl SourceAdapter for Vk {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let mut perms = Vec::new();
        let v = self.call(ctx, "utils.resolveScreenName", &[("screen_name", "vk".into())], KeyPref::Any).await?;
        perms.push(PermissionCheck::granted(
            "Ключ доступа",
            format!("Действителен (utils.resolveScreenName → {})", s(&v, "type").unwrap_or_else(|| "ok".into())),
        ));
        perms.push(match self.call(ctx, "newsfeed.search", &[("q", "новости".into()), ("count", "1".into())], KeyPref::Any).await {
            Ok(_) => PermissionCheck::granted("newsfeed.search", "Поиск публичных постов доступен"),
            Err(e) => PermissionCheck::denied("newsfeed.search", e.to_string()),
        });
        perms.push(if ctx.secret(USER_TOKEN).is_some() {
            match self.call(ctx, "groups.search", &[("q", "новости".into()), ("count", "1".into())], KeyPref::User).await {
                Ok(_) => PermissionCheck::granted("groups.search", "Поиск сообществ доступен (пользовательский ключ)"),
                Err(e) => PermissionCheck::denied("groups.search", e.to_string()),
            }
        } else {
            PermissionCheck::denied("groups.search", "Требуется пользовательский ключ — поиск сообществ отключён")
        });
        Ok(perms)
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let mut b = OutputBuilder::new(&self.info);
        let count = ctx.max_results.clamp(5, 100).to_string();

        if input.kind == InputKind::VkRef {
            let name = input.handle.clone().unwrap_or_default();
            let resolved = self.call(ctx, "utils.resolveScreenName", &[("screen_name", name.clone())], KeyPref::Any).await?;
            let kind = s(&resolved, "type").unwrap_or_default();
            let object_id = num(&resolved, "object_id").unwrap_or(0);
            match kind.as_str() {
                "group" | "page" | "event" => {
                    let gv = self.call(ctx, "groups.getById", &[("group_id", object_id.to_string()), ("fields", GROUP_FIELDS.into())], KeyPref::Any).await?;
                    // API versions return either an array, {groups: [...]} or {items: [...]}.
                    let groups: Vec<Value> = if let Some(a) = gv.as_array() {
                        a.clone()
                    } else {
                        let g = arr(&gv, "/groups");
                        if g.is_empty() { arr(&gv, "/items").to_vec() } else { g.to_vec() }
                    };
                    let Some(g) = groups.first() else {
                        return Err(SwordError::NotFound(format!("сообщество {name}")));
                    };
                    let key = self.add_group(&mut b, g, Category::Vk);
                    let url = Self::group_url(g);
                    b.fact("Сообщество VK", &format!("{} ({})", s(g, "name").unwrap_or_default(), url), &url);
                    if num(g, "is_closed").unwrap_or(0) != 0 {
                        b.note("Сообщество закрыто — стена не запрашивалась.");
                    } else {
                        match self
                            .call(ctx, "wall.get", &[("owner_id", format!("-{object_id}")), ("count", count.clone()), ("filter", "owner".into())], KeyPref::Any)
                            .await
                        {
                            Ok(w) => {
                                for p in arr(&w, "/items") {
                                    self.add_post(&mut b, p, Some(&key), Category::Vk);
                                }
                            }
                            Err(e) => b.note(format!("Стена сообщества недоступна: {e}")),
                        }
                    }
                }
                "user" => {
                    b.note("Ссылка ведёт на личный профиль. Модуль VK анализирует только сообщества и публикации; данные профиля не запрашивались.");
                }
                "application" => b.note("Ссылка ведёт на приложение VK — сведения не запрашивались."),
                _ => return Err(SwordError::NotFound(format!("короткое имя «{name}» не найдено в VK"))),
            }
            return Ok(b.finish());
        }

        // Free text / domain: public posts + (with a user key) communities.
        let q = input.registrable_domain.clone().unwrap_or_else(|| input.text.clone());
        b.source(&format!("https://vk.com/search?c%5Bq%5D={}&c%5Bsection%5D=statuses", url::form_urlencoded::byte_serialize(q.as_bytes()).collect::<String>()), &format!("VK: поиск «{q}»"));
        match self.call(ctx, "newsfeed.search", &[("q", q.clone()), ("count", count.clone()), ("extended", "1".into())], KeyPref::Any).await {
            Ok(v) => {
                let groups = arr(&v, "/groups").to_vec();
                for p in arr(&v, "/items") {
                    let owner = num(p, "owner_id").unwrap_or(0);
                    let owner_key = if owner < 0 {
                        groups.iter().find(|g| num(g, "id") == Some(-owner)).map(|g| {
                            let k = keys::site(&Self::group_url(g));
                            b.entity(&k, EntityKind::Website, &format!("VK: {}", s(g, "name").unwrap_or_default()));
                            k
                        })
                    } else {
                        None
                    };
                    self.add_post(&mut b, p, owner_key.as_deref(), Category::Vk);
                }
            }
            Err(e @ SwordError::Unauthorized(_)) => return Err(e),
            Err(e) => b.note(format!("newsfeed.search: {e}")),
        }
        if ctx.secret(USER_TOKEN).is_some() {
            match self.call(ctx, "groups.search", &[("q", q.clone()), ("count", "15".into())], KeyPref::User).await {
                Ok(v) => {
                    let ids: Vec<String> = arr(&v, "/items").iter().filter_map(|g| num(g, "id")).map(|i| i.to_string()).collect();
                    if !ids.is_empty() {
                        if let Ok(gv) = self.call(ctx, "groups.getById", &[("group_ids", ids.join(",")), ("fields", GROUP_FIELDS.into())], KeyPref::Any).await {
                            let groups: Vec<Value> = if let Some(a) = gv.as_array() { a.clone() } else {
                                let g = arr(&gv, "/groups");
                                if g.is_empty() { arr(&gv, "/items").to_vec() } else { g.to_vec() }
                            };
                            for g in &groups {
                                self.add_group(&mut b, g, Category::Vk);
                            }
                        }
                    }
                }
                Err(e) => b.note(format!("groups.search: {e}")),
            }
        } else {
            b.note("Поиск сообществ VK не выполнялся: нужен пользовательский ключ (groups.search).");
        }
        Ok(b.finish())
    }
}
