//! Wikidata — structured, referenced statements about organisations: official website,
//! founding date, country, headquarters, industry, parent/subsidiary companies, LEI and
//! official accounts. Items describing people (P31 = Q5) are never processed.

use std::collections::{BTreeSet, HashMap};

use async_trait::async_trait;
use serde_json::Value;
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordResult,
};

use super::{arr, fmt_int, info, s, sp};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::output::{FindingExt, OutputBuilder};

const API: &str = "https://www.wikidata.org/w/api.php";
/// Properties that indicate an organisation-like item.
const ORG_PROPS: &[&str] = &["P856", "P159", "P452", "P1278", "P749", "P355", "P1128", "P414", "P3185", "P3789", "P2037", "P1454"];

pub struct Wikidata {
    info: AdapterInfo,
}

impl Default for Wikidata {
    fn default() -> Self {
        Self::new()
    }
}

fn claims<'a>(entity: &'a Value, prop: &str) -> &'a [Value] {
    entity.pointer(&format!("/claims/{prop}")).and_then(Value::as_array).map(|a| a.as_slice()).unwrap_or(&[])
}

/// Values of a property: strings, item ids (`Q…`), times (`+1998-09-04…` → `1998-09-04`) or amounts.
fn values(entity: &Value, prop: &str) -> Vec<String> {
    claims(entity, prop)
        .iter()
        .filter(|c| s(c, "rank").as_deref() != Some("deprecated"))
        .filter_map(|c| {
            let dv = c.pointer("/mainsnak/datavalue/value")?;
            if let Some(st) = dv.as_str() {
                return Some(st.to_string());
            }
            if let Some(id) = dv.get("id").and_then(Value::as_str) {
                return Some(id.to_string());
            }
            if let Some(t) = dv.get("time").and_then(Value::as_str) {
                return Some(t.trim_start_matches('+').chars().take(10).collect::<String>().replace("-00", ""));
            }
            if let Some(a) = dv.get("amount").and_then(Value::as_str) {
                return Some(a.trim_start_matches('+').to_string());
            }
            None
        })
        .collect()
}

fn label(entity: &Value) -> Option<String> {
    sp(entity, "/labels/ru/value").or_else(|| sp(entity, "/labels/en/value"))
}

fn description(entity: &Value) -> Option<String> {
    sp(entity, "/descriptions/ru/value").or_else(|| sp(entity, "/descriptions/en/value"))
}

impl Wikidata {
    pub fn new() -> Self {
        Wikidata {
            info: info(
                "wikidata",
                "Wikidata",
                "Wikimedia Foundation",
                "Структурированные сведения об организациях: официальный сайт, дата основания, страна, штаб-квартира, отрасль, \
                 материнские и дочерние компании, LEI, официальные аккаунты.",
                "MediaWiki API Wikidata: wbsearchentities (поиск по названию), CirrusSearch haswbstatement:P856 (поиск по официальному сайту), \
                 wbgetentities (утверждения). Используются утверждения с рангом normal/preferred; элементы о людях (P31=Q5) исключаются. \
                 Достоверность связей — 0.85 (сообщество редакторов, утверждения обычно снабжены ссылками).",
                &[Category::OrgIntel, Category::DigitalFootprint],
                &[InputKind::Text, InputKind::Domain, InputKind::Url],
                vec![],
                vec![],
                60,
                "https://www.wikidata.org/",
                Some("https://www.wikidata.org/w/api.php"),
                true,
            ),
        }
    }

    async fn api(&self, ctx: &ConnectorContext, params: &[(&str, &str)]) -> SwordResult<Value> {
        let mut p: Vec<(&str, &str)> = params.to_vec();
        p.push(("format", "json"));
        p.push(("formatversion", "2"));
        ctx.json(&self.info, ctx.get(API).query(&p)).await
    }

    async fn entities(&self, ctx: &ConnectorContext, ids: &[String], props: &str) -> SwordResult<HashMap<String, Value>> {
        let mut out = HashMap::new();
        for chunk in ids.chunks(45) {
            let joined = chunk.join("|");
            let v = self.api(ctx, &[("action", "wbgetentities"), ("ids", joined.as_str()), ("props", props), ("languages", "ru|en")]).await?;
            if let Some(obj) = v.get("entities").and_then(Value::as_object) {
                for (k, e) in obj {
                    out.insert(k.clone(), e.clone());
                }
            }
        }
        Ok(out)
    }
}

#[async_trait]
impl SourceAdapter for Wikidata {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        self.api(ctx, &[("action", "wbsearchentities"), ("search", "Wikimedia"), ("language", "en"), ("limit", "1")]).await?;
        Ok(vec![PermissionCheck::granted("MediaWiki API", "Доступ без ключа")])
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let mut b = OutputBuilder::new(&self.info);
        // 1. Candidate items
        let mut ids: Vec<String> = Vec::new();
        if let Some(d) = &input.registrable_domain {
            let variants = [
                format!("https://{d}/"),
                format!("https://{d}"),
                format!("https://www.{d}/"),
                format!("https://www.{d}"),
                format!("http://{d}/"),
                format!("http://www.{d}/"),
            ];
            let expr = format!("haswbstatement:{}", variants.iter().map(|v| format!("P856={v}")).collect::<Vec<_>>().join("|"));
            let v = self.api(ctx, &[("action", "query"), ("list", "search"), ("srsearch", expr.as_str()), ("srlimit", "5"), ("srnamespace", "0")]).await?;
            ids.extend(arr(&v, "/query/search").iter().filter_map(|r| s(r, "title")));
            b.source(&format!("https://www.wikidata.org/w/index.php?search={}", url::form_urlencoded::byte_serialize(expr.as_bytes()).collect::<String>()), &format!("Wikidata: официальный сайт {d}"));
        }
        if ids.is_empty() {
            let text = input.registrable_domain.as_deref().map(|d| d.split('.').next().unwrap_or(d).to_string()).unwrap_or_else(|| input.text.clone());
            let v = self
                .api(ctx, &[("action", "wbsearchentities"), ("search", text.as_str()), ("language", "ru"), ("uselang", "ru"), ("type", "item"), ("limit", "7")])
                .await?;
            ids.extend(arr(&v, "/search").iter().filter_map(|r| s(r, "id")));
            b.source(&format!("https://www.wikidata.org/w/index.php?search={}", url::form_urlencoded::byte_serialize(text.as_bytes()).collect::<String>()), &format!("Wikidata: поиск «{text}»"));
        }
        if ids.is_empty() {
            b.note("Wikidata: подходящих элементов не найдено.");
            return Ok(b.finish());
        }

        // 2. Statements
        let items = self.entities(ctx, &ids, "labels|descriptions|claims").await?;
        let orgs: Vec<(&String, &Value)> = ids
            .iter()
            .filter_map(|id| items.get(id).map(|e| (id, e)))
            .filter(|(_, e)| !values(e, "P31").iter().any(|v| v == "Q5"))
            .filter(|(_, e)| ORG_PROPS.iter().any(|p| !claims(e, p).is_empty()))
            .take(5)
            .collect();
        if orgs.is_empty() {
            b.note("Wikidata: найденные элементы не описывают организации.");
            return Ok(b.finish());
        }

        // 3. Labels of referenced items
        let mut refs = BTreeSet::new();
        for (_, e) in &orgs {
            for p in ["P17", "P159", "P452", "P749", "P355", "P31"] {
                refs.extend(values(e, p).into_iter().filter(|v| v.starts_with('Q')));
            }
        }
        let ref_ids: Vec<String> = refs.into_iter().take(120).collect();
        let ref_entities = self.entities(ctx, &ref_ids, "labels").await.unwrap_or_default();
        let name_of = |q: &str| ref_entities.get(q).and_then(label).unwrap_or_else(|| q.to_string());

        for (id, e) in orgs {
            let page = format!("https://www.wikidata.org/wiki/{id}");
            let name = label(e).unwrap_or_else(|| id.clone());
            let okey = keys::org("wikidata", id);
            b.entity(&okey, EntityKind::Organization, &name);
            let mut summary = Vec::new();
            if let Some(d) = description(e) {
                b.attr(&okey, "Описание", &d, &page);
                summary.push(d);
            }
            let named = |p: &str| values(e, p).iter().map(|q| name_of(q)).collect::<Vec<_>>().join(", ");
            for (prop, label_ru) in [("P31", "Тип"), ("P17", "Страна"), ("P159", "Штаб-квартира"), ("P452", "Отрасль")] {
                let v = named(prop);
                if !v.is_empty() {
                    b.attr(&okey, label_ru, &v, &page);
                    summary.push(format!("{label_ru}: {v}"));
                }
            }
            if let Some(inc) = values(e, "P571").first() {
                b.attr(&okey, "Основана", inc, &page);
                summary.push(format!("основана {inc}"));
            }
            if let Some(emp) = values(e, "P1128").first().and_then(|a| a.parse::<f64>().ok()) {
                b.attr(&okey, "Сотрудников (по Wikidata)", &fmt_int(emp as i64), &page);
            }
            for site in values(e, "P856").iter().take(3) {
                if let Some(host) = sword_core::util::host_of(site) {
                    let reg = sword_core::input::registrable(&host).unwrap_or(host);
                    let dkey = keys::domain(&reg);
                    b.entity(&dkey, EntityKind::Domain, &reg);
                    b.relate(&okey, &dkey, "official_website", 0.85, &page, Some("Wikidata P856"));
                }
            }
            for lei in values(e, "P1278").iter().take(2) {
                let lkey = keys::org("lei", lei);
                b.entity(&lkey, EntityKind::Organization, &name);
                b.attr(&lkey, "LEI", lei, &page);
                b.relate(&okey, &lkey, "same_as", 0.9, &page, Some("Wikidata P1278 (LEI)"));
            }
            for (prop, rel_self_is_child) in [("P749", true), ("P355", false)] {
                for q in values(e, prop).iter().filter(|q| q.starts_with('Q')).take(10) {
                    let other = keys::org("wikidata", q);
                    b.entity(&other, EntityKind::Organization, &name_of(q));
                    if rel_self_is_child {
                        b.relate(&okey, &other, "subsidiary_of", 0.85, &page, Some("Wikidata P749"));
                    } else {
                        b.relate(&other, &okey, "subsidiary_of", 0.85, &page, Some("Wikidata P355"));
                    }
                }
            }
            for (prop, base, label_ru) in [("P3185", "https://vk.com/", "VK"), ("P3789", "https://t.me/", "Telegram"), ("P2037", "https://github.com/", "GitHub")] {
                for acc in values(e, prop).iter().take(2) {
                    let url = format!("{base}{acc}");
                    let akey = keys::site(&url);
                    b.entity(&akey, EntityKind::Website, &format!("{label_ru}: {acc}"));
                    b.relate(&okey, &akey, "official_account", 0.85, &page, Some(&format!("Wikidata {prop}")));
                }
            }
            b.finding(Category::OrgIntel, FindingKind::Organization, &name, Some(&page))
                .snippet(&summary.join("; "))
                .confidence(0.85)
                .attr("Wikidata ID", id.clone())
                .attr("Официальный сайт", values(e, "P856").join(", "))
                .entity(&okey);
            b.fact(&format!("Организация (Wikidata {id})"), &format!("{name}: {}", summary.join("; ")), &page);
            b.source(&page, &name);
        }
        Ok(b.finish())
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_statement_values() {
        let e = serde_json::json!({
            "labels": {"ru": {"value": "Пример"}},
            "claims": {
                "P856": [{"rank": "normal", "mainsnak": {"datavalue": {"value": "https://example.org/"}}}],
                "P571": [{"rank": "normal", "mainsnak": {"datavalue": {"value": {"time": "+1998-09-04T00:00:00Z"}}}}],
                "P17": [{"rank": "deprecated", "mainsnak": {"datavalue": {"value": {"id": "Q1"}}}},
                        {"rank": "preferred", "mainsnak": {"datavalue": {"value": {"id": "Q30"}}}}]
            }
        });
        assert_eq!(values(&e, "P856"), vec!["https://example.org/"]);
        assert_eq!(values(&e, "P571"), vec!["1998-09-04"]);
        assert_eq!(values(&e, "P17"), vec!["Q30"]);
        assert_eq!(label(&e).as_deref(), Some("Пример"));
    }
}
