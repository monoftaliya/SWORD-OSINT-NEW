/** Shared helpers for the small SVG charts. */

/** Clean axis ticks from 0 to a rounded maximum (integers when `integer`). */
export function niceTicks(max: number, count = 3, integer = true): number[] {
  const target = Math.max(max, integer ? 1 : 1e-9);
  const raw = target / Math.max(1, count - 1);
  const p = Math.pow(10, Math.floor(Math.log10(raw)));
  const n = raw / p;
  let step = (n <= 1 ? 1 : n <= 2 ? 2 : n <= 2.5 ? 2.5 : n <= 5 ? 5 : 10) * p;
  if (integer) step = Math.max(1, Math.ceil(step));
  const ticks: number[] = [];
  for (let v = 0; v < target + step * 0.999; v += step) ticks.push(Number(v.toFixed(6)));
  if (ticks.length < 2) ticks.push(step);
  return ticks;
}

const compact = new Intl.NumberFormat('ru-RU', { notation: 'compact', maximumFractionDigits: 1 });
const full = new Intl.NumberFormat('ru-RU', { maximumFractionDigits: 1 });

/** Axis label: in full under 10 000, compact above. */
export function axisLabel(v: number): string {
  return Math.abs(v) >= 10_000 ? compact.format(v) : full.format(v);
}

/** «2026-11-02» → «02.11». */
export function shortDate(iso: string): string {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(iso);
  return m ? `${m[3]}.${m[2]}` : iso;
}

/** Bar path with a 4px rounded data-end and a square baseline. */
export function columnPath(x: number, y: number, w: number, h: number, r = 4): string {
  if (h <= 0) return '';
  const rr = Math.min(r, w / 2, h);
  return `M${x},${y + h}V${y + rr}Q${x},${y} ${x + rr},${y}H${x + w - rr}Q${x + w},${y} ${x + w},${y + rr}V${y + h}Z`;
}
