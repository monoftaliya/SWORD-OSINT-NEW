//! OpenAlex — open catalogue of scholarly works and institutions.

use async_trait::async_trait;
use serde_json::Value;
use sword_core::util::parse_date;
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordResult,
};

use super::{arr, cred, fmt_int, info, num, s, sp};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::output::{link_url_to_domain, FindingExt, OutputBuilder};

const API: &str = "https://api.openalex.org";
const KEY: &str = "openalex.api_key";

pub struct OpenAlex {
    info: AdapterInfo,
}

impl Default for OpenAlex {
    fn default() -> Self {
        Self::new()
    }
}

fn short_id(id: &str) -> String {
    id.rsplit('/').next().unwrap_or(id).to_string()
}

impl OpenAlex {
    pub fn new() -> Self {
        OpenAlex {
            info: info(
                "openalex",
                "OpenAlex",
                "OurResearch (некоммерческая организация)",
                "Научные публикации и организации (институты, компании) из открытого каталога OpenAlex с аффилиациями авторов.",
                "OpenAlex REST API: /works?search= и /institutions?search=. Связь «публикация — организация» строится только по \
                 аффилиациям, указанным в метаданных работы. Без ключа действует небольшой суточный лимит, с бесплатным ключом — выше.",
                &[Category::PublicDocuments, Category::OrgIntel],
                &[InputKind::Text],
                vec![cred(
                    KEY,
                    "API-ключ OpenAlex (необязательно)",
                    false,
                    "Бесплатный ключ увеличивает суточный лимит. Получите его в личном кабинете openalex.org (раздел API key).",
                    Some("https://developers.openalex.org/api-reference/authentication"),
                    None,
                )],
                vec![],
                60,
                "https://openalex.org/",
                Some("https://developers.openalex.org/"),
                true,
            ),
        }
    }

    fn with_auth(&self, ctx: &ConnectorContext, mut params: Vec<(&'static str, String)>) -> Vec<(&'static str, String)> {
        if let Some(k) = ctx.secret(KEY) {
            params.push(("api_key", k));
        }
        if let Some(mail) = &ctx.settings.network.contact_email {
            params.push(("mailto", mail.clone()));
        }
        params
    }
}

#[async_trait]
impl SourceAdapter for OpenAlex {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let params = self.with_auth(ctx, vec![("per-page", "1".into()), ("select", "id".into())]);
        let _: Value = ctx.json(&self.info, ctx.get(&format!("{API}/works")).query(&params)).await?;
        Ok(vec![PermissionCheck::granted(
            "REST API",
            if ctx.secret(KEY).is_some() { "Запросы с ключом API" } else { "Без ключа: ограниченный суточный лимит" },
        )])
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let mut b = OutputBuilder::new(&self.info);
        let q = input.text.clone();
        let per_page = ctx.max_results.clamp(5, 50).to_string();

        if ctx.wants(Category::OrgIntel) {
            let params = self.with_auth(ctx, vec![("search", q.clone()), ("per-page", "5".into())]);
            let v: Value = ctx.json(&self.info, ctx.get(&format!("{API}/institutions")).query(&params)).await?;
            for inst in arr(&v, "/results") {
                let Some(id) = s(inst, "id") else { continue };
                let name = s(inst, "display_name").unwrap_or_else(|| short_id(&id));
                let okey = match s(inst, "ror") {
                    Some(ror) => keys::org("ror", &short_id(&ror)),
                    None => keys::org("openalex", &short_id(&id)),
                };
                b.entity(&okey, EntityKind::Organization, &name);
                for (label, value) in [
                    ("Тип", s(inst, "type")),
                    ("Страна", s(inst, "country_code")),
                    ("Работ в OpenAlex", num(inst, "works_count").map(fmt_int)),
                    ("Цитирований", num(inst, "cited_by_count").map(fmt_int)),
                    ("ROR", s(inst, "ror")),
                ] {
                    if let Some(v) = value {
                        b.attr(&okey, label, &v, &id);
                    }
                }
                if let Some(home) = s(inst, "homepage_url") {
                    if let Some(host) = sword_core::util::host_of(&home) {
                        let reg = sword_core::input::registrable(&host).unwrap_or(host);
                        let dkey = keys::domain(&reg);
                        b.entity(&dkey, EntityKind::Domain, &reg);
                        b.relate(&okey, &dkey, "official_website", 0.85, &id, Some("homepage_url в OpenAlex"));
                    }
                }
                b.finding(Category::OrgIntel, FindingKind::Organization, &name, Some(&id))
                    .snippet(&format!(
                        "{}; страна: {}; работ: {}.",
                        s(inst, "type").unwrap_or_else(|| "организация".into()),
                        s(inst, "country_code").unwrap_or_else(|| "н/д".into()),
                        num(inst, "works_count").map(fmt_int).unwrap_or_else(|| "н/д".into())
                    ))
                    .confidence(0.85)
                    .entity(&okey);
                b.source(&id, &name);
            }
        }

        if ctx.wants(Category::PublicDocuments) {
            let params = self.with_auth(
                ctx,
                vec![
                    ("search", q.clone()),
                    ("per-page", per_page.clone()),
                    ("select", "id,doi,display_name,publication_date,primary_location,authorships,cited_by_count,type".into()),
                ],
            );
            let v: Value = ctx.json(&self.info, ctx.get(&format!("{API}/works")).query(&params)).await?;
            for w in arr(&v, "/results") {
                let Some(id) = s(w, "id") else { continue };
                let title = s(w, "display_name").unwrap_or_else(|| "Публикация".into());
                let landing = sp(w, "/primary_location/landing_page_url").or_else(|| s(w, "doi")).unwrap_or_else(|| id.clone());
                let pkey = keys::publication("openalex", &short_id(&id));
                b.entity(&pkey, EntityKind::Publication, &title);
                if let Some(doi) = s(w, "doi") {
                    b.attr(&pkey, "DOI", &doi, &id);
                }
                if let Some(venue) = sp(w, "/primary_location/source/display_name") {
                    b.attr(&pkey, "Издание", &venue, &id);
                }
                let mut affiliations = Vec::new();
                for a in arr(w, "/authorships").iter().take(20) {
                    for inst in arr(a, "/institutions") {
                        if let (Some(iid), Some(iname)) = (s(inst, "id"), s(inst, "display_name")) {
                            let okey = match s(inst, "ror") {
                                Some(ror) => keys::org("ror", &short_id(&ror)),
                                None => keys::org("openalex", &short_id(&iid)),
                            };
                            if !affiliations.contains(&okey) {
                                b.entity(&okey, EntityKind::Organization, &iname);
                                b.relate(&pkey, &okey, "affiliated_with", 0.9, &id, Some("аффилиация авторов в метаданных работы"));
                                affiliations.push(okey);
                            }
                        }
                    }
                }
                if landing.starts_with("http") && super::is_document_url(&landing) {
                    link_url_to_domain(&mut b, &pkey, &landing);
                }
                b.finding(Category::PublicDocuments, FindingKind::Publication, &title, Some(&landing))
                    .published(s(w, "publication_date").and_then(|d| parse_date(&d)))
                    .confidence(0.9)
                    .attr("Тип", s(w, "type").unwrap_or_default())
                    .attr("Цитирований", num(w, "cited_by_count").unwrap_or(0))
                    .attr("Организаций-аффилиаций", affiliations.len())
                    .entity(&pkey);
                b.source(&id, &title);
            }
        }
        Ok(b.finish())
    }
}
