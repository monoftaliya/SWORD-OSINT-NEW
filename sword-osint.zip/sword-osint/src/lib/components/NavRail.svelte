<script lang="ts">
  import Icon from './Icon.svelte';
  import { app, SECTIONS } from '../stores/app.svelte';
  import { run } from '../stores/run.svelte';

  const online = $derived(app.backend === 'ready');
</script>

<nav class="rail" aria-label="Разделы">
  <div class="items">
    {#each SECTIONS as s (s.id)}
      {@const active = app.section === s.id}
      {@const busy = (s.id === 'discovery' && run.discovery?.live) || (s.id === 'intelligence' && run.audit?.live)}
      <button class="item" class:active onclick={() => app.navigate(s.id)} aria-current={active ? 'page' : undefined}>
        <span class="glow"></span>
        <Icon name={s.icon} size={19} stroke={1.35} />
        {#if busy}<span class="busy"></span>{/if}
        <span class="tip">
          <span class="tip-title">{s.title}</span>
          <span class="tip-hint">{s.hint}</span>
        </span>
      </button>
    {/each}
  </div>
  <div class="foot" title={online ? 'Бэкенд подключён' : app.backendError ?? 'Подключение…'}>
    <span class="state" class:ok={online} class:err={app.backend === 'offline'}></span>
    <span class="ver mono">{app.info?.version ?? '—'}</span>
  </div>
</nav>

<style>
  .rail {
    position: fixed;
    top: var(--titlebar);
    left: 0;
    bottom: 0;
    width: var(--rail);
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 14px 0 16px;
    z-index: 40;
    background: linear-gradient(90deg, rgba(0, 0, 0, 0.66), rgba(0, 0, 0, 0));
  }
  .items {
    display: flex;
    flex-direction: column;
    gap: 6px;
    align-items: center;
  }
  .item {
    position: relative;
    width: 44px;
    height: 44px;
    display: grid;
    place-items: center;
    border: none;
    border-radius: 12px;
    background: transparent;
    color: var(--fg-3);
    cursor: pointer;
    transition: color 0.25s var(--ease), background 0.25s var(--ease);
  }
  .item:hover {
    color: var(--fg);
    background: rgba(255, 255, 255, 0.04);
  }
  .item.active {
    color: #fff;
    background: rgba(255, 255, 255, 0.06);
  }
  .item.active :global(.icon) {
    filter: drop-shadow(0 0 7px rgba(230, 240, 255, 0.75));
  }
  .glow {
    position: absolute;
    left: -12px;
    top: 50%;
    width: 2px;
    height: 0;
    border-radius: 2px;
    background: #fff;
    box-shadow: 0 0 12px 1px rgba(235, 242, 255, 0.85);
    transform: translateY(-50%);
    transition: height 0.35s var(--ease-out);
  }
  .item.active .glow {
    height: 22px;
  }
  .busy {
    position: absolute;
    right: 8px;
    top: 8px;
    width: 6px;
    height: 6px;
    border-radius: 50%;
    background: #fff;
    box-shadow: 0 0 8px #fff;
    animation: pulse 1.2s ease-in-out infinite;
  }
  .tip {
    position: absolute;
    left: 56px;
    top: 50%;
    transform: translate(-6px, -50%);
    opacity: 0;
    pointer-events: none;
    display: flex;
    flex-direction: column;
    gap: 2px;
    padding: 8px 12px;
    border-radius: 10px;
    background: rgba(8, 10, 13, 0.92);
    border: 1px solid var(--line);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
    white-space: nowrap;
    transition: opacity 0.18s var(--ease), transform 0.25s var(--ease);
    z-index: 60;
    text-align: left;
  }
  .item:hover .tip {
    opacity: 1;
    transform: translate(0, -50%);
  }
  .tip-title {
    font-family: var(--font-display);
    font-size: 10px;
    letter-spacing: 0.24em;
    color: #fff;
  }
  .tip-hint {
    font-size: 11.5px;
    color: var(--fg-3);
  }
  .foot {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
  }
  .state {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--fg-4);
  }
  .state.ok {
    background: var(--ok);
    box-shadow: 0 0 8px var(--ok);
  }
  .state.err {
    background: var(--err);
    box-shadow: 0 0 8px var(--err);
  }
  .ver {
    font-size: 9.5px;
    color: var(--fg-4);
  }
</style>
