<!--
  Single-series columns over time (≤24px thick, 4px rounded data-end, square baseline).
  Each column is its own hover/focus target with a tooltip.
-->
<script lang="ts">
  import { axisLabel, columnPath, niceTicks, shortDate } from './scale';
  import { fmtNum } from '../../util/format';

  let {
    data,
    name,
    height = 130,
    tone = 'neutral',
    format = (v: number) => fmtNum(v),
  }: { data: { label: string; value: number }[]; name: string; height?: number; tone?: 'neutral' | 'err'; format?: (v: number) => string } = $props();

  let width = $state(400);
  let active = $state<number | null>(null);

  const pad = { l: 36, r: 10, t: 10, b: 22 };
  const plotW = $derived(Math.max(10, width - pad.l - pad.r));
  const plotH = $derived(Math.max(10, height - pad.t - pad.b));
  const max = $derived(Math.max(0, ...data.map((d) => d.value)));
  const ticks = $derived(niceTicks(max, 3, true));
  const top = $derived(ticks[ticks.length - 1] || 1);
  const band = $derived(data.length ? plotW / data.length : plotW);
  const barW = $derived(Math.max(2, Math.min(24, band - 2)));
  const labelIdx = $derived(data.length <= 2 ? data.map((_, i) => i) : [0, Math.floor((data.length - 1) / 2), data.length - 1]);
  const empty = $derived(data.length === 0 || max === 0);

  function x(i: number) {
    return pad.l + i * band + (band - barW) / 2;
  }
  function h(v: number) {
    return (v / top) * plotH;
  }
</script>

<div class="chart {tone}" bind:clientWidth={width} style:height="{height}px">
  <svg {width} {height} role="img" aria-label="{name}: {data.length} столбцов">
    {#each ticks as t (t)}
      {@const y = pad.t + plotH - (t / top) * plotH}
      <line class="grid" x1={pad.l} x2={pad.l + plotW} y1={y} y2={y} />
      <text class="tick" x={pad.l - 8} y={y + 3.5} text-anchor="end">{axisLabel(t)}</text>
    {/each}
    {#each data as d, i (d.label)}
      <g
        class="col"
        class:on={active === i}
        role="button"
        tabindex="0"
        aria-label="{shortDate(d.label)}: {format(d.value)}"
        onpointerenter={() => (active = i)}
        onpointerleave={() => (active = null)}
        onfocus={() => (active = i)}
        onblur={() => (active = null)}
      >
        <rect class="hit" x={pad.l + i * band} y={pad.t} width={band} height={plotH} />
        <path class="bar" d={columnPath(x(i), pad.t + plotH - h(d.value), barW, h(d.value))} />
      </g>
    {/each}
    {#each labelIdx as i (i)}
      <text class="xlabel" x={x(i) + barW / 2} y={height - 6} text-anchor={i === 0 && data.length > 2 ? 'start' : i === data.length - 1 && data.length > 2 ? 'end' : 'middle'}>{shortDate(data[i].label)}</text>
    {/each}
  </svg>
  {#if empty}
    <div class="nodata">Нет данных за период</div>
  {/if}
  {#if active !== null && data[active]}
    {@const d = data[active]}
    <div class="tip" style:left="{Math.min(Math.max(x(active) + barW / 2, 70), width - 70)}px" style:top="{Math.max(0, pad.t + plotH - h(d.value) - 50)}px">
      <strong class="num">{format(d.value)}</strong>
      <span><i class="key"></i>{name} · {shortDate(d.label)}</span>
    </div>
  {/if}
</div>

<style>
  .chart {
    position: relative;
    width: 100%;
    --c: var(--silver);
  }
  .chart.err {
    --c: var(--err);
  }
  svg {
    display: block;
    overflow: visible;
  }
  .grid {
    stroke: rgba(255, 255, 255, 0.06);
    stroke-width: 1;
  }
  .tick,
  .xlabel {
    fill: var(--fg-3);
    font-size: 10px;
    font-variant-numeric: tabular-nums;
  }
  .hit {
    fill: transparent;
  }
  .col {
    outline: none;
    cursor: default;
  }
  .bar {
    fill: var(--c);
    opacity: 0.62;
    transition: opacity 0.15s;
  }
  .col.on .bar {
    opacity: 1;
  }
  .nodata {
    position: absolute;
    inset: 0;
    display: grid;
    place-items: center;
    color: var(--fg-3);
    font-size: 12px;
    pointer-events: none;
  }
  .tip {
    position: absolute;
    transform: translateX(-50%);
    display: flex;
    flex-direction: column;
    gap: 1px;
    padding: 6px 10px;
    border-radius: 8px;
    background: rgba(8, 10, 13, 0.94);
    border: 1px solid var(--line-strong);
    pointer-events: none;
    white-space: nowrap;
    font-size: 11px;
    color: var(--fg-2);
    z-index: 2;
  }
  .tip strong {
    font-size: 13px;
    color: #fff;
    font-weight: 600;
  }
  .key {
    display: inline-block;
    width: 8px;
    height: 8px;
    border-radius: 2px;
    margin-right: 6px;
    vertical-align: -1px;
    background: var(--c);
  }
</style>
