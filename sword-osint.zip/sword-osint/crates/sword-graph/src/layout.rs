//! Deterministic 2D force-directed layout (Fruchterman–Reingold) used for the static
//! graph figure in PDF reports. The interactive 3D layout runs in the UI (Web Worker).

use std::collections::HashMap;

use sword_core::EntityKind;

use crate::Graph;

/// Node positions normalised to the unit square `[0, 1]²`.
pub struct Layout2D {
    pub graph: Graph,
    pub positions: HashMap<String, (f32, f32)>,
}

/// Lay out at most `max_nodes` nodes (highest degree first; «source» nodes last).
pub fn layout_2d(graph: &Graph, max_nodes: usize, iterations: usize) -> Layout2D {
    let sub = top_subgraph(graph, max_nodes);
    let n = sub.nodes.len();
    let mut positions = HashMap::new();
    if n == 0 {
        return Layout2D { graph: sub, positions };
    }
    if n == 1 {
        positions.insert(sub.nodes[0].key.clone(), (0.5, 0.5));
        return Layout2D { graph: sub, positions };
    }

    let index: HashMap<&str, usize> = sub.nodes.iter().enumerate().map(|(i, nd)| (nd.key.as_str(), i)).collect();
    // Golden-angle spiral initialisation: deterministic and well spread.
    let golden = std::f32::consts::PI * (3.0 - 5f32.sqrt());
    let mut pos: Vec<(f32, f32)> = (0..n)
        .map(|i| {
            let r = ((i as f32 + 0.5) / n as f32).sqrt() * 0.45;
            let a = i as f32 * golden;
            (0.5 + r * a.cos(), 0.5 + r * a.sin())
        })
        .collect();
    let edges: Vec<(usize, usize, f32)> = sub
        .edges
        .iter()
        .filter_map(|e| Some((*index.get(e.from.as_str())?, *index.get(e.to.as_str())?, e.confidence)))
        .collect();

    let k = (1.0 / n as f32).sqrt() * 0.9;
    let mut temperature = 0.1f32;
    let cooling = temperature / (iterations.max(1) as f32 + 1.0);
    let mut disp = vec![(0f32, 0f32); n];

    for _ in 0..iterations {
        for d in disp.iter_mut() {
            *d = (0.0, 0.0);
        }
        for i in 0..n {
            for j in (i + 1)..n {
                let dx = pos[i].0 - pos[j].0;
                let dy = pos[i].1 - pos[j].1;
                let dist = (dx * dx + dy * dy).sqrt().max(1e-4);
                let force = k * k / dist;
                let (ux, uy) = (dx / dist, dy / dist);
                disp[i].0 += ux * force;
                disp[i].1 += uy * force;
                disp[j].0 -= ux * force;
                disp[j].1 -= uy * force;
            }
        }
        for &(a, b, w) in &edges {
            let dx = pos[a].0 - pos[b].0;
            let dy = pos[a].1 - pos[b].1;
            let dist = (dx * dx + dy * dy).sqrt().max(1e-4);
            let force = dist * dist / k * (0.5 + w * 0.5);
            let (ux, uy) = (dx / dist, dy / dist);
            disp[a].0 -= ux * force;
            disp[a].1 -= uy * force;
            disp[b].0 += ux * force;
            disp[b].1 += uy * force;
        }
        for i in 0..n {
            // gentle gravity towards the centre keeps disconnected parts on the page
            disp[i].0 += (0.5 - pos[i].0) * 0.05;
            disp[i].1 += (0.5 - pos[i].1) * 0.05;
            let len = (disp[i].0 * disp[i].0 + disp[i].1 * disp[i].1).sqrt().max(1e-6);
            let step = len.min(temperature);
            pos[i].0 += disp[i].0 / len * step;
            pos[i].1 += disp[i].1 / len * step;
        }
        temperature = (temperature - cooling).max(0.002);
    }

    // Normalise to [0.06, 0.94] keeping the aspect ratio.
    let (mut minx, mut miny, mut maxx, mut maxy) = (f32::MAX, f32::MAX, f32::MIN, f32::MIN);
    for &(x, y) in &pos {
        minx = minx.min(x);
        miny = miny.min(y);
        maxx = maxx.max(x);
        maxy = maxy.max(y);
    }
    let span = (maxx - minx).max(maxy - miny).max(1e-4);
    let (ox, oy) = ((1.0 - (maxx - minx) / span) / 2.0, (1.0 - (maxy - miny) / span) / 2.0);
    for (i, node) in sub.nodes.iter().enumerate() {
        let x = 0.06 + 0.88 * ((pos[i].0 - minx) / span + ox);
        let y = 0.06 + 0.88 * ((pos[i].1 - miny) / span + oy);
        positions.insert(node.key.clone(), (x, y));
    }
    Layout2D { graph: sub, positions }
}

/// Keep the most connected nodes and the edges among them.
pub fn top_subgraph(graph: &Graph, max_nodes: usize) -> Graph {
    if graph.nodes.len() <= max_nodes {
        return graph.clone();
    }
    let mut order: Vec<&crate::GraphNode> = graph.nodes.iter().collect();
    order.sort_by(|a, b| {
        let sa = a.kind == EntityKind::Source;
        let sb = b.kind == EntityKind::Source;
        sa.cmp(&sb).then(b.degree.cmp(&a.degree)).then(a.key.cmp(&b.key))
    });
    let keep: std::collections::HashSet<&str> = order.iter().take(max_nodes).map(|n| n.key.as_str()).collect();
    let nodes = graph.nodes.iter().filter(|n| keep.contains(n.key.as_str())).cloned().collect();
    let edges = graph
        .edges
        .iter()
        .filter(|e| keep.contains(e.from.as_str()) && keep.contains(e.to.as_str()))
        .cloned()
        .collect();
    let mut g = Graph { nodes, edges };
    g.recompute_degrees();
    g
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{GraphEdge, GraphNode};

    fn node(k: &str) -> GraphNode {
        GraphNode { key: k.into(), kind: EntityKind::Domain, label: k.into(), attributes: vec![], sources: vec![], degree: 0 }
    }

    #[test]
    fn positions_are_inside_unit_square() {
        let mut g = Graph { nodes: (0..12).map(|i| node(&format!("domain:n{i}.ru"))).collect(), edges: vec![] };
        for i in 1..12 {
            g.edges.push(GraphEdge {
                id: format!("e{i}"),
                from: "domain:n0.ru".into(),
                to: format!("domain:n{i}.ru"),
                relation: "subdomain_of".into(),
                label: String::new(),
                confidence: 1.0,
                evidence: vec![],
            });
        }
        g.recompute_degrees();
        let l = layout_2d(&g, 50, 200);
        assert_eq!(l.positions.len(), 12);
        for (x, y) in l.positions.values() {
            assert!(*x >= 0.0 && *x <= 1.0 && *y >= 0.0 && *y <= 1.0);
        }
    }
}
