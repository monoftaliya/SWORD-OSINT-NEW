<!--
  Per-source status of an investigation or audit: queued → running → result, with the
  honest reason for every skip or failure and a shortcut to fix missing credentials.
-->
<script lang="ts">
  import Icon from './Icon.svelte';
  import Bits from './Bits.svelte';
  import type { AdapterRun, ErrorKind, RunStatus } from '../api/types';
  import { app } from '../stores/app.svelte';
  import { ui } from '../stores/ui.svelte';
  import type { RunState } from '../stores/run.svelte';
  import { RUN_STATUS_LABEL } from '../util/labels';
  import { fmtAgo, fmtDuration, fmtNum } from '../util/format';

  let { run }: { run: RunState } = $props();

  const ERROR_HINT: Partial<Record<ErrorKind, string>> = {
    not_configured: 'не задан ключ или параметр',
    unauthorized: 'ключ отклонён сервисом',
    forbidden: 'нет прав на метод API',
    rate_limited: 'превышен лимит запросов',
    timeout: 'источник не ответил вовремя',
    network: 'нет соединения с источником',
    upstream: 'ошибка на стороне сервиса',
    unsupported: 'тип запроса не поддерживается',
  };

  type Row = { id: string; name: string; run: AdapterRun | null; willRun: boolean; reason: string | null };

  const rows = $derived.by<Row[]>(() => {
    const seen = new Set<string>();
    const list: Row[] = [];
    for (const p of run.plan) {
      seen.add(p.adapterId);
      list.push({ id: p.adapterId, name: p.name, run: run.runs[p.adapterId] ?? null, willRun: p.willRun, reason: p.reason });
    }
    for (const r of Object.values(run.runs)) {
      if (!seen.has(r.adapterId)) list.push({ id: r.adapterId, name: r.adapterName, run: r, willRun: r.status !== 'skipped', reason: r.message });
    }
    const order: Record<RunStatus, number> = { running: 0, queued: 1, done: 2, failed: 3, timed_out: 3, cancelled: 4, skipped: 5 };
    return list.sort((a, b) => order[a.run?.status ?? (a.willRun ? 'queued' : 'skipped')] - order[b.run?.status ?? (b.willRun ? 'queued' : 'skipped')]);
  });

  function statusOf(r: Row): RunStatus {
    return r.run?.status ?? (r.willRun ? 'queued' : 'skipped');
  }

  function tone(s: RunStatus): 'ok' | 'warn' | 'err' | 'idle' | 'live' {
    if (s === 'done') return 'ok';
    if (s === 'running') return 'live';
    if (s === 'failed' || s === 'timed_out') return 'err';
    if (s === 'cancelled') return 'warn';
    return 'idle';
  }

  function lastUpdate(id: string): string | null {
    const st = app.adapters.find((a) => a.info.id === id)?.status;
    return st?.lastSuccessAt ?? null;
  }

  function configure(id: string) {
    ui.settingsTab = 'connections';
    ui.settingsFocusAdapter = id;
    app.navigate('settings');
  }
</script>

<ul class="timeline">
  {#each rows as r (r.id)}
    {@const status = statusOf(r)}
    {@const fixable = r.run?.errorKind === 'not_configured' || r.run?.errorKind === 'unauthorized' || (!r.willRun && !!r.reason && /ключ|токен|настро/i.test(r.reason))}
    <li class={status}>
      <span class="mark">
        {#if status === 'running'}<Bits kind="spinner" />{:else}<Bits kind="dot" tone={tone(status)} />{/if}
      </span>
      <div class="main">
        <div class="line1">
          <span class="name">{r.name}</span>
          <span class="spacer"></span>
          {#if status === 'done'}
            <span class="count num">{fmtNum(r.run?.resultCount ?? 0)}</span>
          {/if}
          <span class="status">{RUN_STATUS_LABEL[status]}</span>
        </div>
        <div class="line2">
          {#if r.run?.durationMs !== null && r.run?.durationMs !== undefined}<span>{fmtDuration(r.run.durationMs)}</span>{/if}
          {#if r.run?.errorKind}<span class="why">{ERROR_HINT[r.run.errorKind] ?? r.run.errorKind}</span>{/if}
          {#if status === 'done' && (r.run?.resultCount ?? 0) === 0}<span>ничего не найдено</span>{/if}
          {#if lastUpdate(r.id)}<span class="faint">обновлено {fmtAgo(lastUpdate(r.id))}</span>{/if}
        </div>
        {#if (r.run?.message && status !== 'done') || (!r.willRun && r.reason)}
          <div class="msg">{r.run?.message ?? r.reason}</div>
        {/if}
        {#if fixable}
          <button class="fix" onclick={() => configure(r.id)}><Icon name="key" size={12} />Настроить подключение</button>
        {/if}
      </div>
    </li>
  {/each}
</ul>

<style>
  .timeline {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
  }
  li {
    display: flex;
    gap: 10px;
    padding: 8px 4px 9px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.04);
  }
  li:last-child {
    border-bottom: none;
  }
  .mark {
    width: 16px;
    display: grid;
    place-items: center;
    height: 18px;
    flex: none;
  }
  .main {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .line1 {
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .name {
    font-size: 12.5px;
    color: var(--fg);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .skipped .name,
  .queued .name {
    color: var(--fg-2);
  }
  .count {
    font-size: 12px;
    color: #fff;
  }
  .status {
    font-size: 10.5px;
    color: var(--fg-3);
    white-space: nowrap;
  }
  .line2 {
    display: flex;
    flex-wrap: wrap;
    gap: 4px 10px;
    font-size: 11px;
    color: var(--fg-3);
  }
  .why {
    color: var(--warn);
  }
  .failed .why,
  .timed_out .why {
    color: var(--err);
  }
  .msg {
    font-size: 11px;
    color: var(--fg-3);
    line-height: 1.4;
    user-select: text;
  }
  .fix {
    align-self: flex-start;
    display: inline-flex;
    align-items: center;
    gap: 5px;
    margin-top: 3px;
    padding: 2px 0;
    border: none;
    background: none;
    color: var(--fg-2);
    font-size: 11px;
    cursor: pointer;
  }
  .fix:hover {
    color: #fff;
  }
</style>
