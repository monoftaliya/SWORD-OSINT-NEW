//! Shared HTTP client: TLS via rustls (ring provider), system or explicit proxy,
//! per-source rate limiting, bounded retries for transient failures and a uniform mapping
//! of HTTP statuses to [`SwordError`].

use std::collections::HashMap;
use std::sync::{Arc, Mutex};
use std::time::Duration;

use reqwest::{Client, RequestBuilder, Response, StatusCode};
use serde::de::DeserializeOwned;
use sword_core::{NetworkSettings, SwordError, SwordResult, PRODUCT_NAME, VERSION};
use tokio_util::sync::CancellationToken;

use crate::ratelimit::RateLimiter;

/// Install the `ring` crypto provider for rustls once per process.
pub fn install_crypto_provider() {
    let _ = rustls::crypto::ring::default_provider().install_default();
}

#[derive(Clone)]
pub struct HttpClient {
    client: Client,
    no_redirect: Client,
    limiters: Arc<Mutex<HashMap<String, Arc<RateLimiter>>>>,
    user_agent: String,
}

pub fn user_agent(contact: Option<&str>) -> String {
    match contact {
        Some(c) if !c.trim().is_empty() => format!("{PRODUCT_NAME}/{VERSION} (Windows desktop OSINT client; contact: {})", c.trim()),
        _ => format!("{PRODUCT_NAME}/{VERSION} (Windows desktop OSINT client)"),
    }
}

impl HttpClient {
    pub fn new(net: &NetworkSettings) -> SwordResult<Self> {
        install_crypto_provider();
        let ua = user_agent(net.contact_email.as_deref());
        let build = |follow: bool| -> SwordResult<Client> {
            let mut b = Client::builder()
                .user_agent(ua.clone())
                .timeout(Duration::from_secs(net.request_timeout_secs.max(5) as u64))
                .connect_timeout(Duration::from_secs(10))
                .pool_idle_timeout(Duration::from_secs(60))
                .gzip(true)
                .brotli(true)
                .deflate(true)
                .redirect(if follow { reqwest::redirect::Policy::limited(6) } else { reqwest::redirect::Policy::none() });
            if let Some(p) = net.proxy_url.as_deref().filter(|p| !p.trim().is_empty()) {
                let proxy = reqwest::Proxy::all(p.trim()).map_err(|e| SwordError::InvalidInput(format!("адрес прокси: {e}")))?;
                b = b.proxy(proxy);
            }
            b.build().map_err(|e| SwordError::Internal(format!("не удалось создать HTTP-клиент: {e}")))
        };
        Ok(HttpClient {
            client: build(true)?,
            no_redirect: build(false)?,
            limiters: Arc::new(Mutex::new(HashMap::new())),
            user_agent: ua,
        })
    }

    pub fn client(&self) -> &Client {
        &self.client
    }

    /// Client that does not follow redirects (used to verify HTTP→HTTPS redirects).
    pub fn no_redirect(&self) -> &Client {
        &self.no_redirect
    }

    pub fn user_agent(&self) -> &str {
        &self.user_agent
    }

    pub fn limiter(&self, key: &str, per_minute: u32) -> Arc<RateLimiter> {
        let mut map = self.limiters.lock().unwrap_or_else(|p| p.into_inner());
        map.entry(key.to_string()).or_insert_with(|| Arc::new(RateLimiter::new(per_minute))).clone()
    }

    /// Send a request under the rate limit of `key`. Retries twice on 429/503 when the
    /// source asks for a short wait, and once on connection errors.
    pub async fn send(
        &self,
        key: &str,
        per_minute: u32,
        req: RequestBuilder,
        cancel: &CancellationToken,
    ) -> SwordResult<Response> {
        let limiter = self.limiter(key, per_minute);
        let mut attempt = 0u32;
        loop {
            limiter.acquire(cancel).await?;
            let rb = req.try_clone().ok_or_else(|| SwordError::Internal("запрос нельзя повторить".into()))?;
            let result = tokio::select! {
                _ = cancel.cancelled() => return Err(SwordError::Cancelled),
                r = rb.send() => r,
            };
            match result {
                Ok(resp) => {
                    let status = resp.status();
                    if status == StatusCode::TOO_MANY_REQUESTS || status == StatusCode::SERVICE_UNAVAILABLE {
                        let retry = retry_after(&resp);
                        limiter.penalize(retry.unwrap_or(if status == StatusCode::TOO_MANY_REQUESTS { 10 } else { 3 })).await;
                        if attempt < 2 && retry.map(|s| s <= 30).unwrap_or(true) {
                            attempt += 1;
                            continue;
                        }
                        if status == StatusCode::TOO_MANY_REQUESTS {
                            return Err(SwordError::RateLimited { retry_after_secs: retry });
                        }
                        return Err(SwordError::Upstream("HTTP 503 — сервис временно недоступен".into()));
                    }
                    return Ok(resp);
                }
                Err(e) => {
                    let err = map_reqwest_error(&e);
                    if attempt < 1 && matches!(err, SwordError::Network(_)) {
                        attempt += 1;
                        tokio::select! {
                            _ = cancel.cancelled() => return Err(SwordError::Cancelled),
                            _ = tokio::time::sleep(Duration::from_millis(700)) => {}
                        }
                        continue;
                    }
                    return Err(err);
                }
            }
        }
    }
}

fn retry_after(resp: &Response) -> Option<u64> {
    resp.headers().get(reqwest::header::RETRY_AFTER).and_then(|v| v.to_str().ok()).and_then(|s| s.trim().parse::<u64>().ok())
}

pub fn map_reqwest_error(e: &reqwest::Error) -> SwordError {
    if e.is_timeout() {
        SwordError::Timeout
    } else if e.is_decode() {
        SwordError::Parse(e.to_string())
    } else if e.is_connect() || e.is_request() || e.is_body() {
        SwordError::Network(root_cause(e))
    } else if let Some(s) = e.status() {
        status_error(s, "")
    } else {
        SwordError::Network(root_cause(e))
    }
}

fn root_cause(e: &(dyn std::error::Error + 'static)) -> String {
    let mut msg = e.to_string();
    let mut src = e.source();
    while let Some(s) = src {
        msg = s.to_string();
        src = s.source();
    }
    msg
}

/// Map a non-success status to an error with a short excerpt of the body.
pub fn status_error(status: StatusCode, body_excerpt: &str) -> SwordError {
    let detail = if body_excerpt.is_empty() {
        format!("HTTP {}", status.as_u16())
    } else {
        format!("HTTP {}: {}", status.as_u16(), sword_core::util::truncate_chars(body_excerpt.trim(), 160))
    };
    match status.as_u16() {
        401 => SwordError::Unauthorized(detail),
        403 => SwordError::Forbidden(detail),
        404 | 410 => SwordError::NotFound(detail),
        408 | 504 => SwordError::Timeout,
        429 => SwordError::RateLimited { retry_after_secs: None },
        400..=499 => SwordError::InvalidInput(detail),
        _ => SwordError::Upstream(detail),
    }
}

/// Fail on non-2xx responses (with a body excerpt for diagnostics).
pub async fn ensure_success(resp: Response) -> SwordResult<Response> {
    let status = resp.status();
    if status.is_success() {
        return Ok(resp);
    }
    let body = read_text(resp, 2048).await.unwrap_or_default();
    Err(status_error(status, &sword_core::util::strip_html(&body)))
}

/// Read a body as text, keeping at most `max_bytes` (UTF-8 lossy).
pub async fn read_text(mut resp: Response, max_bytes: usize) -> SwordResult<String> {
    let mut buf: Vec<u8> = Vec::new();
    while let Some(chunk) = resp.chunk().await.map_err(|e| map_reqwest_error(&e))? {
        let room = max_bytes.saturating_sub(buf.len());
        if room == 0 {
            break;
        }
        buf.extend_from_slice(&chunk[..chunk.len().min(room)]);
        if buf.len() >= max_bytes {
            break;
        }
    }
    Ok(String::from_utf8_lossy(&buf).into_owned())
}

/// Read raw bytes (bounded).
pub async fn read_bytes(mut resp: Response, max_bytes: usize) -> SwordResult<Vec<u8>> {
    let mut buf: Vec<u8> = Vec::new();
    while let Some(chunk) = resp.chunk().await.map_err(|e| map_reqwest_error(&e))? {
        let room = max_bytes.saturating_sub(buf.len());
        if room == 0 {
            break;
        }
        buf.extend_from_slice(&chunk[..chunk.len().min(room)]);
    }
    Ok(buf)
}

/// Parse JSON after checking the status. Bodies above 16 MiB are rejected.
pub async fn read_json<T: DeserializeOwned>(resp: Response) -> SwordResult<T> {
    let resp = ensure_success(resp).await?;
    let text = read_text(resp, 16 * 1024 * 1024).await?;
    serde_json::from_str(&text).map_err(|e| SwordError::Parse(format!("JSON: {e}")))
}
