<!--
  DATABASES — connected sources (live status, permissions, limits, last update), the
  local knowledge base (full-text search over every stored result) and the storage
  (SQLite statistics, integrity, backup, export, retention, optional OpenSearch).
-->
<script lang="ts">
  import { onMount } from 'svelte';
  import Icon from '../lib/components/Icon.svelte';
  import Bits from '../lib/components/Bits.svelte';
  import Panel from '../lib/components/Panel.svelte';
  import Segmented from '../lib/components/Segmented.svelte';
  import Toggle from '../lib/components/Toggle.svelte';
  import Modal from '../lib/components/Modal.svelte';
  import StatTile from '../lib/components/StatTile.svelte';
  import FindingDrawer from '../lib/components/FindingDrawer.svelte';
  import { api, desktop } from '../lib/api/client';
  import type { AdapterView, Category, DbStats, FindingKind, KnowledgeHit } from '../lib/api/types';
  import { app } from '../lib/stores/app.svelte';
  import { run } from '../lib/stores/run.svelte';
  import { ui } from '../lib/stores/ui.svelte';
  import { CATEGORIES, FINDING_KIND_LABEL, HEALTH_META, categoryMeta } from '../lib/util/labels';
  import { debounce, fmtAgo, fmtBytes, fmtDate, fmtNum, hostOf } from '../lib/util/format';
  import { guarded, openLink } from '../lib/components/ui';

  // ---------------------------------------------------------------- sources
  let checking = $state<Record<string, boolean>>({});
  let checkingAll = $state(false);
  let catFilter = $state<Category | 'all'>('all');

  const adapters = $derived(catFilter === 'all' ? app.adapters : app.adapters.filter((a) => a.info.categories.includes(catFilter as Category)));
  const healthCounts = $derived.by(() => {
    const c = { ok: 0, warn: 0, err: 0, idle: 0 };
    for (const a of app.adapters) c[HEALTH_META[a.status.health].tone]++;
    return c;
  });

  async function check(a: AdapterView) {
    checking = { ...checking, [a.info.id]: true };
    const st = await guarded(() => api.checkAdapter(a.info.id), a.info.name);
    checking = { ...checking, [a.info.id]: false };
    if (st) app.replaceAdapter({ ...a, status: st });
  }

  async function checkAll() {
    checkingAll = true;
    await guarded(() => api.checkAllAdapters(), 'Проверка источников');
    await app.refreshAdapters();
    checkingAll = false;
  }

  async function setEnabled(a: AdapterView, enabled: boolean) {
    const v = await guarded(() => api.setAdapterEnabled(a.info.id, enabled), a.info.name);
    if (v) app.replaceAdapter(v);
  }

  function configure(id: string) {
    ui.settingsTab = 'connections';
    ui.settingsFocusAdapter = id;
    app.navigate('settings');
  }

  // ---------------------------------------------------------------- knowledge
  let hits = $state<KnowledgeHit[]>([]);
  let kbLoading = $state(false);
  let kbAdapter = $state('');
  let kbCategory = $state('');
  let kbKind = $state('');
  let kbSelected = $state<KnowledgeHit | null>(null);
  let kbSearched = $state(false);

  const searchKb = debounce(async (text: string, adapter: string, category: string, kind: string) => {
    if (!desktop() || text.trim().length < 2) {
      hits = [];
      kbSearched = false;
      return;
    }
    kbLoading = true;
    const res = await guarded(() => api.searchKnowledge({ text, adapter: adapter || undefined, category: category || undefined, kind: kind || undefined, limit: 200 }), 'Поиск по базе знаний');
    kbLoading = false;
    kbSearched = true;
    hits = res ?? [];
  }, 300);

  $effect(() => {
    if (ui.databasesTab === 'knowledge') searchKb(ui.knowledgeText, kbAdapter, kbCategory, kbKind);
  });

  // ---------------------------------------------------------------- storage
  let stats = $state<DbStats | null>(null);
  let busy = $state<string | null>(null);
  let integrity = $state<string[] | null>(null);
  let purgeDays = $state(180);
  let confirmPurge = $state(false);
  let confirmClear = $state(false);
  let osPassword = $state('');
  let osResult = $state<string | null>(null);

  async function loadStats() {
    if (!desktop()) return;
    stats = await guarded(() => api.dbStats(), 'Статистика базы');
  }

  async function action<T>(name: string, fn: () => Promise<T>, label: string): Promise<T | null> {
    busy = name;
    const r = await guarded(fn, label);
    busy = null;
    return r;
  }

  async function integrityCheck() {
    integrity = await action('integrity', () => api.dbIntegrityCheck(), 'Проверка целостности');
  }

  async function vacuum() {
    const before = stats?.sizeBytes ?? 0;
    const s = await action('vacuum', () => api.dbVacuum(), 'Сжатие базы');
    if (s) {
      stats = s;
      app.toast('ok', `База сжата: ${fmtBytes(before)} → ${fmtBytes(s.sizeBytes)}`);
    }
  }

  async function backup() {
    const p = await action('backup', () => api.dbBackup(), 'Резервная копия');
    if (p) app.toast('ok', `Резервная копия: ${p}`, 7000);
  }

  async function exportAll() {
    const p = await action('export', () => api.dbExportAll(), 'Экспорт базы');
    if (p) app.toast('ok', `Экспортировано: ${p}`, 7000);
  }

  async function purge() {
    confirmPurge = false;
    const n = await action('purge', () => api.dbPurge(purgeDays), 'Очистка');
    if (n !== null) {
      app.toast('ok', `Удалено исследований: ${n}`);
      loadStats();
    }
  }

  async function clearHistory() {
    confirmClear = false;
    const ok = await action('clear', () => api.dbClearHistory().then(() => true), 'Очистка истории');
    if (ok) {
      run.clearDiscovery();
      app.toast('ok', 'История и результаты удалены');
      loadStats();
    }
  }

  async function saveOsPassword() {
    if (!osPassword) return;
    const r = await guarded(() => api.setCredential('opensearch.password', osPassword), 'Пароль OpenSearch');
    osPassword = '';
    if (r) app.toast('ok', 'Пароль OpenSearch сохранён в хранилище Windows');
  }

  async function osTest() {
    osResult = await action('os-test', () => api.opensearchTest(), 'OpenSearch');
  }

  async function osReindex() {
    const n = await action('os-reindex', () => api.opensearchReindex(), 'Переиндексация');
    if (n !== null) app.toast('ok', `Проиндексировано результатов: ${fmtNum(n)}`);
  }

  $effect(() => {
    if (ui.databasesTab === 'storage') loadStats();
  });

  onMount(() => {
    if (desktop() && !app.adapters.length) app.refreshAdapters();
  });
</script>

<div class="section-root dbs enter">
  <div class="head">
    <Segmented
      bind:value={ui.databasesTab}
      options={[
        { value: 'sources', label: 'Источники' },
        { value: 'knowledge', label: 'База знаний' },
        { value: 'storage', label: 'Хранилище' },
      ]}
    />
    <span class="spacer"></span>
    {#if ui.databasesTab === 'sources'}
      <span class="faint small">
        <Bits kind="dot" tone="ok" /> {healthCounts.ok} доступны · <Bits kind="dot" tone="warn" /> {healthCounts.warn} ограничены · <Bits kind="dot" tone="err" />
        {healthCounts.err} с ошибкой · <Bits kind="dot" /> {healthCounts.idle} не настроены/не проверены
      </span>
      <button class="btn sm" onclick={checkAll} disabled={!desktop() || checkingAll}>{#if checkingAll}<Bits kind="spinner" />{:else}<Icon name="refresh" size={14} />{/if}Проверить все</button>
    {/if}
  </div>

  {#if ui.databasesTab === 'sources'}
    <div class="catbar">
      <button class="chip" class:on={catFilter === 'all'} onclick={() => (catFilter = 'all')}>Все · {app.adapters.length}</button>
      {#each CATEGORIES as c (c.id)}
        <button class="chip" class:on={catFilter === c.id} onclick={() => (catFilter = c.id)}><Icon name={c.icon} size={12} />{c.label}</button>
      {/each}
    </div>
    <div class="grid scroll">
      {#each adapters as a (a.info.id)}
        {@const h = HEALTH_META[a.status.health]}
        <article class="card glass">
          <header>
            <div class="t">
              <span class="name">{a.info.name}</span>
              <span class="prov">{a.info.provider}{a.info.officialApi ? ' · официальный API' : ''}</span>
            </div>
            <Toggle checked={a.enabled} onchange={(v) => setEnabled(a, v)} disabled={!desktop()} />
          </header>
          <p class="desc">{a.info.description}</p>
          <div class="health">
            <Bits kind="dot" tone={h.tone} />
            <span class="hl">{h.label}</span>
            {#if a.status.latencyMs !== null}<span class="faint">{a.status.latencyMs} мс</span>{/if}
            <span class="spacer"></span>
            <button class="btn sm ghost" onclick={() => check(a)} disabled={!desktop() || checking[a.info.id]}>
              {#if checking[a.info.id]}<Bits kind="spinner" />{:else}<Icon name="refresh" size={13} />{/if}Проверить
            </button>
          </div>
          {#if a.status.message}<p class="msg">{a.status.message}</p>{/if}
          <dl>
            <dt>Последняя проверка</dt>
            <dd>{fmtAgo(a.status.checkedAt)}</dd>
            <dt>Последнее обновление</dt>
            <dd>{a.status.lastSuccessAt ? fmtAgo(a.status.lastSuccessAt) : 'данные ещё не получались'}</dd>
            <dt>Лимит</dt>
            <dd>{a.info.rateLimitPerMinute} запр./мин</dd>
            <dt>Категории</dt>
            <dd>{a.info.categories.map((c) => categoryMeta(c).short).join(' · ')}</dd>
          </dl>
          {#if a.status.permissions.length}
            <ul class="perms">
              {#each a.status.permissions as p, i (i)}
                <li class:no={!p.granted}><Icon name={p.granted ? 'check' : 'x'} size={12} /><span>{p.name}</span><span class="pd">{p.detail}</span></li>
              {/each}
            </ul>
          {/if}
          <footer>
            {#if a.missing.length}<span class="miss"><Icon name="key" size={12} />нужно: {a.missing.join(', ')}</span>{/if}
            <span class="spacer"></span>
            <button class="btn sm ghost" onclick={() => openLink(a.info.docsUrl ?? a.info.homepage)}><Icon name="external" size={12} />Документация</button>
            {#if a.info.credentials.length || a.info.options.length}
              <button class="btn sm" onclick={() => configure(a.info.id)}><Icon name="settings" size={13} />Настроить</button>
            {/if}
          </footer>
        </article>
      {:else}
        <div class="empty">{desktop() ? 'Источники загружаются…' : 'Каталог источников доступен в настольном приложении.'}</div>
      {/each}
    </div>
  {:else if ui.databasesTab === 'knowledge'}
    <div class="kb">
      <Panel title="База знаний" subtitle="Полнотекстовый поиск по всем сохранённым результатам" class="kbpanel" pad={false}>
        <div class="kbbar">
          <Icon name="search" size={16} />
          <input class="input q" placeholder="Слова, домен, название организации… (поддерживаются кавычки и префиксы)" bind:value={ui.knowledgeText} />
          <select class="select" bind:value={kbCategory} aria-label="Категория">
            <option value="">все категории</option>
            {#each CATEGORIES as c (c.id)}<option value={c.id}>{c.label}</option>{/each}
          </select>
          <select class="select" bind:value={kbAdapter} aria-label="Источник">
            <option value="">все источники</option>
            {#each app.adapters as a (a.info.id)}<option value={a.info.id}>{a.info.name}</option>{/each}
          </select>
          <select class="select" bind:value={kbKind} aria-label="Тип">
            <option value="">все типы</option>
            {#each Object.entries(FINDING_KIND_LABEL) as [k, l] (k)}<option value={k}>{l}</option>{/each}
          </select>
          {#if kbLoading}<Bits kind="spinner" />{/if}
        </div>
        <div class="hits scroll">
          {#if !ui.knowledgeText.trim()}
            <div class="empty">Введите запрос — поиск идёт по заголовкам, фрагментам и ссылкам всех результатов в локальной базе.</div>
          {:else if kbSearched && !hits.length}
            <div class="empty">Совпадений нет.</div>
          {/if}
          <ul>
            {#each hits as h (h.finding.id + h.investigationId)}
              <li>
                <button class="hit" class:on={kbSelected?.finding.id === h.finding.id} onclick={() => (kbSelected = kbSelected?.finding.id === h.finding.id ? null : h)}>
                  <span class="ht">{h.finding.title}</span>
                  {#if h.finding.snippet}<span class="hs">{h.finding.snippet}</span>{/if}
                  <span class="hm">
                    <span>{FINDING_KIND_LABEL[h.finding.kind as FindingKind]}</span>
                    {#if h.finding.url}<span class="mono">{hostOf(h.finding.url)}</span>{/if}
                    <span>{categoryMeta(h.finding.category).label}</span>
                    <span class="spacer"></span>
                    <span class="inv">«{h.investigationQuery}» · {fmtDate(h.investigationCreatedAt)}</span>
                  </span>
                </button>
              </li>
            {/each}
          </ul>
        </div>
      </Panel>
      {#if kbSelected}
        <div class="kbside">
          <FindingDrawer finding={kbSelected.finding} onclose={() => (kbSelected = null)} />
          <button class="btn sm" onclick={() => kbSelected && run.open(kbSelected.investigationId)}><Icon name="history" size={14} />Открыть исследование</button>
        </div>
      {/if}
    </div>
  {:else}
    <div class="storage scroll">
      {#if stats}
        <div class="tiles">
          <StatTile label="Размер базы" value={fmtBytes(stats.sizeBytes)} sub="журнал WAL {fmtBytes(stats.walBytes)}" />
          <StatTile label="Страницы" value={fmtNum(stats.pageCount)} sub="{fmtNum(stats.freelistPages)} свободных · {fmtBytes(stats.pageSize)}" />
          <StatTile label="Схема" value="v{stats.schemaVersion}" sub="SQLite {stats.sqliteVersion}" />
          <StatTile label="Исследования" value={fmtNum(stats.tables.find((t) => t.name === 'investigations')?.rows ?? 0)} sub="{fmtNum(stats.tables.find((t) => t.name === 'findings')?.rows ?? 0)} результатов" />
        </div>
      {/if}
      <div class="sgrid">
        <Panel title="Таблицы" subtitle={stats?.path ?? ''} class="tables">
          {#if stats}
            <table class="table">
              <thead><tr><th>Таблица</th><th class="r">Строк</th></tr></thead>
              <tbody>
                {#each stats.tables as t (t.name)}
                  <tr><td class="mono">{t.name}</td><td class="r num">{fmtNum(t.rows)}</td></tr>
                {/each}
              </tbody>
            </table>
          {:else}
            <div class="empty small">{desktop() ? 'Загрузка…' : 'Доступно в настольном приложении.'}</div>
          {/if}
        </Panel>

        <Panel title="Обслуживание" class="maint">
          <div class="col">
            <div class="act">
              <div><b>Проверка целостности</b><span>PRAGMA integrity_check по всей базе.</span></div>
              <button class="btn sm" onclick={integrityCheck} disabled={!desktop() || busy !== null}>{#if busy === 'integrity'}<Bits kind="spinner" />{/if}Проверить</button>
            </div>
            {#if integrity}
              <div class="result" class:ok={integrity.length === 1 && integrity[0] === 'ok'}>{integrity.join('; ')}</div>
            {/if}
            <div class="act">
              <div><b>Сжатие (VACUUM)</b><span>Освобождает место после удаления данных.</span></div>
              <button class="btn sm" onclick={vacuum} disabled={!desktop() || busy !== null}>{#if busy === 'vacuum'}<Bits kind="spinner" />{/if}Сжать</button>
            </div>
            <div class="act">
              <div><b>Резервная копия</b><span>Согласованная копия базы (VACUUM INTO) в выбранный файл.</span></div>
              <button class="btn sm" onclick={backup} disabled={!desktop() || busy !== null}><Icon name="download" size={13} />Сохранить копию</button>
            </div>
            <div class="act">
              <div><b>Экспорт всех данных</b><span>Исследования, результаты, источники и граф в JSON.</span></div>
              <button class="btn sm" onclick={exportAll} disabled={!desktop() || busy !== null}><Icon name="download" size={13} />Экспорт JSON</button>
            </div>
            <div class="act">
              <div><b>Удалить старые исследования</b><span>Старше заданного числа дней, вместе с результатами и графом.</span></div>
              <div class="row">
                <input class="input days" type="number" min="1" max="3650" bind:value={purgeDays} aria-label="Дней" />
                <button class="btn sm danger" onclick={() => (confirmPurge = true)} disabled={!desktop() || busy !== null || purgeDays < 1}>Удалить</button>
              </div>
            </div>
            <div class="act">
              <div><b>Очистить историю</b><span>Удаляет все исследования и аудиты. Настройки, активы и ключи сохраняются.</span></div>
              <button class="btn sm danger" onclick={() => (confirmClear = true)} disabled={!desktop() || busy !== null}><Icon name="trash" size={13} />Очистить</button>
            </div>
            <div class="row">
              <button class="btn sm ghost" onclick={() => guarded(() => api.openDataDir(), 'Папка данных')} disabled={!desktop()}><Icon name="folder" size={13} />Папка данных</button>
              <button class="btn sm ghost" onclick={() => guarded(() => api.openLogsDir(), 'Журналы')} disabled={!desktop()}><Icon name="file" size={13} />Журналы</button>
            </div>
          </div>
        </Panel>

        <Panel title="OpenSearch" subtitle="Необязательный внешний поисковый индекс" class="os">
          <div class="col">
            <p class="help">
              По умолчанию поиск выполняет встроенный SQLite FTS5. Если указан кластер OpenSearch (SETTINGS → Поиск), результаты
              дополнительно индексируются в нём, а поиск по базе знаний идёт через OpenSearch.
            </p>
            <dl class="osd">
              <dt>Движок</dt>
              <dd>{app.settings?.search.backend === 'opensearch' ? 'OpenSearch' : 'SQLite FTS5'}</dd>
              <dt>Адрес</dt>
              <dd class="mono">{app.settings?.search.opensearchUrl ?? '—'}</dd>
              <dt>Индекс</dt>
              <dd class="mono">{app.settings?.search.opensearchIndex ?? '—'}</dd>
            </dl>
            <div class="row">
              <input class="input" type="password" placeholder="Пароль пользователя OpenSearch" bind:value={osPassword} autocomplete="off" />
              <button class="btn sm" onclick={saveOsPassword} disabled={!desktop() || !osPassword}>Сохранить</button>
            </div>
            <div class="row">
              <button class="btn sm" onclick={osTest} disabled={!desktop() || !app.settings?.search.opensearchUrl || busy !== null}>{#if busy === 'os-test'}<Bits kind="spinner" />{/if}Проверить подключение</button>
              <button class="btn sm" onclick={osReindex} disabled={!desktop() || !app.settings?.search.opensearchUrl || busy !== null}>{#if busy === 'os-reindex'}<Bits kind="spinner" />{/if}Переиндексировать</button>
            </div>
            {#if osResult}<div class="result ok">{osResult}</div>{/if}
          </div>
        </Panel>
      </div>
    </div>
  {/if}
</div>

<Modal bind:open={confirmPurge} title="Удалить старые исследования">
  <p class="muted">Удалить все исследования и аудиты старше {purgeDays} дн. вместе с результатами, графом и черновиками отчётов? Действие необратимо.</p>
  {#snippet footer()}
    <button class="btn sm ghost" onclick={() => (confirmPurge = false)}>Отмена</button>
    <button class="btn sm danger" onclick={purge}>Удалить</button>
  {/snippet}
</Modal>

<Modal bind:open={confirmClear} title="Очистить историю">
  <p class="muted">Будут удалены все исследования, аудиты, результаты и граф связей. Настройки, ключи API и ваши активы останутся. Действие необратимо.</p>
  {#snippet footer()}
    <button class="btn sm ghost" onclick={() => (confirmClear = false)}>Отмена</button>
    <button class="btn sm danger" onclick={clearHistory}><Icon name="trash" size={13} />Очистить всё</button>
  {/snippet}
</Modal>

<style>
  .head {
    display: flex;
    align-items: center;
    gap: 12px;
  }
  .head .small {
    display: inline-flex;
    align-items: center;
    gap: 6px;
  }
  .catbar {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  }
  .catbar .chip {
    cursor: pointer;
  }
  .catbar .chip.on {
    color: #fff;
    border-color: rgba(230, 238, 250, 0.4);
    background: rgba(230, 238, 250, 0.08);
  }
  .grid {
    flex: 1;
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(330px, 1fr));
    gap: 12px;
    align-content: start;
    padding-right: 4px;
  }
  .card {
    display: flex;
    flex-direction: column;
    gap: 9px;
    padding: 14px 14px 12px;
  }
  .card header {
    display: flex;
    justify-content: space-between;
    gap: 10px;
  }
  .t {
    display: flex;
    flex-direction: column;
    gap: 2px;
    min-width: 0;
  }
  .name {
    font-size: 14px;
    font-weight: 500;
    color: #fff;
  }
  .prov {
    font-size: 11px;
    color: var(--fg-3);
  }
  .desc {
    margin: 0;
    font-size: 12px;
    color: var(--fg-2);
    line-height: 1.5;
  }
  .health {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 12px;
  }
  .msg {
    margin: 0;
    font-size: 11.5px;
    color: var(--fg-3);
    line-height: 1.45;
  }
  dl {
    display: grid;
    grid-template-columns: auto 1fr;
    gap: 3px 12px;
    margin: 0;
    font-size: 11.5px;
  }
  dt {
    color: var(--fg-3);
  }
  dd {
    margin: 0;
    color: var(--fg-2);
  }
  .perms {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 3px;
    font-size: 11.5px;
  }
  .perms li {
    display: grid;
    grid-template-columns: 14px auto 1fr;
    gap: 6px;
    align-items: baseline;
    color: var(--ok);
  }
  .perms li.no {
    color: var(--err);
  }
  .perms span {
    color: var(--fg-2);
  }
  .perms .pd {
    color: var(--fg-3);
  }
  .card footer {
    display: flex;
    align-items: center;
    gap: 6px;
    padding-top: 4px;
    border-top: 1px solid var(--line);
  }
  .miss {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    font-size: 11px;
    color: var(--warn);
  }
  .kb {
    flex: 1;
    min-height: 0;
    display: flex;
    gap: 14px;
  }
  .kb :global(.kbpanel) {
    flex: 1;
  }
  .kbbar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 12px;
    border-bottom: 1px solid var(--line);
    color: var(--fg-3);
  }
  .kbbar .q {
    flex: 1;
  }
  .kbbar .select {
    width: 170px;
    flex: none;
  }
  .hits {
    flex: 1;
    padding: 6px 8px;
  }
  .hits ul {
    list-style: none;
    margin: 0;
    padding: 0;
  }
  .hit {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: 3px;
    padding: 9px 10px;
    border: 1px solid transparent;
    border-radius: 9px;
    background: none;
    text-align: left;
    cursor: pointer;
  }
  .hit:hover {
    background: rgba(255, 255, 255, 0.035);
  }
  .hit.on {
    border-color: var(--line-strong);
    background: rgba(200, 215, 235, 0.06);
  }
  .ht {
    font-size: 13px;
    color: var(--fg);
  }
  .hs {
    font-size: 12px;
    color: var(--fg-3);
    display: -webkit-box;
    -webkit-line-clamp: 2;
    line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
  }
  .hm {
    display: flex;
    gap: 10px;
    font-size: 11px;
    color: var(--fg-3);
  }
  .inv {
    color: var(--fg-2);
  }
  .kbside {
    width: 400px;
    flex: none;
    display: flex;
    flex-direction: column;
    gap: 10px;
    min-height: 0;
  }
  .storage {
    flex: 1;
    display: flex;
    flex-direction: column;
    gap: 14px;
  }
  .tiles {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 12px;
  }
  .sgrid {
    display: grid;
    grid-template-columns: 1fr 1.25fr 1fr;
    gap: 14px;
    align-items: start;
  }
  .r {
    text-align: right;
  }
  .act {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
    padding: 6px 0;
  }
  .act > div:first-child {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .act b {
    font-weight: 500;
    font-size: 12.5px;
  }
  .act span {
    font-size: 11.5px;
    color: var(--fg-3);
  }
  .days {
    width: 84px;
    min-height: 28px;
    padding: 4px 8px;
  }
  .result {
    font-size: 11.5px;
    padding: 8px 10px;
    border-radius: 8px;
    border: 1px solid rgba(240, 138, 138, 0.3);
    color: var(--err);
    word-break: break-word;
  }
  .result.ok {
    border-color: rgba(143, 211, 176, 0.3);
    color: var(--ok);
  }
  .osd {
    grid-template-columns: 70px 1fr;
  }
  .help {
    margin: 0;
  }
</style>
