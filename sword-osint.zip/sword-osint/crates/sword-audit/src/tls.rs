//! TLS certificate check: validity (Mozilla root store), expiry, issuer, SAN coverage and
//! negotiated protocol version. Only a handshake is performed — no application data.

use std::sync::Arc;
use std::time::Duration;

use rustls::pki_types::ServerName;
use sword_connectors::output::{FindingExt, OutputBuilder};
use sword_connectors::ConnectorContext;
use sword_core::{keys, AdapterInfo, AdapterOutput, Category, EntityKind, FindingKind, Severity, SwordError, SwordResult};
use tokio::net::TcpStream;
use tokio_rustls::TlsConnector;

fn issue(b: &mut OutputBuilder, domain: &str, sev: Severity, title: &str, details: &str, fix: &str, url: &str) {
    b.finding(Category::DomainIntel, FindingKind::AuditIssue, &format!("{domain}: {title}"), Some(url))
        .severity(sev)
        .snippet(details)
        .attr("Рекомендация", fix)
        .entity(&keys::domain(domain));
}

fn connector() -> TlsConnector {
    let roots = rustls::RootCertStore::from_iter(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());
    let config = rustls::ClientConfig::builder_with_provider(Arc::new(rustls::crypto::ring::default_provider()))
        .with_safe_default_protocol_versions()
        .expect("ring supports default protocol versions")
        .with_root_certificates(roots)
        .with_no_client_auth();
    TlsConnector::from(Arc::new(config))
}

pub async fn check(ctx: &ConnectorContext, info: &AdapterInfo, domain: &str) -> SwordResult<AdapterOutput> {
    let mut b = OutputBuilder::new(info);
    b.entity(&keys::domain(domain), EntityKind::Domain, domain);
    let cite = format!("https://{domain}/");
    let server_name = ServerName::try_from(domain.to_string()).map_err(|_| SwordError::InvalidInput(format!("некорректное имя хоста {domain}")))?;

    let handshake = async {
        let tcp = tokio::time::timeout(Duration::from_secs(10), TcpStream::connect((domain, 443)))
            .await
            .map_err(|_| SwordError::Timeout)?
            .map_err(|e| SwordError::Network(format!("TCP {domain}:443 — {e}")))?;
        tokio::time::timeout(Duration::from_secs(12), connector().connect(server_name, tcp))
            .await
            .map_err(|_| SwordError::Timeout)?
            .map_err(|e| SwordError::Upstream(e.to_string()))
    };
    let stream = tokio::select! {
        _ = ctx.cancel.cancelled() => return Err(SwordError::Cancelled),
        r = handshake => r,
    };

    let stream = match stream {
        Ok(s) => s,
        Err(SwordError::Upstream(msg)) => {
            let lower = msg.to_lowercase();
            let (sev, title, fix) = if lower.contains("expired") {
                (Severity::Critical, "сертификат просрочен", "Перевыпустите сертификат и настройте автоматическое продление (ACME).")
            } else if lower.contains("notvalidforname") || lower.contains("not valid for") {
                (Severity::High, "сертификат не соответствует имени", "Выпустите сертификат, включающий имя домена в SAN.")
            } else if lower.contains("unknownissuer") || lower.contains("unknown issuer") {
                (Severity::High, "сертификат выдан недоверенным центром", "Используйте сертификат публичного доверенного УЦ и передавайте полную цепочку.")
            } else {
                (Severity::High, "ошибка TLS-рукопожатия", "Проверьте конфигурацию TLS сервера.")
            };
            issue(&mut b, domain, sev, title, &msg, fix, &cite);
            return Ok(b.finish());
        }
        Err(SwordError::Network(msg)) => {
            b.note(format!("Прямое подключение к {domain}:443 не удалось ({msg}). Если сеть работает через прокси, проверка TLS недоступна."));
            return Ok(b.finish());
        }
        Err(e) => return Err(e),
    };

    let (_, conn) = stream.get_ref();
    let protocol = conn.protocol_version().map(|v| format!("{v:?}")).unwrap_or_else(|| "?".into());
    let certs = conn.peer_certificates().map(|c| c.to_vec()).unwrap_or_default();
    let Some(leaf) = certs.first() else {
        issue(&mut b, domain, Severity::High, "сервер не передал сертификат", "", "Проверьте конфигурацию TLS.", &cite);
        return Ok(b.finish());
    };
    let parsed = x509_parser::parse_x509_certificate(leaf.as_ref()).map_err(|e| SwordError::Parse(format!("X.509: {e}")))?;
    let cert = parsed.1;
    let not_after = cert.validity().not_after.timestamp();
    let not_before = cert.validity().not_before.timestamp();
    let now = sword_core::util::now().timestamp();
    let days_left = (not_after - now) / 86_400;
    let issuer = cert.issuer().to_string();
    let sans: Vec<String> = match cert.subject_alternative_name() {
        Ok(Some(ext)) => ext
            .value
            .general_names
            .iter()
            .filter_map(|g| match g {
                x509_parser::extensions::GeneralName::DNSName(n) => Some(n.to_string()),
                _ => None,
            })
            .collect(),
        _ => Vec::new(),
    };
    let expiry = chrono::DateTime::from_timestamp(not_after, 0).map(|d| sword_core::util::fmt_date(&d)).unwrap_or_default();
    let details = format!(
        "Издатель: {issuer}. Действует до {expiry} (осталось {days_left} дн.). Протокол: {protocol}. Имена: {}.",
        sans.iter().take(12).cloned().collect::<Vec<_>>().join(", ")
    );
    b.attr(&keys::domain(domain), "TLS-сертификат до", &expiry, &cite);
    b.attr(&keys::domain(domain), "Издатель сертификата", &issuer, &cite);

    let (sev, title) = if days_left < 0 {
        (Severity::Critical, "сертификат просрочен".to_string())
    } else if days_left < 14 {
        (Severity::High, format!("сертификат истекает через {days_left} дн."))
    } else if days_left < 30 {
        (Severity::Medium, format!("сертификат истекает через {days_left} дн."))
    } else {
        (Severity::Pass, format!("сертификат действителен ({days_left} дн.)"))
    };
    issue(&mut b, domain, sev, &title, &details, "Настройте автоматическое продление и мониторинг срока действия.", &cite);
    let lifetime_days = (not_after - not_before) / 86_400;
    if lifetime_days > 398 {
        issue(&mut b, domain, Severity::Low, "срок действия сертификата больше 398 дней", &format!("{lifetime_days} дней"), "Браузеры не доверяют сертификатам со сроком > 398 дней, выпущенным после 2020 года.", &cite);
    }
    if protocol.contains("1_2") {
        issue(&mut b, domain, Severity::Info, "согласован TLS 1.2", "Сервер не выбрал TLS 1.3 при поддержке клиентом.", "Включите TLS 1.3.", &cite);
    }
    b.fact("TLS", &format!("{domain}: {protocol}, сертификат до {expiry}, {issuer}"), &cite);
    Ok(b.finish())
}
