//! SearXNG — the analyst's own metasearch instance (JSON API).

use async_trait::async_trait;
use serde_json::Value;
use sword_core::util::parse_date;
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordError, SwordResult,
};

use super::{arr, info, is_document_url, opt, s};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::output::{link_url_to_domain, FindingExt, OutputBuilder};

pub struct Searxng {
    info: AdapterInfo,
}

impl Default for Searxng {
    fn default() -> Self {
        Self::new()
    }
}

impl Searxng {
    pub fn new() -> Self {
        Searxng {
            info: info(
                "searxng",
                "SearXNG",
                "собственный экземпляр SearXNG",
                "Метапоиск через ваш экземпляр SearXNG: агрегирует выдачу нескольких поисковых систем без передачи данных третьим лицам напрямую.",
                "HTTP GET {instance}/search?format=json. Используются только результаты, возвращённые экземпляром; \
                 список поисковых систем определяется конфигурацией SearXNG.",
                &[Category::WebSearch, Category::PublicDocuments],
                &[InputKind::Text, InputKind::Domain, InputKind::Url],
                vec![],
                vec![opt(
                    "url",
                    "Адрес экземпляра",
                    true,
                    None,
                    "Адрес вашего экземпляра SearXNG (например, развёрнутого в Docker). В settings.yml включите формат JSON: \
                     search → formats: [html, json]. Публичные экземпляры обычно запрещают JSON-API.",
                    Some("http://localhost:8888"),
                )],
                30,
                "https://docs.searxng.org/",
                Some("https://docs.searxng.org/dev/search_api.html"),
                true,
            ),
        }
    }

    fn base(&self, ctx: &ConnectorContext) -> SwordResult<String> {
        ctx.option(&self.info, "url")
            .map(|u| u.trim_end_matches('/').to_string())
            .filter(|u| u.starts_with("http://") || u.starts_with("https://"))
            .ok_or_else(|| SwordError::NotConfigured("адрес экземпляра SearXNG".into()))
    }

    async fn run(&self, ctx: &ConnectorContext, base: &str, q: &str, categories: &str) -> SwordResult<Value> {
        let req = ctx.get(&format!("{base}/search")).query(&[("q", q), ("format", "json"), ("categories", categories)]);
        ctx.json(&self.info, req).await.map_err(|e| match e {
            SwordError::Forbidden(_) => SwordError::Forbidden(
                "экземпляр запрещает формат JSON — добавьте json в search.formats в settings.yml".into(),
            ),
            other => other,
        })
    }
}

#[async_trait]
impl SourceAdapter for Searxng {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let base = self.base(ctx)?;
        let v = self.run(ctx, &base, "searxng", "general").await?;
        let engines = arr(&v, "/results").iter().filter_map(|r| s(r, "engine")).collect::<std::collections::BTreeSet<_>>();
        Ok(vec![PermissionCheck::granted(
            "JSON API",
            if engines.is_empty() { "Экземпляр отвечает".to_string() } else { format!("Активные движки: {}", engines.into_iter().collect::<Vec<_>>().join(", ")) },
        )])
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let base = self.base(ctx)?;
        let mut b = OutputBuilder::new(&self.info);
        let domain = input.registrable_domain.clone().or_else(|| input.domain.clone());
        let mut queries: Vec<(String, &str, Category)> = Vec::new();
        if ctx.wants(Category::WebSearch) {
            queries.push((domain.as_ref().map(|d| format!("\"{d}\"")).unwrap_or_else(|| input.text.clone()), "general", Category::WebSearch));
        }
        if ctx.wants(Category::PublicDocuments) {
            let q = match &domain {
                Some(d) => format!("site:{d} filetype:pdf"),
                None => format!("{} filetype:pdf", input.text),
            };
            queries.push((q, "general,files", Category::PublicDocuments));
        }
        for (q, cats, category) in queries {
            let v = self.run(ctx, &base, &q, cats).await?;
            b.source(&format!("{base}/search?q={}", url::form_urlencoded::byte_serialize(q.as_bytes()).collect::<String>()), &format!("SearXNG: {q}"));
            for r in arr(&v, "/results").iter().take(ctx.max_results) {
                let Some(url) = s(r, "url") else { continue };
                let title = s(r, "title").unwrap_or_else(|| url.clone());
                let is_doc = is_document_url(&url);
                let doc_key = keys::document(&url);
                {
                    let f = b.finding(
                        if is_doc { Category::PublicDocuments } else { category },
                        if is_doc { FindingKind::Document } else { FindingKind::WebPage },
                        &title,
                        Some(&url),
                    );
                    f.snippet(&s(r, "content").unwrap_or_default())
                        .published(s(r, "publishedDate").and_then(|d| parse_date(&d)))
                        .confidence(0.85)
                        .attr("Поисковая система", s(r, "engine").unwrap_or_default());
                    if is_doc {
                        f.entity(&doc_key);
                    }
                }
                if is_doc {
                    b.entity(&doc_key, EntityKind::Document, &title);
                    link_url_to_domain(&mut b, &doc_key, &url);
                }
                b.source(&url, &title);
            }
            let unresponsive = arr(&v, "/unresponsive_engines");
            if !unresponsive.is_empty() {
                let names: Vec<String> = unresponsive
                    .iter()
                    .filter_map(|e| e.as_array().and_then(|a| a.first()).and_then(Value::as_str).map(str::to_string))
                    .collect();
                if !names.is_empty() {
                    b.note(format!("SearXNG: не ответили движки {}", names.join(", ")));
                }
            }
        }
        Ok(b.finish())
    }
}
