//! HISTORY: search, filter, sort, reopen, compare, delete and export investigations;
//! knowledge-base full-text search (SQLite FTS5 or OpenSearch).

use sword_db::{Comparison, HistoryPage, HistoryQuery, InvestigationDetail, KnowledgeHit, KnowledgeQuery};
use tauri::{AppHandle, State};

use super::save_dialog;
use crate::error::{ApiError, ApiResult};
use crate::state::{blocking, AppState};

#[tauri::command]
pub async fn list_history(state: State<'_, AppState>, query: HistoryQuery) -> ApiResult<HistoryPage> {
    let db = state.db.clone();
    blocking(move || db.list_history(&query)).await
}

#[tauri::command]
pub async fn get_investigation(state: State<'_, AppState>, id: String) -> ApiResult<InvestigationDetail> {
    let db = state.db.clone();
    blocking(move || db.get_detail(&id)).await
}

#[tauri::command]
pub async fn delete_investigations(state: State<'_, AppState>, ids: Vec<String>) -> ApiResult<u32> {
    let running: Vec<String> = state.running.lock().map(|m| m.keys().cloned().collect()).unwrap_or_default();
    if ids.iter().any(|i| running.contains(i)) {
        return Err(ApiError::invalid("нельзя удалить исследование, которое ещё выполняется"));
    }
    let db = state.db.clone();
    let ids2 = ids.clone();
    let n = blocking(move || db.delete_investigations(&ids2)).await?;
    // keep the optional OpenSearch index in sync
    let settings = state.settings();
    if settings.search.backend == "opensearch" {
        if let Some(url) = settings.search.opensearch_url.clone() {
            let password = state.secrets.get("opensearch.password").ok().flatten();
            if let Ok(os) = sword_search::opensearch::OpenSearch::new(state.http().client().clone(), &url, &settings.search.opensearch_index, settings.search.opensearch_username.clone(), password) {
                for id in &ids {
                    if let Err(e) = os.delete_investigation(id).await {
                        tracing::warn!(error = %e, "OpenSearch delete failed");
                    }
                }
            }
        }
    }
    Ok(n)
}

#[tauri::command]
pub async fn compare_investigations(state: State<'_, AppState>, a: String, b: String) -> ApiResult<Comparison> {
    if a == b {
        return Err(ApiError::invalid("выберите два разных исследования"));
    }
    let db = state.db.clone();
    blocking(move || db.compare(&a, &b)).await
}

#[tauri::command]
pub async fn update_notes(state: State<'_, AppState>, id: String, notes: String) -> ApiResult<()> {
    if notes.chars().count() > 20_000 {
        return Err(ApiError::invalid("заметка длиннее 20 000 символов"));
    }
    let db = state.db.clone();
    blocking(move || db.update_notes(&id, &notes)).await
}

fn csv_escape(s: &str) -> String {
    if s.contains([',', '"', '\n', ';']) {
        format!("\"{}\"", s.replace('"', "\"\""))
    } else {
        s.to_string()
    }
}

fn to_csv(d: &InvestigationDetail) -> String {
    let mut out = String::from("\u{FEFF}id,category,kind,title,url,snippet,published_at,retrieved_at,confidence,severity,adapter\n");
    for f in &d.findings {
        out.push_str(
            &[
                f.id.clone(),
                f.category.as_str().to_string(),
                f.kind.as_str().to_string(),
                f.title.clone(),
                f.url.clone().unwrap_or_default(),
                f.snippet.clone().unwrap_or_default(),
                f.published_at.map(|d| d.to_rfc3339()).unwrap_or_default(),
                f.retrieved_at.to_rfc3339(),
                format!("{:.2}", f.confidence),
                f.severity.map(|s| s.as_str().to_string()).unwrap_or_default(),
                f.adapter_id.clone(),
            ]
            .iter()
            .map(|s| csv_escape(s))
            .collect::<Vec<_>>()
            .join(","),
        );
        out.push('\n');
    }
    out
}

fn to_markdown(d: &InvestigationDetail) -> String {
    let r = &d.record;
    let mut md = format!(
        "# SWORD OSINT — {}\n\n- ID: `{}`\n- Дата: {}\n- Статус: {}\n- Результатов: {}\n- Первоисточников: {}\n\n## Сводка\n\n{}\n\n## Результаты\n\n",
        r.query,
        r.id,
        sword_core::util::fmt_datetime(&r.created_at),
        r.status.label_ru(),
        r.result_count,
        r.source_count,
        r.summary
    );
    for f in &d.findings {
        let link = f.url.as_ref().map(|u| format!(" — <{u}>")).unwrap_or_default();
        md.push_str(&format!("- **{}** ({}, {}){}\n", f.title.replace('*', ""), f.kind.label_ru(), f.adapter_id, link));
    }
    md.push_str("\n## Первоисточники\n\n");
    for (i, s) in d.sources.iter().enumerate() {
        md.push_str(&format!("{}. [{}]({})\n", i + 1, s.title.replace(['[', ']'], ""), s.url));
    }
    if !r.limitations.is_empty() {
        md.push_str("\n## Ограничения\n\n");
        for l in &r.limitations {
            md.push_str(&format!("- {l}\n"));
        }
    }
    md
}

/// Export an investigation (JSON with graph, CSV of findings, or Markdown brief).
#[tauri::command]
pub async fn export_investigation(app: AppHandle, state: State<'_, AppState>, id: String, format: String) -> ApiResult<Option<String>> {
    let db = state.db.clone();
    let id2 = id.clone();
    let (detail, graph) = blocking(move || Ok((db.get_detail(&id2)?, db.graph_of(&id2)?))).await?;
    let (ext, filter, body) = match format.as_str() {
        "json" => (
            "json",
            "JSON",
            serde_json::to_string_pretty(&serde_json::json!({ "format": "sword-osint-investigation", "version": 1, "investigation": detail, "graph": graph }))
                .map_err(|e| ApiError::internal(e.to_string()))?,
        ),
        "csv" => ("csv", "CSV", to_csv(&detail)),
        "md" => ("md", "Markdown", to_markdown(&detail)),
        _ => return Err(ApiError::invalid("формат: json, csv или md")),
    };
    let name = format!("sword-osint-{}-{}.{ext}", detail.record.created_at.format("%Y%m%d-%H%M"), super::sanitize_filename(&detail.record.query));
    let Some(path) = save_dialog(&app, "Экспорт исследования", &name, filter, &[ext]).await? else { return Ok(None) };
    std::fs::write(&path, body)?;
    let db = state.db.clone();
    let p = path.display().to_string();
    let p2 = p.clone();
    blocking(move || db.record_export("investigation", &p2)).await?;
    Ok(Some(p))
}

/// Knowledge base search: OpenSearch when configured, otherwise SQLite FTS5.
#[tauri::command]
pub async fn search_knowledge(state: State<'_, AppState>, query: KnowledgeQuery) -> ApiResult<Vec<KnowledgeHit>> {
    let settings = state.settings();
    if settings.search.backend == "opensearch" && !query.text.trim().is_empty() {
        if let Some(url) = settings.search.opensearch_url.clone() {
            let password = state.secrets.get("opensearch.password").ok().flatten();
            let os = sword_search::opensearch::OpenSearch::new(state.http().client().clone(), &url, &settings.search.opensearch_index, settings.search.opensearch_username.clone(), password)?;
            let ids = os.search(&query.text, query.limit.unwrap_or(100) as usize).await?;
            let db = state.db.clone();
            return blocking(move || db.findings_by_ids(&ids)).await;
        }
    }
    let db = state.db.clone();
    blocking(move || db.search_knowledge(&query)).await
}
