//! Persisted, non-secret application settings.
//!
//! Stored as JSON in the SQLite `settings` table. Secrets (API keys, tokens, passwords)
//! are never part of this structure — they live in the OS credential vault.

use std::collections::BTreeMap;

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct NetworkSettings {
    /// Per-request timeout.
    pub request_timeout_secs: u32,
    /// Whole-adapter budget inside one investigation.
    pub adapter_timeout_secs: u32,
    /// How many adapters run in parallel.
    pub max_concurrency: u32,
    pub max_results_per_adapter: u32,
    /// Optional explicit proxy (`http://host:port`, `socks5://…`). Empty = system proxy.
    pub proxy_url: Option<String>,
    /// Contact e-mail added to the User-Agent (polite API usage: Wikimedia, OpenAlex).
    pub contact_email: Option<String>,
    /// DNS-over-HTTPS resolver: `cloudflare` or `google`.
    pub doh_provider: String,
}

impl Default for NetworkSettings {
    fn default() -> Self {
        NetworkSettings {
            request_timeout_secs: 20,
            adapter_timeout_secs: 75,
            max_concurrency: 6,
            max_results_per_adapter: 25,
            proxy_url: None,
            contact_email: None,
            doh_provider: "cloudflare".into(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct AdapterSettings {
    pub enabled: bool,
    pub options: BTreeMap<String, String>,
}

impl Default for AdapterSettings {
    fn default() -> Self {
        AdapterSettings { enabled: true, options: BTreeMap::new() }
    }
}

/// Graphics preferences used by the Particle Engine and the 3D network view.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct GraphicsSettings {
    /// `auto` | `webgpu` | `webgl2`
    pub renderer: String,
    /// `auto` | `low` | `medium` | `high` | `ultra`
    pub quality: String,
    pub bloom: bool,
    pub trails: bool,
    /// 0 = display refresh rate.
    pub fps_limit: u32,
    pub reduce_motion: bool,
    /// Keep the particle universe animated behind non-DISCOVERY sections.
    pub background_animation: bool,
    pub max_pixel_ratio: f32,
    pub show_fps: bool,
}

impl Default for GraphicsSettings {
    fn default() -> Self {
        GraphicsSettings {
            renderer: "auto".into(),
            quality: "auto".into(),
            bloom: true,
            trails: true,
            fps_limit: 0,
            reduce_motion: false,
            background_animation: true,
            max_pixel_ratio: 2.0,
            show_fps: false,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct PrivacySettings {
    /// Automatically delete investigations older than N days (0 = keep forever).
    pub retention_days: u32,
    /// Store result snippets in the local database.
    pub store_snippets: bool,
}

impl Default for PrivacySettings {
    fn default() -> Self {
        PrivacySettings { retention_days: 0, store_snippets: true }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct SearchBackendSettings {
    /// `sqlite` (embedded FTS5) or `opensearch` (external cluster).
    pub backend: String,
    pub opensearch_url: Option<String>,
    pub opensearch_index: String,
    pub opensearch_username: Option<String>,
}

impl Default for SearchBackendSettings {
    fn default() -> Self {
        SearchBackendSettings {
            backend: "sqlite".into(),
            opensearch_url: None,
            opensearch_index: "sword-findings".into(),
            opensearch_username: None,
        }
    }
}

#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ReportDefaults {
    pub author: String,
    pub organization: String,
    pub classification: String,
    /// `graphite` | `midnight` | `paper`
    pub theme: String,
    /// `a4` | `letter`
    pub paper: String,
}

impl Default for ReportDefaults {
    fn default() -> Self {
        ReportDefaults {
            author: String::new(),
            organization: String::new(),
            classification: "Для внутреннего использования".into(),
            theme: "graphite".into(),
            paper: "a4".into(),
        }
    }
}

#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct AppSettings {
    pub network: NetworkSettings,
    pub adapters: BTreeMap<String, AdapterSettings>,
    pub graphics: GraphicsSettings,
    pub privacy: PrivacySettings,
    pub search: SearchBackendSettings,
    pub report: ReportDefaults,
}

impl AppSettings {
    pub fn adapter_enabled(&self, id: &str) -> bool {
        self.adapters.get(id).map(|a| a.enabled).unwrap_or(true)
    }

    /// Non-empty option value configured for an adapter.
    pub fn adapter_option(&self, id: &str, key: &str) -> Option<String> {
        self.adapters
            .get(id)
            .and_then(|a| a.options.get(key))
            .map(|v| v.trim().to_string())
            .filter(|v| !v.is_empty())
    }

    /// Clamp values coming from the UI to safe ranges.
    pub fn sanitized(mut self) -> Self {
        let n = &mut self.network;
        n.request_timeout_secs = n.request_timeout_secs.clamp(5, 120);
        n.adapter_timeout_secs = n.adapter_timeout_secs.clamp(15, 600);
        n.max_concurrency = n.max_concurrency.clamp(1, 16);
        n.max_results_per_adapter = n.max_results_per_adapter.clamp(5, 200);
        if n.doh_provider != "google" {
            n.doh_provider = "cloudflare".into();
        }
        n.proxy_url = n.proxy_url.take().map(|s| s.trim().to_string()).filter(|s| !s.is_empty());
        n.contact_email = n.contact_email.take().map(|s| s.trim().to_string()).filter(|s| !s.is_empty());
        let g = &mut self.graphics;
        if !["auto", "webgpu", "webgl2"].contains(&g.renderer.as_str()) {
            g.renderer = "auto".into();
        }
        if !["auto", "low", "medium", "high", "ultra"].contains(&g.quality.as_str()) {
            g.quality = "auto".into();
        }
        g.fps_limit = g.fps_limit.min(240);
        g.max_pixel_ratio = g.max_pixel_ratio.clamp(0.5, 3.0);
        if !["graphite", "midnight", "paper"].contains(&self.report.theme.as_str()) {
            self.report.theme = "graphite".into();
        }
        if !["a4", "letter"].contains(&self.report.paper.as_str()) {
            self.report.paper = "a4".into();
        }
        if self.search.backend != "opensearch" {
            self.search.backend = "sqlite".into();
        }
        self
    }
}
