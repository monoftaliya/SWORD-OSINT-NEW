/**
 * Live investigations and audits: consumes the backend event stream and exposes the
 * state the DISCOVERY / INTELLIGENCE screens and the particle engine react to.
 */
import { api } from '../api/client';
import { onInvestigationEvent } from '../api/events';
import type {
  AdapterRun,
  AuditCheck,
  ClassifiedInput,
  Finding,
  InvestigationEvent,
  InvestigationKind,
  InvestigationRecord,
  InvestigationRequest,
  PlannedAdapter,
  SourceRef,
} from '../api/types';
import { app } from './app.svelte';

export interface RunState {
  id: string;
  kind: InvestigationKind;
  query: string;
  input: ClassifiedInput | null;
  plan: PlannedAdapter[];
  runs: Record<string, AdapterRun>;
  findings: Finding[];
  sources: SourceRef[];
  record: InvestigationRecord | null;
  live: boolean;
  startedAt: number;
}

function emptyRun(id: string, kind: InvestigationKind, query: string): RunState {
  return { id, kind, query, input: null, plan: [], runs: {}, findings: [], sources: [], record: null, live: true, startedAt: Date.now() };
}

export function runProgress(r: RunState | null): { done: number; total: number; ratio: number } {
  if (!r) return { done: 0, total: 0, ratio: 0 };
  const active = r.plan.filter((p) => p.willRun);
  const total = active.length;
  const done = active.filter((p) => {
    const s = r.runs[p.adapterId]?.status;
    return s !== undefined && s !== 'queued' && s !== 'running';
  }).length;
  return { done, total, ratio: total === 0 ? (r.live ? 0 : 1) : done / total };
}

class RunStore {
  /** DISCOVERY investigation (live or reopened from history). */
  discovery = $state<RunState | null>(null);
  /** INTELLIGENCE audit (live or reopened). */
  audit = $state<RunState | null>(null);
  starting = $state(false);
  private bound = false;

  async bind() {
    if (this.bound) return;
    this.bound = true;
    await onInvestigationEvent((e) => this.handle(e));
  }

  private target(id: string): 'discovery' | 'audit' | null {
    if (this.discovery?.id === id) return 'discovery';
    if (this.audit?.id === id) return 'audit';
    return null;
  }

  private update(id: string, fn: (r: RunState) => void) {
    const t = this.target(id);
    if (!t) return;
    const r = this[t];
    if (!r) return;
    fn(r);
    this[t] = { ...r };
  }

  handle(e: InvestigationEvent) {
    switch (e.type) {
      case 'started': {
        const slot = e.kind === 'exposure_audit' ? 'audit' : 'discovery';
        const existing = this[slot];
        const r = existing && existing.id === e.investigationId ? existing : emptyRun(e.investigationId, e.kind, e.query);
        r.input = e.input;
        r.plan = e.plan;
        for (const p of e.plan) {
          r.runs[p.adapterId] ??= {
            adapterId: p.adapterId,
            adapterName: p.name,
            status: p.willRun ? 'queued' : 'skipped',
            startedAt: null,
            finishedAt: null,
            durationMs: null,
            resultCount: 0,
            errorKind: null,
            message: p.reason,
          };
        }
        this[slot] = { ...r };
        break;
      }
      case 'adapterUpdate':
        this.update(e.investigationId, (r) => {
          r.runs = { ...r.runs, [e.run.adapterId]: e.run };
        });
        break;
      case 'findings':
        this.update(e.investigationId, (r) => {
          r.findings = [...r.findings, ...e.findings];
        });
        break;
      case 'finished': {
        const t = this.target(e.investigationId);
        this.update(e.investigationId, (r) => {
          r.record = e.record;
          r.live = false;
        });
        const label = e.record.kind === 'exposure_audit' ? 'Аудит' : 'Исследование';
        if (e.record.status === 'completed' || e.record.status === 'partial') {
          app.toast('ok', `${label} завершено: ${e.record.resultCount} результатов`);
        } else if (e.record.status === 'cancelled') {
          app.toast('info', `${label} отменено`);
        } else {
          app.toast('err', `${label}: ${e.record.error ?? 'ошибка'}`);
        }
        // reload the persisted, de-duplicated result set
        if (t) setTimeout(() => this.reload(t, e.investigationId), 250);
        break;
      }
    }
  }

  private async reload(slot: 'discovery' | 'audit', id: string) {
    try {
      const d = await api.getInvestigation(id);
      const cur = this[slot];
      if (!cur || cur.id !== id) return;
      const runs: Record<string, AdapterRun> = {};
      for (const r of d.runs) runs[r.adapterId] = r;
      this[slot] = { ...cur, record: d.record, findings: d.findings, sources: d.sources, runs, live: false };
    } catch {
      /* the live data stays visible */
    }
  }

  async start(request: InvestigationRequest) {
    this.starting = true;
    try {
      await this.bind();
      const id = await api.startInvestigation(request);
      if (!this.discovery || this.discovery.id !== id) this.discovery = emptyRun(id, 'discovery', request.query);
      return id;
    } catch (e) {
      app.error(e, 'Запуск исследования');
      return null;
    } finally {
      this.starting = false;
    }
  }

  async startAudit(assetIds: string[], checks: AuditCheck[]) {
    this.starting = true;
    try {
      await this.bind();
      const id = await api.startAudit({ assetIds, checks });
      if (!this.audit || this.audit.id !== id) this.audit = emptyRun(id, 'exposure_audit', 'Аудит');
      return id;
    } catch (e) {
      app.error(e, 'Запуск аудита');
      return null;
    } finally {
      this.starting = false;
    }
  }

  async cancel(slot: 'discovery' | 'audit') {
    const r = this[slot];
    if (!r || !r.live) return;
    try {
      await api.cancelInvestigation(r.id);
    } catch (e) {
      app.error(e, 'Отмена');
    }
  }

  /** Reopen a stored investigation in DISCOVERY or INTELLIGENCE. */
  async open(id: string) {
    try {
      const d = await api.getInvestigation(id);
      const runs: Record<string, AdapterRun> = {};
      for (const r of d.runs) runs[r.adapterId] = r;
      const plan: PlannedAdapter[] = d.runs.map((r) => ({
        adapterId: r.adapterId,
        name: r.adapterName,
        categories: [],
        willRun: r.status !== 'skipped',
        reason: r.status === 'skipped' ? r.message : null,
      }));
      const state: RunState = {
        id,
        kind: d.record.kind,
        query: d.record.query,
        input: null,
        plan,
        runs,
        findings: d.findings,
        sources: d.sources,
        record: d.record,
        live: d.record.status === 'running',
        startedAt: new Date(d.record.createdAt).getTime(),
      };
      if (d.record.kind === 'exposure_audit') {
        this.audit = state;
        app.navigate('intelligence');
      } else {
        this.discovery = state;
        app.navigate('discovery');
      }
    } catch (e) {
      app.error(e, 'Открытие исследования');
    }
  }

  clearDiscovery() {
    if (this.discovery?.live) return;
    this.discovery = null;
  }
}

export const run = new RunStore();
