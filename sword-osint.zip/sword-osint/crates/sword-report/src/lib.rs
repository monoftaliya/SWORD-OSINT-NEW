//! # sword-report — Report Engine
//!
//! Renders investigations into professional PDF documents with `printpdf`:
//!
//! 1. Cover (SWORD OSINT wordmark, report ID, generation date, query, status, author)
//! 2. Source query · 3. Methodology · 4. Checked sources · 5. Findings
//! 6. Analytical summary (with key facts and analyst conclusion)
//! 7. Graph of confirmed relations (vector figure + provenance table)
//! 8. References to primary sources (clickable) · 9. Limitations
//!
//! Every page carries the report ID; PDF bookmarks mirror the sections. Report content is
//! taken exclusively from stored investigation data — nothing is generated or invented.

mod composer;
mod fonts;
mod sections;
mod theme;

use std::collections::BTreeMap;

use chrono::{DateTime, Utc};
use printpdf::{ExtendedGraphicsState, Mm, PdfDocument, PdfPage, PdfSaveOptions};
use serde::{Deserialize, Serialize};
use sword_core::{AdapterInfo, AdapterRun, Finding, InvestigationRecord, SourceRef, SwordError, SwordResult, PRODUCT_NAME, VERSION};
use sword_graph::Graph;

pub use theme::Theme;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum SectionId {
    Query,
    Methodology,
    Sources,
    Findings,
    Summary,
    Graph,
    References,
    Limitations,
}

impl SectionId {
    pub const ALL: [SectionId; 8] = [
        SectionId::Query,
        SectionId::Methodology,
        SectionId::Sources,
        SectionId::Findings,
        SectionId::Summary,
        SectionId::Graph,
        SectionId::References,
        SectionId::Limitations,
    ];

    pub fn as_str(&self) -> &'static str {
        match self {
            SectionId::Query => "query",
            SectionId::Methodology => "methodology",
            SectionId::Sources => "sources",
            SectionId::Findings => "findings",
            SectionId::Summary => "summary",
            SectionId::Graph => "graph",
            SectionId::References => "references",
            SectionId::Limitations => "limitations",
        }
    }
}

/// Everything the analyst can configure in REPORT STUDIO.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct ReportOptions {
    pub title: Option<String>,
    /// Enabled sections in display order (the cover is always first).
    pub sections: Vec<SectionId>,
    /// Analyst notes per section id.
    pub notes: BTreeMap<String, String>,
    pub analyst_conclusion: String,
    /// `graphite` | `midnight` | `paper`
    pub theme: String,
    /// `silver` | `ice` | `amber`
    pub accent: String,
    /// `a4` | `letter`
    pub paper: String,
    pub author: String,
    pub organization: String,
    pub classification: String,
    pub max_findings_per_category: u32,
    pub include_edge_table: bool,
    pub include_source_nodes: bool,
}

impl Default for ReportOptions {
    fn default() -> Self {
        ReportOptions {
            title: None,
            sections: SectionId::ALL.to_vec(),
            notes: BTreeMap::new(),
            analyst_conclusion: String::new(),
            theme: "graphite".into(),
            accent: "silver".into(),
            paper: "a4".into(),
            author: String::new(),
            organization: String::new(),
            classification: "Для внутреннего использования".into(),
            max_findings_per_category: 40,
            include_edge_table: true,
            include_source_nodes: false,
        }
    }
}

/// Data of one investigation, loaded from the database.
#[derive(Debug, Clone)]
pub struct ReportData {
    pub report_id: String,
    pub generated_at: DateTime<Utc>,
    pub record: InvestigationRecord,
    pub runs: Vec<AdapterRun>,
    pub adapters: Vec<AdapterInfo>,
    pub findings: Vec<Finding>,
    pub sources: Vec<SourceRef>,
    pub graph: Graph,
}

#[derive(Debug, Clone)]
pub struct RenderedReport {
    pub bytes: Vec<u8>,
    pub pages: u32,
    pub warnings: Vec<String>,
}

/// `SWR-YYYYMMDD-XXXXXX`
pub fn new_report_id() -> String {
    let hex = uuid::Uuid::new_v4().simple().to_string();
    format!("SWR-{}-{}", Utc::now().format("%Y%m%d"), hex[..6].to_uppercase())
}

fn mm_to_pt(mm: f32) -> f32 {
    mm * 72.0 / 25.4
}

/// Render the report to PDF bytes.
pub fn render(data: &ReportData, opts: &ReportOptions) -> SwordResult<RenderedReport> {
    let (w_mm, h_mm) = if opts.paper == "letter" { (215.9, 279.4) } else { (210.0, 297.0) };
    let (w, h) = (mm_to_pt(w_mm), mm_to_pt(h_mm));
    let title = opts.title.clone().filter(|t| !t.trim().is_empty()).unwrap_or_else(|| format!("{PRODUCT_NAME} — {}", data.record.query));

    let mut doc = PdfDocument::new(&title);
    doc.metadata.info.author = if opts.author.trim().is_empty() { PRODUCT_NAME.to_string() } else { opts.author.clone() };
    doc.metadata.info.creator = format!("{PRODUCT_NAME} {VERSION}");
    doc.metadata.info.producer = format!("{PRODUCT_NAME} Report Engine (printpdf)");
    doc.metadata.info.subject = format!("Отчёт {} по запросу «{}»", data.report_id, data.record.query);
    doc.metadata.info.keywords = vec!["OSINT".into(), data.report_id.clone(), data.record.id.clone()];
    doc.metadata.info.identifier = data.report_id.clone();
    if let Ok(dt) = printpdf::DateTime::from_unix_timestamp(data.generated_at.timestamp()) {
        doc.metadata.info.creation_date = dt.clone();
        doc.metadata.info.modification_date = dt.clone();
        doc.metadata.info.metadata_date = dt;
    }

    let fonts = fonts::Fonts::load(&mut doc)?;
    let alpha: Vec<(f32, printpdf::ExtendedGraphicsStateId)> = [0.05f32, 0.08, 0.12, 0.18, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95]
        .iter()
        .map(|&a| (a, doc.add_graphics_state(ExtendedGraphicsState::default().with_current_fill_alpha(a).with_current_stroke_alpha(a))))
        .collect();
    let theme = Theme::from_options(&opts.theme, &opts.accent);

    let mut c = composer::Composer::new(&fonts, &theme, w, h, alpha.clone());
    sections::cover(&mut c, data, opts);
    c.new_page(composer::PageKind::Content);
    let mut first = true;
    let mut index = 0;
    for s in &opts.sections {
        index += 1;
        if !first && matches!(s, SectionId::Findings | SectionId::Graph | SectionId::References) {
            c.new_page(composer::PageKind::Content);
        }
        first = false;
        match s {
            SectionId::Query => sections::query(&mut c, index, data, opts),
            SectionId::Methodology => sections::methodology(&mut c, index, data, opts),
            SectionId::Sources => sections::sources(&mut c, index, data, opts),
            SectionId::Findings => sections::findings(&mut c, index, data, opts),
            SectionId::Summary => sections::summary(&mut c, index, data, opts),
            SectionId::Graph => sections::graph(&mut c, index, data, opts),
            SectionId::References => sections::references(&mut c, index, data, opts),
            SectionId::Limitations => sections::limitations(&mut c, index, data, opts),
        }
    }
    let (mut pages, bookmarks) = c.finish();
    sections::decorate(&mut pages, &fonts, &theme, w, h, data, opts, &alpha);

    let page_count = pages.len() as u32;
    let pdf_pages: Vec<PdfPage> = pages.into_iter().map(|(_, ops)| PdfPage::new(Mm(w_mm), Mm(h_mm), ops)).collect();
    doc.with_pages(pdf_pages);
    doc.add_bookmark("Обложка", 1);
    for (name, page) in &bookmarks {
        doc.add_bookmark(name, *page);
    }
    let mut warnings = Vec::new();
    let bytes = doc.save(&PdfSaveOptions { subset_fonts: true, ..Default::default() }, &mut warnings);
    if bytes.len() < 512 {
        return Err(SwordError::Internal("PDF не сформирован".into()));
    }
    Ok(RenderedReport { bytes, pages: page_count, warnings: warnings.iter().map(|w| format!("{w:?}")).take(20).collect() })
}

#[cfg(test)]
mod tests {
    use super::*;
    use sword_core::util::{new_id, now};
    use sword_core::*;
    use sword_graph::{GraphEdge, GraphNode};

    fn sample() -> ReportData {
        let rec = InvestigationRecord {
            id: new_id(),
            kind: InvestigationKind::Discovery,
            query: "example.org".into(),
            input_kind: InputKind::Domain,
            categories: vec![Category::DomainIntel, Category::OrgIntel],
            status: InvestigationStatus::Completed,
            created_at: now(),
            finished_at: Some(now()),
            duration_ms: Some(5400),
            result_count: 1,
            source_count: 1,
            node_count: 2,
            edge_count: 1,
            adapters: vec!["dns".into()],
            summary: "Тестовая сводка для проверки вёрстки (TEST FIXTURE).".into(),
            key_facts: vec![KeyFact { label: "DNSSEC".into(), value: "не подтверждено".into(), adapter_id: "dns".into(), source_url: "https://cloudflare-dns.com/".into() }],
            limitations: vec!["Тестовые данные: используется только для проверки генератора PDF.".into()],
            error: None,
            notes: String::new(),
        };
        let mut run = AdapterRun::new("dns", "DNS (DoH)", RunStatus::Done);
        run.result_count = 1;
        let ev = Evidence { source_url: "https://cloudflare-dns.com/dns-query?name=example.org&type=MX".into(), adapter_id: "dns".into(), retrieved_at: now(), note: None };
        ReportData {
            report_id: new_report_id(),
            generated_at: now(),
            record: rec,
            runs: vec![run],
            adapters: vec![],
            findings: vec![Finding {
                id: new_id(),
                adapter_id: "dns".into(),
                category: Category::DomainIntel,
                kind: FindingKind::DnsRecord,
                title: "MX: example.org (TEST FIXTURE)".into(),
                url: Some(ev.source_url.clone()),
                snippet: Some("0 .".into()),
                published_at: None,
                retrieved_at: now(),
                confidence: 1.0,
                severity: None,
                attributes: vec![],
                entity_key: None,
            }],
            sources: vec![SourceRef { url: ev.source_url.clone(), title: "DoH MX".into(), adapter_id: "dns".into(), retrieved_at: now() }],
            graph: Graph {
                nodes: vec![
                    GraphNode { key: "domain:example.org".into(), kind: EntityKind::Domain, label: "example.org".into(), attributes: vec![], sources: vec!["dns".into()], degree: 1 },
                    GraphNode { key: "domain:iana.org".into(), kind: EntityKind::Domain, label: "iana.org".into(), attributes: vec![], sources: vec!["dns".into()], degree: 1 },
                ],
                edges: vec![GraphEdge { id: "e1".into(), from: "domain:example.org".into(), to: "domain:iana.org".into(), relation: "dns_hosted_by".into(), label: "DNS обслуживается".into(), confidence: 1.0, evidence: vec![ev] }],
            },
        }
    }

    #[test]
    fn renders_all_themes() {
        for theme in ["graphite", "midnight", "paper"] {
            let opts = ReportOptions { theme: theme.into(), ..Default::default() };
            let r = render(&sample(), &opts).unwrap();
            assert!(r.bytes.starts_with(b"%PDF"));
            assert!(r.pages >= 3);
            if std::env::var("SWORD_WRITE_SAMPLE").is_ok() {
                std::fs::write(format!("sample-{theme}.pdf"), &r.bytes).unwrap();
            }
        }
    }

    #[test]
    fn report_ids_are_well_formed() {
        let id = new_report_id();
        assert!(id.starts_with("SWR-") && id.len() == 19, "{id}");
    }
}
