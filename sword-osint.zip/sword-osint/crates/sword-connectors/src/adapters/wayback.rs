//! Internet Archive Wayback Machine — archive history and archived public documents.

use async_trait::async_trait;
use serde_json::Value;
use sword_core::util::{fmt_date, parse_date};
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordError, SwordResult,
};

use super::info;
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::output::{link_url_to_domain, FindingExt, OutputBuilder};

const CDX: &str = "https://web.archive.org/cdx/search/cdx";

pub struct Wayback {
    info: AdapterInfo,
}

impl Default for Wayback {
    fn default() -> Self {
        Self::new()
    }
}

impl Wayback {
    pub fn new() -> Self {
        Wayback {
            info: info(
                "wayback",
                "Wayback Machine",
                "Internet Archive",
                "История сайта в веб-архиве: первая и последняя копии; архивные публичные документы домена (PDF, DOCX, XLSX…).",
                "Wayback CDX Server API (web.archive.org/cdx/search/cdx, output=json): первая/последняя запись для домена, \
                 поиск документов по MIME-типу с фильтром statuscode:200 и схлопыванием по urlkey. Ссылки ведут на архивные копии.",
                &[Category::PublicWebsites, Category::DigitalFootprint, Category::PublicDocuments],
                &[InputKind::Domain, InputKind::Url],
                vec![],
                vec![],
                15,
                "https://web.archive.org/",
                Some("https://github.com/internetarchive/wayback/tree/master/wayback-cdx-server"),
                true,
            ),
        }
    }

    async fn cdx(&self, ctx: &ConnectorContext, params: &[(&str, &str)]) -> SwordResult<Vec<Vec<String>>> {
        let resp = ctx.send(&self.info, ctx.get(CDX).query(params)).await?;
        let text = crate::http::read_text(crate::http::ensure_success(resp).await?, 8 * 1024 * 1024).await?;
        if text.trim().is_empty() {
            return Ok(Vec::new());
        }
        let v: Value = serde_json::from_str(&text).map_err(|e| SwordError::Parse(format!("CDX: {e}")))?;
        let rows: Vec<Vec<String>> = v
            .as_array()
            .map(|a| {
                a.iter()
                    .skip(1) // header row
                    .filter_map(|r| r.as_array().map(|c| c.iter().map(|x| x.as_str().unwrap_or_default().to_string()).collect()))
                    .collect()
            })
            .unwrap_or_default();
        Ok(rows)
    }
}

#[async_trait]
impl SourceAdapter for Wayback {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        self.cdx(ctx, &[("url", "archive.org"), ("output", "json"), ("limit", "1")]).await?;
        Ok(vec![PermissionCheck::granted("CDX API", "Доступ без ключа")])
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let domain = input.domain.clone().ok_or_else(|| SwordError::InvalidInput("нужен домен".into()))?;
        let mut b = OutputBuilder::new(&self.info);
        let site_key = keys::site(&format!("https://{domain}"));
        let reg = input.registrable_domain.clone().unwrap_or_else(|| domain.clone());
        let dkey = keys::domain(&reg);

        if ctx.wants(Category::PublicWebsites) || ctx.wants(Category::DigitalFootprint) {
            let first = self.cdx(ctx, &[("url", domain.as_str()), ("output", "json"), ("limit", "1"), ("fl", "timestamp,original,statuscode")]).await?;
            let last = self.cdx(ctx, &[("url", domain.as_str()), ("output", "json"), ("limit", "-1"), ("fl", "timestamp,original,statuscode")]).await?;
            let calendar = format!("https://web.archive.org/web/*/{domain}");
            if let Some(f) = first.first() {
                let first_dt = parse_date(&f[0]);
                let last_row = last.last();
                let last_dt = last_row.and_then(|r| parse_date(&r[0]));
                let first_url = format!("https://web.archive.org/web/{}/{}", f[0], f.get(1).cloned().unwrap_or_default());
                b.entity(&site_key, EntityKind::Website, &domain);
                b.entity(&dkey, EntityKind::Domain, &reg);
                b.relate(&site_key, &dkey, "hosted_on", 1.0, &calendar, None);
                if let Some(d) = first_dt {
                    b.attr(&site_key, "Первая архивная копия", &fmt_date(&d), &first_url);
                    b.fact("Первая копия в веб-архиве", &fmt_date(&d), &first_url);
                }
                if let Some(d) = last_dt {
                    b.attr(&site_key, "Последняя архивная копия", &fmt_date(&d), &calendar);
                }
                b.finding(Category::DigitalFootprint, FindingKind::Archive, &format!("Веб-архив: {domain}"), Some(&calendar))
                    .snippet(&format!(
                        "Первая копия: {}; последняя: {}.",
                        first_dt.map(|d| fmt_date(&d)).unwrap_or_else(|| "н/д".into()),
                        last_dt.map(|d| fmt_date(&d)).unwrap_or_else(|| "н/д".into())
                    ))
                    .published(first_dt)
                    .entity(&site_key);
                b.source(&calendar, &format!("Wayback Machine: {domain}"));
            } else {
                b.note(format!("В веб-архиве нет копий {domain}."));
            }
        }

        if ctx.wants(Category::PublicDocuments) || ctx.wants(Category::DigitalFootprint) {
            let pattern = format!("{reg}/*");
            let limit = ctx.max_results.clamp(5, 100).to_string();
            let rows = self
                .cdx(
                    ctx,
                    &[
                        ("url", pattern.as_str()),
                        ("output", "json"),
                        ("fl", "timestamp,original,mimetype,statuscode"),
                        ("filter", "statuscode:200"),
                        ("filter", "mimetype:application/(pdf|msword|vnd\\..*|rtf)"),
                        ("collapse", "urlkey"),
                        ("limit", limit.as_str()),
                    ],
                )
                .await;
            match rows {
                Ok(rows) => {
                    for r in rows {
                        if r.len() < 3 {
                            continue;
                        }
                        let (stamp, original, mime) = (&r[0], &r[1], &r[2]);
                        let archived = format!("https://web.archive.org/web/{stamp}/{original}");
                        let name = original.rsplit('/').find(|p| !p.is_empty()).unwrap_or(original.as_str());
                        let name = url::form_urlencoded::parse(name.as_bytes()).map(|(k, _)| k.into_owned()).next().unwrap_or_else(|| name.to_string());
                        let doc_key = keys::document(original);
                        b.entity(&doc_key, EntityKind::Document, &name);
                        b.attr(&doc_key, "Архивная копия", &archived, &archived);
                        b.attr(&doc_key, "MIME-тип", mime, &archived);
                        link_url_to_domain(&mut b, &doc_key, original);
                        b.finding(Category::PublicDocuments, FindingKind::Document, &name, Some(&archived))
                            .snippet(&format!("Исходный адрес: {original}"))
                            .published(parse_date(stamp))
                            .attr("Тип", mime.clone())
                            .entity(&doc_key);
                        b.source(&archived, &name);
                    }
                }
                Err(e) => b.note(format!("Поиск архивных документов не выполнен: {e}")),
            }
        }
        Ok(b.finish())
    }
}
