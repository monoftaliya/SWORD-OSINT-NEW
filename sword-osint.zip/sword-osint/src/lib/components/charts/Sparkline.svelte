<!-- Compact trend line in the de-emphasis hue; the latest point is the accent dot. -->
<script lang="ts">
  let { values, height = 34, name, format = (v: number) => String(Math.round(v)) }: { values: number[]; height?: number; name: string; format?: (v: number) => string } = $props();

  let width = $state(160);
  let active = $state<number | null>(null);
  const min = $derived(values.length ? Math.min(...values) : 0);
  const max = $derived(values.length ? Math.max(...values) : 1);
  const span = $derived(max - min || 1);
  const pts = $derived(values.map((v, i) => [values.length <= 1 ? width / 2 : 3 + (i / (values.length - 1)) * (width - 6), 4 + (1 - (v - min) / span) * (height - 8)] as const));
  const d = $derived(pts.map(([x, y], i) => `${i ? 'L' : 'M'}${x.toFixed(1)},${y.toFixed(1)}`).join(''));
  const focus = $derived(pts.length ? pts[active ?? pts.length - 1] : null);

  function onMove(e: PointerEvent) {
    if (!pts.length) return;
    const r = (e.currentTarget as SVGElement).getBoundingClientRect();
    const x = e.clientX - r.left;
    let best = 0;
    pts.forEach(([px], i) => {
      if (Math.abs(px - x) < Math.abs(pts[best][0] - x)) best = i;
    });
    active = best;
  }
</script>

<div class="spark" bind:clientWidth={width} style:height="{height}px">
  {#if values.length > 1}
    <svg {width} {height} role="img" aria-label="{name}: последнее значение {format(values[values.length - 1])}" onpointermove={onMove} onpointerleave={() => (active = null)}>
      <path d={d} />
      {#if active !== null}
        <line x1={pts[active][0]} x2={pts[active][0]} y1="0" y2={height} />
      {/if}
      {#if focus}<circle cx={focus[0]} cy={focus[1]} r="3.5" />{/if}
    </svg>
    {#if active !== null}
      <span class="tip num">{format(values[active])}</span>
    {/if}
  {:else}
    <span class="none">недостаточно замеров</span>
  {/if}
</div>

<style>
  .spark {
    position: relative;
    width: 100%;
  }
  svg {
    display: block;
    overflow: visible;
  }
  path {
    fill: none;
    stroke: rgba(199, 208, 220, 0.5);
    stroke-width: 2;
    stroke-linejoin: round;
    stroke-linecap: round;
  }
  line {
    stroke: rgba(255, 255, 255, 0.25);
  }
  circle {
    fill: #fff;
    stroke: #07090c;
    stroke-width: 2;
  }
  .tip {
    position: absolute;
    right: 0;
    top: -18px;
    font-size: 11px;
    color: #fff;
  }
  .none {
    font-size: 11px;
    color: var(--fg-3);
  }
</style>
