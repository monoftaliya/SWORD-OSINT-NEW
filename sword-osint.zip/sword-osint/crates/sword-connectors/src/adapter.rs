//! The source adapter contract.
//!
//! Each adapter lives in its own module (`adapters/*.rs`) and provides:
//! * a static [`AdapterInfo`] (categories, accepted inputs, credentials, options, rate limit,
//!   methodology text for reports);
//! * `check` — an availability + API-permission probe;
//! * `search` — the actual query, returning findings, entities, relations, sources and facts.
//!
//! Rate limiting and error mapping are provided by the shared HTTP client, so every adapter
//! behaves consistently (`429` cool-downs, timeouts, cancellation).

use std::time::Instant;

use async_trait::async_trait;
use sword_core::{
    AdapterHealth, AdapterInfo, AdapterOutput, AdapterStatus, ClassifiedInput, PermissionCheck, SwordError, SwordResult,
};

use crate::context::ConnectorContext;

#[async_trait]
pub trait SourceAdapter: Send + Sync {
    fn info(&self) -> &AdapterInfo;

    /// Can the adapter process this kind of input at all?
    fn supports(&self, input: &ClassifiedInput) -> bool {
        self.info().input_kinds.contains(&input.kind)
    }

    /// Human-readable list of missing required credentials/options.
    fn missing_config(&self, ctx: &ConnectorContext) -> Vec<String> {
        let info = self.info();
        let mut missing: Vec<String> = info
            .credentials
            .iter()
            .filter(|c| c.required && ctx.secret(&c.key).is_none())
            .map(|c| c.label.clone())
            .collect();
        missing.extend(info.options.iter().filter(|o| o.required && ctx.option(info, &o.key).is_none()).map(|o| o.label.clone()));
        missing
    }

    /// Lightweight availability and permission probe.
    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>>;

    /// Query the source.
    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput>;
}

/// Run the health check of an adapter and turn the outcome into an [`AdapterStatus`].
pub async fn health(adapter: &dyn SourceAdapter, ctx: &ConnectorContext) -> AdapterStatus {
    let info = adapter.info();
    let now = sword_core::util::now();
    if !ctx.settings.adapter_enabled(&info.id) {
        return AdapterStatus {
            adapter_id: info.id.clone(),
            health: AdapterHealth::Disabled,
            message: "Источник отключён в настройках".into(),
            checked_at: Some(now),
            last_success_at: None,
            latency_ms: None,
            permissions: Vec::new(),
        };
    }
    let missing = adapter.missing_config(ctx);
    if !missing.is_empty() {
        return AdapterStatus {
            adapter_id: info.id.clone(),
            health: AdapterHealth::Unconfigured,
            message: format!("Требуется настройка: {}", missing.join(", ")),
            checked_at: Some(now),
            last_success_at: None,
            latency_ms: None,
            permissions: Vec::new(),
        };
    }
    let started = Instant::now();
    let result = adapter.check(ctx).await;
    let latency = started.elapsed().as_millis().min(u32::MAX as u128) as u32;
    match result {
        Ok(perms) => {
            let degraded = perms.iter().any(|p| !p.granted);
            AdapterStatus {
                adapter_id: info.id.clone(),
                health: if degraded { AdapterHealth::Degraded } else { AdapterHealth::Online },
                message: if degraded {
                    "Источник доступен, часть возможностей ограничена правами доступа".into()
                } else {
                    "Источник доступен".into()
                },
                checked_at: Some(now),
                last_success_at: Some(now),
                latency_ms: Some(latency),
                permissions: perms,
            }
        }
        Err(e) => AdapterStatus {
            adapter_id: info.id.clone(),
            health: match &e {
                SwordError::Unauthorized(_) | SwordError::Forbidden(_) => AdapterHealth::Unauthorized,
                SwordError::RateLimited { .. } => AdapterHealth::RateLimited,
                SwordError::NotConfigured(_) => AdapterHealth::Unconfigured,
                _ => AdapterHealth::Offline,
            },
            message: e.to_string(),
            checked_at: Some(now),
            last_success_at: None,
            latency_ms: Some(latency),
            permissions: Vec::new(),
        },
    }
}
