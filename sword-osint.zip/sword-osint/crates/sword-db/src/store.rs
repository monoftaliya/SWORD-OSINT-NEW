//! Small repositories: settings, own assets, credential metadata, connector status,
//! metrics, reports, report drafts and the export journal.

use chrono::{DateTime, Utc};
use rusqlite::{params, OptionalExtension};
use serde::{Deserialize, Serialize};
use sword_core::{AdapterHealth, AdapterStatus, AppSettings, SwordError, SwordResult};

use crate::{opt_ts, parse_opt_ts, parse_ts, to_json, ts, Database};

const SETTINGS_KEY: &str = "app_settings";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AssetKind {
    Email,
    Domain,
    RepoLocal,
    RepoGithub,
}

impl AssetKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            AssetKind::Email => "email",
            AssetKind::Domain => "domain",
            AssetKind::RepoLocal => "repo_local",
            AssetKind::RepoGithub => "repo_github",
        }
    }
    pub fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "email" => AssetKind::Email,
            "domain" => AssetKind::Domain,
            "repo_local" => AssetKind::RepoLocal,
            "repo_github" => AssetKind::RepoGithub,
            _ => return None,
        })
    }
}

/// An asset the analyst declared as their own (INTELLIGENCE → «Мои активы»).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Asset {
    pub id: String,
    pub kind: AssetKind,
    /// Masked for e-mails, plain for domains/repositories.
    pub display: String,
    pub value_hash: String,
    /// Plain value for non-sensitive kinds (domain, repo path, owner/repo). `None` for e-mail.
    pub plain_value: Option<String>,
    pub attested: bool,
    pub verified: bool,
    pub verification_token: Option<String>,
    pub created_at: DateTime<Utc>,
    pub verified_at: Option<DateTime<Utc>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct MetricSample {
    pub name: String,
    pub value: f64,
    #[serde(default)]
    pub labels: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ReportRecord {
    pub id: String,
    pub investigation_id: Option<String>,
    pub title: String,
    pub created_at: DateTime<Utc>,
    pub path: String,
    pub pages: u32,
    pub bytes: u64,
    pub duration_ms: u32,
    pub exists: bool,
}

impl Database {
    // ---------------------------------------------------------------- settings

    pub fn load_settings(&self) -> SwordResult<AppSettings> {
        let raw: Option<String> = self.with(|c| {
            c.query_row("SELECT value FROM settings WHERE key = ?1", params![SETTINGS_KEY], |r| r.get(0)).optional()
        })?;
        Ok(raw.and_then(|s| serde_json::from_str::<AppSettings>(&s).ok()).unwrap_or_default().sanitized())
    }

    pub fn save_settings(&self, settings: &AppSettings) -> SwordResult<()> {
        let json = to_json(settings);
        self.with(|c| {
            c.execute(
                "INSERT INTO settings (key, value, updated_at) VALUES (?1, ?2, ?3) \
                 ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
                params![SETTINGS_KEY, json, ts(&Utc::now())],
            )
        })?;
        Ok(())
    }

    // ---------------------------------------------------------------- assets

    pub fn list_assets(&self) -> SwordResult<Vec<Asset>> {
        self.with(|c| {
            let mut st = c.prepare(
                "SELECT id, kind, display, value_hash, plain_value, attested, verified, verification_token, created_at, verified_at \
                 FROM assets ORDER BY kind, display",
            )?;
            let rows = st
                .query_map([], |r| {
                    let kind: String = r.get(1)?;
                    let created: String = r.get(8)?;
                    let verified_at: Option<String> = r.get(9)?;
                    Ok(Asset {
                        id: r.get(0)?,
                        kind: AssetKind::parse(&kind).unwrap_or(AssetKind::Domain),
                        display: r.get(2)?,
                        value_hash: r.get(3)?,
                        plain_value: r.get(4)?,
                        attested: r.get::<_, i64>(5)? != 0,
                        verified: r.get::<_, i64>(6)? != 0,
                        verification_token: r.get(7)?,
                        created_at: parse_ts(&created),
                        verified_at: parse_opt_ts(verified_at),
                    })
                })?
                .collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(rows)
        })
    }

    pub fn get_asset(&self, id: &str) -> SwordResult<Asset> {
        self.list_assets()?
            .into_iter()
            .find(|a| a.id == id)
            .ok_or_else(|| SwordError::NotFound(format!("актив {id}")))
    }

    pub fn insert_asset(&self, a: &Asset) -> SwordResult<()> {
        let n = self.with(|c| {
            c.execute(
                "INSERT OR IGNORE INTO assets (id, kind, display, value_hash, plain_value, attested, verified, verification_token, created_at, verified_at) \
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)",
                params![
                    a.id,
                    a.kind.as_str(),
                    a.display,
                    a.value_hash,
                    a.plain_value,
                    a.attested as i64,
                    a.verified as i64,
                    a.verification_token,
                    ts(&a.created_at),
                    opt_ts(&a.verified_at)
                ],
            )
        })?;
        if n == 0 {
            return Err(SwordError::InvalidInput("такой актив уже добавлен".into()));
        }
        Ok(())
    }

    pub fn set_asset_verified(&self, id: &str, verified: bool) -> SwordResult<()> {
        let when = if verified { Some(ts(&Utc::now())) } else { None };
        self.with(|c| c.execute("UPDATE assets SET verified = ?2, verified_at = ?3 WHERE id = ?1", params![id, verified as i64, when]))?;
        Ok(())
    }

    pub fn delete_asset(&self, id: &str) -> SwordResult<()> {
        self.with(|c| c.execute("DELETE FROM assets WHERE id = ?1", params![id]))?;
        Ok(())
    }

    // ---------------------------------------------------------------- credential metadata

    pub fn set_credential_meta(&self, key: &str, fingerprint: &str) -> SwordResult<()> {
        self.with(|c| {
            c.execute(
                "INSERT INTO credential_meta (key, updated_at, fingerprint) VALUES (?1, ?2, ?3) \
                 ON CONFLICT(key) DO UPDATE SET updated_at = excluded.updated_at, fingerprint = excluded.fingerprint",
                params![key, ts(&Utc::now()), fingerprint],
            )
        })?;
        Ok(())
    }

    pub fn delete_credential_meta(&self, key: &str) -> SwordResult<()> {
        self.with(|c| c.execute("DELETE FROM credential_meta WHERE key = ?1", params![key]))?;
        Ok(())
    }

    /// key → (updated_at, fingerprint)
    pub fn credential_meta(&self) -> SwordResult<std::collections::HashMap<String, (DateTime<Utc>, String)>> {
        self.with(|c| {
            let mut st = c.prepare("SELECT key, updated_at, fingerprint FROM credential_meta")?;
            let rows = st
                .query_map([], |r| {
                    let k: String = r.get(0)?;
                    let u: String = r.get(1)?;
                    let f: String = r.get(2)?;
                    Ok((k, (parse_ts(&u), f)))
                })?
                .collect::<rusqlite::Result<std::collections::HashMap<_, _>>>()?;
            Ok(rows)
        })
    }

    // ---------------------------------------------------------------- connector status

    pub fn save_status(&self, s: &AdapterStatus) -> SwordResult<()> {
        self.with(|c| {
            c.execute(
                "INSERT INTO connector_status (adapter_id, health, message, checked_at, last_success_at, latency_ms, permissions) \
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7) \
                 ON CONFLICT(adapter_id) DO UPDATE SET health = excluded.health, message = excluded.message, \
                   checked_at = excluded.checked_at, \
                   last_success_at = COALESCE(excluded.last_success_at, connector_status.last_success_at), \
                   latency_ms = excluded.latency_ms, permissions = excluded.permissions",
                params![
                    s.adapter_id,
                    s.health.as_str(),
                    s.message,
                    opt_ts(&s.checked_at),
                    opt_ts(&s.last_success_at),
                    s.latency_ms.map(|v| v as i64),
                    to_json(&s.permissions)
                ],
            )
        })?;
        Ok(())
    }

    /// Record that an adapter delivered data successfully (updates «last updated»).
    pub fn mark_adapter_success(&self, adapter_id: &str, at: &DateTime<Utc>) -> SwordResult<()> {
        self.with(|c| {
            c.execute(
                "INSERT INTO connector_status (adapter_id, health, message, last_success_at) VALUES (?1, 'online', 'Данные получены', ?2) \
                 ON CONFLICT(adapter_id) DO UPDATE SET last_success_at = excluded.last_success_at",
                params![adapter_id, ts(at)],
            )
        })?;
        Ok(())
    }

    pub fn list_status(&self) -> SwordResult<Vec<AdapterStatus>> {
        self.with(|c| {
            let mut st = c.prepare(
                "SELECT adapter_id, health, message, checked_at, last_success_at, latency_ms, permissions FROM connector_status",
            )?;
            let rows = st
                .query_map([], |r| {
                    let health: String = r.get(1)?;
                    let checked: Option<String> = r.get(3)?;
                    let success: Option<String> = r.get(4)?;
                    let latency: Option<i64> = r.get(5)?;
                    let perms: String = r.get(6)?;
                    Ok(AdapterStatus {
                        adapter_id: r.get(0)?,
                        health: AdapterHealth::parse(&health),
                        message: r.get(2)?,
                        checked_at: parse_opt_ts(checked),
                        last_success_at: parse_opt_ts(success),
                        latency_ms: latency.map(|v| v.clamp(0, u32::MAX as i64) as u32),
                        permissions: crate::from_json(&perms),
                    })
                })?
                .collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(rows)
        })
    }

    // ---------------------------------------------------------------- metrics

    pub fn insert_metrics(&self, samples: &[MetricSample]) -> SwordResult<()> {
        let now = ts(&Utc::now());
        self.with(|c| {
            let tx = c.transaction()?;
            {
                let mut st = tx.prepare("INSERT INTO metrics (ts, name, value, labels) VALUES (?1, ?2, ?3, ?4)")?;
                for s in samples.iter().filter(|s| s.value.is_finite()) {
                    st.execute(params![now, s.name, s.value, s.labels])?;
                }
            }
            // keep the metrics table bounded
            tx.execute("DELETE FROM metrics WHERE id NOT IN (SELECT id FROM metrics ORDER BY id DESC LIMIT 50000)", [])?;
            tx.commit()
        })
    }

    // ---------------------------------------------------------------- reports

    pub fn insert_report(&self, r: &ReportRecord, options_json: &str) -> SwordResult<()> {
        self.with(|c| {
            c.execute(
                "INSERT INTO reports (id, investigation_id, title, created_at, path, pages, bytes, duration_ms, options) \
                 VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)",
                params![
                    r.id,
                    r.investigation_id,
                    r.title,
                    ts(&r.created_at),
                    r.path,
                    r.pages as i64,
                    r.bytes as i64,
                    r.duration_ms as i64,
                    options_json
                ],
            )
        })?;
        Ok(())
    }

    pub fn list_reports(&self, investigation_id: Option<&str>) -> SwordResult<Vec<ReportRecord>> {
        let rows = self.with(|c| {
            let mut st = c.prepare(
                "SELECT id, investigation_id, title, created_at, path, pages, bytes, duration_ms FROM reports \
                 WHERE (?1 IS NULL OR investigation_id = ?1) ORDER BY created_at DESC LIMIT 200",
            )?;
            let rows = st
                .query_map(params![investigation_id], |r| {
                    let created: String = r.get(3)?;
                    let path: String = r.get(4)?;
                    Ok(ReportRecord {
                        id: r.get(0)?,
                        investigation_id: r.get(1)?,
                        title: r.get(2)?,
                        created_at: parse_ts(&created),
                        exists: false,
                        path,
                        pages: r.get::<_, i64>(5)?.max(0) as u32,
                        bytes: r.get::<_, i64>(6)?.max(0) as u64,
                        duration_ms: r.get::<_, i64>(7)?.max(0) as u32,
                    })
                })?
                .collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(rows)
        })?;
        Ok(rows
            .into_iter()
            .map(|mut r| {
                r.exists = std::path::Path::new(&r.path).exists();
                r
            })
            .collect())
    }

    pub fn get_report(&self, id: &str) -> SwordResult<ReportRecord> {
        self.list_reports(None)?.into_iter().find(|r| r.id == id).ok_or_else(|| SwordError::NotFound(format!("отчёт {id}")))
    }

    pub fn delete_report(&self, id: &str) -> SwordResult<Option<String>> {
        let path: Option<String> =
            self.with(|c| c.query_row("SELECT path FROM reports WHERE id = ?1", params![id], |r| r.get(0)).optional())?;
        self.with(|c| c.execute("DELETE FROM reports WHERE id = ?1", params![id]))?;
        Ok(path)
    }

    pub fn load_report_draft(&self, investigation_id: &str) -> SwordResult<Option<String>> {
        self.with(|c| {
            c.query_row("SELECT options FROM report_drafts WHERE investigation_id = ?1", params![investigation_id], |r| r.get(0))
                .optional()
        })
    }

    pub fn save_report_draft(&self, investigation_id: &str, options_json: &str) -> SwordResult<()> {
        self.with(|c| {
            c.execute(
                "INSERT INTO report_drafts (investigation_id, options, updated_at) VALUES (?1, ?2, ?3) \
                 ON CONFLICT(investigation_id) DO UPDATE SET options = excluded.options, updated_at = excluded.updated_at",
                params![investigation_id, options_json, ts(&Utc::now())],
            )
        })?;
        Ok(())
    }

    // ---------------------------------------------------------------- export journal

    /// Remember a file written by the app (only such files may be revealed/opened from UI).
    pub fn record_export(&self, kind: &str, path: &str) -> SwordResult<()> {
        self.with(|c| {
            c.execute(
                "INSERT INTO exports (id, created_at, kind, path) VALUES (?1, ?2, ?3, ?4)",
                params![sword_core::util::new_id(), ts(&Utc::now()), kind, path],
            )
        })?;
        Ok(())
    }

    pub fn is_known_output(&self, path: &str) -> SwordResult<bool> {
        let n: i64 = self.with(|c| {
            c.query_row(
                "SELECT (SELECT COUNT(*) FROM exports WHERE path = ?1) + (SELECT COUNT(*) FROM reports WHERE path = ?1)",
                params![path],
                |r| r.get(0),
            )
        })?;
        Ok(n > 0)
    }
}
