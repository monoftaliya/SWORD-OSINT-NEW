//! Embedded fonts (IBM Plex Sans / Mono, SIL OFL 1.1) and text measurement.
//!
//! Plex covers Latin and Cyrillic. Characters without a glyph are replaced by «·» before
//! layout so the PDF never contains invisible .notdef boxes.

use printpdf::{FontId, ParsedFont, PdfDocument};
use sword_core::{SwordError, SwordResult};

static PLEX_LIGHT: &[u8] = include_bytes!("../assets/fonts/IBMPlexSans-Light.ttf");
static PLEX_REGULAR: &[u8] = include_bytes!("../assets/fonts/IBMPlexSans-Regular.ttf");
static PLEX_MEDIUM: &[u8] = include_bytes!("../assets/fonts/IBMPlexSans-Medium.ttf");
static PLEX_SEMIBOLD: &[u8] = include_bytes!("../assets/fonts/IBMPlexSans-SemiBold.ttf");
static PLEX_MONO: &[u8] = include_bytes!("../assets/fonts/IBMPlexMono-Regular.ttf");

pub struct Font {
    pub id: FontId,
    face: ttf_parser::Face<'static>,
    upm: f32,
}

impl Font {
    fn load(doc: &mut PdfDocument, bytes: &'static [u8], name: &str) -> SwordResult<Self> {
        let mut warnings = Vec::new();
        let parsed = ParsedFont::from_bytes(bytes, 0, &mut warnings)
            .ok_or_else(|| SwordError::Internal(format!("не удалось загрузить шрифт {name}")))?;
        let id = doc.add_font(&parsed);
        let face = ttf_parser::Face::parse(bytes, 0).map_err(|e| SwordError::Internal(format!("шрифт {name}: {e}")))?;
        let upm = face.units_per_em() as f32;
        Ok(Font { id, face, upm })
    }

    fn advance(&self, c: char) -> f32 {
        self.face
            .glyph_index(c)
            .and_then(|g| self.face.glyph_hor_advance(g))
            .map(|a| a as f32)
            .unwrap_or(self.upm * 0.5)
    }

    /// Width of `text` at `size` pt, with optional extra character spacing (Tc).
    pub fn width(&self, text: &str, size: f32) -> f32 {
        self.width_spaced(text, size, 0.0)
    }

    pub fn width_spaced(&self, text: &str, size: f32, char_spacing: f32) -> f32 {
        let n = text.chars().count() as f32;
        text.chars().map(|c| self.advance(c)).sum::<f32>() * size / self.upm + char_spacing * n
    }

    pub fn has_glyph(&self, c: char) -> bool {
        self.face.glyph_index(c).is_some()
    }
}

pub struct Fonts {
    pub light: Font,
    pub regular: Font,
    pub medium: Font,
    pub semibold: Font,
    pub mono: Font,
}

impl Fonts {
    pub fn load(doc: &mut PdfDocument) -> SwordResult<Self> {
        Ok(Fonts {
            light: Font::load(doc, PLEX_LIGHT, "IBM Plex Sans Light")?,
            regular: Font::load(doc, PLEX_REGULAR, "IBM Plex Sans")?,
            medium: Font::load(doc, PLEX_MEDIUM, "IBM Plex Sans Medium")?,
            semibold: Font::load(doc, PLEX_SEMIBOLD, "IBM Plex Sans SemiBold")?,
            mono: Font::load(doc, PLEX_MONO, "IBM Plex Mono")?,
        })
    }

    /// Replace characters the fonts cannot render and normalise whitespace.
    pub fn sanitize(&self, s: &str) -> String {
        s.chars()
            .map(|c| match c {
                '\t' => ' ',
                '\r' => ' ',
                '\u{00A0}' | '\u{202F}' | '\u{2009}' => ' ',
                '\n' => '\n',
                c if c.is_control() => ' ',
                c if self.regular.has_glyph(c) => c,
                _ => '·',
            })
            .collect()
    }
}
