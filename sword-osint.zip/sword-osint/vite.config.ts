import { defineConfig } from 'vite';
import { svelte } from '@sveltejs/vite-plugin-svelte';

// Tauri expects a fixed dev port and serves the built files from ../dist.
// three.js is only imported by the lazily loaded 3D engines (particle universe and
// network graph), so the bundler places it in its own asynchronous chunk.
export default defineConfig({
  plugins: [svelte()],
  clearScreen: false,
  server: {
    port: 1420,
    strictPort: true,
    host: '127.0.0.1',
    watch: { ignored: ['**/src-tauri/**', '**/crates/**', '**/target/**'] },
  },
  envPrefix: ['VITE_', 'TAURI_ENV_'],
  build: {
    // WebView2 on Windows 11 is evergreen Chromium.
    target: 'chrome120',
    sourcemap: false,
    chunkSizeWarningLimit: 1800,
  },
  worker: { format: 'es' },
});
