<!--
  Parts of one whole as a ring (2px surface gaps), total in the centre, legend with
  values and shares. Hovering a segment or a legend row shows that part in the centre.
-->
<script lang="ts">
  import { fmtNum } from '../../util/format';

  let {
    items,
    caption,
    size = 120,
  }: { items: { key: string; label: string; value: number; color: string }[]; caption: string; size?: number } = $props();

  let active = $state<string | null>(null);
  const parts = $derived(items.filter((i) => i.value > 0));
  const total = $derived(parts.reduce((s, i) => s + i.value, 0));
  const R = $derived(size / 2 - 9);
  const C = $derived(2 * Math.PI * R);
  const gap = $derived(parts.length > 1 ? 2 : 0);
  const segs = $derived.by(() => {
    let off = 0;
    return parts.map((p) => {
      const len = total ? (p.value / total) * C : 0;
      const s = { ...p, dash: `${Math.max(0.5, len - gap)} ${C}`, offset: -off };
      off += len;
      return s;
    });
  });
  const shown = $derived(parts.find((p) => p.key === active) ?? null);
</script>

<div class="donut">
  <div class="ring" style:width="{size}px" style:height="{size}px">
    <svg width={size} height={size} viewBox="0 0 {size} {size}" role="img" aria-label="{caption}: {fmtNum(total)}">
      <circle class="track" cx={size / 2} cy={size / 2} r={R} />
      <g transform="rotate(-90 {size / 2} {size / 2})">
        {#each segs as s (s.key)}
          <circle
            class="seg"
            class:dim={active !== null && active !== s.key}
            cx={size / 2}
            cy={size / 2}
            r={R}
            stroke={s.color}
            stroke-dasharray={s.dash}
            stroke-dashoffset={s.offset}
            role="presentation"
            onpointerenter={() => (active = s.key)}
            onpointerleave={() => (active = null)}
          />
        {/each}
      </g>
    </svg>
    <div class="center">
      {#if shown}
        <strong class="num">{fmtNum(shown.value)}</strong>
        <span>{shown.label}</span>
      {:else}
        <strong class="num">{fmtNum(total)}</strong>
        <span>{caption}</span>
      {/if}
    </div>
  </div>
  <ul class="legend">
    {#each items as it (it.key)}
      <li>
        <button
          type="button"
          class:on={active === it.key}
          onpointerenter={() => (active = it.key)}
          onpointerleave={() => (active = null)}
          onfocus={() => (active = it.key)}
          onblur={() => (active = null)}
        >
          <i class="key" style:background={it.color}></i>
          <span class="lbl">{it.label}</span>
          <span class="val num">{fmtNum(it.value)}</span>
          <span class="pct num">{total ? Math.round((it.value / total) * 100) : 0}%</span>
        </button>
      </li>
    {/each}
  </ul>
</div>

<style>
  .donut {
    display: flex;
    align-items: center;
    gap: 18px;
  }
  .ring {
    position: relative;
    flex: none;
  }
  svg {
    display: block;
  }
  .track {
    fill: none;
    stroke: rgba(255, 255, 255, 0.04);
    stroke-width: 12;
  }
  .seg {
    fill: none;
    stroke-width: 12;
    pointer-events: stroke;
    transition: opacity 0.15s;
  }
  .seg.dim {
    opacity: 0.3;
  }
  .center {
    position: absolute;
    inset: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    pointer-events: none;
    text-align: center;
    padding: 0 22px;
  }
  .center strong {
    font-size: 19px;
    font-weight: 600;
    color: #fff;
  }
  .center span {
    font-size: 10.5px;
    color: var(--fg-3);
    line-height: 1.25;
  }
  .legend {
    list-style: none;
    margin: 0;
    padding: 0;
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 1px;
  }
  .legend button {
    width: 100%;
    display: grid;
    grid-template-columns: 8px minmax(0, 1fr) auto 32px;
    align-items: center;
    gap: 8px;
    padding: 4px 6px;
    border: none;
    border-radius: 6px;
    background: transparent;
    color: var(--fg-2);
    font-size: 12px;
    text-align: left;
    cursor: default;
  }
  .legend button.on,
  .legend button:focus-visible {
    background: rgba(255, 255, 255, 0.045);
    outline: none;
  }
  .key {
    width: 8px;
    height: 8px;
    border-radius: 2px;
  }
  .lbl {
    line-height: 1.3;
    overflow-wrap: anywhere;
  }
  .val {
    color: var(--fg);
  }
  .pct {
    color: var(--fg-3);
    text-align: right;
  }
</style>
