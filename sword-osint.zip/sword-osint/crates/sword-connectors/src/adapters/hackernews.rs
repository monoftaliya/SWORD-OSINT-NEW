//! Hacker News (Algolia HN Search API) — public discussions of companies, products and domains.

use async_trait::async_trait;
use sword_core::util::parse_date;
use sword_core::{AdapterInfo, AdapterOutput, Category, ClassifiedInput, FindingKind, InputKind, PermissionCheck, SwordResult};

use super::{arr, info, num, s};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::output::{FindingExt, OutputBuilder};

const ENDPOINT: &str = "https://hn.algolia.com/api/v1/search";

pub struct HackerNews {
    info: AdapterInfo,
}

impl Default for HackerNews {
    fn default() -> Self {
        Self::new()
    }
}

impl HackerNews {
    pub fn new() -> Self {
        HackerNews {
            info: info(
                "hackernews",
                "Hacker News",
                "Y Combinator / Algolia",
                "Публичные обсуждения на Hacker News: упоминания организаций, продуктов и доменов.",
                "Algolia HN Search API (hn.algolia.com/api/v1/search), теги story. Для доменов поиск ограничивается полем url. \
                 Сохраняются заголовок, ссылка на обсуждение, дата и метрики; имена авторов не сохраняются.",
                &[Category::SocialNetworks, Category::DigitalFootprint],
                &[InputKind::Text, InputKind::Domain, InputKind::Url],
                vec![],
                vec![],
                100,
                "https://news.ycombinator.com/",
                Some("https://hn.algolia.com/api"),
                true,
            ),
        }
    }
}

#[async_trait]
impl SourceAdapter for HackerNews {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let req = ctx.get(ENDPOINT).query(&[("query", "osint"), ("hitsPerPage", "1")]);
        let _: serde_json::Value = ctx.json(&self.info, req).await?;
        Ok(vec![PermissionCheck::granted("Search API", "Доступ без ключа")])
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let mut b = OutputBuilder::new(&self.info);
        let hits = ctx.max_results.clamp(5, 50).to_string();
        let (query, restrict) = match &input.registrable_domain {
            Some(d) => (d.clone(), Some("url")),
            None => (input.text.clone(), None),
        };
        let mut params: Vec<(&str, &str)> = vec![("query", query.as_str()), ("tags", "story"), ("hitsPerPage", hits.as_str())];
        if let Some(attr) = restrict {
            params.push(("restrictSearchableAttributes", attr));
        }
        let v: serde_json::Value = ctx.json(&self.info, ctx.get(ENDPOINT).query(&params)).await?;
        b.source(
            &format!("https://hn.algolia.com/?q={}", url::form_urlencoded::byte_serialize(query.as_bytes()).collect::<String>()),
            &format!("Hacker News: «{query}»"),
        );
        for h in arr(&v, "/hits") {
            let Some(id) = s(h, "objectID") else { continue };
            let item = format!("https://news.ycombinator.com/item?id={id}");
            let title = s(h, "title").unwrap_or_else(|| "Обсуждение на Hacker News".into());
            let f = b.finding(Category::SocialNetworks, FindingKind::Publication, &title, Some(&item));
            f.published(s(h, "created_at").and_then(|d| parse_date(&d)))
                .confidence(0.85)
                .attr("Баллы", num(h, "points").map(|n| n.to_string()).unwrap_or_default())
                .attr("Комментарии", num(h, "num_comments").map(|n| n.to_string()).unwrap_or_default());
            if let Some(link) = s(h, "url") {
                f.attr("Ссылка в обсуждении", link);
            }
            if let Some(text) = s(h, "story_text") {
                f.snippet(&text);
            }
            b.source(&item, &title);
        }
        Ok(b.finish())
    }
}
