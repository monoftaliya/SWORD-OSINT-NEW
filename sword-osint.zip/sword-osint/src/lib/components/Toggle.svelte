<script lang="ts">
  let { checked = $bindable(false), label = '', disabled = false, onchange }: { checked?: boolean; label?: string; disabled?: boolean; onchange?: (v: boolean) => void } = $props();

  function flip() {
    if (disabled) return;
    checked = !checked;
    onchange?.(checked);
  }
</script>

<button type="button" class="toggle" class:on={checked} {disabled} role="switch" aria-checked={checked} onclick={flip}>
  <span class="track"><span class="knob"></span></span>
  {#if label}<span class="label-text">{label}</span>{/if}
</button>

<style>
  .toggle {
    display: inline-flex;
    align-items: center;
    gap: 10px;
    background: none;
    border: none;
    padding: 0;
    cursor: pointer;
    color: var(--fg-2);
    font-size: 12.5px;
    text-align: left;
  }
  .toggle:disabled {
    opacity: 0.4;
    cursor: default;
  }
  .track {
    position: relative;
    width: 34px;
    height: 19px;
    border-radius: 99px;
    border: 1px solid var(--line-strong);
    background: rgba(255, 255, 255, 0.04);
    transition: background 0.25s var(--ease), border-color 0.25s;
    flex: none;
  }
  .knob {
    position: absolute;
    top: 2px;
    left: 2px;
    width: 13px;
    height: 13px;
    border-radius: 50%;
    background: var(--fg-3);
    transition: transform 0.3s var(--ease-out), background 0.25s, box-shadow 0.25s;
  }
  .on .track {
    background: rgba(230, 238, 250, 0.16);
    border-color: rgba(230, 238, 250, 0.4);
  }
  .on .knob {
    transform: translateX(15px);
    background: #fff;
    box-shadow: 0 0 10px rgba(235, 242, 255, 0.9);
  }
  .on .label-text {
    color: var(--fg);
  }
</style>
