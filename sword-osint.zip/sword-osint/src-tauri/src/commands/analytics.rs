//! ANALYTICS: statistics computed from the local database.

use std::collections::HashMap;

use sword_analytics::AnalyticsReport;
use tauri::State;

use crate::error::ApiResult;
use crate::state::{blocking, AppState};

#[tauri::command]
pub async fn get_analytics(state: State<'_, AppState>, range_days: u32) -> ApiResult<AnalyticsReport> {
    let mut names: HashMap<String, String> = state.registry().all().iter().map(|a| (a.info().id.clone(), a.info().name.clone())).collect();
    for c in sword_audit::AuditCheck::ALL {
        let i = c.module_info();
        names.insert(i.id, format!("Аудит: {}", i.name));
    }
    let db = state.db.clone();
    blocking(move || sword_analytics::compute(&db, range_days.min(3650), &names)).await
}
