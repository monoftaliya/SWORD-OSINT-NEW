//! Investigation history: records, adapter runs, findings, sources and graphs.

use std::collections::{BTreeSet, HashMap};

use rusqlite::types::Value;
use rusqlite::{params, params_from_iter, OptionalExtension, Row};
use serde::{Deserialize, Serialize};
use sword_core::util::canonical_url;
use sword_core::{
    AdapterRun, Category, ErrorKind, Finding, FindingKind, InputKind, InvestigationKind, InvestigationRecord,
    InvestigationStatus, RunStatus, Severity, SourceRef, SwordError, SwordResult,
};
use sword_graph::{Graph, GraphEdge, GraphNode};

use crate::{fts_query, opt_ts, parse_opt_ts, parse_ts, to_json, ts, Database};

const RECORD_COLS: &str = "id, kind, query, input_kind, categories, status, created_at, finished_at, duration_ms, \
     result_count, source_count, node_count, edge_count, adapters, summary, key_facts, limitations, error, notes";

const FINDING_COLS: &str = "f.id, f.investigation_id, f.adapter_id, f.category, f.kind, f.title, f.url, f.snippet, \
     f.published_at, f.retrieved_at, f.confidence, f.severity, f.attributes, f.entity_key";

/// Filters, search and sorting for HISTORY.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct HistoryQuery {
    pub search: Option<String>,
    pub status: Option<String>,
    pub kind: Option<String>,
    pub category: Option<String>,
    pub adapter: Option<String>,
    /// Inclusive `YYYY-MM-DD` bounds (UTC).
    pub from: Option<String>,
    pub to: Option<String>,
    /// `created_desc` (default) | `created_asc` | `results_desc` | `results_asc` |
    /// `duration_desc` | `query_asc` | `sources_desc`
    pub sort: Option<String>,
    pub limit: Option<u32>,
    pub offset: Option<u32>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct HistoryPage {
    pub items: Vec<InvestigationRecord>,
    pub total: u32,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InvestigationDetail {
    pub record: InvestigationRecord,
    pub runs: Vec<AdapterRun>,
    pub findings: Vec<Finding>,
    pub sources: Vec<SourceRef>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct FindingBrief {
    pub title: String,
    pub url: Option<String>,
    pub adapter_id: String,
    pub kind: FindingKind,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AdapterDelta {
    pub adapter_id: String,
    pub adapter_name: String,
    pub a_status: Option<RunStatus>,
    pub b_status: Option<RunStatus>,
    pub a_results: Option<u32>,
    pub b_results: Option<u32>,
}

/// Side-by-side comparison of two investigations.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Comparison {
    pub a: InvestigationRecord,
    pub b: InvestigationRecord,
    pub common_sources: Vec<String>,
    pub only_a_sources: Vec<String>,
    pub only_b_sources: Vec<String>,
    pub common_findings: Vec<FindingBrief>,
    pub only_a_findings: Vec<FindingBrief>,
    pub only_b_findings: Vec<FindingBrief>,
    pub common_entities: Vec<String>,
    pub only_a_entities: Vec<String>,
    pub only_b_entities: Vec<String>,
    pub adapters: Vec<AdapterDelta>,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
#[serde(default, rename_all = "camelCase")]
pub struct KnowledgeQuery {
    pub text: String,
    pub adapter: Option<String>,
    pub category: Option<String>,
    pub kind: Option<String>,
    pub limit: Option<u32>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct KnowledgeHit {
    pub finding: Finding,
    pub investigation_id: String,
    pub investigation_query: String,
    pub investigation_created_at: chrono::DateTime<chrono::Utc>,
    pub rank: f64,
}

fn record_from_row(r: &Row<'_>) -> rusqlite::Result<InvestigationRecord> {
    let kind: String = r.get(1)?;
    let input_kind: String = r.get(3)?;
    let categories: String = r.get(4)?;
    let status: String = r.get(5)?;
    let created: String = r.get(6)?;
    let finished: Option<String> = r.get(7)?;
    let duration: Option<i64> = r.get(8)?;
    let adapters: String = r.get(13)?;
    let key_facts: String = r.get(15)?;
    let limitations: String = r.get(16)?;
    Ok(InvestigationRecord {
        id: r.get(0)?,
        kind: InvestigationKind::parse(&kind).unwrap_or(InvestigationKind::Discovery),
        query: r.get(2)?,
        input_kind: InputKind::parse(&input_kind).unwrap_or(InputKind::Text),
        categories: crate::from_json::<Vec<Category>>(&categories),
        status: InvestigationStatus::parse(&status).unwrap_or(InvestigationStatus::Failed),
        created_at: parse_ts(&created),
        finished_at: parse_opt_ts(finished),
        duration_ms: duration.map(|d| d.clamp(0, u32::MAX as i64) as u32),
        result_count: r.get::<_, i64>(9)?.max(0) as u32,
        source_count: r.get::<_, i64>(10)?.max(0) as u32,
        node_count: r.get::<_, i64>(11)?.max(0) as u32,
        edge_count: r.get::<_, i64>(12)?.max(0) as u32,
        adapters: crate::from_json::<Vec<String>>(&adapters),
        summary: r.get(14)?,
        key_facts: crate::from_json(&key_facts),
        limitations: crate::from_json(&limitations),
        error: r.get(17)?,
        notes: r.get(18)?,
    })
}

/// Map a row selected with [`FINDING_COLS`] (offset 0).
fn finding_from_row(r: &Row<'_>) -> rusqlite::Result<Finding> {
    let category: String = r.get(3)?;
    let kind: String = r.get(4)?;
    let published: Option<String> = r.get(8)?;
    let retrieved: String = r.get(9)?;
    let severity: Option<String> = r.get(11)?;
    let attributes: String = r.get(12)?;
    Ok(Finding {
        id: r.get(0)?,
        adapter_id: r.get(2)?,
        category: Category::parse(&category).unwrap_or(Category::WebSearch),
        kind: FindingKind::parse(&kind).unwrap_or(FindingKind::WebPage),
        title: r.get(5)?,
        url: r.get(6)?,
        snippet: r.get(7)?,
        published_at: parse_opt_ts(published),
        retrieved_at: parse_ts(&retrieved),
        confidence: r.get::<_, f64>(10)? as f32,
        severity: severity.as_deref().and_then(Severity::parse),
        attributes: crate::from_json(&attributes),
        entity_key: r.get(13)?,
    })
}

fn run_from_row(r: &Row<'_>) -> rusqlite::Result<AdapterRun> {
    let status: String = r.get(2)?;
    let started: Option<String> = r.get(3)?;
    let finished: Option<String> = r.get(4)?;
    let duration: Option<i64> = r.get(5)?;
    let error_kind: Option<String> = r.get(7)?;
    Ok(AdapterRun {
        adapter_id: r.get(0)?,
        adapter_name: r.get(1)?,
        status: RunStatus::parse(&status).unwrap_or(RunStatus::Failed),
        started_at: parse_opt_ts(started),
        finished_at: parse_opt_ts(finished),
        duration_ms: duration.map(|d| d.clamp(0, u32::MAX as i64) as u32),
        result_count: r.get::<_, i64>(6)?.max(0) as u32,
        error_kind: error_kind.as_deref().and_then(ErrorKind::parse),
        message: r.get(8)?,
    })
}

fn upsert_record(tx: &rusqlite::Transaction<'_>, rec: &InvestigationRecord) -> rusqlite::Result<()> {
    tx.execute(
        "INSERT INTO investigations (id, kind, query, input_kind, categories, status, created_at, finished_at, duration_ms, \
           result_count, source_count, node_count, edge_count, adapters, summary, key_facts, limitations, error, notes) \
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15, ?16, ?17, ?18, ?19) \
         ON CONFLICT(id) DO UPDATE SET kind = excluded.kind, query = excluded.query, input_kind = excluded.input_kind, \
           categories = excluded.categories, status = excluded.status, finished_at = excluded.finished_at, \
           duration_ms = excluded.duration_ms, result_count = excluded.result_count, source_count = excluded.source_count, \
           node_count = excluded.node_count, edge_count = excluded.edge_count, adapters = excluded.adapters, \
           summary = excluded.summary, key_facts = excluded.key_facts, limitations = excluded.limitations, \
           error = excluded.error",
        params![
            rec.id,
            rec.kind.as_str(),
            rec.query,
            rec.input_kind.as_str(),
            to_json(&rec.categories),
            rec.status.as_str(),
            ts(&rec.created_at),
            opt_ts(&rec.finished_at),
            rec.duration_ms.map(|d| d as i64),
            rec.result_count as i64,
            rec.source_count as i64,
            rec.node_count as i64,
            rec.edge_count as i64,
            to_json(&rec.adapters),
            rec.summary,
            to_json(&rec.key_facts),
            to_json(&rec.limitations),
            rec.error,
            rec.notes,
        ],
    )?;
    Ok(())
}

impl Database {
    /// Insert the header of an investigation that has just started.
    pub fn insert_running(&self, rec: &InvestigationRecord) -> SwordResult<()> {
        self.with(|c| {
            let tx = c.transaction()?;
            upsert_record(&tx, rec)?;
            tx.commit()
        })
    }

    /// Persist a finished investigation with all its children in one transaction.
    pub fn save_investigation(
        &self,
        rec: &InvestigationRecord,
        runs: &[AdapterRun],
        findings: &[Finding],
        sources: &[SourceRef],
        graph: &Graph,
        store_snippets: bool,
    ) -> SwordResult<()> {
        self.with(|c| {
            let tx = c.transaction()?;
            upsert_record(&tx, rec)?;
            for table in ["adapter_runs", "findings", "sources", "graph_nodes", "graph_edges"] {
                tx.execute(&format!("DELETE FROM {table} WHERE investigation_id = ?1"), params![rec.id])?;
            }
            {
                let mut st = tx.prepare(
                    "INSERT INTO adapter_runs (investigation_id, adapter_id, adapter_name, status, started_at, finished_at, \
                       duration_ms, result_count, error_kind, message) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)",
                )?;
                for r in runs {
                    st.execute(params![
                        rec.id,
                        r.adapter_id,
                        r.adapter_name,
                        r.status.as_str(),
                        opt_ts(&r.started_at),
                        opt_ts(&r.finished_at),
                        r.duration_ms.map(|d| d as i64),
                        r.result_count as i64,
                        r.error_kind.map(|k| k.as_str()),
                        r.message,
                    ])?;
                }
            }
            {
                let mut st = tx.prepare(
                    "INSERT OR REPLACE INTO findings (id, investigation_id, adapter_id, category, kind, title, url, snippet, \
                       published_at, retrieved_at, confidence, severity, attributes, entity_key) \
                     VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14)",
                )?;
                for f in findings {
                    st.execute(params![
                        f.id,
                        rec.id,
                        f.adapter_id,
                        f.category.as_str(),
                        f.kind.as_str(),
                        f.title,
                        f.url,
                        if store_snippets { f.snippet.clone() } else { None },
                        opt_ts(&f.published_at),
                        ts(&f.retrieved_at),
                        f.confidence as f64,
                        f.severity.map(|s| s.as_str()),
                        to_json(&f.attributes),
                        f.entity_key,
                    ])?;
                }
            }
            {
                let mut st = tx.prepare(
                    "INSERT OR IGNORE INTO sources (investigation_id, url, title, adapter_id, retrieved_at) VALUES (?1, ?2, ?3, ?4, ?5)",
                )?;
                for s in sources {
                    st.execute(params![rec.id, s.url, s.title, s.adapter_id, ts(&s.retrieved_at)])?;
                }
            }
            {
                let mut st = tx.prepare(
                    "INSERT OR REPLACE INTO graph_nodes (investigation_id, key, kind, label, attributes, sources) VALUES (?1, ?2, ?3, ?4, ?5, ?6)",
                )?;
                for n in &graph.nodes {
                    st.execute(params![rec.id, n.key, n.kind.as_str(), n.label, to_json(&n.attributes), to_json(&n.sources)])?;
                }
            }
            {
                let mut st = tx.prepare(
                    "INSERT OR REPLACE INTO graph_edges (investigation_id, id, from_key, to_key, relation, confidence, evidence) VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7)",
                )?;
                for e in &graph.edges {
                    st.execute(params![rec.id, e.id, e.from, e.to, e.relation, e.confidence as f64, to_json(&e.evidence)])?;
                }
            }
            tx.commit()
        })
    }

    /// Investigations left `running` by a crash are marked as failed at startup.
    pub fn mark_interrupted(&self) -> SwordResult<u32> {
        self.with(|c| {
            c.execute(
                "UPDATE investigations SET status = 'failed', error = 'Выполнение прервано (приложение было закрыто)' WHERE status = 'running'",
                [],
            )
            .map(|n| n as u32)
        })
    }

    pub fn update_notes(&self, id: &str, notes: &str) -> SwordResult<()> {
        let n = self.with(|c| c.execute("UPDATE investigations SET notes = ?2 WHERE id = ?1", params![id, notes]))?;
        if n == 0 {
            return Err(SwordError::NotFound(format!("исследование {id}")));
        }
        Ok(())
    }

    pub fn get_record(&self, id: &str) -> SwordResult<Option<InvestigationRecord>> {
        self.with(|c| {
            c.query_row(&format!("SELECT {RECORD_COLS} FROM investigations WHERE id = ?1"), params![id], record_from_row)
                .optional()
        })
    }

    pub fn get_detail(&self, id: &str) -> SwordResult<InvestigationDetail> {
        let record = self.get_record(id)?.ok_or_else(|| SwordError::NotFound(format!("исследование {id}")))?;
        let (runs, findings, sources) = self.with(|c| {
            let mut st = c.prepare(
                "SELECT adapter_id, adapter_name, status, started_at, finished_at, duration_ms, result_count, error_kind, message \
                 FROM adapter_runs WHERE investigation_id = ?1 ORDER BY adapter_name",
            )?;
            let runs = st.query_map(params![id], run_from_row)?.collect::<rusqlite::Result<Vec<_>>>()?;
            let mut st = c.prepare(&format!(
                "SELECT {FINDING_COLS} FROM findings f WHERE f.investigation_id = ?1 ORDER BY f.category, f.confidence DESC, f.rowid"
            ))?;
            let findings = st.query_map(params![id], finding_from_row)?.collect::<rusqlite::Result<Vec<_>>>()?;
            let mut st = c.prepare(
                "SELECT url, title, adapter_id, retrieved_at FROM sources WHERE investigation_id = ?1 ORDER BY adapter_id, url",
            )?;
            let sources = st
                .query_map(params![id], |r| {
                    let retrieved: String = r.get(3)?;
                    Ok(SourceRef { url: r.get(0)?, title: r.get(1)?, adapter_id: r.get(2)?, retrieved_at: parse_ts(&retrieved) })
                })?
                .collect::<rusqlite::Result<Vec<_>>>()?;
            Ok((runs, findings, sources))
        })?;
        Ok(InvestigationDetail { record, runs, findings, sources })
    }

    pub fn list_history(&self, q: &HistoryQuery) -> SwordResult<HistoryPage> {
        let mut where_sql: Vec<String> = Vec::new();
        let mut args: Vec<Value> = Vec::new();

        if let Some(expr) = q.search.as_deref().and_then(fts_query) {
            args.push(Value::Text(expr.clone()));
            let a = args.len();
            args.push(Value::Text(expr));
            let b = args.len();
            where_sql.push(format!(
                "(i.rowid IN (SELECT rowid FROM investigations_fts WHERE investigations_fts MATCH ?{a}) \
                  OR i.id IN (SELECT f.investigation_id FROM findings_fts JOIN findings f ON f.rowid = findings_fts.rowid \
                              WHERE findings_fts MATCH ?{b}))"
            ));
        }
        if let Some(s) = q.status.as_deref().filter(|s| !s.is_empty()) {
            args.push(Value::Text(s.to_string()));
            where_sql.push(format!("i.status = ?{}", args.len()));
        }
        if let Some(k) = q.kind.as_deref().filter(|s| !s.is_empty()) {
            args.push(Value::Text(k.to_string()));
            where_sql.push(format!("i.kind = ?{}", args.len()));
        }
        if let Some(cat) = q.category.as_deref().filter(|s| !s.is_empty()) {
            args.push(Value::Text(format!("%\"{}\"%", cat.replace(['%', '_', '"'], ""))));
            where_sql.push(format!("i.categories LIKE ?{}", args.len()));
        }
        if let Some(ad) = q.adapter.as_deref().filter(|s| !s.is_empty()) {
            args.push(Value::Text(ad.to_string()));
            where_sql.push(format!(
                "EXISTS (SELECT 1 FROM adapter_runs r WHERE r.investigation_id = i.id AND r.adapter_id = ?{})",
                args.len()
            ));
        }
        if let Some(from) = q.from.as_deref().filter(|s| s.len() == 10) {
            args.push(Value::Text(format!("{from}T00:00:00.000Z")));
            where_sql.push(format!("i.created_at >= ?{}", args.len()));
        }
        if let Some(to) = q.to.as_deref().filter(|s| s.len() == 10) {
            args.push(Value::Text(format!("{to}T23:59:59.999Z")));
            where_sql.push(format!("i.created_at <= ?{}", args.len()));
        }
        let where_clause = if where_sql.is_empty() { String::new() } else { format!("WHERE {}", where_sql.join(" AND ")) };
        let order = match q.sort.as_deref().unwrap_or("created_desc") {
            "created_asc" => "i.created_at ASC",
            "results_desc" => "i.result_count DESC, i.created_at DESC",
            "results_asc" => "i.result_count ASC, i.created_at DESC",
            "duration_desc" => "i.duration_ms DESC, i.created_at DESC",
            "sources_desc" => "i.source_count DESC, i.created_at DESC",
            "query_asc" => "i.query COLLATE NOCASE ASC",
            _ => "i.created_at DESC",
        };
        let limit = q.limit.unwrap_or(50).clamp(1, 500) as i64;
        let offset = q.offset.unwrap_or(0) as i64;
        let cols = RECORD_COLS.split(", ").map(|c| format!("i.{c}")).collect::<Vec<_>>().join(", ");

        self.with(|c| {
            let total: i64 = c.query_row(
                &format!("SELECT COUNT(*) FROM investigations i {where_clause}"),
                params_from_iter(args.iter()),
                |r| r.get(0),
            )?;
            let mut page_args = args.clone();
            page_args.push(Value::Integer(limit));
            page_args.push(Value::Integer(offset));
            let sql = format!(
                "SELECT {cols} FROM investigations i {where_clause} ORDER BY {order} LIMIT ?{} OFFSET ?{}",
                page_args.len() - 1,
                page_args.len()
            );
            let mut st = c.prepare(&sql)?;
            let items = st.query_map(params_from_iter(page_args.iter()), record_from_row)?.collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(HistoryPage { items, total: total.max(0) as u32 })
        })
    }

    pub fn delete_investigations(&self, ids: &[String]) -> SwordResult<u32> {
        self.with(|c| {
            let tx = c.transaction()?;
            let mut n = 0u32;
            for id in ids {
                n += tx.execute("DELETE FROM investigations WHERE id = ?1", params![id])? as u32;
            }
            tx.commit()?;
            Ok(n)
        })
    }

    pub fn graph_of(&self, id: &str) -> SwordResult<Graph> {
        self.with(|c| load_graph(c, Some(id)))
    }

    /// Graphs of the `limit` most recent investigations (for the merged knowledge graph).
    pub fn recent_graphs(&self, limit: u32) -> SwordResult<Vec<Graph>> {
        let ids: Vec<String> = self.with(|c| {
            let mut st = c.prepare("SELECT id FROM investigations WHERE node_count > 0 ORDER BY created_at DESC LIMIT ?1")?;
            let ids = st.query_map(params![limit as i64], |r| r.get::<_, String>(0))?.collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(ids)
        })?;
        ids.iter().map(|id| self.graph_of(id)).collect()
    }

    pub fn compare(&self, a: &str, b: &str) -> SwordResult<Comparison> {
        let da = self.get_detail(a)?;
        let db = self.get_detail(b)?;
        let ga = self.graph_of(a)?;
        let gb = self.graph_of(b)?;

        let src_a: BTreeSet<String> = da.sources.iter().map(|s| canonical_url(&s.url)).collect();
        let src_b: BTreeSet<String> = db.sources.iter().map(|s| canonical_url(&s.url)).collect();

        let ident = |f: &Finding| match &f.url {
            Some(u) => canonical_url(u),
            None => format!("{}::{}", f.adapter_id, f.title.to_lowercase()),
        };
        let brief = |f: &Finding| FindingBrief { title: f.title.clone(), url: f.url.clone(), adapter_id: f.adapter_id.clone(), kind: f.kind };
        let fa: HashMap<String, &Finding> = da.findings.iter().map(|f| (ident(f), f)).collect();
        let fb: HashMap<String, &Finding> = db.findings.iter().map(|f| (ident(f), f)).collect();

        let mut common_findings = Vec::new();
        let mut only_a_findings = Vec::new();
        for (k, f) in &fa {
            if fb.contains_key(k) {
                common_findings.push(brief(f));
            } else {
                only_a_findings.push(brief(f));
            }
        }
        let only_b_findings: Vec<FindingBrief> = fb.iter().filter(|(k, _)| !fa.contains_key(*k)).map(|(_, f)| brief(f)).collect();

        let ent_a: BTreeSet<String> = ga.nodes.iter().filter(|n| !n.key.starts_with("source:")).map(|n| n.label.clone()).collect();
        let ent_b: BTreeSet<String> = gb.nodes.iter().filter(|n| !n.key.starts_with("source:")).map(|n| n.label.clone()).collect();

        let mut adapter_ids: BTreeSet<String> = da.runs.iter().map(|r| r.adapter_id.clone()).collect();
        adapter_ids.extend(db.runs.iter().map(|r| r.adapter_id.clone()));
        let adapters = adapter_ids
            .into_iter()
            .map(|id| {
                let ra = da.runs.iter().find(|r| r.adapter_id == id);
                let rb = db.runs.iter().find(|r| r.adapter_id == id);
                AdapterDelta {
                    adapter_name: ra.or(rb).map(|r| r.adapter_name.clone()).unwrap_or_else(|| id.clone()),
                    adapter_id: id,
                    a_status: ra.map(|r| r.status),
                    b_status: rb.map(|r| r.status),
                    a_results: ra.map(|r| r.result_count),
                    b_results: rb.map(|r| r.result_count),
                }
            })
            .collect();

        Ok(Comparison {
            common_sources: src_a.intersection(&src_b).cloned().collect(),
            only_a_sources: src_a.difference(&src_b).cloned().collect(),
            only_b_sources: src_b.difference(&src_a).cloned().collect(),
            common_findings,
            only_a_findings,
            only_b_findings,
            common_entities: ent_a.intersection(&ent_b).cloned().collect(),
            only_a_entities: ent_a.difference(&ent_b).cloned().collect(),
            only_b_entities: ent_b.difference(&ent_a).cloned().collect(),
            adapters,
            a: da.record,
            b: db.record,
        })
    }

    /// Full-text search across all stored findings (DATABASES → Knowledge base).
    pub fn search_knowledge(&self, q: &KnowledgeQuery) -> SwordResult<Vec<KnowledgeHit>> {
        let limit = q.limit.unwrap_or(100).clamp(1, 500) as i64;
        let mut args: Vec<Value> = Vec::new();
        let mut where_sql: Vec<String> = Vec::new();
        let fts = fts_query(&q.text);
        let from = if let Some(expr) = &fts {
            args.push(Value::Text(expr.clone()));
            where_sql.push(format!("findings_fts MATCH ?{}", args.len()));
            "findings_fts JOIN findings f ON f.rowid = findings_fts.rowid"
        } else {
            "findings f"
        };
        for (col, val) in [("f.adapter_id", &q.adapter), ("f.category", &q.category), ("f.kind", &q.kind)] {
            if let Some(v) = val.as_deref().filter(|v| !v.is_empty()) {
                args.push(Value::Text(v.to_string()));
                where_sql.push(format!("{col} = ?{}", args.len()));
            }
        }
        let rank = if fts.is_some() { "bm25(findings_fts)" } else { "0.0" };
        let order = if fts.is_some() { "rank ASC" } else { "i.created_at DESC" };
        let where_clause = if where_sql.is_empty() { String::new() } else { format!("WHERE {}", where_sql.join(" AND ")) };
        args.push(Value::Integer(limit));
        let sql = format!(
            "SELECT {FINDING_COLS}, i.query, i.created_at, {rank} AS rank FROM {from} \
             JOIN investigations i ON i.id = f.investigation_id {where_clause} ORDER BY {order} LIMIT ?{}",
            args.len()
        );
        self.with(|c| {
            let mut st = c.prepare(&sql)?;
            let rows = st
                .query_map(params_from_iter(args.iter()), |r| {
                    let finding = finding_from_row(r)?;
                    let created: String = r.get(15)?;
                    Ok(KnowledgeHit {
                        finding,
                        investigation_id: r.get(1)?,
                        investigation_query: r.get(14)?,
                        investigation_created_at: parse_ts(&created),
                        rank: r.get::<_, f64>(16)?,
                    })
                })?
                .collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(rows)
        })
    }

    /// Findings by id (used to resolve OpenSearch hits).
    pub fn findings_by_ids(&self, ids: &[String]) -> SwordResult<Vec<KnowledgeHit>> {
        if ids.is_empty() {
            return Ok(Vec::new());
        }
        let placeholders = (1..=ids.len()).map(|i| format!("?{i}")).collect::<Vec<_>>().join(", ");
        let sql = format!(
            "SELECT {FINDING_COLS}, i.query, i.created_at, 0.0 FROM findings f JOIN investigations i ON i.id = f.investigation_id \
             WHERE f.id IN ({placeholders})"
        );
        self.with(|c| {
            let mut st = c.prepare(&sql)?;
            let mut hits = st
                .query_map(params_from_iter(ids.iter()), |r| {
                    let finding = finding_from_row(r)?;
                    let created: String = r.get(15)?;
                    Ok(KnowledgeHit {
                        finding,
                        investigation_id: r.get(1)?,
                        investigation_query: r.get(14)?,
                        investigation_created_at: parse_ts(&created),
                        rank: 0.0,
                    })
                })?
                .collect::<rusqlite::Result<Vec<_>>>()?;
            // keep the order given by the external ranking
            hits.sort_by_key(|h| ids.iter().position(|i| i == &h.finding.id).unwrap_or(usize::MAX));
            Ok(hits)
        })
    }

    /// All findings of an investigation (used for exports and OpenSearch indexing).
    pub fn findings_of(&self, id: &str) -> SwordResult<Vec<Finding>> {
        self.with(|c| {
            let mut st = c.prepare(&format!("SELECT {FINDING_COLS} FROM findings f WHERE f.investigation_id = ?1"))?;
            let rows = st.query_map(params![id], finding_from_row)?.collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(rows)
        })
    }
}

fn load_graph(c: &rusqlite::Connection, id: Option<&str>) -> rusqlite::Result<Graph> {
    let mut st = c.prepare("SELECT key, kind, label, attributes, sources FROM graph_nodes WHERE investigation_id = ?1")?;
    let nodes = st
        .query_map(params![id], |r| {
            let kind: String = r.get(1)?;
            let attributes: String = r.get(3)?;
            let sources: String = r.get(4)?;
            Ok(GraphNode {
                key: r.get(0)?,
                kind: sword_core::EntityKind::parse(&kind).unwrap_or(sword_core::EntityKind::Website),
                label: r.get(2)?,
                attributes: crate::from_json(&attributes),
                sources: crate::from_json(&sources),
                degree: 0,
            })
        })?
        .collect::<rusqlite::Result<Vec<_>>>()?;
    let mut st =
        c.prepare("SELECT id, from_key, to_key, relation, confidence, evidence FROM graph_edges WHERE investigation_id = ?1")?;
    let edges = st
        .query_map(params![id], |r| {
            let relation: String = r.get(3)?;
            let evidence: String = r.get(5)?;
            Ok(GraphEdge {
                id: r.get(0)?,
                from: r.get(1)?,
                to: r.get(2)?,
                label: sword_graph::relation_label(&relation).to_string(),
                relation,
                confidence: r.get::<_, f64>(4)? as f32,
                evidence: crate::from_json(&evidence),
            })
        })?
        .collect::<rusqlite::Result<Vec<_>>>()?;
    let mut g = Graph { nodes, edges };
    g.recompute_degrees();
    Ok(g)
}

#[cfg(test)]
mod tests {
    use super::*;
    use sword_core::util::{new_id, now};

    fn record(query: &str) -> InvestigationRecord {
        InvestigationRecord {
            id: new_id(),
            kind: InvestigationKind::Discovery,
            query: query.into(),
            input_kind: InputKind::Domain,
            categories: vec![Category::DomainIntel],
            status: InvestigationStatus::Completed,
            created_at: now(),
            finished_at: Some(now()),
            duration_ms: Some(1200),
            result_count: 1,
            source_count: 1,
            node_count: 0,
            edge_count: 0,
            adapters: vec!["dns".into()],
            summary: "Сводка по домену".into(),
            key_facts: vec![],
            limitations: vec![],
            error: None,
            notes: String::new(),
        }
    }

    #[test]
    fn saves_lists_searches_and_deletes() {
        let db = Database::open_in_memory().unwrap();
        let rec = record("example.com");
        let f = Finding {
            id: new_id(),
            adapter_id: "dns".into(),
            category: Category::DomainIntel,
            kind: FindingKind::DnsRecord,
            title: "MX-записи example.com".into(),
            url: Some("https://cloudflare-dns.com/dns-query?name=example.com&type=MX".into()),
            snippet: Some("mail.example.com".into()),
            published_at: None,
            retrieved_at: now(),
            confidence: 1.0,
            severity: None,
            attributes: vec![],
            entity_key: None,
        };
        let src = SourceRef { url: f.url.clone().unwrap(), title: "DoH".into(), adapter_id: "dns".into(), retrieved_at: now() };
        let run = AdapterRun::new("dns", "DNS", RunStatus::Done);
        db.save_investigation(&rec, &[run], &[f.clone()], &[src], &Graph::default(), true).unwrap();

        let page = db.list_history(&HistoryQuery { search: Some("example".into()), ..Default::default() }).unwrap();
        assert_eq!(page.total, 1);
        let detail = db.get_detail(&rec.id).unwrap();
        assert_eq!(detail.findings.len(), 1);
        let hits = db.search_knowledge(&KnowledgeQuery { text: "mail".into(), ..Default::default() }).unwrap();
        assert_eq!(hits.len(), 1);
        assert_eq!(db.delete_investigations(&[rec.id.clone()]).unwrap(), 1);
        assert_eq!(db.list_history(&HistoryQuery::default()).unwrap().total, 0);
        // FTS rows are removed by triggers
        assert!(db.search_knowledge(&KnowledgeQuery { text: "mail".into(), ..Default::default() }).unwrap().is_empty());
    }
}
