//! # sword-audit — Privacy & Exposure Audit
//!
//! Self-assessment of the analyst's *own* assets, using legal sources only:
//!
//! | Check            | Asset            | Source                                         |
//! |------------------|------------------|------------------------------------------------|
//! | e-mail breaches  | own e-mail       | Have I Been Pwned API (key)                    |
//! | DNS hygiene      | own domain       | DNS-over-HTTPS                                  |
//! | web config       | own domain       | HTTPS response of the site                     |
//! | TLS              | own domain       | TLS handshake                                   |
//! | exposed files    | verified domain  | HTTPS GET of well-known sensitive paths        |
//! | dangling DNS     | verified domain  | CT logs + DoH                                   |
//! | incidents        | own domain       | HIBP breach catalogue                          |
//! | public surface   | own domain       | Certificate Transparency                       |
//! | secrets (local)  | own repository   | local working copy                              |
//! | secrets (GitHub) | own repository   | GitHub secret scanning API                      |
//!
//! No stolen databases, leaked dumps or people-search aggregators are used. Passwords are
//! checked with k-anonymity and never stored; secrets are kept only as redacted previews
//! and fingerprints.

pub mod dns_posture;
pub mod identity;
pub mod secrets;
pub mod surface;
pub mod tls;
pub mod web_posture;

use std::collections::{BTreeMap, HashMap};
use std::path::PathBuf;
use std::sync::Arc;
use std::time::{Duration, Instant};

use serde::{Deserialize, Serialize};
use sword_connectors::ConnectorContext;
use sword_core::util::{canonical_url, now};
use sword_core::{
    AdapterInfo, AdapterOutput, AdapterRun, Category, ClassifiedInput, EventSink, Finding, InputKind, InvestigationEvent,
    InvestigationKind, InvestigationRecord, InvestigationStatus, PlannedAdapter, RunStatus, Severity, SourceRef, SwordError,
    SwordResult,
};
use sword_graph::GraphBuilder;
use sword_search::InvestigationOutcome;
use tokio::sync::Semaphore;
use tokio::task::JoinSet;

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TargetKind {
    Email,
    Domain,
    RepoLocal,
    RepoGithub,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum AuditCheck {
    EmailBreaches,
    DnsHygiene,
    WebConfig,
    Tls,
    ExposedFiles,
    DanglingDns,
    Incidents,
    Surface,
    SecretsLocal,
    SecretsGithub,
}

impl AuditCheck {
    pub const ALL: [AuditCheck; 10] = [
        AuditCheck::EmailBreaches,
        AuditCheck::DnsHygiene,
        AuditCheck::WebConfig,
        AuditCheck::Tls,
        AuditCheck::ExposedFiles,
        AuditCheck::DanglingDns,
        AuditCheck::Incidents,
        AuditCheck::Surface,
        AuditCheck::SecretsLocal,
        AuditCheck::SecretsGithub,
    ];

    pub fn as_str(&self) -> &'static str {
        match self {
            AuditCheck::EmailBreaches => "email_breaches",
            AuditCheck::DnsHygiene => "dns_hygiene",
            AuditCheck::WebConfig => "web_config",
            AuditCheck::Tls => "tls",
            AuditCheck::ExposedFiles => "exposed_files",
            AuditCheck::DanglingDns => "dangling_dns",
            AuditCheck::Incidents => "incidents",
            AuditCheck::Surface => "surface",
            AuditCheck::SecretsLocal => "secrets_local",
            AuditCheck::SecretsGithub => "secrets_github",
        }
    }

    pub fn label_ru(&self) -> &'static str {
        match self {
            AuditCheck::EmailBreaches => "Утечки адреса (HIBP)",
            AuditCheck::DnsHygiene => "DNS и почтовая гигиена",
            AuditCheck::WebConfig => "Конфигурация веб-сервера",
            AuditCheck::Tls => "TLS-сертификат",
            AuditCheck::ExposedFiles => "Опубликованные служебные файлы",
            AuditCheck::DanglingDns => "Висячие CNAME (захват поддоменов)",
            AuditCheck::Incidents => "Известные инциденты",
            AuditCheck::Surface => "Публичная поверхность (CT)",
            AuditCheck::SecretsLocal => "Секреты в репозитории",
            AuditCheck::SecretsGithub => "GitHub secret scanning",
        }
    }

    pub fn target(&self) -> TargetKind {
        match self {
            AuditCheck::EmailBreaches => TargetKind::Email,
            AuditCheck::SecretsLocal => TargetKind::RepoLocal,
            AuditCheck::SecretsGithub => TargetKind::RepoGithub,
            _ => TargetKind::Domain,
        }
    }

    /// Active probes that need a DNS proof of ownership.
    pub fn requires_verified(&self) -> bool {
        matches!(self, AuditCheck::ExposedFiles | AuditCheck::DanglingDns)
    }

    pub fn category(&self) -> Category {
        match self {
            AuditCheck::EmailBreaches | AuditCheck::Incidents => Category::EmailExposure,
            AuditCheck::Surface | AuditCheck::SecretsLocal | AuditCheck::SecretsGithub => Category::DigitalFootprint,
            _ => Category::DomainIntel,
        }
    }

    pub fn module_info(&self) -> AdapterInfo {
        AdapterInfo {
            id: format!("audit.{}", self.as_str()),
            name: self.label_ru().to_string(),
            provider: "SWORD OSINT audit".into(),
            description: self.label_ru().to_string(),
            methodology: methodology(*self).to_string(),
            categories: vec![self.category()],
            input_kinds: vec![InputKind::Text],
            credentials: vec![],
            options: vec![],
            rate_limit_per_minute: if matches!(self, AuditCheck::ExposedFiles) { 30 } else { 60 },
            homepage: String::new(),
            docs_url: None,
            official_api: true,
        }
    }
}

pub fn methodology(c: AuditCheck) -> &'static str {
    match c {
        AuditCheck::EmailBreaches => "HIBP API v3 /breachedAccount и /pasteAccount с ключом аналитика, только для адресов, заявленных как собственные.",
        AuditCheck::DnsHygiene => "DoH-запросы TXT/MX/CAA/NS/A: SPF (включая лимит 10 DNS-запросов), DMARC, DKIM по типовым селекторам, MTA-STS, TLS-RPT, CAA, DNSSEC.",
        AuditCheck::WebConfig => "HTTP- и HTTPS-запрос главной страницы: перенаправление на HTTPS, заголовки безопасности, флаги cookie, раскрытие версий, security.txt.",
        AuditCheck::Tls => "TLS-рукопожатие с проверкой цепочки по корневому хранилищу Mozilla (webpki-roots): срок действия, издатель, SAN, версия протокола.",
        AuditCheck::ExposedFiles => "GET-запросы к 12 типовым чувствительным путям (.git, .env, резервные копии, служебные страницы) с проверкой сигнатур; только для доменов с DNS-подтверждением владения.",
        AuditCheck::DanglingDns => "Имена из журналов CT → CNAME на облачные сервисы → проверка NXDOMAIN цели (пассивно, через DoH); только для подтверждённых доменов.",
        AuditCheck::Incidents => "Каталог инцидентов Have I Been Pwned (/breaches?Domain=).",
        AuditCheck::Surface => "Журналы Certificate Transparency (crt.sh / CertSpotter): инвентаризация имён и выявление служебных систем.",
        AuditCheck::SecretsLocal => "Обход рабочей копии репозитория с учётом .gitignore; 17 правил высокоточных форматов токенов и энтропийные проверки; значения не сохраняются.",
        AuditCheck::SecretsGithub => "GitHub REST API /secret-scanning/alerts (state=open, hide_secret=true) с токеном владельца репозитория.",
    }
}

/// One asset to audit. `value` holds the plain value in memory only (e-mail addresses are
/// decrypted from the OS vault for the duration of the run).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AuditTarget {
    pub asset_id: String,
    pub kind: TargetKind,
    #[serde(skip_serializing)]
    pub value: String,
    pub display: String,
    pub verified: bool,
}

#[derive(Debug, Clone)]
pub struct AuditRequest {
    pub targets: Vec<AuditTarget>,
    pub checks: Vec<AuditCheck>,
}

struct Job {
    run_id: String,
    name: String,
    check: AuditCheck,
    target: AuditTarget,
}

async fn execute(job: &Job, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
    let info = job.check.module_info();
    let v = job.target.value.as_str();
    match job.check {
        AuditCheck::EmailBreaches => identity::email_breaches(ctx, &info, v).await,
        AuditCheck::DnsHygiene => dns_posture::check(ctx, &info, v).await,
        AuditCheck::WebConfig => web_posture::check(ctx, &info, v).await,
        AuditCheck::Tls => tls::check(ctx, &info, v).await,
        AuditCheck::ExposedFiles => web_posture::exposed_files(ctx, &info, v, job.target.verified).await,
        AuditCheck::DanglingDns => surface::dangling_dns(ctx, &info, v, job.target.verified).await,
        AuditCheck::Incidents => surface::incidents(ctx, &info, v).await,
        AuditCheck::Surface => surface::inventory(ctx, &info, v).await,
        AuditCheck::SecretsGithub => secrets::github_alerts(ctx, &info, v).await,
        AuditCheck::SecretsLocal => {
            let root = PathBuf::from(v);
            let cancel = ctx.cancel.clone();
            tokio::task::spawn_blocking(move || secrets::scan_local_repository(&root, &info, &cancel).map(|(out, _)| out))
                .await
                .map_err(|e| SwordError::Internal(format!("сканирование прервано: {e}")))?
        }
    }
}

/// Run an exposure audit and return an outcome stored like any investigation.
pub async fn run_audit(id: String, req: AuditRequest, ctx: ConnectorContext, sink: Arc<dyn EventSink>) -> SwordResult<InvestigationOutcome> {
    if req.targets.is_empty() || req.checks.is_empty() {
        return Err(SwordError::InvalidInput("выберите активы и проверки".into()));
    }
    let query = format!("Аудит: {}", req.targets.iter().map(|t| t.display.clone()).collect::<Vec<_>>().join(", "));
    let started_at = now();
    let t0 = Instant::now();

    // Plan
    let mut plan = Vec::new();
    let mut jobs = Vec::new();
    let mut n = 0;
    for target in &req.targets {
        for check in &req.checks {
            if check.target() != target.kind {
                continue;
            }
            n += 1;
            let run_id = format!("audit.{}#{n}", check.as_str());
            let name = format!("{} — {}", check.label_ru(), target.display);
            let reason = (check.requires_verified() && !target.verified)
                .then(|| "требуется подтверждение владения доменом (DNS TXT) в «Мои активы»".to_string());
            plan.push(PlannedAdapter {
                adapter_id: run_id.clone(),
                name: name.clone(),
                categories: vec![check.category()],
                will_run: reason.is_none(),
                reason: reason.clone(),
            });
            if reason.is_none() {
                jobs.push(Job { run_id, name, check: *check, target: target.clone() });
            }
        }
    }
    let input = ClassifiedInput {
        raw: query.clone(),
        kind: InputKind::Text,
        text: query.clone(),
        domain: None,
        registrable_domain: None,
        url: None,
        email: None,
        ip: None,
        handle: None,
        handle_query: None,
    };
    sink.emit(InvestigationEvent::Started {
        investigation_id: id.clone(),
        kind: InvestigationKind::ExposureAudit,
        query: query.clone(),
        input,
        plan: plan.clone(),
    });
    let mut runs: HashMap<String, AdapterRun> = HashMap::new();
    for p in &plan {
        let mut r = AdapterRun::new(&p.adapter_id, &p.name, if p.will_run { RunStatus::Queued } else { RunStatus::Skipped });
        r.message = p.reason.clone();
        if !p.will_run {
            sink.emit(InvestigationEvent::AdapterUpdate { investigation_id: id.clone(), run: r.clone() });
        }
        runs.insert(p.adapter_id.clone(), r);
    }

    let budget = Duration::from_secs(ctx.settings.network.adapter_timeout_secs.max(30) as u64 * 2);
    let sem = Arc::new(Semaphore::new(3));
    let mut set: JoinSet<(String, chrono::DateTime<chrono::Utc>, u32, SwordResult<AdapterOutput>)> = JoinSet::new();
    for job in jobs {
        let ctx = ctx.clone();
        let sem = sem.clone();
        let sink = sink.clone();
        let inv = id.clone();
        set.spawn(async move {
            let _permit = tokio::select! {
                _ = ctx.cancel.cancelled() => return (job.run_id.clone(), now(), 0, Err(SwordError::Cancelled)),
                p = sem.acquire_owned() => p,
            };
            let started = now();
            let mut running = AdapterRun::new(&job.run_id, &job.name, RunStatus::Running);
            running.started_at = Some(started);
            sink.emit(InvestigationEvent::AdapterUpdate { investigation_id: inv, run: running });
            let t = Instant::now();
            let result = tokio::select! {
                _ = ctx.cancel.cancelled() => Err(SwordError::Cancelled),
                r = tokio::time::timeout(budget, execute(&job, &ctx)) => r.unwrap_or(Err(SwordError::Timeout)),
            };
            (job.run_id.clone(), started, t.elapsed().as_millis().min(u32::MAX as u128) as u32, result)
        });
    }

    let mut outputs: Vec<(String, AdapterOutput)> = Vec::new();
    while let Some(joined) = set.join_next().await {
        let Ok((run_id, started, ms, result)) = joined else { continue };
        let Some(run) = runs.get_mut(&run_id) else { continue };
        run.started_at = Some(started);
        run.finished_at = Some(now());
        run.duration_ms = Some(ms);
        match result {
            Ok(out) => {
                run.status = RunStatus::Done;
                run.result_count = out.findings.len() as u32;
                if !out.findings.is_empty() {
                    sink.emit(InvestigationEvent::Findings { investigation_id: id.clone(), adapter_id: run_id.clone(), findings: out.findings.clone() });
                }
                outputs.push((run_id.clone(), out));
            }
            Err(e) => {
                run.status = match e {
                    SwordError::Cancelled => RunStatus::Cancelled,
                    SwordError::Timeout => RunStatus::TimedOut,
                    _ => RunStatus::Failed,
                };
                run.error_kind = Some(e.kind());
                run.message = Some(e.to_string());
            }
        }
        sink.emit(InvestigationEvent::AdapterUpdate { investigation_id: id.clone(), run: run.clone() });
    }
    let runs: Vec<AdapterRun> = plan.iter().filter_map(|p| runs.remove(&p.adapter_id)).collect();

    // Assemble
    let mut findings: Vec<Finding> = outputs.iter().flat_map(|(_, o)| o.findings.iter().cloned()).collect();
    findings.sort_by_key(|f| f.severity.unwrap_or(Severity::Info));
    let sources = {
        let mut seen = std::collections::HashSet::new();
        outputs
            .iter()
            .flat_map(|(_, o)| o.sources.iter().cloned())
            .filter(|s: &SourceRef| seen.insert(canonical_url(&s.url)))
            .collect::<Vec<_>>()
    };
    let mut gb = GraphBuilder::new();
    for (rid, out) in &outputs {
        gb.add_output(rid.split('#').next().unwrap_or(rid), out);
    }
    let graph = gb.build();
    let facts: Vec<_> = outputs.iter().flat_map(|(_, o)| o.facts.iter().cloned()).collect();
    let names: HashMap<String, String> = runs.iter().map(|r| (r.adapter_id.clone(), r.adapter_name.clone())).collect();
    let mut limitations = sword_search::summary::limitations(&runs, &outputs, &names);
    limitations.retain(|l| !l.contains("Полнота поисковой выдачи"));
    limitations.push("Проверки выполняются снаружи, как это видит любой пользователь интернета; внутренние системы и история git не анализируются.".into());

    let mut by_sev: BTreeMap<Severity, usize> = BTreeMap::new();
    for f in &findings {
        *by_sev.entry(f.severity.unwrap_or(Severity::Info)).or_default() += 1;
    }
    let done = runs.iter().filter(|r| r.status == RunStatus::Done).count();
    let failed = runs.iter().filter(|r| matches!(r.status, RunStatus::Failed | RunStatus::TimedOut)).count();
    let mut summary = format!(
        "Аудит собственных активов: {}. Выполнено проверок: {done} из {} (ошибок: {failed}).\nИтог по уровням: {}.",
        req.targets.iter().map(|t| t.display.clone()).collect::<Vec<_>>().join(", "),
        runs.len(),
        [Severity::Critical, Severity::High, Severity::Medium, Severity::Low, Severity::Info, Severity::Pass]
            .iter()
            .map(|s| format!("{} — {}", s.label_ru(), by_sev.get(s).copied().unwrap_or(0)))
            .collect::<Vec<_>>()
            .join(", ")
    );
    let urgent: Vec<&Finding> = findings.iter().filter(|f| matches!(f.severity, Some(Severity::Critical | Severity::High))).take(10).collect();
    if !urgent.is_empty() {
        summary.push_str("\n\nТребуют первоочередного внимания:");
        for f in urgent {
            summary.push_str(&format!("\n• [{}] {}", f.severity.map(|s| s.label_ru()).unwrap_or(""), f.title));
        }
    }
    let status = if ctx.cancel.is_cancelled() {
        InvestigationStatus::Cancelled
    } else if done == 0 {
        InvestigationStatus::Failed
    } else if failed > 0 {
        InvestigationStatus::Partial
    } else {
        InvestigationStatus::Completed
    };
    let mut categories: Vec<Category> = req.checks.iter().map(|c| c.category()).collect();
    categories.sort();
    categories.dedup();
    let record = InvestigationRecord {
        id: id.clone(),
        kind: InvestigationKind::ExposureAudit,
        query,
        input_kind: InputKind::Text,
        categories,
        status,
        created_at: started_at,
        finished_at: Some(now()),
        duration_ms: Some(t0.elapsed().as_millis().min(u32::MAX as u128) as u32),
        result_count: findings.len() as u32,
        source_count: sources.len() as u32,
        node_count: graph.nodes.len() as u32,
        edge_count: graph.edges.len() as u32,
        adapters: runs.iter().filter(|r| r.status != RunStatus::Skipped).map(|r| r.adapter_id.clone()).collect(),
        summary,
        key_facts: facts,
        limitations,
        error: (status == InvestigationStatus::Failed).then(|| "Ни одна проверка не завершилась успешно".to_string()),
        notes: String::new(),
    };
    sink.emit(InvestigationEvent::Finished { investigation_id: id, record: record.clone() });
    Ok(InvestigationOutcome { record, runs, findings, sources, graph })
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn checks_map_to_targets() {
        assert_eq!(AuditCheck::EmailBreaches.target(), TargetKind::Email);
        assert_eq!(AuditCheck::Tls.target(), TargetKind::Domain);
        assert!(AuditCheck::ExposedFiles.requires_verified());
        assert!(!AuditCheck::DnsHygiene.requires_verified());
        for c in AuditCheck::ALL {
            assert!(c.module_info().id.starts_with("audit."));
            assert!(!methodology(c).is_empty());
        }
    }
}
