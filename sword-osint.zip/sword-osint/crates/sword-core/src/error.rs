//! Unified error type.
//!
//! Every failure that can reach the UI is a [`SwordError`]. Its [`ErrorKind`] is a stable
//! string identifier persisted in the database (error statistics in ANALYTICS) and used by
//! the UI to choose wording and remediation hints. Messages are in Russian because they are
//! shown to the analyst verbatim.

use serde::{Deserialize, Serialize};

pub type SwordResult<T> = Result<T, SwordError>;

#[derive(Debug, Clone, PartialEq, thiserror::Error)]
pub enum SwordError {
    #[error("сетевая ошибка: {0}")]
    Network(String),
    #[error("превышено время ожидания ответа")]
    Timeout,
    #[error("источник ограничил частоту запросов{}", retry_hint(.retry_after_secs))]
    RateLimited { retry_after_secs: Option<u64> },
    #[error("нет авторизации: {0}")]
    Unauthorized(String),
    #[error("доступ запрещён источником: {0}")]
    Forbidden(String),
    #[error("не найдено: {0}")]
    NotFound(String),
    #[error("некорректный ввод: {0}")]
    InvalidInput(String),
    #[error("источник не настроен: {0}")]
    NotConfigured(String),
    #[error("не удалось разобрать ответ источника: {0}")]
    Parse(String),
    #[error("ошибка базы данных: {0}")]
    Database(String),
    #[error("ошибка файловой системы: {0}")]
    Io(String),
    #[error("операция отменена")]
    Cancelled,
    #[error("источник вернул ошибку: {0}")]
    Upstream(String),
    #[error("{0}")]
    Unsupported(String),
    #[error("внутренняя ошибка: {0}")]
    Internal(String),
}

fn retry_hint(secs: &Option<u64>) -> String {
    match secs {
        Some(s) => format!(" (повтор через {s} с)"),
        None => String::new(),
    }
}

/// Stable machine-readable error classification.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ErrorKind {
    Network,
    Timeout,
    RateLimited,
    Unauthorized,
    Forbidden,
    NotFound,
    InvalidInput,
    NotConfigured,
    Parse,
    Database,
    Io,
    Cancelled,
    Upstream,
    Unsupported,
    Internal,
}

impl ErrorKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            ErrorKind::Network => "network",
            ErrorKind::Timeout => "timeout",
            ErrorKind::RateLimited => "rate_limited",
            ErrorKind::Unauthorized => "unauthorized",
            ErrorKind::Forbidden => "forbidden",
            ErrorKind::NotFound => "not_found",
            ErrorKind::InvalidInput => "invalid_input",
            ErrorKind::NotConfigured => "not_configured",
            ErrorKind::Parse => "parse",
            ErrorKind::Database => "database",
            ErrorKind::Io => "io",
            ErrorKind::Cancelled => "cancelled",
            ErrorKind::Upstream => "upstream",
            ErrorKind::Unsupported => "unsupported",
            ErrorKind::Internal => "internal",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "network" => ErrorKind::Network,
            "timeout" => ErrorKind::Timeout,
            "rate_limited" => ErrorKind::RateLimited,
            "unauthorized" => ErrorKind::Unauthorized,
            "forbidden" => ErrorKind::Forbidden,
            "not_found" => ErrorKind::NotFound,
            "invalid_input" => ErrorKind::InvalidInput,
            "not_configured" => ErrorKind::NotConfigured,
            "parse" => ErrorKind::Parse,
            "database" => ErrorKind::Database,
            "io" => ErrorKind::Io,
            "cancelled" => ErrorKind::Cancelled,
            "upstream" => ErrorKind::Upstream,
            "unsupported" => ErrorKind::Unsupported,
            "internal" => ErrorKind::Internal,
            _ => return None,
        })
    }
}

impl SwordError {
    pub fn kind(&self) -> ErrorKind {
        match self {
            SwordError::Network(_) => ErrorKind::Network,
            SwordError::Timeout => ErrorKind::Timeout,
            SwordError::RateLimited { .. } => ErrorKind::RateLimited,
            SwordError::Unauthorized(_) => ErrorKind::Unauthorized,
            SwordError::Forbidden(_) => ErrorKind::Forbidden,
            SwordError::NotFound(_) => ErrorKind::NotFound,
            SwordError::InvalidInput(_) => ErrorKind::InvalidInput,
            SwordError::NotConfigured(_) => ErrorKind::NotConfigured,
            SwordError::Parse(_) => ErrorKind::Parse,
            SwordError::Database(_) => ErrorKind::Database,
            SwordError::Io(_) => ErrorKind::Io,
            SwordError::Cancelled => ErrorKind::Cancelled,
            SwordError::Upstream(_) => ErrorKind::Upstream,
            SwordError::Unsupported(_) => ErrorKind::Unsupported,
            SwordError::Internal(_) => ErrorKind::Internal,
        }
    }

    /// `true` for failures worth retrying later (transient network conditions).
    pub fn is_transient(&self) -> bool {
        matches!(
            self,
            SwordError::Network(_) | SwordError::Timeout | SwordError::RateLimited { .. } | SwordError::Upstream(_)
        )
    }
}

impl From<std::io::Error> for SwordError {
    fn from(e: std::io::Error) -> Self {
        SwordError::Io(e.to_string())
    }
}

impl From<serde_json::Error> for SwordError {
    fn from(e: serde_json::Error) -> Self {
        SwordError::Parse(e.to_string())
    }
}

/// Serializable error envelope returned by every Tauri command.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ErrorPayload {
    pub kind: ErrorKind,
    pub message: String,
}

impl From<&SwordError> for ErrorPayload {
    fn from(e: &SwordError) -> Self {
        ErrorPayload { kind: e.kind(), message: e.to_string() }
    }
}

impl From<SwordError> for ErrorPayload {
    fn from(e: SwordError) -> Self {
        ErrorPayload::from(&e)
    }
}
