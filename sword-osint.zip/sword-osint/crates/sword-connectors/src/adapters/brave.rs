//! Brave Search API — independent web index (official API, key required).

use async_trait::async_trait;
use serde_json::Value;
use sword_core::util::parse_date;
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordError, SwordResult,
};

use super::{arr, cred, info, is_document_url, s};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::output::{link_url_to_domain, FindingExt, OutputBuilder};

const ENDPOINT: &str = "https://api.search.brave.com/res/v1/web/search";
const KEY: &str = "brave.api_key";

pub struct Brave {
    info: AdapterInfo,
}

impl Default for Brave {
    fn default() -> Self {
        Self::new()
    }
}

impl Brave {
    pub fn new() -> Self {
        Brave {
            info: info(
                "brave",
                "Brave Search",
                "Brave Software",
                "Независимый поисковый индекс Brave: веб-страницы и документы по запросу, домену или организации.",
                "Brave Web Search API (api.search.brave.com/res/v1/web/search), заголовок X-Subscription-Token. \
                 Для категории «Публичные документы» выполняется отдельный запрос с операторами site: и filetype:. \
                 Учитываются только результаты, возвращённые API; ранжирование — по версии Brave.",
                &[Category::WebSearch, Category::PublicDocuments],
                &[InputKind::Text, InputKind::Domain, InputKind::Url],
                vec![cred(
                    KEY,
                    "API-ключ Brave Search",
                    true,
                    "Зарегистрируйтесь на api-dashboard.search.brave.com, выберите тариф (бесплатный план — 2 000 запросов в месяц, \
                     1 запрос/с) и создайте ключ в разделе API Keys.",
                    Some("https://api-dashboard.search.brave.com/"),
                    Some("BSA…"),
                )],
                vec![],
                50,
                "https://brave.com/search/api/",
                Some("https://api-dashboard.search.brave.com/app/documentation/web-search/get-started"),
                true,
            ),
        }
    }

    async fn run_query(&self, ctx: &ConnectorContext, key: &str, q: &str, count: usize) -> SwordResult<Value> {
        let count = count.clamp(1, 20).to_string();
        let req = ctx
            .get(ENDPOINT)
            .query(&[("q", q), ("count", count.as_str()), ("safesearch", "moderate")])
            .header("X-Subscription-Token", key)
            .header("Accept", "application/json");
        ctx.json(&self.info, req).await
    }
}

#[async_trait]
impl SourceAdapter for Brave {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let key = ctx.secret(KEY).ok_or_else(|| SwordError::NotConfigured("API-ключ Brave Search".into()))?;
        self.run_query(ctx, &key, "brave search api", 1).await?;
        Ok(vec![PermissionCheck::granted("Web Search API", "Ключ принят (проверка расходует 1 запрос квоты)")])
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let key = ctx.secret(KEY).ok_or_else(|| SwordError::NotConfigured("API-ключ Brave Search".into()))?;
        let mut b = OutputBuilder::new(&self.info);
        let mut queries: Vec<(String, Category)> = Vec::new();
        let domain = input.registrable_domain.clone().or_else(|| input.domain.clone());
        if ctx.wants(Category::WebSearch) {
            let q = match &domain {
                Some(d) => format!("\"{d}\""),
                None => input.text.clone(),
            };
            queries.push((q, Category::WebSearch));
        }
        if ctx.wants(Category::PublicDocuments) {
            let q = match &domain {
                Some(d) => format!("site:{d} (filetype:pdf OR filetype:docx OR filetype:xlsx OR filetype:pptx OR filetype:doc)"),
                None => format!("\"{}\" filetype:pdf", input.text),
            };
            queries.push((q, Category::PublicDocuments));
        }

        for (q, category) in queries {
            let v = self.run_query(ctx, &key, &q, ctx.max_results).await?;
            let search_url = format!("https://search.brave.com/search?q={}", url::form_urlencoded::byte_serialize(q.as_bytes()).collect::<String>());
            b.source(&search_url, &format!("Brave Search: {q}"));
            for r in arr(&v, "/web/results") {
                let Some(url) = s(r, "url") else { continue };
                let title = s(r, "title").unwrap_or_else(|| url.clone());
                let is_doc = is_document_url(&url);
                let kind = if is_doc { FindingKind::Document } else { FindingKind::WebPage };
                let cat = if is_doc { Category::PublicDocuments } else { category };
                let published = s(r, "page_age").and_then(|d| parse_date(&d));
                let host = r.pointer("/meta_url/hostname").and_then(Value::as_str).unwrap_or_default().to_string();
                let doc_key = keys::document(&url);
                {
                    let f = b.finding(cat, kind, &title, Some(&url));
                    f.snippet(&s(r, "description").unwrap_or_default()).published(published).confidence(0.9).attr("Хост", &host);
                    if let Some(age) = s(r, "age") {
                        f.attr("Возраст страницы", age);
                    }
                    if is_doc {
                        f.entity(&doc_key);
                    }
                }
                if is_doc {
                    b.entity(&doc_key, EntityKind::Document, &title);
                    b.attr(&doc_key, "Найдено через", "Brave Search", &url);
                    link_url_to_domain(&mut b, &doc_key, &url);
                }
                b.source(&url, &title);
            }
        }
        if b.finding_count() == 0 {
            b.note("Brave Search не вернул результатов по запросу.");
        }
        Ok(b.finish())
    }
}
