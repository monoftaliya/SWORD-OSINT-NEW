//! Bluesky (AT Protocol) — public post search through the official XRPC API.
//!
//! Since 2025 the public AppView rejects unauthenticated `searchPosts` calls, so the adapter
//! signs in with an *app password* (Settings → Privacy and security → App passwords) and
//! queries `app.bsky.feed.searchPosts` through the account's PDS.

use std::time::{Duration, Instant};

use async_trait::async_trait;
use serde_json::{json, Value};
use sword_core::util::parse_date;
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordError, SwordResult,
};
use tokio::sync::Mutex;

use super::{arr, cred, info, num, opt, s, sp};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::http;
use crate::output::{FindingExt, OutputBuilder};

const HANDLE: &str = "bluesky.handle";
const APP_PASSWORD: &str = "bluesky.app_password";

pub struct Bluesky {
    info: AdapterInfo,
    session: Mutex<Option<(String, String, Instant)>>, // (service, access jwt, obtained)
}

impl Default for Bluesky {
    fn default() -> Self {
        Self::new()
    }
}

impl Bluesky {
    pub fn new() -> Self {
        Bluesky {
            info: info(
                "bluesky",
                "Bluesky",
                "Bluesky Social / AT Protocol",
                "Поиск публичных постов Bluesky по ключевым словам, домену или названию организации.",
                "XRPC: com.atproto.server.createSession (пароль приложения) → app.bsky.feed.searchPosts через PDS учётной записи. \
                 Используются только публичные посты, возвращённые API; закрытые данные недоступны.",
                &[Category::SocialNetworks],
                &[InputKind::Text, InputKind::Domain, InputKind::Url],
                vec![
                    cred(HANDLE, "Handle учётной записи", true, "Ваш handle в Bluesky, например name.bsky.social.", None, Some("name.bsky.social")),
                    cred(
                        APP_PASSWORD,
                        "Пароль приложения",
                        true,
                        "Не используйте основной пароль. Создайте пароль приложения: Bluesky → Настройки → Конфиденциальность и безопасность → Пароли приложений.",
                        Some("https://bsky.app/settings/app-passwords"),
                        Some("xxxx-xxxx-xxxx-xxxx"),
                    ),
                ],
                vec![opt("service", "Сервер (PDS)", false, Some("https://bsky.social"), "Адрес PDS вашей учётной записи.", None)],
                60,
                "https://bsky.app/",
                Some("https://docs.bsky.app/docs/api/app-bsky-feed-search-posts"),
                true,
            ),
            session: Mutex::new(None),
        }
    }

    fn service(&self, ctx: &ConnectorContext) -> String {
        ctx.option(&self.info, "service").unwrap_or_else(|| "https://bsky.social".into()).trim_end_matches('/').to_string()
    }

    async fn token(&self, ctx: &ConnectorContext, force: bool) -> SwordResult<(String, String)> {
        let service = self.service(ctx);
        let mut guard = self.session.lock().await;
        if !force {
            if let Some((svc, jwt, at)) = guard.as_ref() {
                if svc == &service && at.elapsed() < Duration::from_secs(60 * 60) {
                    return Ok((svc.clone(), jwt.clone()));
                }
            }
        }
        let handle = ctx.secret(HANDLE).ok_or_else(|| SwordError::NotConfigured("handle Bluesky".into()))?;
        let password = ctx.secret(APP_PASSWORD).ok_or_else(|| SwordError::NotConfigured("пароль приложения Bluesky".into()))?;
        let req = ctx
            .post(&format!("{service}/xrpc/com.atproto.server.createSession"))
            .json(&json!({ "identifier": handle, "password": password }));
        let resp = ctx.send(&self.info, req).await?;
        let v: Value = http::read_json(resp).await.map_err(|e| match e {
            SwordError::Unauthorized(_) | SwordError::InvalidInput(_) => {
                SwordError::Unauthorized("Bluesky отклонил handle или пароль приложения".into())
            }
            other => other,
        })?;
        let jwt = s(&v, "accessJwt").ok_or_else(|| SwordError::Parse("в ответе нет accessJwt".into()))?;
        *guard = Some((service.clone(), jwt.clone(), Instant::now()));
        Ok((service, jwt))
    }
}

#[async_trait]
impl SourceAdapter for Bluesky {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let (service, _) = self.token(ctx, true).await?;
        Ok(vec![
            PermissionCheck::granted("Сессия", format!("Вход выполнен на {service}")),
            PermissionCheck::granted("app.bsky.feed.searchPosts", "Поиск публичных постов доступен"),
        ])
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let mut b = OutputBuilder::new(&self.info);
        let (service, jwt) = self.token(ctx, false).await?;
        let q = input.registrable_domain.clone().unwrap_or_else(|| input.text.clone());
        let limit = ctx.max_results.clamp(5, 100).to_string();
        let req = ctx
            .get(&format!("{service}/xrpc/app.bsky.feed.searchPosts"))
            .query(&[("q", q.as_str()), ("limit", limit.as_str()), ("sort", "latest")])
            .bearer_auth(&jwt);
        let v: Value = ctx.json(&self.info, req).await?;
        b.source(
            &format!("https://bsky.app/search?q={}", url::form_urlencoded::byte_serialize(q.as_bytes()).collect::<String>()),
            &format!("Bluesky: «{q}»"),
        );
        for p in arr(&v, "/posts") {
            let Some(uri) = s(p, "uri") else { continue };
            let handle = sp(p, "/author/handle").unwrap_or_default();
            let rkey = uri.rsplit('/').next().unwrap_or_default();
            if handle.is_empty() || rkey.is_empty() {
                continue;
            }
            let url = format!("https://bsky.app/profile/{handle}/post/{rkey}");
            let text = sp(p, "/record/text").unwrap_or_default();
            let title: String = text.chars().take(90).collect::<String>();
            let pub_key = keys::publication("bluesky", &uri);
            b.finding(Category::SocialNetworks, FindingKind::SocialPost, if title.is_empty() { "Пост Bluesky" } else { &title }, Some(&url))
                .snippet(&text)
                .published(sp(p, "/record/createdAt").and_then(|d| parse_date(&d)))
                .confidence(0.85)
                .attr("Отметки «нравится»", num(p, "likeCount").unwrap_or(0))
                .attr("Репосты", num(p, "repostCount").unwrap_or(0))
                .entity(&pub_key);
            b.entity(&pub_key, EntityKind::Publication, if title.is_empty() { "Пост Bluesky" } else { &title });
            b.attr(&pub_key, "Опубликовано", &sp(p, "/record/createdAt").unwrap_or_default(), &url);
            b.source(&url, "Пост Bluesky");
        }
        Ok(b.finish())
    }
}
