<!--
  Tiny presentational atoms in one component, selected with `kind`:
  status dot · confidence meter · severity badge · spinner.
-->
<script lang="ts">
  import { SEVERITY_META, confidenceLabel } from '../util/labels';
  import type { Severity } from '../api/types';

  let {
    kind,
    tone = 'idle',
    pulse = false,
    value = 0,
    severity = 'info',
    label = '',
  }: { kind: 'dot' | 'confidence' | 'severity' | 'spinner'; tone?: 'ok' | 'warn' | 'err' | 'idle' | 'live'; pulse?: boolean; value?: number; severity?: Severity; label?: string } = $props();
</script>

{#if kind === 'dot'}
  <span class="dot {tone}" class:pulse title={label}></span>
{:else if kind === 'confidence'}
  <span class="conf" title="Достоверность {value.toFixed(2)} — {confidenceLabel(value)}">
    <span class="bar"><span class="fill" style:width="{Math.round(value * 100)}%"></span></span>
    <span class="v mono">{value.toFixed(2)}</span>
  </span>
{:else if kind === 'severity'}
  <span class="sev" style:--c={SEVERITY_META[severity].color}>{label || SEVERITY_META[severity].label}</span>
{:else}
  <span class="spinner" aria-label="Загрузка"></span>
{/if}

<style>
  .dot {
    display: inline-block;
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--fg-4);
    flex: none;
  }
  .dot.ok {
    background: var(--ok);
    box-shadow: 0 0 8px var(--ok);
  }
  .dot.warn {
    background: var(--warn);
    box-shadow: 0 0 8px var(--warn);
  }
  .dot.err {
    background: var(--err);
    box-shadow: 0 0 8px var(--err);
  }
  .dot.live {
    background: #fff;
    box-shadow: 0 0 10px #fff;
  }
  .dot.pulse {
    animation: pulse 1.2s ease-in-out infinite;
  }
  .conf {
    display: inline-flex;
    align-items: center;
    gap: 7px;
  }
  .bar {
    width: 44px;
    height: 3px;
    border-radius: 3px;
    background: rgba(255, 255, 255, 0.08);
    overflow: hidden;
  }
  .fill {
    display: block;
    height: 100%;
    background: linear-gradient(90deg, rgba(200, 212, 228, 0.5), #fff);
    box-shadow: 0 0 6px rgba(255, 255, 255, 0.6);
  }
  .v {
    font-size: 10.5px;
    color: var(--fg-3);
  }
  .sev {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    height: 20px;
    padding: 0 8px;
    border-radius: 6px;
    font-size: 10.5px;
    color: var(--c);
    border: 1px solid color-mix(in srgb, var(--c) 38%, transparent);
    background: color-mix(in srgb, var(--c) 9%, transparent);
    white-space: nowrap;
  }
  .sev::before {
    content: '';
    width: 5px;
    height: 5px;
    border-radius: 50%;
    background: var(--c);
    box-shadow: 0 0 6px var(--c);
  }
  .spinner {
    display: inline-block;
    width: 16px;
    height: 16px;
    border-radius: 50%;
    border: 1.5px solid rgba(255, 255, 255, 0.12);
    border-top-color: #fff;
    animation: spin 0.8s linear infinite;
  }
</style>
