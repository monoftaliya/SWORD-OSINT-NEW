//! Token-bucket rate limiter, one per source.
//!
//! Every outgoing request of an adapter first acquires a token. Sources that answer
//! `429 Too Many Requests` can push the bucket into a cool-down (`penalize`), which then
//! applies to every later request of that source — including other investigations.

use std::time::Duration;

use sword_core::{SwordError, SwordResult};
use tokio::sync::Mutex;
use tokio::time::Instant;
use tokio_util::sync::CancellationToken;

pub struct RateLimiter {
    state: Mutex<State>,
}

struct State {
    per_minute: u32,
    tokens: f64,
    capacity: f64,
    last_refill: Instant,
    blocked_until: Option<Instant>,
}

impl RateLimiter {
    pub fn new(per_minute: u32) -> Self {
        let per_minute = per_minute.max(1);
        let capacity = burst_for(per_minute);
        RateLimiter {
            state: Mutex::new(State {
                per_minute,
                tokens: capacity,
                capacity,
                last_refill: Instant::now(),
                blocked_until: None,
            }),
        }
    }

    /// Change the budget (e.g. after detecting the subscription tier of an API key).
    pub async fn set_rate(&self, per_minute: u32) {
        let mut s = self.state.lock().await;
        let per_minute = per_minute.max(1);
        if s.per_minute != per_minute {
            s.per_minute = per_minute;
            s.capacity = burst_for(per_minute);
            s.tokens = s.tokens.min(s.capacity);
        }
    }

    /// Wait for a token (cancellable).
    pub async fn acquire(&self, cancel: &CancellationToken) -> SwordResult<()> {
        loop {
            let wait = {
                let mut s = self.state.lock().await;
                let now = Instant::now();
                let mut blocked = None;
                if let Some(until) = s.blocked_until {
                    if until > now {
                        blocked = Some(until - now);
                    } else {
                        s.blocked_until = None;
                    }
                }
                match blocked {
                    Some(d) => Some(d),
                    None => {
                        let rate = s.per_minute as f64 / 60.0;
                        let elapsed = now.duration_since(s.last_refill).as_secs_f64();
                        s.tokens = (s.tokens + elapsed * rate).min(s.capacity);
                        s.last_refill = now;
                        if s.tokens >= 1.0 {
                            s.tokens -= 1.0;
                            None
                        } else {
                            Some(Duration::from_secs_f64(((1.0 - s.tokens) / rate).max(0.01)))
                        }
                    }
                }
            };
            match wait {
                None => return Ok(()),
                Some(d) => {
                    tokio::select! {
                        _ = cancel.cancelled() => return Err(SwordError::Cancelled),
                        _ = tokio::time::sleep(d) => {}
                    }
                }
            }
        }
    }

    /// Block the source for `secs` seconds (honours `Retry-After`).
    pub async fn penalize(&self, secs: u64) {
        let mut s = self.state.lock().await;
        let until = Instant::now() + Duration::from_secs(secs.clamp(1, 900));
        s.blocked_until = Some(match s.blocked_until {
            Some(u) if u > until => u,
            _ => until,
        });
        s.tokens = 0.0;
    }
}

fn burst_for(per_minute: u32) -> f64 {
    (per_minute as f64 / 10.0).clamp(1.0, 10.0)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[tokio::test(start_paused = true)]
    async fn enforces_rate() {
        let rl = RateLimiter::new(60); // 1 token/s, burst 6
        let cancel = CancellationToken::new();
        let start = Instant::now();
        for _ in 0..8 {
            rl.acquire(&cancel).await.unwrap();
        }
        // 6 immediately + 2 more at 1/s
        assert!(start.elapsed() >= Duration::from_millis(1900));
    }

    #[tokio::test]
    async fn cancellation_interrupts_wait() {
        let rl = RateLimiter::new(1);
        let cancel = CancellationToken::new();
        rl.acquire(&cancel).await.unwrap();
        cancel.cancel();
        assert_eq!(rl.acquire(&cancel).await, Err(SwordError::Cancelled));
    }
}
