//! Storage maintenance: statistics, integrity check, VACUUM, backups, retention and the
//! full JSON export (DATABASES → Storage).

use std::path::Path;

use chrono::{Duration, Utc};
use rusqlite::params;
use serde::{Deserialize, Serialize};
use sword_core::{SwordError, SwordResult};

use crate::{ts, Database};

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TableStat {
    pub name: String,
    pub rows: u64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct DbStats {
    pub path: String,
    pub size_bytes: u64,
    pub wal_bytes: u64,
    pub page_size: u64,
    pub page_count: u64,
    pub freelist_pages: u64,
    pub schema_version: i64,
    pub sqlite_version: String,
    pub tables: Vec<TableStat>,
}

const TABLES: &[&str] = &[
    "investigations",
    "adapter_runs",
    "findings",
    "sources",
    "graph_nodes",
    "graph_edges",
    "assets",
    "connector_status",
    "metrics",
    "reports",
    "report_drafts",
    "exports",
];

impl Database {
    pub fn stats(&self) -> SwordResult<DbStats> {
        let path = self.path().to_path_buf();
        let size_bytes = std::fs::metadata(&path).map(|m| m.len()).unwrap_or(0);
        let wal_bytes = std::fs::metadata(path.with_extension("db-wal")).map(|m| m.len()).unwrap_or(0);
        self.with(|c| {
            let page_size: i64 = c.query_row("PRAGMA page_size", [], |r| r.get(0))?;
            let page_count: i64 = c.query_row("PRAGMA page_count", [], |r| r.get(0))?;
            let freelist: i64 = c.query_row("PRAGMA freelist_count", [], |r| r.get(0))?;
            let schema_version: i64 = c.query_row("PRAGMA user_version", [], |r| r.get(0))?;
            let sqlite_version: String = c.query_row("SELECT sqlite_version()", [], |r| r.get(0))?;
            let mut tables = Vec::new();
            for t in TABLES {
                let n: i64 = c.query_row(&format!("SELECT COUNT(*) FROM {t}"), [], |r| r.get(0))?;
                tables.push(TableStat { name: t.to_string(), rows: n.max(0) as u64 });
            }
            Ok(DbStats {
                path: path.display().to_string(),
                size_bytes: if size_bytes > 0 { size_bytes } else { (page_size * page_count).max(0) as u64 },
                wal_bytes,
                page_size: page_size.max(0) as u64,
                page_count: page_count.max(0) as u64,
                freelist_pages: freelist.max(0) as u64,
                schema_version,
                sqlite_version,
                tables,
            })
        })
    }

    /// `PRAGMA integrity_check` — returns `["ok"]` for a healthy database.
    pub fn integrity_check(&self) -> SwordResult<Vec<String>> {
        self.with(|c| {
            let mut st = c.prepare("PRAGMA integrity_check")?;
            let rows = st.query_map([], |r| r.get::<_, String>(0))?.collect::<rusqlite::Result<Vec<_>>>()?;
            Ok(rows)
        })
    }

    /// Rebuild FTS indexes, checkpoint the WAL and compact the file.
    pub fn vacuum(&self) -> SwordResult<()> {
        self.with(|c| {
            c.execute_batch(
                "INSERT INTO findings_fts(findings_fts) VALUES('rebuild');
                 INSERT INTO investigations_fts(investigations_fts) VALUES('rebuild');
                 PRAGMA wal_checkpoint(TRUNCATE);
                 VACUUM;
                 PRAGMA optimize;",
            )
        })
    }

    /// Consistent online backup into a new file (`VACUUM INTO`).
    pub fn backup_to(&self, target: &Path) -> SwordResult<()> {
        if target.exists() {
            std::fs::remove_file(target)?;
        }
        let p = target.display().to_string();
        self.with(|c| c.execute("VACUUM INTO ?1", params![p]))?;
        Ok(())
    }

    /// Delete investigations older than `days` days. Returns how many were removed.
    pub fn purge_older_than(&self, days: u32) -> SwordResult<u32> {
        if days == 0 {
            return Ok(0);
        }
        let cutoff = ts(&(Utc::now() - Duration::days(days as i64)));
        self.with(|c| c.execute("DELETE FROM investigations WHERE created_at < ?1 AND status != 'running'", params![cutoff]))
            .map(|n| n as u32)
    }

    /// Remove all investigation data, metrics and reports (assets and settings are kept).
    pub fn clear_history(&self) -> SwordResult<()> {
        self.with(|c| {
            c.execute_batch(
                "DELETE FROM investigations; DELETE FROM metrics; DELETE FROM reports; DELETE FROM exports;
                 INSERT INTO findings_fts(findings_fts) VALUES('rebuild');
                 INSERT INTO investigations_fts(investigations_fts) VALUES('rebuild');",
            )
        })
    }

    /// Full JSON export of the investigation history (no secrets, no asset hashes).
    pub fn export_all_json(&self) -> SwordResult<String> {
        let page = self.list_history(&crate::HistoryQuery { limit: Some(500), ..Default::default() })?;
        let mut items = Vec::new();
        let total = page.total;
        let mut offset = 0u32;
        let mut current = page;
        loop {
            for rec in &current.items {
                let detail = self.get_detail(&rec.id)?;
                let graph = self.graph_of(&rec.id)?;
                items.push(serde_json::json!({ "investigation": detail, "graph": graph }));
            }
            offset += current.items.len() as u32;
            if offset >= total || current.items.is_empty() {
                break;
            }
            current = self.list_history(&crate::HistoryQuery { limit: Some(500), offset: Some(offset), ..Default::default() })?;
        }
        let doc = serde_json::json!({
            "format": "sword-osint-export",
            "version": 1,
            "exportedAt": ts(&Utc::now()),
            "investigations": items,
        });
        serde_json::to_string_pretty(&doc).map_err(|e| SwordError::Internal(e.to_string()))
    }
}
