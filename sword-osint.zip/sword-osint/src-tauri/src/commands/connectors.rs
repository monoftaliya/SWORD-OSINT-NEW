//! Source registry: status, health/permission checks, enabling, options and credentials.

use std::collections::{BTreeMap, HashMap};
use std::sync::Arc;

use sword_core::util::sha256_hex;
use sword_core::{AdapterStatus, AdapterView, AppSettings, CredentialState};
use tauri::State;
use tokio_util::sync::CancellationToken;

use crate::error::{ApiError, ApiResult};
use crate::state::{blocking, AppState};

fn build_views(state: &AppState, statuses: Vec<AdapterStatus>, meta: HashMap<String, (chrono::DateTime<chrono::Utc>, String)>) -> Vec<AdapterView> {
    let settings = state.settings();
    let ctx = match state.context(CancellationToken::new()) {
        Ok(c) => Some(c),
        Err(e) => {
            tracing::warn!(error = %e, "context unavailable");
            None
        }
    };
    let status_map: HashMap<String, AdapterStatus> = statuses.into_iter().map(|s| (s.adapter_id.clone(), s)).collect();
    state
        .registry()
        .all()
        .iter()
        .map(|a| {
            let info = a.info().clone();
            let missing = ctx.as_ref().map(|c| a.missing_config(c)).unwrap_or_default();
            let credentials = info
                .credentials
                .iter()
                .map(|c| {
                    let m = meta.get(&c.key);
                    CredentialState {
                        key: c.key.clone(),
                        is_set: state.secrets.has(&c.key),
                        updated_at: m.map(|(t, _)| *t),
                        fingerprint: m.map(|(_, f)| f.clone()),
                    }
                })
                .collect();
            let options: BTreeMap<String, String> = settings.adapters.get(&info.id).map(|a| a.options.clone()).unwrap_or_default();
            let enabled = settings.adapter_enabled(&info.id);
            let mut status = status_map.get(&info.id).cloned().unwrap_or_else(|| AdapterStatus::unknown(&info.id));
            if !enabled {
                status.health = sword_core::AdapterHealth::Disabled;
                status.message = "Источник отключён в настройках".into();
            } else if !missing.is_empty() {
                status.health = sword_core::AdapterHealth::Unconfigured;
                status.message = format!("Требуется настройка: {}", missing.join(", "));
            }
            AdapterView { configured: missing.is_empty(), missing, enabled, credentials, options, status, info }
        })
        .collect()
}

#[tauri::command]
pub async fn list_adapters(state: State<'_, AppState>) -> ApiResult<Vec<AdapterView>> {
    let db = state.db.clone();
    let (statuses, meta) = blocking(move || Ok((db.list_status()?, db.credential_meta()?))).await?;
    Ok(build_views(&state, statuses, meta))
}

async fn run_check(state: &AppState, id: &str) -> ApiResult<AdapterStatus> {
    let adapter = state.registry().get(id).ok_or_else(|| ApiError::not_found(format!("источник {id}")))?;
    let ctx = state.context(CancellationToken::new())?;
    let status = tokio::time::timeout(std::time::Duration::from_secs(45), sword_connectors::health(adapter.as_ref(), &ctx))
        .await
        .unwrap_or_else(|_| AdapterStatus {
            adapter_id: id.to_string(),
            health: sword_core::AdapterHealth::Offline,
            message: "Проверка не завершилась за 45 секунд".into(),
            checked_at: Some(sword_core::util::now()),
            last_success_at: None,
            latency_ms: None,
            permissions: vec![],
        });
    let db = state.db.clone();
    let to_save = status.clone();
    blocking(move || db.save_status(&to_save)).await?;
    Ok(status)
}

#[tauri::command]
pub async fn check_adapter(state: State<'_, AppState>, id: String) -> ApiResult<AdapterStatus> {
    run_check(&state, &id).await
}

#[tauri::command]
pub async fn check_all_adapters(state: State<'_, AppState>) -> ApiResult<Vec<AdapterStatus>> {
    let ids: Vec<String> = state.registry().all().iter().map(|a| a.info().id.clone()).collect();
    let sem = Arc::new(tokio::sync::Semaphore::new(4));
    let mut out = Vec::new();
    let checks = ids.iter().map(|id| {
        let sem = sem.clone();
        let st: &AppState = &state;
        async move {
            let _p = sem.acquire().await;
            run_check(st, id).await
        }
    });
    for r in futures::future::join_all(checks).await {
        match r {
            Ok(s) => out.push(s),
            Err(e) => tracing::warn!(error = %e.message, "adapter check failed"),
        }
    }
    Ok(out)
}

async fn update_settings(state: &AppState, f: impl FnOnce(&mut AppSettings)) -> ApiResult<()> {
    let mut s = (*state.settings()).clone();
    f(&mut s);
    let applied = state.apply_settings(s)?;
    let db = state.db.clone();
    let to_save = (*applied).clone();
    blocking(move || db.save_settings(&to_save)).await
}

async fn single_view(state: &AppState, id: &str) -> ApiResult<AdapterView> {
    let db = state.db.clone();
    let (statuses, meta) = blocking(move || Ok((db.list_status()?, db.credential_meta()?))).await?;
    build_views(state, statuses, meta).into_iter().find(|v| v.info.id == id).ok_or_else(|| ApiError::not_found(format!("источник {id}")))
}

#[tauri::command]
pub async fn set_adapter_enabled(state: State<'_, AppState>, id: String, enabled: bool) -> ApiResult<AdapterView> {
    if state.registry().get(&id).is_none() {
        return Err(ApiError::not_found(format!("источник {id}")));
    }
    update_settings(&state, |s| s.adapters.entry(id.clone()).or_default().enabled = enabled).await?;
    single_view(&state, &id).await
}

#[tauri::command]
pub async fn set_adapter_option(state: State<'_, AppState>, id: String, key: String, value: String) -> ApiResult<AdapterView> {
    let adapter = state.registry().get(&id).ok_or_else(|| ApiError::not_found(format!("источник {id}")))?;
    if !adapter.info().options.iter().any(|o| o.key == key) {
        return Err(ApiError::invalid(format!("у источника нет параметра {key}")));
    }
    let value = value.trim().to_string();
    if key == "url" || key == "instance" || key == "service" {
        if !value.is_empty() && !(value.starts_with("http://") || value.starts_with("https://")) {
            return Err(ApiError::invalid("адрес должен начинаться с http:// или https://"));
        }
    }
    update_settings(&state, |s| {
        let entry = s.adapters.entry(id.clone()).or_default();
        if value.is_empty() {
            entry.options.remove(&key);
        } else {
            entry.options.insert(key.clone(), value.clone());
        }
    })
    .await?;
    single_view(&state, &id).await
}

/// Vault keys that may be written from the UI: adapter credentials + OpenSearch password.
fn allowed_key(state: &AppState, key: &str) -> bool {
    key == "opensearch.password" || state.registry().credential_keys().iter().any(|k| k == key)
}

#[tauri::command]
pub async fn set_credential(state: State<'_, AppState>, key: String, value: String) -> ApiResult<CredentialState> {
    if !allowed_key(&state, &key) {
        return Err(ApiError::invalid(format!("неизвестный ключ {key}")));
    }
    let value = value.trim().to_string();
    if value.is_empty() {
        return Err(ApiError::invalid("значение не может быть пустым"));
    }
    if value.len() > 4096 {
        return Err(ApiError::invalid("значение слишком длинное"));
    }
    state.secrets.set(&key, &value)?;
    let fingerprint = sha256_hex(value.as_bytes())[..6].to_string();
    let db = state.db.clone();
    let (k, f) = (key.clone(), fingerprint.clone());
    blocking(move || db.set_credential_meta(&k, &f)).await?;
    Ok(CredentialState { key, is_set: true, updated_at: Some(sword_core::util::now()), fingerprint: Some(fingerprint) })
}

#[tauri::command]
pub async fn delete_credential(state: State<'_, AppState>, key: String) -> ApiResult<()> {
    if !allowed_key(&state, &key) {
        return Err(ApiError::invalid(format!("неизвестный ключ {key}")));
    }
    state.secrets.delete(&key)?;
    let db = state.db.clone();
    blocking(move || db.delete_credential_meta(&key)).await
}
