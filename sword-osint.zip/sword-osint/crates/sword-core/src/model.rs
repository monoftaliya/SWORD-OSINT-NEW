//! Domain model shared by all engines and serialized to the UI (camelCase JSON).
//!
//! Provenance is a first-class concern: every graph attribute and every relation carries
//! the source URL, the adapter that produced it and the retrieval time, and every
//! relation carries a numeric confidence. Nothing in this model can be created without
//! a source — this is what keeps reports free of invented results.

use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

use crate::error::ErrorKind;
use crate::input::{ClassifiedInput, InputKind};

// ---------------------------------------------------------------------------------------
// Categories
// ---------------------------------------------------------------------------------------

/// Discovery categories (section 5 of the specification).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Category {
    WebSearch,
    SocialNetworks,
    Vk,
    Telegram,
    PublicWebsites,
    DomainIntel,
    EmailExposure,
    PublicDocuments,
    OrgIntel,
    DigitalFootprint,
}

impl Category {
    pub const ALL: [Category; 10] = [
        Category::WebSearch,
        Category::SocialNetworks,
        Category::Vk,
        Category::Telegram,
        Category::PublicWebsites,
        Category::DomainIntel,
        Category::EmailExposure,
        Category::PublicDocuments,
        Category::OrgIntel,
        Category::DigitalFootprint,
    ];

    pub fn as_str(&self) -> &'static str {
        match self {
            Category::WebSearch => "web_search",
            Category::SocialNetworks => "social_networks",
            Category::Vk => "vk",
            Category::Telegram => "telegram",
            Category::PublicWebsites => "public_websites",
            Category::DomainIntel => "domain_intel",
            Category::EmailExposure => "email_exposure",
            Category::PublicDocuments => "public_documents",
            Category::OrgIntel => "org_intel",
            Category::DigitalFootprint => "digital_footprint",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        Category::ALL.iter().copied().find(|c| c.as_str() == s)
    }

    /// Upper-case title used in the UI and in reports.
    pub fn title(&self) -> &'static str {
        match self {
            Category::WebSearch => "WEB SEARCH",
            Category::SocialNetworks => "SOCIAL NETWORKS",
            Category::Vk => "VK",
            Category::Telegram => "TELEGRAM PUBLIC SOURCES",
            Category::PublicWebsites => "PUBLIC WEBSITES",
            Category::DomainIntel => "DOMAIN INTELLIGENCE",
            Category::EmailExposure => "EMAIL EXPOSURE CHECK",
            Category::PublicDocuments => "PUBLIC DOCUMENTS",
            Category::OrgIntel => "ORGANIZATION INTELLIGENCE",
            Category::DigitalFootprint => "DIGITAL FOOTPRINT",
        }
    }

    /// Russian description used in reports.
    pub fn label_ru(&self) -> &'static str {
        match self {
            Category::WebSearch => "Веб-поиск",
            Category::SocialNetworks => "Социальные сети",
            Category::Vk => "ВКонтакте",
            Category::Telegram => "Публичные источники Telegram",
            Category::PublicWebsites => "Публичные веб-сайты",
            Category::DomainIntel => "Разведка по домену",
            Category::EmailExposure => "Проверка раскрытия e-mail",
            Category::PublicDocuments => "Публичные документы",
            Category::OrgIntel => "Сведения об организации",
            Category::DigitalFootprint => "Цифровой след",
        }
    }
}

// ---------------------------------------------------------------------------------------
// Findings
// ---------------------------------------------------------------------------------------

/// What a single finding represents.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum FindingKind {
    WebPage,
    Document,
    Publication,
    SocialPost,
    Community,
    Channel,
    Organization,
    Domain,
    DnsRecord,
    Registration,
    Certificate,
    Subdomain,
    Archive,
    Breach,
    Project,
    Website,
    Network,
    Encyclopedia,
    AuditIssue,
}

impl FindingKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            FindingKind::WebPage => "web_page",
            FindingKind::Document => "document",
            FindingKind::Publication => "publication",
            FindingKind::SocialPost => "social_post",
            FindingKind::Community => "community",
            FindingKind::Channel => "channel",
            FindingKind::Organization => "organization",
            FindingKind::Domain => "domain",
            FindingKind::DnsRecord => "dns_record",
            FindingKind::Registration => "registration",
            FindingKind::Certificate => "certificate",
            FindingKind::Subdomain => "subdomain",
            FindingKind::Archive => "archive",
            FindingKind::Breach => "breach",
            FindingKind::Project => "project",
            FindingKind::Website => "website",
            FindingKind::Network => "network",
            FindingKind::Encyclopedia => "encyclopedia",
            FindingKind::AuditIssue => "audit_issue",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        use FindingKind::*;
        [
            WebPage, Document, Publication, SocialPost, Community, Channel, Organization, Domain, DnsRecord,
            Registration, Certificate, Subdomain, Archive, Breach, Project, Website, Network, Encyclopedia,
            AuditIssue,
        ]
        .into_iter()
        .find(|k| k.as_str() == s)
    }

    pub fn label_ru(&self) -> &'static str {
        match self {
            FindingKind::WebPage => "Веб-страница",
            FindingKind::Document => "Документ",
            FindingKind::Publication => "Публикация",
            FindingKind::SocialPost => "Публичный пост",
            FindingKind::Community => "Сообщество",
            FindingKind::Channel => "Канал",
            FindingKind::Organization => "Организация",
            FindingKind::Domain => "Домен",
            FindingKind::DnsRecord => "DNS",
            FindingKind::Registration => "Регистрация домена",
            FindingKind::Certificate => "Сертификаты",
            FindingKind::Subdomain => "Поддомен",
            FindingKind::Archive => "Архив",
            FindingKind::Breach => "Инцидент утечки",
            FindingKind::Project => "Проект",
            FindingKind::Website => "Сайт / профиль",
            FindingKind::Network => "Сеть",
            FindingKind::Encyclopedia => "Энциклопедия",
            FindingKind::AuditIssue => "Проверка безопасности",
        }
    }
}

/// Severity of audit findings (Privacy & Exposure Audit).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum Severity {
    Critical,
    High,
    Medium,
    Low,
    Info,
    Pass,
}

impl Severity {
    pub fn as_str(&self) -> &'static str {
        match self {
            Severity::Critical => "critical",
            Severity::High => "high",
            Severity::Medium => "medium",
            Severity::Low => "low",
            Severity::Info => "info",
            Severity::Pass => "pass",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "critical" => Severity::Critical,
            "high" => Severity::High,
            "medium" => Severity::Medium,
            "low" => Severity::Low,
            "info" => Severity::Info,
            "pass" => Severity::Pass,
            _ => return None,
        })
    }

    pub fn label_ru(&self) -> &'static str {
        match self {
            Severity::Critical => "Критично",
            Severity::High => "Высокий",
            Severity::Medium => "Средний",
            Severity::Low => "Низкий",
            Severity::Info => "Инфо",
            Severity::Pass => "В норме",
        }
    }
}

/// Simple labelled value attached to a finding.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Attr {
    pub label: String,
    pub value: String,
}

impl Attr {
    pub fn new(label: impl Into<String>, value: impl Into<String>) -> Self {
        Attr { label: label.into(), value: value.into() }
    }
}

/// One verifiable result produced by a source adapter. A finding always comes from a
/// real response of a source; `url` points to the primary source whenever one exists.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Finding {
    pub id: String,
    pub adapter_id: String,
    pub category: Category,
    pub kind: FindingKind,
    pub title: String,
    pub url: Option<String>,
    pub snippet: Option<String>,
    pub published_at: Option<DateTime<Utc>>,
    pub retrieved_at: DateTime<Utc>,
    /// 0.0 – 1.0, see [`confidence_label`].
    pub confidence: f32,
    pub severity: Option<Severity>,
    pub attributes: Vec<Attr>,
    /// Key of the graph entity this finding describes (if any).
    pub entity_key: Option<String>,
}

/// Human label for a confidence value.
pub fn confidence_label(c: f32) -> &'static str {
    if c >= 0.95 {
        "подтверждено"
    } else if c >= 0.8 {
        "высокая"
    } else if c >= 0.6 {
        "средняя"
    } else {
        "низкая"
    }
}

// ---------------------------------------------------------------------------------------
// Graph primitives with provenance
// ---------------------------------------------------------------------------------------

/// Node types of the relationship graph (section 7 of the specification).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, PartialOrd, Ord, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum EntityKind {
    Domain,
    Organization,
    Website,
    Project,
    Document,
    Publication,
    Source,
}

impl EntityKind {
    pub const ALL: [EntityKind; 7] = [
        EntityKind::Domain,
        EntityKind::Organization,
        EntityKind::Website,
        EntityKind::Project,
        EntityKind::Document,
        EntityKind::Publication,
        EntityKind::Source,
    ];

    pub fn as_str(&self) -> &'static str {
        match self {
            EntityKind::Domain => "domain",
            EntityKind::Organization => "organization",
            EntityKind::Website => "website",
            EntityKind::Project => "project",
            EntityKind::Document => "document",
            EntityKind::Publication => "publication",
            EntityKind::Source => "source",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        EntityKind::ALL.iter().copied().find(|k| k.as_str() == s)
    }

    pub fn label_ru(&self) -> &'static str {
        match self {
            EntityKind::Domain => "Домены",
            EntityKind::Organization => "Организации",
            EntityKind::Website => "Публичные сайты",
            EntityKind::Project => "Публичные проекты",
            EntityKind::Document => "Публичные документы",
            EntityKind::Publication => "Публикации",
            EntityKind::Source => "Проверенные источники",
        }
    }
}

/// A fact about an entity together with where it came from.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct NodeAttribute {
    pub label: String,
    pub value: String,
    pub source_url: String,
    pub adapter_id: String,
    pub retrieved_at: DateTime<Utc>,
}

/// An object of the investigation (domain, organization, website, …).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Entity {
    /// Stable key, e.g. `domain:example.com`, `org:lei:5493001KJTIIGC8Y1R12`.
    pub key: String,
    pub kind: EntityKind,
    pub label: String,
    pub attributes: Vec<NodeAttribute>,
}

/// Evidence for a relation: the primary source that states it.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Evidence {
    pub source_url: String,
    pub adapter_id: String,
    pub retrieved_at: DateTime<Utc>,
    pub note: Option<String>,
}

/// A confirmed relation between two entities. Only structured, source-backed statements
/// become relations; free-text mentions never do.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct Relation {
    pub from: String,
    pub to: String,
    pub relation: String,
    pub confidence: f32,
    pub evidence: Evidence,
}

/// A source document that was actually consulted.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SourceRef {
    pub url: String,
    pub title: String,
    pub adapter_id: String,
    pub retrieved_at: DateTime<Utc>,
}

/// A short statement used for the analytical summary, always traceable to a source.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct KeyFact {
    pub label: String,
    pub value: String,
    pub adapter_id: String,
    pub source_url: String,
}

/// Everything a single adapter produced for one investigation.
#[derive(Debug, Clone, Default, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AdapterOutput {
    pub findings: Vec<Finding>,
    pub entities: Vec<Entity>,
    pub relations: Vec<Relation>,
    pub sources: Vec<SourceRef>,
    pub facts: Vec<KeyFact>,
    /// Honest notes about limitations encountered (skipped sub-queries, missing permissions…).
    pub notes: Vec<String>,
}

// ---------------------------------------------------------------------------------------
// Runs, investigations and events
// ---------------------------------------------------------------------------------------

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum RunStatus {
    Queued,
    Running,
    Done,
    Failed,
    Skipped,
    Cancelled,
    TimedOut,
}

impl RunStatus {
    pub fn as_str(&self) -> &'static str {
        match self {
            RunStatus::Queued => "queued",
            RunStatus::Running => "running",
            RunStatus::Done => "done",
            RunStatus::Failed => "failed",
            RunStatus::Skipped => "skipped",
            RunStatus::Cancelled => "cancelled",
            RunStatus::TimedOut => "timed_out",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "queued" => RunStatus::Queued,
            "running" => RunStatus::Running,
            "done" => RunStatus::Done,
            "failed" => RunStatus::Failed,
            "skipped" => RunStatus::Skipped,
            "cancelled" => RunStatus::Cancelled,
            "timed_out" => RunStatus::TimedOut,
            _ => return None,
        })
    }

    pub fn is_terminal(&self) -> bool {
        !matches!(self, RunStatus::Queued | RunStatus::Running)
    }
}

/// Execution record of one adapter (or audit module) within an investigation.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct AdapterRun {
    pub adapter_id: String,
    pub adapter_name: String,
    pub status: RunStatus,
    pub started_at: Option<DateTime<Utc>>,
    pub finished_at: Option<DateTime<Utc>>,
    pub duration_ms: Option<u32>,
    pub result_count: u32,
    pub error_kind: Option<ErrorKind>,
    pub message: Option<String>,
}

impl AdapterRun {
    pub fn new(adapter_id: impl Into<String>, adapter_name: impl Into<String>, status: RunStatus) -> Self {
        AdapterRun {
            adapter_id: adapter_id.into(),
            adapter_name: adapter_name.into(),
            status,
            started_at: None,
            finished_at: None,
            duration_ms: None,
            result_count: 0,
            error_kind: None,
            message: None,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum InvestigationKind {
    Discovery,
    ExposureAudit,
}

impl InvestigationKind {
    pub fn as_str(&self) -> &'static str {
        match self {
            InvestigationKind::Discovery => "discovery",
            InvestigationKind::ExposureAudit => "exposure_audit",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        match s {
            "discovery" => Some(InvestigationKind::Discovery),
            "exposure_audit" => Some(InvestigationKind::ExposureAudit),
            _ => None,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum InvestigationStatus {
    Running,
    Completed,
    Partial,
    Failed,
    Cancelled,
}

impl InvestigationStatus {
    pub fn as_str(&self) -> &'static str {
        match self {
            InvestigationStatus::Running => "running",
            InvestigationStatus::Completed => "completed",
            InvestigationStatus::Partial => "partial",
            InvestigationStatus::Failed => "failed",
            InvestigationStatus::Cancelled => "cancelled",
        }
    }

    pub fn parse(s: &str) -> Option<Self> {
        Some(match s {
            "running" => InvestigationStatus::Running,
            "completed" => InvestigationStatus::Completed,
            "partial" => InvestigationStatus::Partial,
            "failed" => InvestigationStatus::Failed,
            "cancelled" => InvestigationStatus::Cancelled,
            _ => return None,
        })
    }

    pub fn label_ru(&self) -> &'static str {
        match self {
            InvestigationStatus::Running => "выполняется",
            InvestigationStatus::Completed => "завершено",
            InvestigationStatus::Partial => "завершено частично",
            InvestigationStatus::Failed => "ошибка",
            InvestigationStatus::Cancelled => "отменено",
        }
    }
}

/// What the analyst asked for.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InvestigationRequest {
    pub query: String,
    pub categories: Vec<Category>,
    /// Optional explicit adapter subset (ids). Empty = all adapters of the categories.
    #[serde(default)]
    pub adapters: Vec<String>,
}

/// Planned (or skipped) adapter for an investigation.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PlannedAdapter {
    pub adapter_id: String,
    pub name: String,
    pub categories: Vec<Category>,
    pub will_run: bool,
    pub reason: Option<String>,
}

/// Persisted header of an investigation (one row in HISTORY).
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct InvestigationRecord {
    pub id: String,
    pub kind: InvestigationKind,
    pub query: String,
    pub input_kind: InputKind,
    pub categories: Vec<Category>,
    pub status: InvestigationStatus,
    pub created_at: DateTime<Utc>,
    pub finished_at: Option<DateTime<Utc>>,
    pub duration_ms: Option<u32>,
    pub result_count: u32,
    pub source_count: u32,
    pub node_count: u32,
    pub edge_count: u32,
    pub adapters: Vec<String>,
    pub summary: String,
    pub key_facts: Vec<KeyFact>,
    pub limitations: Vec<String>,
    pub error: Option<String>,
    pub notes: String,
}

/// Events streamed to the UI while an investigation or audit runs
/// (Tauri event `sword://investigation`).
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "camelCase")]
pub enum InvestigationEvent {
    #[serde(rename_all = "camelCase")]
    Started {
        investigation_id: String,
        kind: InvestigationKind,
        query: String,
        input: ClassifiedInput,
        plan: Vec<PlannedAdapter>,
    },
    #[serde(rename_all = "camelCase")]
    AdapterUpdate { investigation_id: String, run: AdapterRun },
    #[serde(rename_all = "camelCase")]
    Findings { investigation_id: String, adapter_id: String, findings: Vec<Finding> },
    #[serde(rename_all = "camelCase")]
    Finished { investigation_id: String, record: InvestigationRecord },
}

/// Receiver of investigation events (implemented by the desktop runtime).
pub trait EventSink: Send + Sync {
    fn emit(&self, event: InvestigationEvent);
}

/// Sink that drops events (tests, background jobs).
pub struct NullSink;

impl EventSink for NullSink {
    fn emit(&self, _event: InvestigationEvent) {}
}

/// Helper: does the given input kind make sense for e-mail/domain oriented adapters.
pub fn input_has_domain(input: &ClassifiedInput) -> bool {
    matches!(input.kind, InputKind::Domain | InputKind::Url | InputKind::Email) && input.domain.is_some()
}
