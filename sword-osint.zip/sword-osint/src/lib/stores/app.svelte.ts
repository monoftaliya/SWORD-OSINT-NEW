/**
 * Global application state (Svelte 5 runes): navigation, settings, adapter catalogue,
 * toasts and live performance figures of the 3D engine.
 */
import { api, desktop, toApiError } from '../api/client';
import type { AdapterView, ApiError, AppInfo, AppSettings, Category } from '../api/types';

export type SectionId = 'discovery' | 'network' | 'intelligence' | 'databases' | 'analytics' | 'history' | 'report' | 'settings';

export const SECTIONS: { id: SectionId; title: string; icon: import('../components/icons').IconName; hint: string }[] = [
  { id: 'discovery', title: 'DISCOVERY', icon: 'discovery', hint: 'Поиск по публичным источникам' },
  { id: 'network', title: 'NETWORK', icon: 'network', hint: '3D-граф подтверждённых связей' },
  { id: 'intelligence', title: 'INTELLIGENCE', icon: 'intelligence', hint: 'Аудит цифровой безопасности' },
  { id: 'databases', title: 'DATABASES', icon: 'databases', hint: 'Источники, база знаний, хранилище' },
  { id: 'analytics', title: 'ANALYTICS', icon: 'analytics', hint: 'Статистика и производительность' },
  { id: 'history', title: 'HISTORY', icon: 'history', hint: 'История исследований' },
  { id: 'report', title: 'REPORT STUDIO', icon: 'report', hint: 'PDF-отчёты' },
  { id: 'settings', title: 'SETTINGS', icon: 'settings', hint: 'Подключения и параметры' },
];

export interface Toast {
  id: number;
  tone: 'ok' | 'err' | 'info';
  text: string;
}

export interface PerfInfo {
  fps: number;
  backend: string;
  particles: number;
  gpu: string;
  heapMb: number | null;
  /** Automatic simplification step of the particle scene (index into SIMPLIFY_STEPS). */
  simplified: number;
}

class AppStore {
  section = $state<SectionId>('discovery');
  settings = $state<AppSettings | null>(null);
  info = $state<AppInfo | null>(null);
  backend = $state<'connecting' | 'ready' | 'offline'>('connecting');
  backendError = $state<string | null>(null);
  adapters = $state<AdapterView[]>([]);
  toasts = $state<Toast[]>([]);
  perf = $state<PerfInfo>({ fps: 0, backend: '—', particles: 0, gpu: '', heapMb: null, simplified: 0 });
  /** Investigation that NETWORK / REPORT STUDIO should open. */
  focusInvestigation = $state<string | null>(null);
  /** Increments when graphics settings require re-creating the 3D engine. */
  engineEpoch = $state(0);
  /**
   * Graceful degradation after the GPU device was lost (driver reset, TDR):
   * 0 — normal, 1 — without post-processing, 2 — WebGL 2 without post-processing.
   * Lasts until the application is restarted.
   */
  gpuSafeMode = $state(0);
  /** Categories selected on the DISCOVERY screen (shared with the 3D beacons). */
  selectedCategories = $state<Category[]>(['web_search', 'domain_intel', 'org_intel', 'public_websites']);
  private toastSeq = 0;
  private lastGpuRecovery = 0;

  navigate(section: SectionId, investigationId?: string) {
    if (investigationId !== undefined) this.focusInvestigation = investigationId;
    this.section = section;
  }

  toast(tone: Toast['tone'], text: string, timeout = 4200) {
    const id = ++this.toastSeq;
    this.toasts = [...this.toasts, { id, tone, text }];
    setTimeout(() => this.dismiss(id), timeout);
  }

  error(e: unknown, prefix?: string) {
    const err: ApiError = toApiError(e);
    this.toast('err', prefix ? `${prefix}: ${err.message}` : err.message, 6500);
  }

  dismiss(id: number) {
    this.toasts = this.toasts.filter((t) => t.id !== id);
  }

  async init() {
    if (!desktop()) {
      this.backend = 'offline';
      this.backendError = 'Интерфейс открыт вне настольного приложения — функции бэкенда недоступны.';
      return;
    }
    try {
      const [info, settings] = await Promise.all([api.appInfo(), api.getSettings()]);
      this.info = info;
      this.settings = settings;
      this.backend = 'ready';
      if (!info.vaultPersistent) {
        this.toast('err', 'Хранилище учётных данных Windows недоступно: ключи API будут храниться только до закрытия приложения.', 9000);
      }
      await this.refreshAdapters();
    } catch (e) {
      this.backend = 'offline';
      this.backendError = toApiError(e).message;
    }
  }

  async refreshAdapters() {
    try {
      this.adapters = await api.listAdapters();
    } catch (e) {
      this.error(e, 'Список источников');
    }
  }

  replaceAdapter(view: AdapterView) {
    this.adapters = this.adapters.map((a) => (a.info.id === view.info.id ? view : a));
  }

  async saveSettings(next: AppSettings, opts: { restartEngine?: boolean } = {}) {
    try {
      this.settings = await api.saveSettings(next);
      if (opts.restartEngine) this.engineEpoch++;
      return true;
    } catch (e) {
      this.error(e, 'Сохранение настроек');
      return false;
    }
  }

  /**
   * Read-modify-write against the settings stored in the core. Adapter toggles and options
   * are written by their own commands, so a form must never save a stale full copy.
   */
  async patchSettings(patch: (current: AppSettings) => AppSettings, opts: { restartEngine?: boolean } = {}) {
    try {
      const fresh = await api.getSettings();
      this.settings = await api.saveSettings(patch(fresh));
      if (opts.restartEngine) this.engineEpoch++;
      return true;
    } catch (e) {
      this.error(e, 'Сохранение настроек');
      return false;
    }
  }

  /** Called by a 3D view whose GPU device was lost: degrade one step and rebuild the scene. */
  /** Recreate the particle scene at full quality after an automatic simplification. */
  restoreGraphics() {
    this.perf = { ...this.perf, simplified: 0 };
    this.engineEpoch++;
  }

  recoverGpu(message: string): boolean {
    // both 3D views can report the same reset; escalate only once per incident
    const now = Date.now();
    if (now - this.lastGpuRecovery < 4000) return true;
    if (this.gpuSafeMode >= 2) return false;
    this.lastGpuRecovery = now;
    this.gpuSafeMode++;
    this.toast(
      'info',
      this.gpuSafeMode === 1
        ? `Графическое устройство сброшено (${message}). Сцена перезапущена без эффектов свечения и шлейфов.`
        : 'Повторный сброс графического устройства. Сцена перезапущена в режиме совместимости WebGL 2.',
      8000,
    );
    setTimeout(() => this.engineEpoch++, 600);
    return true;
  }

  /** Adapters (enabled, configured) serving a category — for readiness hints. */
  readiness(category: Category): { ready: number; total: number } {
    const list = this.adapters.filter((a) => a.info.categories.includes(category));
    return { ready: list.filter((a) => a.enabled && a.configured).length, total: list.length };
  }
}

export const app = new AppStore();
