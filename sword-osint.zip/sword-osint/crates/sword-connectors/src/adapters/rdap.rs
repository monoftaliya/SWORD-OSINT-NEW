//! Registration data: RDAP (RFC 9082/9083) for domains and IP networks, with a WHOIS
//! fallback for TLDs that do not publish RDAP (e.g. .ru / .su / .рф).

use async_trait::async_trait;
use serde_json::Value;
use sword_core::util::{fmt_date, parse_date};
use sword_core::{
    keys, AdapterInfo, AdapterOutput, Category, ClassifiedInput, EntityKind, FindingKind, InputKind, PermissionCheck,
    SwordError, SwordResult,
};

use super::{arr, info, s};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::doh::{self, RecordType};
use crate::http;
use crate::output::{FindingExt, OutputBuilder};
use crate::whois;

pub struct Rdap {
    info: AdapterInfo,
}

impl Default for Rdap {
    fn default() -> Self {
        Self::new()
    }
}

/// `fn` value of a jCard (`["vcard", [["fn", {}, "text", "Name"], …]]`).
fn vcard_prop(entity: &Value, prop: &str) -> Option<String> {
    arr(entity, "/vcardArray/1").iter().find_map(|p| {
        let a = p.as_array()?;
        (a.first()?.as_str()? == prop).then(|| a.get(3).and_then(Value::as_str).map(str::to_string)).flatten()
    })
}

fn find_entity<'a>(v: &'a Value, role: &str) -> Option<&'a Value> {
    for e in arr(v, "/entities") {
        if arr(e, "/roles").iter().any(|r| r.as_str() == Some(role)) {
            return Some(e);
        }
        if let Some(inner) = find_entity(e, role) {
            return Some(inner);
        }
    }
    None
}

fn event(v: &Value, action: &str) -> Option<String> {
    arr(v, "/events").iter().find(|e| s(e, "eventAction").as_deref() == Some(action)).and_then(|e| s(e, "eventDate"))
}

impl Rdap {
    pub fn new() -> Self {
        Rdap {
            info: info(
                "rdap",
                "RDAP / WHOIS",
                "реестры доменов и RIR",
                "Регистрационные данные домена (регистратор, даты, статусы, DNS-серверы, DNSSEC) и владелец IP-сети хостинга.",
                "RDAP через rdap.org (перенаправление на авторитетный сервер реестра по bootstrap IANA). Для зон без RDAP — WHOIS (порт 43) \
                 авторитетного сервера (для .ru/.su/.рф — whois.tcinet.ru). Владелец сети определяется RDAP-запросом к RIR по IP из A-записи.",
                &[Category::DomainIntel, Category::OrgIntel],
                &[InputKind::Domain, InputKind::Url, InputKind::Email, InputKind::Ip],
                vec![],
                vec![],
                30,
                "https://about.rdap.org/",
                Some("https://www.rfc-editor.org/rfc/rfc9083"),
                true,
            ),
        }
    }

    async fn rdap(&self, ctx: &ConnectorContext, path: &str) -> SwordResult<(String, Value)> {
        let req = ctx.get(&format!("https://rdap.org/{path}")).header("accept", "application/rdap+json");
        let resp = ctx.send(&self.info, req).await?;
        let final_url = resp.url().to_string();
        let v: Value = http::read_json(resp).await?;
        Ok((final_url, v))
    }

    async fn network(&self, b: &mut OutputBuilder, ctx: &ConnectorContext, ip: &str, from_key: Option<&str>) -> SwordResult<()> {
        let (url, v) = self.rdap(ctx, &format!("ip/{ip}")).await?;
        let name = s(&v, "name").unwrap_or_else(|| "сеть".into());
        let range = match (s(&v, "startAddress"), s(&v, "endAddress")) {
            (Some(a), Some(z)) => format!("{a} – {z}"),
            _ => s(&v, "handle").unwrap_or_default(),
        };
        let owner_entity = find_entity(&v, "registrant").or_else(|| find_entity(&v, "administrative"));
        let individual = owner_entity.and_then(|e| vcard_prop(e, "kind")).as_deref() == Some("individual");
        let owner = owner_entity.filter(|_| !individual).and_then(|e| vcard_prop(e, "fn"));
        b.finding(Category::DomainIntel, FindingKind::Network, &format!("Сеть {name} ({ip})"), Some(&url))
            .snippet(&format!("Диапазон: {range}. Владелец: {}.", owner.clone().unwrap_or_else(|| "не указан".into())))
            .attr("Страна", s(&v, "country").unwrap_or_default())
            .attr("Handle", s(&v, "handle").unwrap_or_default());
        b.source(&url, &format!("RDAP: IP {ip}"));
        if let Some(org) = owner {
            let okey = keys::org("name", &org);
            b.entity(&okey, EntityKind::Organization, &org);
            b.attr(&okey, "Сеть", &format!("{name} ({range})"), &url);
            if let Some(country) = s(&v, "country") {
                b.attr(&okey, "Страна (RIR)", &country, &url);
            }
            if let Some(fk) = from_key {
                b.relate(fk, &okey, "hosted_on_network", 0.9, &url, Some(&format!("IP {ip} принадлежит сети {name}")));
            }
            b.fact("Сеть размещения", &format!("{org} — {name}, {range}"), &url);
        }
        Ok(())
    }
}

#[async_trait]
impl SourceAdapter for Rdap {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let (url, _) = self.rdap(ctx, "domain/example.com").await?;
        Ok(vec![
            PermissionCheck::granted("RDAP", format!("Bootstrap работает ({})", http_host(&url))),
            PermissionCheck::granted("WHOIS (порт 43)", "Используется для зон без RDAP; доступность зависит от сетевой политики"),
        ])
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let mut b = OutputBuilder::new(&self.info);
        if input.kind == InputKind::Ip {
            let ip = input.ip.clone().unwrap_or_default();
            self.network(&mut b, ctx, &ip, None).await?;
            return Ok(b.finish());
        }
        let domain = input.registrable_domain.clone().or_else(|| input.domain.clone()).ok_or_else(|| SwordError::InvalidInput("нужен домен".into()))?;
        let dkey = keys::domain(&domain);
        b.entity(&dkey, EntityKind::Domain, &domain);

        match self.rdap(ctx, &format!("domain/{domain}")).await {
            Ok((url, v)) => {
                let registrar = find_entity(&v, "registrar");
                let registrar_name = registrar.and_then(|e| vcard_prop(e, "fn"));
                let iana_id = registrar.and_then(|e| {
                    arr(e, "/publicIds").iter().find(|p| s(p, "type").map(|t| t.contains("IANA")).unwrap_or(false)).and_then(|p| s(p, "identifier"))
                });
                let created = event(&v, "registration").and_then(|d| parse_date(&d));
                let expires = event(&v, "expiration").and_then(|d| parse_date(&d));
                let changed = event(&v, "last changed").and_then(|d| parse_date(&d));
                let status: Vec<String> = arr(&v, "/status").iter().filter_map(|x| x.as_str().map(str::to_string)).collect();
                let nameservers: Vec<String> =
                    arr(&v, "/nameservers").iter().filter_map(|n| s(n, "ldhName").map(|x| x.to_lowercase())).collect();
                let signed = v.pointer("/secureDNS/delegationSigned").and_then(Value::as_bool);

                if let Some(r) = &registrar_name {
                    b.attr(&dkey, "Регистратор", r, &url);
                }
                if let Some(d) = created {
                    b.attr(&dkey, "Зарегистрирован", &fmt_date(&d), &url);
                }
                if let Some(d) = expires {
                    b.attr(&dkey, "Оплачен до", &fmt_date(&d), &url);
                }
                if !status.is_empty() {
                    b.attr(&dkey, "Статусы", &status.join(", "), &url);
                }
                if !nameservers.is_empty() {
                    b.attr(&dkey, "DNS-серверы (реестр)", &nameservers.join(", "), &url);
                }
                if let Some(sig) = signed {
                    b.attr(&dkey, "DNSSEC (реестр)", if sig { "делегирование подписано" } else { "не подписано" }, &url);
                }
                b.finding(Category::DomainIntel, FindingKind::Registration, &format!("Регистрация {domain}"), Some(&url))
                    .snippet(&format!(
                        "Регистратор: {}. Создан: {}. Истекает: {}.",
                        registrar_name.clone().unwrap_or_else(|| "н/д".into()),
                        created.map(|d| fmt_date(&d)).unwrap_or_else(|| "н/д".into()),
                        expires.map(|d| fmt_date(&d)).unwrap_or_else(|| "н/д".into())
                    ))
                    .published(changed)
                    .attr("Статусы", status.join(", "))
                    .attr("DNS-серверы", nameservers.join(", "))
                    .entity(&dkey);
                if let Some(r) = &registrar_name {
                    let rkey = match &iana_id {
                        Some(id) => keys::org("iana-registrar", id),
                        None => keys::org("name", r),
                    };
                    b.entity(&rkey, EntityKind::Organization, r);
                    if let Some(id) = &iana_id {
                        b.attr(&rkey, "IANA Registrar ID", id, &url);
                    }
                    b.relate(&dkey, &rkey, "registered_via", 1.0, &url, Some("RDAP: роль registrar"));
                }
                b.fact(
                    "Регистрация домена",
                    &format!(
                        "регистратор {}, создан {}, оплачен до {}",
                        registrar_name.unwrap_or_else(|| "н/д".into()),
                        created.map(|d| fmt_date(&d)).unwrap_or_else(|| "н/д".into()),
                        expires.map(|d| fmt_date(&d)).unwrap_or_else(|| "н/д".into())
                    ),
                    &url,
                );
                b.source(&url, &format!("RDAP: {domain}"));
            }
            Err(SwordError::NotFound(_)) | Err(SwordError::InvalidInput(_)) => {
                // No RDAP for this TLD — use WHOIS.
                let server = whois::server_for(&domain, &ctx.cancel).await?;
                let text = whois::query(&server, &domain, &ctx.cancel).await?;
                let w = whois::parse(&text);
                let cite = format!("whois://{server}/{domain}");
                if w.registrar.is_none() && w.created.is_none() && text.to_lowercase().contains("no entries found") {
                    b.note(format!("WHOIS {server}: домен {domain} не зарегистрирован"));
                    return Ok(b.finish());
                }
                for (label, value) in [
                    ("Регистратор", w.registrar.clone()),
                    ("Зарегистрирован", w.created.as_deref().and_then(parse_date).map(|d| fmt_date(&d))),
                    ("Оплачен до", w.expires.as_deref().and_then(parse_date).map(|d| fmt_date(&d))),
                    ("Организация-администратор", w.org.clone()),
                ] {
                    if let Some(v) = value {
                        b.attr(&dkey, label, &v, &cite);
                    }
                }
                if !w.nameservers.is_empty() {
                    b.attr(&dkey, "DNS-серверы (реестр)", &w.nameservers.join(", "), &cite);
                }
                b.finding(Category::DomainIntel, FindingKind::Registration, &format!("Регистрация {domain} (WHOIS)"), None)
                    .snippet(&format!(
                        "Сервер: {server}. Регистратор: {}. Создан: {}. Оплачен до: {}.",
                        w.registrar.clone().unwrap_or_else(|| "н/д".into()),
                        w.created.clone().unwrap_or_else(|| "н/д".into()),
                        w.expires.clone().unwrap_or_else(|| "н/д".into())
                    ))
                    .attr("Статусы", w.status.join(", "))
                    .attr("Источник", cite.clone())
                    .entity(&dkey);
                if let Some(r) = &w.registrar {
                    let rkey = keys::org("name", r);
                    b.entity(&rkey, EntityKind::Organization, r);
                    b.relate(&dkey, &rkey, "registered_via", 1.0, &cite, Some("WHOIS: registrar"));
                }
                if let Some(org) = &w.org {
                    let okey = keys::org("name", org);
                    b.entity(&okey, EntityKind::Organization, org);
                    b.attr(&okey, "Администратор домена", &domain, &cite);
                    b.relate(&okey, &dkey, "official_website", 0.95, &cite, Some("администратор домена по данным реестра"));
                }
                b.fact("Регистрация домена (WHOIS)", &format!("регистратор {}, оплачен до {}", w.registrar.unwrap_or_else(|| "н/д".into()), w.expires.unwrap_or_else(|| "н/д".into())), &cite);
                b.note(format!("RDAP для зоны недоступен — использован WHOIS {server}"));
            }
            Err(e) => return Err(e),
        }

        // Hosting network of the apex A record.
        match doh::query(ctx, &domain, RecordType::A).await {
            Ok(r) => {
                if let Some(ip) = r.data_of(RecordType::A).first() {
                    if let Err(e) = self.network(&mut b, ctx, ip, Some(&dkey)).await {
                        b.note(format!("RDAP по IP {ip}: {e}"));
                    }
                }
            }
            Err(e) => b.note(format!("A-запись не получена: {e}")),
        }
        Ok(b.finish())
    }
}

fn http_host(url: &str) -> String {
    sword_core::util::host_of(url).unwrap_or_else(|| url.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_jcard_and_roles() {
        let v = serde_json::json!({
            "entities": [{ "roles": ["registrar"], "vcardArray": ["vcard", [["version", {}, "text", "4.0"], ["fn", {}, "text", "Example Registrar, Inc."]]],
                           "publicIds": [{"type": "IANA Registrar ID", "identifier": "292"}] }],
            "events": [{"eventAction": "registration", "eventDate": "1995-08-14T04:00:00Z"}]
        });
        let r = find_entity(&v, "registrar").unwrap();
        assert_eq!(vcard_prop(r, "fn").as_deref(), Some("Example Registrar, Inc."));
        assert_eq!(event(&v, "registration").as_deref(), Some("1995-08-14T04:00:00Z"));
    }
}
