//! Own identities: e-mail breach check (HIBP, own addresses only), password exposure via
//! Pwned Passwords k-anonymity (the password never leaves the machine — only the first 5
//! hex chars of its SHA-1 do), and DNS TXT proof of domain ownership.

use serde::{Deserialize, Serialize};
use sha1::{Digest, Sha1};
use sword_connectors::adapters::hibp::{breach_severity, breach_title, breach_url, Hibp, KEY as HIBP_KEY};
use sword_connectors::doh::{self, RecordType};
use sword_connectors::http;
use sword_connectors::output::{FindingExt, OutputBuilder};
use sword_connectors::ConnectorContext;
use sword_core::util::{mask_email, strip_html};
use sword_core::{AdapterInfo, AdapterOutput, Category, FindingKind, Severity, SwordError, SwordResult};

pub async fn email_breaches(ctx: &ConnectorContext, info: &AdapterInfo, email: &str) -> SwordResult<AdapterOutput> {
    let mut b = OutputBuilder::new(info);
    let masked = mask_email(email);
    if ctx.secret(HIBP_KEY).is_none() {
        b.finding(Category::EmailExposure, FindingKind::AuditIssue, &format!("{masked}: проверка не выполнена — нет ключа HIBP"), Some("https://haveibeenpwned.com/API/Key"))
            .severity(Severity::Info)
            .snippet("Проверка собственных адресов использует официальный API Have I Been Pwned и требует API-ключа.")
            .attr("Рекомендация", "Задайте ключ в SETTINGS → Подключения → Have I Been Pwned.");
        return Ok(b.finish());
    }
    let (breaches, pastes) = Hibp::new().account(ctx, email).await?;
    let profile = "https://haveibeenpwned.com/";
    b.source(profile, "Have I Been Pwned");
    if breaches.is_empty() && pastes.is_empty() {
        b.finding(Category::EmailExposure, FindingKind::AuditIssue, &format!("{masked}: в известных утечках не найден"), Some(profile))
            .severity(Severity::Pass)
            .snippet("Адрес не обнаружен в каталоге утечек и публикаций HIBP на момент проверки.");
    }
    for br in &breaches {
        let url = breach_url(br);
        let classes = br
            .get("DataClasses")
            .and_then(|v| v.as_array())
            .map(|a| a.iter().filter_map(|x| x.as_str()).collect::<Vec<_>>().join(", "))
            .unwrap_or_default();
        b.finding(Category::EmailExposure, FindingKind::AuditIssue, &format!("{masked}: {}", breach_title(br)), Some(&url))
            .severity(breach_severity(br))
            .snippet(&strip_html(br.get("Description").and_then(|d| d.as_str()).unwrap_or_default()))
            .attr("Раскрытые данные", classes)
            .attr("Рекомендация", "Смените пароль на этом и других сервисах, где он повторялся; включите двухфакторную аутентификацию.");
        b.source(&url, &breach_title(br));
    }
    for p in &pastes {
        b.finding(Category::EmailExposure, FindingKind::AuditIssue, &format!("{masked}: адрес опубликован в paste-сервисе"), None)
            .severity(Severity::Medium)
            .snippet(&format!("Источник: {}", p.get("Source").and_then(|s| s.as_str()).unwrap_or("?")))
            .attr("Рекомендация", "Проверьте, какие данные раскрыты вместе с адресом, и смените пароли.");
    }
    b.fact("Собственный адрес", &format!("{masked}: утечек {}, публикаций {}", breaches.len(), pastes.len()), profile);
    Ok(b.finish())
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct PasswordExposure {
    pub exposed: bool,
    /// How many times the password appears in the Pwned Passwords corpus.
    pub count: u64,
    /// Number of candidate suffixes returned for the prefix (k-anonymity set size).
    pub bucket_size: usize,
}

/// Pwned Passwords range API with padding. The password is hashed locally; only the first
/// five hex characters of SHA-1 are sent. Nothing is stored or logged.
pub async fn password_exposure(ctx: &ConnectorContext, password: &str) -> SwordResult<PasswordExposure> {
    if password.is_empty() {
        return Err(SwordError::InvalidInput("пустой пароль".into()));
    }
    let digest = hex::encode_upper(Sha1::digest(password.as_bytes()));
    let (prefix, suffix) = digest.split_at(5);
    let req = ctx.http.client().get(format!("https://api.pwnedpasswords.com/range/{prefix}")).header("Add-Padding", "true");
    let resp = ctx.send_with("pwnedpasswords", 120, req).await?;
    let body = http::read_text(http::ensure_success(resp).await?, 2 * 1024 * 1024).await?;
    let mut count = 0u64;
    let mut bucket = 0usize;
    for line in body.lines() {
        let Some((suf, n)) = line.trim().split_once(':') else { continue };
        let n: u64 = n.trim().parse().unwrap_or(0);
        if n == 0 {
            continue; // padding entries
        }
        bucket += 1;
        if suf.eq_ignore_ascii_case(suffix) {
            count = n;
        }
    }
    Ok(PasswordExposure { exposed: count > 0, count, bucket_size: bucket })
}

/// DNS TXT record expected for domain ownership proof.
pub fn verification_record(token: &str) -> String {
    format!("sword-osint-verification={token}")
}

/// Check that the domain publishes the verification TXT record (apex or `_sword-osint`).
pub async fn verify_domain(ctx: &ConnectorContext, domain: &str, token: &str) -> SwordResult<bool> {
    let expected = verification_record(token);
    for name in [domain.to_string(), format!("_sword-osint.{domain}")] {
        let r = doh::query(ctx, &name, RecordType::Txt).await?;
        if r.data_of(RecordType::Txt).iter().any(|t| t.trim() == expected) {
            return Ok(true);
        }
    }
    Ok(false)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sha1_prefix_matches_hibp_format() {
        // SHA-1("password") = 5BAA61E4C9B93F3F0682250B6CF8331B7EE68FD8
        let d = hex::encode_upper(Sha1::digest(b"password"));
        assert_eq!(&d[..5], "5BAA6");
        assert_eq!(verification_record("abc"), "sword-osint-verification=abc");
    }
}
