//! Execution context handed to adapters for one investigation (or health check).

use std::sync::Arc;

use reqwest::{RequestBuilder, Response};
use serde::de::DeserializeOwned;
use sword_core::{AdapterInfo, AppSettings, Category, OwnedAssets, SecretStore, SwordResult};
use tokio_util::sync::CancellationToken;

use crate::http::{self, HttpClient};

#[derive(Clone)]
pub struct ConnectorContext {
    pub http: HttpClient,
    pub secrets: Arc<dyn SecretStore>,
    pub settings: Arc<AppSettings>,
    pub assets: Arc<OwnedAssets>,
    pub cancel: CancellationToken,
    /// Categories requested by the analyst (adapters tailor sub-queries to them).
    pub categories: Vec<Category>,
    pub max_results: usize,
}

impl ConnectorContext {
    pub fn new(
        http: HttpClient,
        secrets: Arc<dyn SecretStore>,
        settings: Arc<AppSettings>,
        assets: Arc<OwnedAssets>,
        cancel: CancellationToken,
    ) -> Self {
        let max_results = settings.network.max_results_per_adapter as usize;
        ConnectorContext { http, secrets, settings, assets, cancel, categories: Vec::new(), max_results }
    }

    pub fn with_categories(mut self, categories: Vec<Category>) -> Self {
        self.categories = categories;
        self
    }

    pub fn wants(&self, c: Category) -> bool {
        self.categories.is_empty() || self.categories.contains(&c)
    }

    /// Secret by vault key; vault errors are logged and treated as «not set».
    pub fn secret(&self, key: &str) -> Option<String> {
        match self.secrets.get(key) {
            Ok(Some(v)) if !v.trim().is_empty() => Some(v.trim().to_string()),
            Ok(_) => None,
            Err(e) => {
                tracing::warn!(key, error = %e, "secret store read failed");
                None
            }
        }
    }

    /// Option value configured for the adapter, or the declared default.
    pub fn option(&self, info: &AdapterInfo, key: &str) -> Option<String> {
        self.settings.adapter_option(&info.id, key).or_else(|| {
            info.options.iter().find(|o| o.key == key).and_then(|o| o.default.clone()).filter(|d| !d.is_empty())
        })
    }

    /// Send under the adapter's default rate limit.
    pub async fn send(&self, info: &AdapterInfo, req: RequestBuilder) -> SwordResult<Response> {
        self.http.send(&info.id, info.rate_limit_per_minute, req, &self.cancel).await
    }

    /// Send under a custom rate budget (e.g. a sub-API with its own limits).
    pub async fn send_with(&self, key: &str, per_minute: u32, req: RequestBuilder) -> SwordResult<Response> {
        self.http.send(key, per_minute, req, &self.cancel).await
    }

    pub async fn json<T: DeserializeOwned>(&self, info: &AdapterInfo, req: RequestBuilder) -> SwordResult<T> {
        let resp = self.send(info, req).await?;
        http::read_json(resp).await
    }

    pub async fn text(&self, info: &AdapterInfo, req: RequestBuilder, max_bytes: usize) -> SwordResult<String> {
        let resp = self.send(info, req).await?;
        let resp = http::ensure_success(resp).await?;
        http::read_text(resp, max_bytes).await
    }

    pub fn get(&self, url: &str) -> RequestBuilder {
        self.http.client().get(url)
    }

    pub fn post(&self, url: &str) -> RequestBuilder {
        self.http.client().post(url)
    }
}
