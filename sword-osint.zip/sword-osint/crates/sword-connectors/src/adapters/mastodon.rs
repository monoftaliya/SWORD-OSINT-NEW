//! Mastodon — public hashtag timelines and (with a token) status search on an instance.

use async_trait::async_trait;
use serde_json::Value;
use sword_core::util::parse_date;
use sword_core::{AdapterInfo, AdapterOutput, Category, ClassifiedInput, FindingKind, InputKind, PermissionCheck, SwordError, SwordResult};

use super::{arr, cred, info, num, opt, s, sp};
use crate::adapter::SourceAdapter;
use crate::context::ConnectorContext;
use crate::output::{FindingExt, OutputBuilder};

const TOKEN: &str = "mastodon.token";

pub struct Mastodon {
    info: AdapterInfo,
}

impl Default for Mastodon {
    fn default() -> Self {
        Self::new()
    }
}

impl Mastodon {
    pub fn new() -> Self {
        Mastodon {
            info: info(
                "mastodon",
                "Mastodon",
                "сеть Fediverse",
                "Публичные посты Mastodon: лента хештега на выбранном сервере; с токеном — полнотекстовый поиск статусов.",
                "Mastodon REST API: /api/v1/timelines/tag/{hashtag} (без авторизации, если сервер разрешает) и \
                 /api/v2/search?type=statuses (с токеном доступа; область видимости определяется сервером).",
                &[Category::SocialNetworks],
                &[InputKind::Text, InputKind::Domain, InputKind::Url],
                vec![cred(
                    TOKEN,
                    "Токен доступа (необязательно)",
                    false,
                    "На вашем сервере: Настройки → Разработка → Новое приложение, область read:search и read:statuses; скопируйте «Ваш токен доступа».",
                    None,
                    None,
                )],
                vec![opt("instance", "Сервер", false, Some("https://mastodon.social"), "Адрес сервера Mastodon.", Some("https://mastodon.social"))],
                60,
                "https://joinmastodon.org/",
                Some("https://docs.joinmastodon.org/methods/timelines/#tag"),
                true,
            ),
        }
    }

    fn instance(&self, ctx: &ConnectorContext) -> String {
        ctx.option(&self.info, "instance").unwrap_or_else(|| "https://mastodon.social".into()).trim_end_matches('/').to_string()
    }
}

fn hashtag(text: &str) -> String {
    text.split(|c: char| !c.is_alphanumeric()).filter(|w| !w.is_empty()).collect::<Vec<_>>().join("")
}

#[async_trait]
impl SourceAdapter for Mastodon {
    fn info(&self) -> &AdapterInfo {
        &self.info
    }

    async fn check(&self, ctx: &ConnectorContext) -> SwordResult<Vec<PermissionCheck>> {
        let inst = self.instance(ctx);
        let v: Value = ctx.json(&self.info, ctx.get(&format!("{inst}/api/v2/instance"))).await?;
        let mut perms = vec![PermissionCheck::granted(
            "Сервер",
            format!("{} (версия {})", s(&v, "title").unwrap_or_else(|| inst.clone()), s(&v, "version").unwrap_or_else(|| "?".into())),
        )];
        match ctx.secret(TOKEN) {
            Some(t) => {
                let r = ctx.json::<Value>(&self.info, ctx.get(&format!("{inst}/api/v1/apps/verify_credentials")).bearer_auth(t)).await;
                perms.push(match r {
                    Ok(_) => PermissionCheck::granted("Поиск статусов", "Токен действителен"),
                    Err(e) => PermissionCheck::denied("Поиск статусов", format!("Токен не принят: {e}")),
                });
            }
            None => perms.push(PermissionCheck::denied("Поиск статусов", "Без токена доступна только лента хештега")),
        }
        Ok(perms)
    }

    async fn search(&self, input: &ClassifiedInput, ctx: &ConnectorContext) -> SwordResult<AdapterOutput> {
        let inst = self.instance(ctx);
        let mut b = OutputBuilder::new(&self.info);
        let limit = ctx.max_results.clamp(5, 40).to_string();
        let statuses: Vec<Value> = if let Some(token) = ctx.secret(TOKEN) {
            let q = input.registrable_domain.clone().unwrap_or_else(|| input.text.clone());
            let req = ctx
                .get(&format!("{inst}/api/v2/search"))
                .query(&[("q", q.as_str()), ("type", "statuses"), ("limit", limit.as_str()), ("resolve", "false")])
                .bearer_auth(token);
            let v: Value = ctx.json(&self.info, req).await?;
            b.source(&format!("{inst}/search"), &format!("Mastodon: поиск «{q}»"));
            arr(&v, "/statuses").to_vec()
        } else {
            let source_text = input.registrable_domain.as_deref().map(|d| d.split('.').next().unwrap_or(d).to_string()).unwrap_or_else(|| input.text.clone());
            let tag = hashtag(&source_text);
            if tag.is_empty() {
                return Err(SwordError::InvalidInput("из запроса нельзя составить хештег".into()));
            }
            let url = format!("{inst}/api/v1/timelines/tag/{}", url::form_urlencoded::byte_serialize(tag.as_bytes()).collect::<String>());
            let v: Value = ctx.json(&self.info, ctx.get(&url).query(&[("limit", limit.as_str())])).await.map_err(|e| match e {
                SwordError::Unauthorized(_) | SwordError::Forbidden(_) | SwordError::InvalidInput(_) => SwordError::Forbidden(
                    "сервер не разрешает читать ленты без входа — добавьте токен доступа".into(),
                ),
                other => other,
            })?;
            b.source(&format!("{inst}/tags/{tag}"), &format!("Mastodon: #{tag}"));
            b.note(format!("Без токена использована лента хештега #{tag} на {inst}"));
            v.as_array().cloned().unwrap_or_default()
        };
        for st in &statuses {
            let Some(url) = s(st, "url").or_else(|| s(st, "uri")) else { continue };
            let text = sword_core::util::strip_html(&s(st, "content").unwrap_or_default());
            let title: String = text.chars().take(90).collect();
            b.finding(Category::SocialNetworks, FindingKind::SocialPost, if title.is_empty() { "Пост Mastodon" } else { &title }, Some(&url))
                .snippet(&text)
                .published(s(st, "created_at").and_then(|d| parse_date(&d)))
                .confidence(0.8)
                .attr("Сервер автора", sp(st, "/account/acct").and_then(|a| a.split('@').nth(1).map(str::to_string)).unwrap_or_else(|| inst.clone()))
                .attr("Репосты", num(st, "reblogs_count").unwrap_or(0));
            b.source(&url, "Пост Mastodon");
        }
        Ok(b.finish())
    }
}
