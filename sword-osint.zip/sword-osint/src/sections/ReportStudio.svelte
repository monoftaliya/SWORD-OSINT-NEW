<!--
  REPORT STUDIO — visual editor for PDF reports: choose and order sections, add notes and
  the analyst's conclusion, pick the look (theme, accent, paper), then generate a vector
  PDF with clickable primary-source links. Drafts are saved per investigation.
-->
<script lang="ts">
  import { onMount } from 'svelte';
  import Icon from '../lib/components/Icon.svelte';
  import Bits from '../lib/components/Bits.svelte';
  import Panel from '../lib/components/Panel.svelte';
  import Segmented from '../lib/components/Segmented.svelte';
  import Toggle from '../lib/components/Toggle.svelte';
  import Modal from '../lib/components/Modal.svelte';
  import { api, desktop } from '../lib/api/client';
  import type { InvestigationRecord, ReportOptions, ReportRecord, ReportTheme, SectionId } from '../lib/api/types';
  import { app } from '../lib/stores/app.svelte';
  import { SECTION_META, STATUS_LABEL } from '../lib/util/labels';
  import { debounce, fmtBytes, fmtDateTime, fmtDuration, fmtNum, truncate } from '../lib/util/format';
  import { guarded } from '../lib/components/ui';

  const ALL_SECTIONS: SectionId[] = ['query', 'methodology', 'sources', 'findings', 'summary', 'graph', 'references', 'limitations'];
  const THEMES: { id: ReportTheme; label: string; cover: string; page: string; text: string }[] = [
    { id: 'graphite', label: 'Графит', cover: '#05070A', page: '#FFFFFF', text: '#15181D' },
    { id: 'midnight', label: 'Полночь', cover: '#040608', page: '#07090C', text: '#E7EBF1' },
    { id: 'paper', label: 'Бумага', cover: '#FFFFFF', page: '#FFFFFF', text: '#15181D' },
  ];
  const ACCENTS: Record<ReportOptions['accent'], { light: string; dark: string; label: string }> = {
    silver: { light: '#5A6573', dark: '#C7D0DC', label: 'Серебро' },
    ice: { light: '#3E6E8E', dark: '#9CCBEA', label: 'Лёд' },
    amber: { light: '#8A5A1E', dark: '#E2B672', label: 'Янтарь' },
  };

  let investigations = $state<InvestigationRecord[]>([]);
  let filter = $state('');
  let selectedId = $state<string | null>(app.focusInvestigation);
  let opts = $state<ReportOptions | null>(null);
  /** Investigation the loaded options belong to (guards autosave while switching). */
  let optsFor = $state<string | null>(null);
  let loadingOpts = $state(false);
  let saving = $state(false);
  let generating = $state(false);
  let reports = $state<ReportRecord[]>([]);
  let showAllReports = $state(false);
  let openNote = $state<SectionId | null>(null);
  let deleteTarget = $state<ReportRecord | null>(null);
  let deleteOpen = $state(false);

  const selected = $derived(investigations.find((i) => i.id === selectedId) ?? null);
  const shown = $derived(
    investigations.filter((i) => !filter.trim() || i.query.toLowerCase().includes(filter.trim().toLowerCase())),
  );
  const disabledSections = $derived(opts ? ALL_SECTIONS.filter((s) => !opts!.sections.includes(s)) : []);
  const theme = $derived(THEMES.find((t) => t.id === opts?.theme) ?? THEMES[0]);
  const accent = $derived(opts ? ACCENTS[opts.accent] : ACCENTS.silver);
  const accentOnPage = $derived(theme.id === 'midnight' ? accent.dark : accent.light);

  async function loadInvestigations() {
    if (!desktop()) return;
    const page = await guarded(() => api.listHistory({ sort: 'created_desc', limit: 200, offset: 0 }), 'История');
    if (!page) return;
    investigations = page.items.filter((i) => i.status !== 'running');
    if (!selectedId || !investigations.some((i) => i.id === selectedId)) selectedId = investigations[0]?.id ?? null;
  }

  async function loadReports() {
    if (!desktop()) return;
    reports = (await guarded(() => api.listReports(showAllReports ? undefined : (selectedId ?? undefined)), 'Отчёты')) ?? [];
  }

  $effect(() => {
    const id = selectedId;
    if (!id || !desktop()) {
      opts = null;
      optsFor = null;
      return;
    }
    let cancelled = false;
    opts = null;
    optsFor = null;
    loadingOpts = true;
    api
      .getReportOptions(id)
      .then((o) => {
        if (cancelled) return;
        // a stored draft never contains a section twice (keyed list in the editor)
        opts = { ...o, sections: [...new Set(o.sections)] };
        optsFor = id;
      })
      .catch((e) => !cancelled && app.error(e, 'Параметры отчёта'))
      .finally(() => !cancelled && (loadingOpts = false));
    return () => {
      cancelled = true;
    };
  });

  $effect(() => {
    void selectedId;
    void showAllReports;
    loadReports();
  });

  // autosave the draft
  const persist = debounce(async (id: string, o: ReportOptions) => {
    saving = true;
    await guarded(() => api.saveReportOptions(id, o), 'Черновик отчёта');
    saving = false;
  }, 700);

  $effect(() => {
    const o = opts;
    const id = optsFor;
    if (!o || !id) return;
    const snapshot = $state.snapshot(o) as ReportOptions;
    persist(id, snapshot);
  });

  function toggleSection(s: SectionId) {
    if (!opts) return;
    opts.sections = opts.sections.includes(s) ? opts.sections.filter((x) => x !== s) : [...opts.sections, s];
  }

  function move(s: SectionId, dir: -1 | 1) {
    if (!opts) return;
    const list = [...opts.sections];
    const i = list.indexOf(s);
    const j = i + dir;
    if (i < 0 || j < 0 || j >= list.length) return;
    [list[i], list[j]] = [list[j], list[i]];
    opts.sections = list;
  }

  function setNote(s: SectionId, v: string) {
    if (!opts) return;
    opts.notes = { ...opts.notes, [s]: v };
  }

  async function generate() {
    if (!opts || !optsFor) return;
    generating = true;
    const id = optsFor;
    const r = await guarded(() => api.generateReport(id, $state.snapshot(opts) as ReportOptions), 'Формирование PDF');
    generating = false;
    if (r) {
      app.toast('ok', `PDF готов: ${r.pages} стр., ${fmtBytes(r.bytes)} за ${fmtDuration(r.durationMs)}`, 6000);
      await loadReports();
    }
  }

  async function resetDefaults() {
    if (!opts || !app.settings) return;
    const d = app.settings.report;
    opts = {
      ...opts,
      title: null,
      sections: [...ALL_SECTIONS],
      notes: {},
      analystConclusion: '',
      theme: d.theme,
      accent: 'silver',
      paper: d.paper,
      author: d.author,
      organization: d.organization,
      classification: d.classification,
      maxFindingsPerCategory: 40,
      includeEdgeTable: true,
      includeSourceNodes: false,
    };
  }

  async function removeReport() {
    const r = deleteTarget;
    deleteOpen = false;
    if (!r) return;
    const ok = await guarded(() => api.deleteReport(r.id).then(() => true), 'Удаление отчёта');
    if (ok) await loadReports();
    deleteTarget = null;
  }

  async function saveAs(r: ReportRecord) {
    const p = await guarded(() => api.saveReportAs(r.id), 'Сохранение');
    if (p) app.toast('ok', `Сохранено: ${p}`, 6000);
  }

  onMount(loadInvestigations);
</script>

<div class="section-root studio enter">
  <div class="cols">
    <!-- investigations -->
    <Panel title="Исследование" subtitle="Источник данных отчёта" class="pick" pad={false}>
      <div class="pickbar"><input class="input" placeholder="Фильтр" bind:value={filter} /></div>
      <ul class="invs scroll">
        {#each shown as i (i.id)}
          <li>
            <button class:on={i.id === selectedId} onclick={() => (selectedId = i.id)}>
              <span class="iq">{truncate(i.query, 60)}</span>
              <span class="im">{i.kind === 'exposure_audit' ? 'Аудит' : 'Исследование'} · {STATUS_LABEL[i.status]} · {fmtNum(i.resultCount)} рез. · {fmtDateTime(i.createdAt)}</span>
            </button>
          </li>
        {:else}
          <li class="empty small">{desktop() ? 'Нет завершённых исследований.' : 'Доступно в настольном приложении.'}</li>
        {/each}
      </ul>
    </Panel>

    <!-- editor -->
    <Panel title="Редактор отчёта" subtitle={selected ? selected.query : 'Выберите исследование'} class="editor">
      {#snippet actions()}
        {#if saving}<span class="faint tiny">сохранение…</span>{:else if opts}<span class="faint tiny">черновик сохранён</span>{/if}
        <button class="btn sm ghost" onclick={resetDefaults} disabled={!opts}>Сбросить</button>
        <button class="btn sm primary" onclick={generate} disabled={!opts || generating || !opts.sections.length}>
          {#if generating}<Bits kind="spinner" />{:else}<Icon name="report" size={14} />{/if}Сформировать PDF
        </button>
      {/snippet}
      {#if loadingOpts && !opts}
        <div class="empty"><Bits kind="spinner" /></div>
      {:else if opts}
        <div class="ed">
          <div class="grid2">
            <div class="field"><label for="rt">Заголовок</label><input id="rt" class="input" placeholder={selected ? `Отчёт: ${selected.query}` : ''} value={opts.title ?? ''} oninput={(e) => opts && (opts.title = e.currentTarget.value || null)} /></div>
            <div class="field"><label for="rc">Гриф</label><input id="rc" class="input" bind:value={opts.classification} /></div>
            <div class="field"><label for="ra">Автор</label><input id="ra" class="input" bind:value={opts.author} /></div>
            <div class="field"><label for="ro">Организация</label><input id="ro" class="input" bind:value={opts.organization} /></div>
          </div>

          <span class="label">Оформление</span>
          <div class="looks">
            {#each THEMES as t (t.id)}
              <button class="look" class:on={opts.theme === t.id} onclick={() => opts && (opts.theme = t.id)} aria-pressed={opts.theme === t.id}>
                <span class="mini">
                  <span class="mc" style:background={t.cover}></span>
                  <span class="mp" style:background={t.page}><i style:background={t.text}></i><i style:background={t.text}></i><i style:background={t.text}></i></span>
                </span>
                <span>{t.label}</span>
              </button>
            {/each}
            <div class="col tight">
              <span class="tiny faint">Акцент</span>
              <Segmented size="sm" bind:value={opts.accent} options={(Object.keys(ACCENTS) as ReportOptions['accent'][]).map((k) => ({ value: k, label: ACCENTS[k].label }))} />
              <span class="tiny faint">Формат</span>
              <Segmented size="sm" bind:value={opts.paper} options={[{ value: 'a4', label: 'A4' }, { value: 'letter', label: 'Letter' }]} />
            </div>
          </div>

          <span class="label">Разделы · обложка всегда первая</span>
          <ul class="secs">
            {#each opts.sections as s, i (s)}
              <li class="on">
                <div class="srow">
                  <input type="checkbox" checked onchange={() => toggleSection(s)} aria-label="Включить раздел" />
                  <span class="sn">{i + 1}. {SECTION_META[s].title}</span>
                  <span class="sh">{SECTION_META[s].hint}</span>
                  <span class="spacer"></span>
                  {#if opts.notes[s]}<Icon name="tag" size={12} />{/if}
                  <button class="btn ghost sm icon" title="Заметка к разделу" onclick={() => (openNote = openNote === s ? null : s)}><Icon name="file" size={13} /></button>
                  <button class="btn ghost sm icon" title="Выше" onclick={() => move(s, -1)} disabled={i === 0}><Icon name="chevronUp" size={13} /></button>
                  <button class="btn ghost sm icon" title="Ниже" onclick={() => move(s, 1)} disabled={i === opts.sections.length - 1}><Icon name="chevronDown" size={13} /></button>
                </div>
                {#if openNote === s}
                  <textarea class="textarea" rows="3" placeholder="Заметка аналитика — будет выведена в начале раздела" value={opts.notes[s] ?? ''} oninput={(e) => setNote(s, e.currentTarget.value)}></textarea>
                {/if}
              </li>
            {/each}
            {#each disabledSections as s (s)}
              <li>
                <div class="srow">
                  <input type="checkbox" onchange={() => toggleSection(s)} aria-label="Включить раздел" />
                  <span class="sn off">{SECTION_META[s].title}</span>
                  <span class="sh">{SECTION_META[s].hint}</span>
                </div>
              </li>
            {/each}
          </ul>

          <div class="field">
            <label for="concl">Заключение аналитика</label>
            <textarea id="concl" class="textarea" rows="4" placeholder="Выводы аналитика (выводятся в аналитической сводке отдельно от автоматической сводки)" bind:value={opts.analystConclusion}></textarea>
          </div>

          <span class="label">Содержимое</span>
          <div class="row wrap">
            <div class="field narrow">
              <label for="mx">Результатов на категорию</label>
              <input id="mx" class="input" type="number" min="5" max="500" bind:value={opts.maxFindingsPerCategory} />
            </div>
            <Toggle bind:checked={opts.includeEdgeTable} label="Таблица происхождения связей" />
            <Toggle bind:checked={opts.includeSourceNodes} label="Источники как узлы схемы" />
          </div>
        </div>
      {:else}
        <div class="empty">Выберите исследование слева.</div>
      {/if}
    </Panel>

    <!-- preview & files -->
    <div class="right">
      <Panel title="Схема макета" subtitle="Порядок и оформление разделов" scroll={false}>
        {#if opts}
          <div class="pages">
            <div class="page cover" style:background={theme.cover} class:light={theme.cover === '#FFFFFF'}>
              <span class="pc-mark" style:color={theme.cover === '#FFFFFF' ? '#15181D' : '#F2F5F9'}>SWORD OSINT</span>
              <span class="pc-title" style:background={theme.cover === '#FFFFFF' ? '#15181D' : '#F2F5F9'}></span>
              <span class="pc-sub" style:background={accentOnPage}></span>
              <span class="pc-cls" style:color={theme.cover === '#FFFFFF' ? '#6A737E' : '#8E98A5'}>{truncate(opts.classification, 28)}</span>
            </div>
            {#each [opts.sections.slice(0, 4), opts.sections.slice(4)] as chunk, p (p)}
              {#if chunk.length}
                <div class="page" style:background={theme.page}>
                  {#each chunk as s (s)}
                    <span class="ph"><i style:background={accentOnPage}></i><b style:color={theme.text}>{SECTION_META[s].title}</b></span>
                    <span class="pl" style:background={theme.text}></span>
                    <span class="pl short" style:background={theme.text}></span>
                  {/each}
                </div>
              {/if}
            {/each}
          </div>
          <p class="help">Схематичное представление. Точный результат — векторный PDF со встроенными шрифтами, оглавлением и кликабельными ссылками.</p>
        {:else}
          <div class="empty small">Нет выбранного исследования.</div>
        {/if}
      </Panel>

      <Panel title="Готовые отчёты" class="files" pad={false}>
        {#snippet actions()}
          <Toggle bind:checked={showAllReports} label="все" />
        {/snippet}
        <ul class="reps scroll">
          {#each reports as r (r.id)}
            <li>
              <div class="rt">
                <span class="rn" title={r.path}>{r.title}</span>
                <span class="rm">{fmtDateTime(r.createdAt)} · {r.pages} стр. · {fmtBytes(r.bytes)}{r.exists ? '' : ' · файл удалён с диска'}</span>
              </div>
              <div class="ra">
                <button class="btn ghost sm icon" title="Открыть" disabled={!r.exists} onclick={() => guarded(() => api.openReport(r.id), 'Открытие')}><Icon name="external" size={13} /></button>
                <button class="btn ghost sm icon" title="Показать в папке" disabled={!r.exists} onclick={() => guarded(() => api.revealReport(r.id), 'Папка')}><Icon name="folder" size={13} /></button>
                <button class="btn ghost sm icon" title="Сохранить как…" disabled={!r.exists} onclick={() => saveAs(r)}><Icon name="download" size={13} /></button>
                <button class="btn ghost sm icon" title="Удалить" onclick={() => ((deleteTarget = r), (deleteOpen = true))}><Icon name="trash" size={13} /></button>
              </div>
            </li>
          {:else}
            <li class="empty small">Отчётов пока нет.</li>
          {/each}
        </ul>
      </Panel>
    </div>
  </div>
</div>

<Modal bind:open={deleteOpen} title="Удалить отчёт" onclose={() => (deleteTarget = null)}>
  <p class="muted">Удалить «{deleteTarget?.title}» из списка и PDF-файл с диска?</p>
  {#snippet footer()}
    <button class="btn sm ghost" onclick={() => (deleteOpen = false)}>Отмена</button>
    <button class="btn sm danger" onclick={removeReport}><Icon name="trash" size={13} />Удалить</button>
  {/snippet}
</Modal>

<style>
  .cols {
    flex: 1;
    min-height: 0;
    display: grid;
    grid-template-columns: 300px minmax(440px, 1fr) 380px;
    gap: 14px;
  }
  .pickbar {
    padding: 10px 12px;
    border-bottom: 1px solid var(--line);
  }
  .invs {
    list-style: none;
    margin: 0;
    padding: 6px;
    flex: 1;
  }
  .invs button {
    width: 100%;
    display: flex;
    flex-direction: column;
    align-items: stretch;
    gap: 2px;
    padding: 8px 10px;
    border: 1px solid transparent;
    border-radius: 9px;
    background: none;
    text-align: left;
    cursor: pointer;
  }
  .invs button:hover {
    background: rgba(255, 255, 255, 0.035);
  }
  .invs button.on {
    border-color: var(--line-strong);
    background: rgba(200, 215, 235, 0.07);
  }
  .iq {
    font-size: 12.5px;
    color: var(--fg);
  }
  .im {
    font-size: 10.5px;
    color: var(--fg-3);
  }
  .ed {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  .grid2 {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 10px 12px;
  }
  .looks {
    display: flex;
    gap: 10px;
    align-items: stretch;
  }
  .look {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 6px;
    padding: 8px;
    border-radius: 10px;
    border: 1px solid var(--line);
    background: rgba(255, 255, 255, 0.02);
    color: var(--fg-2);
    font-size: 11.5px;
    cursor: pointer;
  }
  .look.on {
    border-color: rgba(230, 238, 250, 0.45);
    color: #fff;
    box-shadow: 0 0 16px rgba(220, 232, 248, 0.12);
  }
  .mini {
    display: flex;
    gap: 4px;
  }
  .mc,
  .mp {
    width: 34px;
    height: 46px;
    border-radius: 3px;
    border: 1px solid rgba(255, 255, 255, 0.12);
  }
  .mp {
    display: flex;
    flex-direction: column;
    gap: 4px;
    padding: 6px 5px;
  }
  .mp i {
    height: 2px;
    border-radius: 2px;
    opacity: 0.55;
  }
  .tight {
    gap: 5px;
    justify-content: center;
  }
  .secs {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 4px;
  }
  .secs li {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding: 4px 6px;
    border-radius: 9px;
    border: 1px solid var(--line);
  }
  .secs li:not(.on) {
    border-style: dashed;
    opacity: 0.7;
  }
  .srow {
    display: flex;
    align-items: center;
    gap: 9px;
    min-height: 30px;
  }
  .srow input {
    accent-color: #e9eef6;
  }
  .sn {
    font-size: 12.5px;
    color: var(--fg);
    white-space: nowrap;
  }
  .sn.off {
    color: var(--fg-3);
  }
  .sh {
    font-size: 11px;
    color: var(--fg-3);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    min-width: 0;
  }
  .narrow {
    width: 200px;
  }
  .right {
    display: flex;
    flex-direction: column;
    gap: 14px;
    min-height: 0;
  }
  .right :global(.files) {
    flex: 1;
  }
  .pages {
    display: flex;
    gap: 10px;
    justify-content: center;
    padding: 4px 0 10px;
  }
  .page {
    width: 96px;
    height: 136px;
    border-radius: 4px;
    padding: 10px 8px;
    display: flex;
    flex-direction: column;
    gap: 4px;
    box-shadow: 0 8px 26px rgba(0, 0, 0, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.08);
    overflow: hidden;
  }
  .cover {
    justify-content: flex-end;
    gap: 6px;
  }
  .pc-mark {
    font-family: var(--font-display);
    font-size: 5px;
    letter-spacing: 0.3em;
    margin-bottom: auto;
  }
  .pc-title {
    height: 5px;
    width: 80%;
    border-radius: 2px;
  }
  .pc-sub {
    height: 2px;
    width: 50%;
    border-radius: 2px;
  }
  .pc-cls {
    font-size: 5px;
  }
  .ph {
    display: flex;
    align-items: center;
    gap: 3px;
    margin-top: 4px;
  }
  .ph i {
    width: 2px;
    height: 7px;
  }
  .ph b {
    font-size: 5.5px;
    font-weight: 600;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .pl {
    height: 1.5px;
    opacity: 0.25;
    border-radius: 2px;
  }
  .pl.short {
    width: 70%;
  }
  .help {
    margin: 0;
  }
  .reps {
    list-style: none;
    margin: 0;
    padding: 6px;
    flex: 1;
  }
  .reps li {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px;
    border-bottom: 1px solid rgba(255, 255, 255, 0.04);
  }
  .rt {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 2px;
  }
  .rn {
    font-size: 12.5px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .rm {
    font-size: 10.5px;
    color: var(--fg-3);
  }
  .ra {
    display: flex;
    gap: 2px;
  }
</style>
