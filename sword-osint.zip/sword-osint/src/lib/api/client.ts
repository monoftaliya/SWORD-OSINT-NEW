/**
 * Typed command client. Every call goes through `call()`, which normalises errors to
 * `ApiError` and reports a clear «backend unavailable» error when the UI runs outside
 * the desktop shell (e.g. `npm run dev` in a plain browser).
 */
import { invoke, isTauri } from '@tauri-apps/api/core';
import type {
  AdapterStatus,
  AdapterView,
  AnalyticsReport,
  ApiError,
  AppInfo,
  AppSettings,
  Asset,
  AssetKind,
  AuditCheck,
  ClassifiedInput,
  Comparison,
  CredentialState,
  DbStats,
  Finding,
  Graph,
  GraphScope,
  HistoryPage,
  HistoryQuery,
  InvestigationDetail,
  InvestigationRequest,
  KnowledgeHit,
  KnowledgeQuery,
  MetricSample,
  PasswordExposure,
  PlannedAdapter,
  ReportOptions,
  ReportRecord,
} from './types';

export const desktop = (): boolean => {
  try {
    return isTauri();
  } catch {
    return false;
  }
};

export function toApiError(e: unknown): ApiError {
  if (e && typeof e === 'object' && 'message' in e && 'kind' in e) return e as ApiError;
  if (typeof e === 'string') return { kind: 'internal', message: e };
  if (e instanceof Error) return { kind: 'internal', message: e.message };
  return { kind: 'internal', message: 'Неизвестная ошибка' };
}

async function call<T>(cmd: string, args?: Record<string, unknown>): Promise<T> {
  if (!desktop()) {
    throw { kind: 'internal', message: 'Бэкенд SWORD OSINT недоступен: интерфейс запущен вне настольного приложения.' } satisfies ApiError;
  }
  try {
    return await invoke<T>(cmd, args);
  } catch (e) {
    throw toApiError(e);
  }
}

export const api = {
  // system
  appInfo: () => call<AppInfo>('app_info'),
  getSettings: () => call<AppSettings>('get_settings'),
  saveSettings: (settings: AppSettings) => call<AppSettings>('save_settings', { settings }),
  recordMetrics: (samples: MetricSample[]) => call<void>('record_metrics', { samples }),
  openExternal: (url: string) => call<void>('open_external', { url }),
  openPath: (path: string) => call<void>('open_path', { path }),
  revealPath: (path: string) => call<void>('reveal_path', { path }),
  openDataDir: () => call<void>('open_data_dir'),
  openLogsDir: () => call<void>('open_logs_dir'),

  // connectors
  listAdapters: () => call<AdapterView[]>('list_adapters'),
  checkAdapter: (id: string) => call<AdapterStatus>('check_adapter', { id }),
  checkAllAdapters: () => call<AdapterStatus[]>('check_all_adapters'),
  setAdapterEnabled: (id: string, enabled: boolean) => call<AdapterView>('set_adapter_enabled', { id, enabled }),
  setAdapterOption: (id: string, key: string, value: string) => call<AdapterView>('set_adapter_option', { id, key, value }),
  setCredential: (key: string, value: string) => call<CredentialState>('set_credential', { key, value }),
  deleteCredential: (key: string) => call<void>('delete_credential', { key }),

  // discovery
  classifyQuery: (query: string) => call<ClassifiedInput>('classify_query', { query }),
  planInvestigation: (request: InvestigationRequest) => call<PlannedAdapter[]>('plan_investigation', { request }),
  startInvestigation: (request: InvestigationRequest) => call<string>('start_investigation', { request }),
  cancelInvestigation: (id: string) => call<boolean>('cancel_investigation', { id }),
  runningInvestigations: () => call<string[]>('running_investigations'),

  // history
  listHistory: (query: HistoryQuery) => call<HistoryPage>('list_history', { query }),
  getInvestigation: (id: string) => call<InvestigationDetail>('get_investigation', { id }),
  deleteInvestigations: (ids: string[]) => call<number>('delete_investigations', { ids }),
  compareInvestigations: (a: string, b: string) => call<Comparison>('compare_investigations', { a, b }),
  updateNotes: (id: string, notes: string) => call<void>('update_notes', { id, notes }),
  exportInvestigation: (id: string, format: 'json' | 'csv' | 'md') => call<string | null>('export_investigation', { id, format }),
  searchKnowledge: (query: KnowledgeQuery) => call<KnowledgeHit[]>('search_knowledge', { query }),

  // graph
  getGraph: (scope: GraphScope) => call<Graph>('get_graph', { scope }),
  exportGraph: (scope: GraphScope, format: 'json' | 'graphml' | 'gexf') => call<string | null>('export_graph', { scope, format }),
  saveImage: (dataUrl: string, suggestedName: string) => call<string | null>('save_image', { dataUrl, suggestedName }),

  // intelligence
  listAssets: () => call<Asset[]>('list_assets'),
  addAsset: (asset: { kind: AssetKind; value: string; attested: boolean }) => call<Asset>('add_asset', { asset }),
  removeAsset: (id: string) => call<void>('remove_asset', { id }),
  verifyAsset: (id: string) => call<Asset>('verify_asset', { id }),
  pickFolder: () => call<string | null>('pick_folder'),
  startAudit: (request: { assetIds: string[]; checks: AuditCheck[] }) => call<string>('start_audit', { request }),
  checkPassword: (password: string) => call<PasswordExposure>('check_password', { password }),
  scanText: (text: string, label?: string) => call<Finding[]>('scan_text', { text, label: label ?? null }),
  scanUrl: (url: string) => call<Finding[]>('scan_url', { url }),

  // analytics
  getAnalytics: (rangeDays: number) => call<AnalyticsReport>('get_analytics', { rangeDays }),

  // reports
  getReportOptions: (investigationId: string) => call<ReportOptions>('get_report_options', { investigationId }),
  saveReportOptions: (investigationId: string, options: ReportOptions) => call<void>('save_report_options', { investigationId, options }),
  generateReport: (investigationId: string, options: ReportOptions) => call<ReportRecord>('generate_report', { investigationId, options }),
  listReports: (investigationId?: string) => call<ReportRecord[]>('list_reports', { investigationId: investigationId ?? null }),
  openReport: (id: string) => call<void>('open_report', { id }),
  revealReport: (id: string) => call<void>('reveal_report', { id }),
  saveReportAs: (id: string) => call<string | null>('save_report_as', { id }),
  deleteReport: (id: string) => call<void>('delete_report', { id }),

  // databases
  dbStats: () => call<DbStats>('db_stats'),
  dbIntegrityCheck: () => call<string[]>('db_integrity_check'),
  dbVacuum: () => call<DbStats>('db_vacuum'),
  dbBackup: () => call<string | null>('db_backup'),
  dbExportAll: () => call<string | null>('db_export_all'),
  dbPurge: (olderThanDays: number) => call<number>('db_purge', { olderThanDays }),
  dbClearHistory: () => call<void>('db_clear_history'),
  opensearchTest: () => call<string>('opensearch_test'),
  opensearchReindex: () => call<number>('opensearch_reindex'),
};
