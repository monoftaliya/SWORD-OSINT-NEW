<!--
  HISTORY — every investigation and audit stored in SQLite: full-text search, filters,
  sorting, reopening, comparison of two runs, notes, export and deletion.
-->
<script lang="ts">
  import { onMount } from 'svelte';
  import Icon from '../lib/components/Icon.svelte';
  import Bits from '../lib/components/Bits.svelte';
  import Panel from '../lib/components/Panel.svelte';
  import Modal from '../lib/components/Modal.svelte';
  import { api, desktop } from '../lib/api/client';
  import type { Comparison, FindingBrief, HistoryQuery, InvestigationDetail, InvestigationRecord } from '../lib/api/types';
  import { app } from '../lib/stores/app.svelte';
  import { run } from '../lib/stores/run.svelte';
  import { ui } from '../lib/stores/ui.svelte';
  import { CATEGORIES, FINDING_KIND_LABEL, INPUT_KIND_LABEL, RUN_STATUS_LABEL, STATUS_LABEL, categoryMeta } from '../lib/util/labels';
  import { debounce, fmtDateTime, fmtDuration, fmtNum, hostOf, plural, truncate } from '../lib/util/format';
  import { guarded, openLink } from '../lib/components/ui';

  let items = $state<InvestigationRecord[]>([]);
  let total = $state(0);
  let loading = $state(false);
  let checked = $state<string[]>([]);
  let detail = $state<InvestigationDetail | null>(null);
  let notes = $state('');
  let notesDirty = $state(false);
  let confirmDelete = $state<string[] | null>(null);
  let deleteOpen = $state(false);
  let comparison = $state<Comparison | null>(null);
  let compareOpen = $state(false);
  let searchText = $state(ui.history.search ?? '');

  const q = $derived(ui.history);
  const page = $derived(Math.floor((q.offset ?? 0) / (q.limit ?? 40)) + 1);
  const pages = $derived(Math.max(1, Math.ceil(total / (q.limit ?? 40))));

  function clean(h: HistoryQuery): HistoryQuery {
    const out: HistoryQuery = { sort: h.sort, limit: h.limit, offset: h.offset };
    for (const k of ['search', 'status', 'kind', 'category', 'adapter', 'from', 'to'] as const) {
      const v = h[k];
      if (typeof v === 'string' && v.trim()) out[k] = v.trim();
    }
    return out;
  }

  async function load() {
    if (!desktop()) return;
    loading = true;
    const res = await guarded(() => api.listHistory(clean(ui.history)), 'История');
    loading = false;
    if (!res) return;
    items = res.items;
    total = res.total;
    checked = checked.filter((id) => res.items.some((i) => i.id === id));
  }

  $effect(() => {
    void JSON.stringify(ui.history);
    load();
  });

  const setSearch = debounce((s: string) => (ui.history = { ...ui.history, search: s, offset: 0 }), 300);

  function patch(p: Partial<HistoryQuery>) {
    ui.history = { ...ui.history, ...p, offset: 0 };
  }

  function sortBy(field: 'created' | 'results' | 'duration' | 'query' | 'sources') {
    const cur = ui.history.sort ?? 'created_desc';
    const next: Record<string, HistoryQuery['sort']> = {
      created: cur === 'created_desc' ? 'created_asc' : 'created_desc',
      results: cur === 'results_desc' ? 'results_asc' : 'results_desc',
      duration: 'duration_desc',
      query: 'query_asc',
      sources: 'sources_desc',
    };
    patch({ sort: next[field] });
  }

  function sortMark(field: string) {
    const s = ui.history.sort ?? 'created_desc';
    if (!s.startsWith(field)) return '';
    return s.endsWith('asc') ? '↑' : '↓';
  }

  async function openDetail(r: InvestigationRecord) {
    if (detail?.record.id === r.id) {
      detail = null;
      return;
    }
    const d = await guarded(() => api.getInvestigation(r.id), 'Исследование');
    if (d) {
      detail = d;
      notes = d.record.notes;
      notesDirty = false;
    }
  }

  async function saveNotes() {
    if (!detail) return;
    const id = detail.record.id;
    const ok = await guarded(() => api.updateNotes(id, notes).then(() => true), 'Заметки');
    if (ok) {
      notesDirty = false;
      app.toast('ok', 'Заметки сохранены', 2000);
      items = items.map((i) => (i.id === id ? { ...i, notes } : i));
    }
  }

  async function exportAs(id: string, format: 'json' | 'csv' | 'md') {
    const p = await guarded(() => api.exportInvestigation(id, format), 'Экспорт');
    if (p) app.toast('ok', `Сохранено: ${p}`, 6000);
  }

  function askDelete(ids: string[]) {
    confirmDelete = ids;
    deleteOpen = true;
  }

  async function doDelete() {
    const ids = confirmDelete ?? [];
    deleteOpen = false;
    const n = await guarded(() => api.deleteInvestigations(ids), 'Удаление');
    if (n !== null) {
      app.toast('ok', `Удалено: ${n}`);
      if (detail && ids.includes(detail.record.id)) detail = null;
      if (run.discovery && ids.includes(run.discovery.id) && !run.discovery.live) run.clearDiscovery();
      checked = checked.filter((id) => !ids.includes(id));
      load();
    }
    confirmDelete = null;
  }

  async function compare() {
    if (checked.length !== 2) return;
    const c = await guarded(() => api.compareInvestigations(checked[0], checked[1]), 'Сравнение');
    if (c) {
      comparison = c;
      compareOpen = true;
    }
  }

  function toggleCheck(id: string) {
    checked = checked.includes(id) ? checked.filter((x) => x !== id) : [...checked, id];
  }

  function statusTone(s: InvestigationRecord['status']): 'ok' | 'warn' | 'err' | 'idle' | 'live' {
    return s === 'completed' ? 'ok' : s === 'partial' ? 'warn' : s === 'failed' ? 'err' : s === 'running' ? 'live' : 'idle';
  }

  onMount(() => {
    if (desktop() && !app.adapters.length) app.refreshAdapters();
  });
</script>

{#snippet briefs(list: FindingBrief[], empty: string)}
  {#if list.length === 0}
    <span class="faint small">{empty}</span>
  {:else}
    <ul class="briefs">
      {#each list.slice(0, 60) as b, i (i)}
        <li>
          <span class="bk">{FINDING_KIND_LABEL[b.kind]}</span>
          {#if b.url}
            <button class="lnk" onclick={() => openLink(b.url)} title={b.url}>{truncate(b.title, 70)}</button>
          {:else}
            <span>{truncate(b.title, 70)}</span>
          {/if}
        </li>
      {/each}
      {#if list.length > 60}<li class="faint">и ещё {list.length - 60}</li>{/if}
    </ul>
  {/if}
{/snippet}

<div class="section-root hist enter">
  <div class="bar glass">
    <Icon name="search" size={16} />
    <input
      class="input q"
      placeholder="Поиск по запросам, сводкам и заметкам"
      bind:value={searchText}
      oninput={() => setSearch(searchText)}
    />
    <select class="select" value={q.kind ?? ''} onchange={(e) => patch({ kind: e.currentTarget.value })} aria-label="Тип">
      <option value="">все типы</option>
      <option value="discovery">исследования</option>
      <option value="exposure_audit">аудиты</option>
    </select>
    <select class="select" value={q.status ?? ''} onchange={(e) => patch({ status: e.currentTarget.value })} aria-label="Статус">
      <option value="">любой статус</option>
      {#each Object.entries(STATUS_LABEL) as [k, l] (k)}<option value={k}>{l}</option>{/each}
    </select>
    <select class="select" value={q.category ?? ''} onchange={(e) => patch({ category: e.currentTarget.value })} aria-label="Категория">
      <option value="">все категории</option>
      {#each CATEGORIES as c (c.id)}<option value={c.id}>{c.label}</option>{/each}
    </select>
    <select class="select" value={q.adapter ?? ''} onchange={(e) => patch({ adapter: e.currentTarget.value })} aria-label="Источник">
      <option value="">все источники</option>
      {#each app.adapters as a (a.info.id)}<option value={a.info.id}>{a.info.name}</option>{/each}
    </select>
    <input class="input date" type="date" value={q.from ?? ''} onchange={(e) => patch({ from: e.currentTarget.value })} aria-label="С даты" />
    <input class="input date" type="date" value={q.to ?? ''} onchange={(e) => patch({ to: e.currentTarget.value })} aria-label="По дату" />
    {#if loading}<Bits kind="spinner" />{/if}
  </div>

  <div class="main">
    <Panel title="Исследования и аудиты" subtitle={plural(total, 'запись', 'записи', 'записей')} pad={false} class="tablepanel">
      {#snippet actions()}
        {#if checked.length}
          <span class="faint small">выбрано {checked.length}</span>
          <button class="btn sm" onclick={compare} disabled={checked.length !== 2} title="Выберите ровно два"><Icon name="compare" size={13} />Сравнить</button>
          <button class="btn sm danger" onclick={() => askDelete(checked)}><Icon name="trash" size={13} />Удалить</button>
        {/if}
      {/snippet}
      <div class="tablewrap scroll">
        <table class="table">
          <thead>
            <tr>
              <th class="cb"></th>
              <th><button class="sort" onclick={() => sortBy('query')}>Запрос {sortMark('query')}</button></th>
              <th>Статус</th>
              <th>Категории</th>
              <th class="r"><button class="sort" onclick={() => sortBy('results')}>Результаты {sortMark('results')}</button></th>
              <th class="r"><button class="sort" onclick={() => sortBy('sources')}>Ссылки {sortMark('sources')}</button></th>
              <th class="r"><button class="sort" onclick={() => sortBy('duration')}>Время {sortMark('duration')}</button></th>
              <th><button class="sort" onclick={() => sortBy('created')}>Дата {sortMark('created')}</button></th>
            </tr>
          </thead>
          <tbody>
            {#each items as r (r.id)}
              <tr class="clickable" class:selected={detail?.record.id === r.id} onclick={() => openDetail(r)}>
                <td class="cb" onclick={(e) => e.stopPropagation()}>
                  <input type="checkbox" checked={checked.includes(r.id)} onchange={() => toggleCheck(r.id)} aria-label="Выбрать" />
                </td>
                <td>
                  <div class="qcell">
                    <span class="qq">{r.query}</span>
                    <span class="qk">{r.kind === 'exposure_audit' ? 'аудит' : INPUT_KIND_LABEL[r.inputKind]}{r.notes ? ' · есть заметки' : ''}</span>
                  </div>
                </td>
                <td><span class="st"><Bits kind="dot" tone={statusTone(r.status)} />{STATUS_LABEL[r.status]}</span></td>
                <td class="cats">{r.categories.map((c) => categoryMeta(c).short).join(' · ')}</td>
                <td class="r num">{fmtNum(r.resultCount)}</td>
                <td class="r num">{fmtNum(r.sourceCount)}</td>
                <td class="r num">{fmtDuration(r.durationMs)}</td>
                <td class="nowrap faint">{fmtDateTime(r.createdAt)}</td>
              </tr>
            {:else}
              <tr><td colspan="8"><div class="empty small">{desktop() ? (loading ? 'Загрузка…' : 'Записей нет. Запущенные исследования и аудиты появятся здесь автоматически.') : 'История доступна в настольном приложении.'}</div></td></tr>
            {/each}
          </tbody>
        </table>
      </div>
      {#snippet footer()}
        <span class="faint small">Страница {page} из {pages}</span>
        <span class="spacer"></span>
        <button class="btn sm ghost" disabled={page <= 1} onclick={() => (ui.history = { ...ui.history, offset: Math.max(0, (q.offset ?? 0) - (q.limit ?? 40)) })}>← Назад</button>
        <button class="btn sm ghost" disabled={page >= pages} onclick={() => (ui.history = { ...ui.history, offset: (q.offset ?? 0) + (q.limit ?? 40) })}>Вперёд →</button>
      {/snippet}
    </Panel>

    {#if detail}
      {@const r = detail.record}
      <Panel title={r.kind === 'exposure_audit' ? 'Аудит' : 'Исследование'} subtitle={fmtDateTime(r.createdAt)} class="detail enter">
        {#snippet actions()}
          <button class="btn sm ghost icon" onclick={() => (detail = null)} aria-label="Закрыть"><Icon name="x" size={14} /></button>
        {/snippet}
        <div class="col">
          <h3>{r.query}</h3>
          <div class="row wrap">
            <span class="chip"><Bits kind="dot" tone={statusTone(r.status)} />{STATUS_LABEL[r.status]}</span>
            <span class="chip">{fmtNum(r.resultCount)} результатов</span>
            <span class="chip">{fmtNum(r.sourceCount)} ссылок</span>
            <span class="chip">{fmtNum(r.nodeCount)} объектов · {fmtNum(r.edgeCount)} связей</span>
            <span class="chip">{fmtDuration(r.durationMs)}</span>
          </div>
          {#if r.error}<p class="err">{r.error}</p>{/if}
          <div class="row wrap">
            <button class="btn sm primary" onclick={() => run.open(r.id)}><Icon name="eye" size={13} />Открыть</button>
            {#if r.kind === 'discovery'}
              <button class="btn sm" onclick={() => { ui.networkMode = 'investigation'; app.navigate('network', r.id); }} disabled={r.nodeCount === 0}><Icon name="network" size={13} />Граф</button>
            {/if}
            <button class="btn sm" onclick={() => app.navigate('report', r.id)}><Icon name="report" size={13} />Отчёт</button>
            <button class="btn sm ghost" onclick={() => exportAs(r.id, 'json')}>JSON</button>
            <button class="btn sm ghost" onclick={() => exportAs(r.id, 'csv')}>CSV</button>
            <button class="btn sm ghost" onclick={() => exportAs(r.id, 'md')}>MD</button>
            <button class="btn sm danger icon" title="Удалить" onclick={() => askDelete([r.id])}><Icon name="trash" size={13} /></button>
          </div>

          {#if r.summary}
            <span class="eyebrow">Сводка</span>
            {#each r.summary.split('\n').filter((l) => l.trim()) as p, i (i)}<p class="sum">{p}</p>{/each}
          {/if}

          <span class="eyebrow">Заметки аналитика</span>
          <textarea class="textarea" rows="4" bind:value={notes} oninput={() => (notesDirty = true)} placeholder="Выводы, контекст, следующие шаги…"></textarea>
          <button class="btn sm" onclick={saveNotes} disabled={!notesDirty}>Сохранить заметки</button>

          <span class="eyebrow">Источники</span>
          <table class="table mini">
            <tbody>
              {#each detail.runs as x (x.adapterId)}
                <tr>
                  <td>{x.adapterName}</td>
                  <td class="faint">{RUN_STATUS_LABEL[x.status]}</td>
                  <td class="r num">{x.status === 'done' ? fmtNum(x.resultCount) : ''}</td>
                  <td class="r num faint">{fmtDuration(x.durationMs)}</td>
                </tr>
              {/each}
            </tbody>
          </table>

          {#if r.limitations.length}
            <span class="eyebrow">Ограничения</span>
            <ul class="lim">{#each r.limitations as l, i (i)}<li>{l}</li>{/each}</ul>
          {/if}
        </div>
      </Panel>
    {/if}
  </div>
</div>

<Modal bind:open={deleteOpen} title="Удаление" onclose={() => (confirmDelete = null)}>
  <p class="muted">Удалить {plural(confirmDelete?.length ?? 0, 'запись', 'записи', 'записей')} вместе с результатами, графом и черновиками отчётов? Сформированные PDF-файлы останутся на диске.</p>
  {#snippet footer()}
    <button class="btn sm ghost" onclick={() => (deleteOpen = false)}>Отмена</button>
    <button class="btn sm danger" onclick={doDelete}><Icon name="trash" size={13} />Удалить</button>
  {/snippet}
</Modal>

<Modal bind:open={compareOpen} title="Сравнение" width={980}>
  {#if comparison}
    {@const c = comparison}
    <div class="cmp">
      <div class="cmphead">
        <div><span class="eyebrow">A</span><b>{c.a.query}</b><span class="faint small">{fmtDateTime(c.a.createdAt)} · {fmtNum(c.a.resultCount)} результатов</span></div>
        <div><span class="eyebrow">B</span><b>{c.b.query}</b><span class="faint small">{fmtDateTime(c.b.createdAt)} · {fmtNum(c.b.resultCount)} результатов</span></div>
      </div>
      <div class="cmpstats">
        <span>Общие первоисточники: <b class="num">{c.commonSources.length}</b></span>
        <span>Только в A: <b class="num">{c.onlyASources.length}</b></span>
        <span>Только в B: <b class="num">{c.onlyBSources.length}</b></span>
        <span>Общие объекты графа: <b class="num">{c.commonEntities.length}</b></span>
      </div>
      <div class="cmpcols">
        <div><span class="label">Только в A</span>{@render briefs(c.onlyAFindings, 'нет')}</div>
        <div><span class="label">Общие результаты</span>{@render briefs(c.commonFindings, 'нет')}</div>
        <div><span class="label">Только в B</span>{@render briefs(c.onlyBFindings, 'нет')}</div>
      </div>
      <span class="label">Объекты графа</span>
      <div class="cmpcols">
        <div>{#each c.onlyAEntities.slice(0, 40) as e (e)}<span class="ent mono">{e}</span>{:else}<span class="faint small">нет</span>{/each}</div>
        <div>{#each c.commonEntities.slice(0, 40) as e (e)}<span class="ent mono">{e}</span>{:else}<span class="faint small">нет</span>{/each}</div>
        <div>{#each c.onlyBEntities.slice(0, 40) as e (e)}<span class="ent mono">{e}</span>{:else}<span class="faint small">нет</span>{/each}</div>
      </div>
      <span class="label">Источники</span>
      <table class="table mini">
        <thead><tr><th>Источник</th><th>A</th><th class="r">A</th><th>B</th><th class="r">B</th></tr></thead>
        <tbody>
          {#each c.adapters as d (d.adapterId)}
            <tr>
              <td>{d.adapterName}</td>
              <td class="faint">{d.aStatus ? RUN_STATUS_LABEL[d.aStatus] : '—'}</td>
              <td class="r num">{d.aResults ?? '—'}</td>
              <td class="faint">{d.bStatus ? RUN_STATUS_LABEL[d.bStatus] : '—'}</td>
              <td class="r num">{d.bResults ?? '—'}</td>
            </tr>
          {/each}
        </tbody>
      </table>
      {#if c.commonSources.length}
        <span class="label">Общие первоисточники</span>
        <div class="srcs">
          {#each c.commonSources.slice(0, 40) as s (s)}<button class="lnk" onclick={() => openLink(s)}>{hostOf(s)} — {truncate(s, 80)}</button>{/each}
        </div>
      {/if}
    </div>
  {/if}
  {#snippet footer()}
    <button class="btn sm" onclick={() => (compareOpen = false)}>Закрыть</button>
  {/snippet}
</Modal>

<style>
  .bar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 8px 10px 8px 16px;
    color: var(--fg-3);
  }
  .bar .q {
    flex: 1;
    min-width: 200px;
  }
  .bar .select {
    width: 150px;
    flex: none;
  }
  .bar .date {
    width: 140px;
    flex: none;
    color-scheme: dark;
  }
  .main {
    flex: 1;
    min-height: 0;
    display: flex;
    gap: 14px;
  }
  .main :global(.tablepanel) {
    flex: 1;
  }
  .main :global(.detail) {
    width: 420px;
    flex: none;
  }
  .tablewrap {
    flex: 1;
  }
  .cb {
    width: 34px;
  }
  .cb input,
  td input {
    accent-color: #e9eef6;
  }
  .sort {
    border: none;
    background: none;
    padding: 0;
    color: inherit;
    font: inherit;
    letter-spacing: inherit;
    text-transform: inherit;
    cursor: pointer;
  }
  .sort:hover {
    color: #fff;
  }
  .r {
    text-align: right;
  }
  .qcell {
    display: flex;
    flex-direction: column;
    gap: 1px;
    max-width: 380px;
  }
  .qq {
    color: var(--fg);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .qk {
    font-size: 11px;
    color: var(--fg-3);
  }
  .st {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    white-space: nowrap;
    font-size: 12px;
  }
  .cats {
    font-family: var(--font-display);
    font-size: 8.5px;
    letter-spacing: 0.16em;
    color: var(--fg-3);
    max-width: 220px;
  }
  h3 {
    margin: 0;
    font-size: 15px;
    font-weight: 500;
    color: #fff;
    word-break: break-word;
    user-select: text;
  }
  .err {
    margin: 0;
    color: var(--err);
    font-size: 12px;
  }
  .sum {
    margin: 0;
    font-size: 12px;
    line-height: 1.55;
    color: var(--fg-2);
    user-select: text;
  }
  .mini td {
    padding: 5px 6px;
    font-size: 12px;
  }
  .lim {
    margin: 0;
    padding-left: 16px;
    font-size: 12px;
    color: var(--fg-2);
  }
  .cmp {
    display: flex;
    flex-direction: column;
    gap: 12px;
  }
  .cmphead {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 14px;
  }
  .cmphead > div {
    display: flex;
    flex-direction: column;
    gap: 3px;
    padding: 10px 12px;
    border: 1px solid var(--line);
    border-radius: 10px;
  }
  .cmphead b {
    font-weight: 500;
    color: #fff;
  }
  .cmpstats {
    display: flex;
    flex-wrap: wrap;
    gap: 18px;
    font-size: 12px;
    color: var(--fg-2);
  }
  .cmpstats b {
    color: #fff;
  }
  .cmpcols {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 14px;
  }
  .cmpcols > div {
    display: flex;
    flex-direction: column;
    gap: 6px;
    min-width: 0;
  }
  .briefs {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 4px;
    font-size: 11.5px;
  }
  .briefs li {
    display: flex;
    flex-direction: column;
  }
  .bk {
    font-size: 10px;
    color: var(--fg-4);
  }
  .lnk {
    border: none;
    background: none;
    padding: 0;
    text-align: left;
    color: var(--fg-2);
    font-size: 11.5px;
    cursor: pointer;
  }
  .lnk:hover {
    color: #fff;
  }
  .ent {
    font-size: 10.5px;
    color: var(--fg-2);
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .srcs {
    display: flex;
    flex-direction: column;
    gap: 3px;
  }
</style>
