/**
 * Layout worker: runs the 3D force simulation off the main thread and streams node
 * positions back (~30 updates per second) until the layout has cooled down.
 */
import { ForceLayout3D, type LayoutGraph } from './force3d';

export type LayoutRequest =
  | ({ type: 'start'; epoch: number } & LayoutGraph)
  | { type: 'reheat'; alpha: number }
  | { type: 'stop' };

export type LayoutResponse = { type: 'tick'; epoch: number; positions: Float32Array; alpha: number; done: boolean };

let sim: ForceLayout3D | null = null;
let epoch = 0;
let timer: ReturnType<typeof setTimeout> | null = null;

function loop() {
  timer = null;
  const s = sim;
  if (!s) return;
  const t0 = performance.now();
  // simulate for up to ~12 ms per batch, then publish a snapshot
  do {
    s.tick();
  } while (!s.done && performance.now() - t0 < 12);
  const positions = s.pos.slice();
  const msg: LayoutResponse = { type: 'tick', epoch, positions, alpha: s.alpha, done: s.done };
  (self as unknown as { postMessage(m: LayoutResponse, transfer: Transferable[]): void }).postMessage(msg, [positions.buffer]);
  if (!s.done) timer = setTimeout(loop, 16);
}

self.onmessage = (e: MessageEvent<LayoutRequest>) => {
  const m = e.data;
  if (m.type === 'start') {
    epoch = m.epoch;
    sim = new ForceLayout3D(m);
    if (timer) clearTimeout(timer);
    loop();
  } else if (m.type === 'reheat') {
    if (!sim) return;
    sim.reheat(m.alpha);
    if (!timer) loop();
  } else if (m.type === 'stop') {
    sim = null;
    if (timer) clearTimeout(timer);
    timer = null;
  }
};
