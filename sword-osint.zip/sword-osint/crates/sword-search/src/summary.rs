//! Deterministic analytical summary and limitations — composed only from data actually
//! received (facts, counts, run statuses). No generated or inferred claims.

use std::collections::{BTreeMap, HashMap};

use sword_core::{confidence_label, AdapterOutput, AdapterRun, ClassifiedInput, EntityKind, Finding, KeyFact, RunStatus};
use sword_graph::Graph;

fn plural(n: usize, one: &str, few: &str, many: &str) -> String {
    let m10 = n % 10;
    let m100 = n % 100;
    let w = if m10 == 1 && m100 != 11 {
        one
    } else if (2..=4).contains(&m10) && !(12..=14).contains(&m100) {
        few
    } else {
        many
    };
    format!("{n} {w}")
}

pub fn compose(
    input: &ClassifiedInput,
    runs: &[AdapterRun],
    findings: &[Finding],
    source_count: usize,
    graph: &Graph,
    facts: &[KeyFact],
    names: &HashMap<String, String>,
) -> String {
    let planned = runs.len();
    let done = runs.iter().filter(|r| r.status == RunStatus::Done).count();
    let failed = runs.iter().filter(|r| matches!(r.status, RunStatus::Failed | RunStatus::TimedOut)).count();
    let skipped = runs.iter().filter(|r| r.status == RunStatus::Skipped).count();

    let mut out = String::new();
    out.push_str(&format!(
        "Запрос «{}» распознан как {}. Успешно опрошено источников: {done} из {planned} (ошибок: {failed}, не применимо или не настроено: {skipped}). \
         Получено {} из {}.",
        input.raw,
        input.kind.label_ru(),
        plural(findings.len(), "результат", "результата", "результатов"),
        plural(source_count, "первоисточника", "первоисточников", "первоисточников"),
    ));

    if findings.is_empty() {
        out.push_str(
            "\n\nИсточники не вернули данных по запросу. Отсутствие результатов не означает отсутствия сведений — \
             см. раздел «Ограничения исследования».",
        );
    }

    if !facts.is_empty() {
        out.push_str("\n\nКлючевые факты (каждый подтверждён ссылкой на первоисточник):");
        for f in facts.iter().take(14) {
            let src = names.get(&f.adapter_id).cloned().unwrap_or_else(|| f.adapter_id.clone());
            out.push_str(&format!("\n• {}: {} [{}]", f.label, f.value, src));
        }
        if facts.len() > 14 {
            out.push_str(&format!("\n• … и ещё {} фактов в разделе результатов.", facts.len() - 14));
        }
    }

    if !findings.is_empty() {
        let mut by_cat: BTreeMap<&str, usize> = BTreeMap::new();
        for f in findings {
            *by_cat.entry(f.category.label_ru()).or_default() += 1;
        }
        let dist = by_cat.iter().map(|(k, v)| format!("{k} — {v}")).collect::<Vec<_>>().join("; ");
        out.push_str(&format!("\n\nРаспределение результатов по категориям: {dist}."));
    }

    let nodes = graph.nodes.iter().filter(|n| n.kind != EntityKind::Source).count();
    let edges: Vec<_> = graph.edges.iter().filter(|e| e.relation != "documented_by").collect();
    if nodes > 0 {
        let mean = if edges.is_empty() { 0.0 } else { edges.iter().map(|e| e.confidence).sum::<f32>() / edges.len() as f32 };
        out.push_str(&format!(
            "\n\nГраф подтверждённых связей: {}, {}{}.",
            plural(nodes, "объект", "объекта", "объектов"),
            plural(edges.len(), "связь", "связи", "связей"),
            if edges.is_empty() { String::new() } else { format!(", средняя достоверность {:.2} ({})", mean, confidence_label(mean)) }
        ));
    }
    out
}

/// Honest list of what could not be covered.
pub fn limitations(runs: &[AdapterRun], outputs: &[(String, AdapterOutput)], names: &HashMap<String, String>) -> Vec<String> {
    let mut out = Vec::new();
    for r in runs {
        match r.status {
            RunStatus::Skipped => out.push(format!(
                "{}: не опрашивался — {}.",
                r.adapter_name,
                r.message.clone().unwrap_or_else(|| "не применим к запросу".into())
            )),
            RunStatus::Failed => out.push(format!("{}: ошибка — {}.", r.adapter_name, r.message.clone().unwrap_or_default())),
            RunStatus::TimedOut => out.push(format!("{}: превышено время ожидания, результаты могут быть неполными.", r.adapter_name)),
            RunStatus::Cancelled => out.push(format!("{}: опрос отменён аналитиком.", r.adapter_name)),
            _ => {}
        }
    }
    for (id, o) in outputs {
        let name = names.get(id).cloned().unwrap_or_else(|| id.clone());
        for n in &o.notes {
            out.push(format!("{name}: {n}"));
        }
    }
    out.push(
        "Исследование охватывает только публичные данные, доступные через официальные API и публичные интерфейсы на момент выполнения; \
         закрытые профили, закрытые сообщества и сведения, требующие обхода ограничений платформ, не запрашивались."
            .into(),
    );
    out.push("Полнота поисковой выдачи определяется индексами и ранжированием поисковых систем.".into());
    out.push(
        "Уровень достоверности связи отражает надёжность источника утверждения (реестр, DNS, база знаний, самозаявление), \
         а не независимую ручную проверку."
            .into(),
    );
    out
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn russian_plurals() {
        assert_eq!(plural(1, "результат", "результата", "результатов"), "1 результат");
        assert_eq!(plural(3, "результат", "результата", "результатов"), "3 результата");
        assert_eq!(plural(11, "результат", "результата", "результатов"), "11 результатов");
        assert_eq!(plural(22, "результат", "результата", "результатов"), "22 результата");
    }
}
