//! # sword-db — Database Engine
//!
//! Local SQLite database (WAL mode, FTS5 full-text indexes) holding investigation history,
//! findings, graphs, connector status, own assets, metrics and report records.
//!
//! Storage strategy:
//! * one file `sword.db` in the per-user application data directory;
//! * timestamps are RFC 3339 UTC strings (sortable, human-readable in exports);
//! * nested structures (attributes, evidence) are JSON columns;
//! * full-text search via external-content FTS5 tables kept in sync by triggers;
//! * no secrets: API keys live in the OS credential vault, own e-mail addresses are stored
//!   only as a masked display string + SHA-256 hash.
//!
//! All methods are synchronous; the desktop runtime calls them from blocking worker
//! threads so the UI thread never waits on disk I/O.

pub mod investigations;
pub mod maintenance;
mod schema;
pub mod store;

use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};
use std::time::Duration;

use chrono::{DateTime, SecondsFormat, Utc};
use rusqlite::Connection;
use sword_core::{SwordError, SwordResult};

pub use investigations::*;
pub use maintenance::*;
pub use schema::SCHEMA_VERSION;
pub use store::*;

/// Thread-safe handle to the database.
#[derive(Clone)]
pub struct Database {
    conn: Arc<Mutex<Connection>>,
    path: PathBuf,
}

impl Database {
    /// Open (or create) the database file and apply migrations.
    pub fn open(path: &Path) -> SwordResult<Self> {
        if let Some(dir) = path.parent() {
            std::fs::create_dir_all(dir)?;
        }
        let conn = Connection::open(path).map_err(db_err)?;
        Self::init(conn, path.to_path_buf())
    }

    /// In-memory database (tests).
    pub fn open_in_memory() -> SwordResult<Self> {
        let conn = Connection::open_in_memory().map_err(db_err)?;
        Self::init(conn, PathBuf::from(":memory:"))
    }

    fn init(mut conn: Connection, path: PathBuf) -> SwordResult<Self> {
        conn.busy_timeout(Duration::from_secs(8)).map_err(db_err)?;
        let _mode: String = conn.query_row("PRAGMA journal_mode=WAL", [], |r| r.get(0)).map_err(db_err)?;
        conn.execute_batch("PRAGMA foreign_keys = ON; PRAGMA synchronous = NORMAL; PRAGMA temp_store = MEMORY;")
            .map_err(db_err)?;
        schema::migrate(&mut conn).map_err(db_err)?;
        Ok(Database { conn: Arc::new(Mutex::new(conn)), path })
    }

    pub fn path(&self) -> &Path {
        &self.path
    }

    /// Run a closure with exclusive access to the connection.
    pub fn with<T>(&self, f: impl FnOnce(&mut Connection) -> rusqlite::Result<T>) -> SwordResult<T> {
        let mut guard = self.conn.lock().map_err(|_| SwordError::Database("соединение заблокировано после сбоя".into()))?;
        f(&mut guard).map_err(db_err)
    }
}

pub(crate) fn db_err(e: rusqlite::Error) -> SwordError {
    SwordError::Database(e.to_string())
}

pub(crate) fn ts(dt: &DateTime<Utc>) -> String {
    dt.to_rfc3339_opts(SecondsFormat::Millis, true)
}

pub(crate) fn opt_ts(dt: &Option<DateTime<Utc>>) -> Option<String> {
    dt.as_ref().map(ts)
}

pub(crate) fn parse_ts(s: &str) -> DateTime<Utc> {
    DateTime::parse_from_rfc3339(s).map(|d| d.with_timezone(&Utc)).unwrap_or_else(|_| DateTime::<Utc>::UNIX_EPOCH)
}

pub(crate) fn parse_opt_ts(s: Option<String>) -> Option<DateTime<Utc>> {
    s.as_deref().map(parse_ts)
}

pub(crate) fn to_json<T: serde::Serialize>(v: &T) -> String {
    serde_json::to_string(v).unwrap_or_else(|_| "null".into())
}

pub(crate) fn from_json<T: serde::de::DeserializeOwned + Default>(s: &str) -> T {
    serde_json::from_str(s).unwrap_or_default()
}

/// Build a safe FTS5 MATCH expression from free user text: each token is quoted, the last
/// one gets prefix matching. Returns `None` when there is nothing searchable.
pub fn fts_query(input: &str) -> Option<String> {
    let tokens: Vec<String> = input
        .split(|c: char| !(c.is_alphanumeric() || c == '_' || c == '.' || c == '@' || c == '-'))
        .map(|t| t.trim_matches(|c| c == '.' || c == '-').replace('"', ""))
        .filter(|t| !t.is_empty())
        .take(12)
        .collect();
    if tokens.is_empty() {
        return None;
    }
    let last = tokens.len() - 1;
    Some(
        tokens
            .iter()
            .enumerate()
            .map(|(i, t)| if i == last { format!("\"{t}\"*") } else { format!("\"{t}\"") })
            .collect::<Vec<_>>()
            .join(" "),
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn builds_fts_queries() {
        assert_eq!(fts_query("example.com  отчёт").as_deref(), Some("\"example.com\" \"отчёт\"*"));
        assert_eq!(fts_query("  \"  ").as_deref(), None);
    }

    #[test]
    fn opens_and_migrates() {
        let db = Database::open_in_memory().unwrap();
        let v: i64 = db.with(|c| c.query_row("PRAGMA user_version", [], |r| r.get(0))).unwrap();
        assert_eq!(v, SCHEMA_VERSION);
    }
}
