import { listen, type UnlistenFn } from '@tauri-apps/api/event';
import { desktop } from './client';
import type { InvestigationEvent } from './types';

export const INVESTIGATION_EVENT = 'sword://investigation';

/** Subscribe to the investigation/audit event stream. No-op outside the desktop shell. */
export async function onInvestigationEvent(handler: (e: InvestigationEvent) => void): Promise<UnlistenFn> {
  if (!desktop()) return () => {};
  return listen<InvestigationEvent>(INVESTIGATION_EVENT, (msg) => handler(msg.payload));
}
