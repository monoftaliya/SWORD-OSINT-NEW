/**
 * Cinematic orbit camera with inertia, shared by the particle universe and the 3D graph.
 *
 *  wheel up / down      — smooth zoom in / out (exponential, eased)
 *  hold wheel + drag    — pan through space (middle button)
 *  mouse move           — perspective parallax
 *  left drag            — rotate the scene (velocity keeps gliding after release)
 *  double click         — animated return to the initial view
 *
 * Listeners are attached to the canvas only, so scrolling panels and lists never
 * conflicts with camera control.
 */
import { PerspectiveCamera, Spherical, Vector2, Vector3 } from 'three/webgpu';

export interface RigOptions {
  distance: number;
  minDistance: number;
  maxDistance: number;
  theta?: number;
  phi?: number;
  target?: Vector3;
  parallax?: number;
  autoRotate?: number;
  reduceMotion?: boolean;
}

interface Tween {
  from: { theta: number; phi: number; radius: number; target: Vector3 };
  to: { theta: number; phi: number; radius: number; target: Vector3 };
  t: number;
  duration: number;
}

const ease = (t: number) => 1 - Math.pow(1 - t, 4);

export class CameraRig {
  enabled = true;
  /** Normalised pointer position (−1…1), updated on move — used for parallax and picking. */
  readonly pointer = new Vector2(0, 0);
  pointerInside = false;
  onClick: ((ndc: Vector2, e: PointerEvent) => void) | null = null;
  onDoubleClick: ((ndc: Vector2, e: MouseEvent) => boolean) | null = null;

  private sph = new Spherical();
  private target = new Vector3();
  private radiusGoal: number;
  private vTheta = 0;
  private vPhi = 0;
  private vPan = new Vector3();
  private parallax = new Vector2();
  private drag: 'rotate' | 'pan' | null = null;
  private last = new Vector2();
  private downAt = new Vector2();
  private moved = 0;
  private tween: Tween | null = null;
  private home: { theta: number; phi: number; radius: number; target: Vector3 };
  private readonly abort = new AbortController();
  private idle = 0;

  constructor(
    private camera: PerspectiveCamera,
    private dom: HTMLElement,
    private opts: RigOptions,
  ) {
    const theta = opts.theta ?? 0;
    const phi = opts.phi ?? Math.PI / 2.25;
    this.home = { theta, phi, radius: opts.distance, target: (opts.target ?? new Vector3()).clone() };
    this.sph.set(opts.distance, phi, theta);
    this.target.copy(this.home.target);
    this.radiusGoal = opts.distance;
    const o = { signal: this.abort.signal };
    dom.addEventListener('pointerdown', this.onDown, o);
    dom.addEventListener('pointermove', this.onMove, o);
    dom.addEventListener('pointerup', this.onUp, o);
    dom.addEventListener('pointercancel', this.onUp, o);
    dom.addEventListener('pointerleave', () => (this.pointerInside = false), o);
    dom.addEventListener('pointerenter', () => (this.pointerInside = true), o);
    dom.addEventListener('wheel', this.onWheel, { passive: false, signal: this.abort.signal });
    dom.addEventListener('dblclick', this.onDbl, o);
    dom.addEventListener('contextmenu', (e) => e.preventDefault(), o);
    // Windows middle-click autoscroll must never start over the scene.
    dom.addEventListener('mousedown', (e) => e.button === 1 && e.preventDefault(), o);
    dom.addEventListener('auxclick', (e) => e.preventDefault(), o);
    this.apply(0);
  }

  get distance() {
    return this.sph.radius;
  }

  /** `true` while the camera still moves noticeably (used for render-on-demand). */
  get moving() {
    return (
      this.drag !== null ||
      this.tween !== null ||
      Math.abs(this.vTheta) > 1e-4 ||
      Math.abs(this.vPhi) > 1e-4 ||
      this.vPan.lengthSq() > 1e-6 ||
      Math.abs(this.radiusGoal - this.sph.radius) > 1e-3 ||
      this.idle < 0.6
    );
  }

  setReduceMotion(v: boolean) {
    this.opts.reduceMotion = v;
  }

  private ndc(e: { clientX: number; clientY: number }, out = new Vector2()) {
    const r = this.dom.getBoundingClientRect();
    return out.set(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1);
  }

  private onDown = (e: PointerEvent) => {
    if (!this.enabled) return;
    if (e.button === 0) this.drag = 'rotate';
    else if (e.button === 1) {
      this.drag = 'pan';
      e.preventDefault();
    } else return;
    this.tween = null;
    this.last.set(e.clientX, e.clientY);
    this.downAt.set(e.clientX, e.clientY);
    this.moved = 0;
    this.dom.setPointerCapture(e.pointerId);
  };

  private onMove = (e: PointerEvent) => {
    this.ndc(e, this.pointer);
    this.pointerInside = true;
    this.idle = 0;
    if (!this.enabled || !this.drag) return;
    const dx = e.clientX - this.last.x;
    const dy = e.clientY - this.last.y;
    this.last.set(e.clientX, e.clientY);
    this.moved += Math.abs(dx) + Math.abs(dy);
    const h = this.dom.clientHeight || 1;
    if (this.drag === 'rotate') {
      this.vTheta = (-dx / h) * Math.PI * 2.2;
      this.vPhi = (-dy / h) * Math.PI * 1.6;
      this.sph.theta += this.vTheta;
      this.sph.phi += this.vPhi;
    } else {
      const scale = (this.sph.radius * Math.tan((this.camera.fov * Math.PI) / 360) * 2) / h;
      const right = new Vector3().setFromMatrixColumn(this.camera.matrixWorld, 0);
      const up = new Vector3().setFromMatrixColumn(this.camera.matrixWorld, 1);
      const delta = right.multiplyScalar(-dx * scale).add(up.multiplyScalar(dy * scale));
      this.target.add(delta);
      this.vPan.copy(delta);
    }
  };

  private onUp = (e: PointerEvent) => {
    if (!this.drag) return;
    const wasRotate = this.drag === 'rotate';
    this.drag = null;
    try {
      this.dom.releasePointerCapture(e.pointerId);
    } catch {
      /* already released */
    }
    if (wasRotate && this.moved < 4 && this.onClick) this.onClick(this.ndc(e), e);
  };

  private onWheel = (e: WheelEvent) => {
    if (!this.enabled) return;
    e.preventDefault();
    this.tween = null;
    this.idle = 0;
    const delta = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaY;
    const factor = Math.exp(delta * 0.0011);
    this.radiusGoal = Math.min(this.opts.maxDistance, Math.max(this.opts.minDistance, this.radiusGoal * factor));
  };

  private onDbl = (e: MouseEvent) => {
    if (!this.enabled) return;
    if (this.onDoubleClick && this.onDoubleClick(this.ndc(e), e)) return;
    this.reset();
  };

  /** Redefine the initial view (e.g. after a graph layout has settled). */
  setHome(radius: number, target?: Vector3) {
    this.home.radius = Math.min(this.opts.maxDistance, Math.max(this.opts.minDistance, radius));
    if (target) this.home.target = target.clone();
  }

  /** Animated return to the initial view. */
  reset(duration = 1.25) {
    this.flyTo({ ...this.home, target: this.home.target.clone() }, duration);
  }

  /** Animated move to look at `target` from `radius`. */
  focus(target: Vector3, radius: number, duration = 1.1) {
    const r = Math.min(this.opts.maxDistance, Math.max(this.opts.minDistance, radius));
    this.flyTo({ theta: this.sph.theta, phi: this.sph.phi, radius: r, target: target.clone() }, duration);
  }

  private flyTo(to: Tween['to'], duration: number) {
    this.vTheta = this.vPhi = 0;
    this.vPan.set(0, 0, 0);
    // shortest angular path
    let theta = to.theta;
    while (theta - this.sph.theta > Math.PI) theta -= Math.PI * 2;
    while (theta - this.sph.theta < -Math.PI) theta += Math.PI * 2;
    this.tween = {
      from: { theta: this.sph.theta, phi: this.sph.phi, radius: this.sph.radius, target: this.target.clone() },
      to: { ...to, theta },
      t: 0,
      duration: this.opts.reduceMotion ? 0.01 : duration,
    };
  }

  update(dt: number) {
    this.idle += dt;
    if (this.tween) {
      const tw = this.tween;
      tw.t = Math.min(1, tw.t + dt / tw.duration);
      const k = ease(tw.t);
      this.sph.theta = tw.from.theta + (tw.to.theta - tw.from.theta) * k;
      this.sph.phi = tw.from.phi + (tw.to.phi - tw.from.phi) * k;
      this.sph.radius = tw.from.radius + (tw.to.radius - tw.from.radius) * k;
      this.radiusGoal = this.sph.radius;
      this.target.lerpVectors(tw.from.target, tw.to.target, k);
      if (tw.t >= 1) this.tween = null;
    } else if (!this.drag) {
      // inertia
      const decay = Math.exp(-dt * 3.2);
      this.sph.theta += this.vTheta;
      this.sph.phi += this.vPhi;
      this.vTheta *= decay;
      this.vPhi *= decay;
      this.target.add(this.vPan);
      this.vPan.multiplyScalar(Math.exp(-dt * 6));
      // gentle drift
      if (this.opts.autoRotate && !this.opts.reduceMotion) this.sph.theta += this.opts.autoRotate * dt;
      // smooth zoom
      this.sph.radius += (this.radiusGoal - this.sph.radius) * (1 - Math.exp(-dt * 7));
    }
    this.sph.phi = Math.min(Math.PI - 0.12, Math.max(0.12, this.sph.phi));
    this.apply(dt);
  }

  private apply(dt: number) {
    // parallax follows the pointer smoothly
    const amp = this.opts.reduceMotion ? 0 : (this.opts.parallax ?? 0.06);
    const goal = this.pointerInside ? this.pointer : new Vector2();
    this.parallax.lerp(goal, 1 - Math.exp(-dt * 2.5));
    const s = new Spherical(this.sph.radius, this.sph.phi + this.parallax.y * amp, this.sph.theta - this.parallax.x * amp);
    this.camera.position.setFromSpherical(s).add(this.target);
    this.camera.lookAt(this.target);
    this.camera.updateMatrixWorld();
  }

  dispose() {
    this.abort.abort();
  }
}
