/**
 * GPU detection and particle budgets. Discrete GPUs (NVIDIA RTX, AMD Radeon) get the high
 * tier; integrated and software adapters get smaller budgets. A runtime frame-rate
 * governor then scales the active particle count up or down.
 */
export type Tier = 'low' | 'medium' | 'high' | 'ultra';

export const PARTICLES: Record<Tier, number> = {
  low: 14_000,
  medium: 42_000,
  high: 110_000,
  ultra: 240_000,
};

export interface GpuInfo {
  vendor: string;
  description: string;
  webgpu: boolean;
  software: boolean;
  discrete: boolean;
}

/**
 * three.js r187 returns promises from `setAnimationLoop` and `dispose` (both wait for a
 * pending initialisation, and `dispose` releases resources asynchronously). A failure there,
 * typically during teardown after a device loss, is not actionable and must not surface as
 * an unhandled rejection.
 */
export function settle(result: Promise<unknown> | undefined): void {
  result?.catch(() => {});
}

let detected: Promise<GpuInfo> | null = null;
let lossFilter = false;

/**
 * After a device loss (driver reset, sleep, GPU switch) three.js's WebGPU backend leaves
 * pending error-scope promises that reject ("Instance dropped in popErrorScope"). The loss
 * itself is already handled by the views (scene restarted in a safer mode); these echoes
 * carry nothing further, so they are kept out of the error log.
 */
export function silenceDeviceLossEchoes() {
  if (lossFilter) return;
  lossFilter = true;
  window.addEventListener('unhandledrejection', (e) => {
    const reason: unknown = e.reason;
    const message = reason instanceof Error ? reason.message : String(reason ?? '');
    if (/popErrorScope|Instance dropped|external Instance reference|Device is lost|device was lost/i.test(message)) e.preventDefault();
  });
}

/** Adapter information, probed once per session and shared by both 3D views. */
export function detectGpu(): Promise<GpuInfo> {
  detected ??= probeGpu();
  return detected;
}

async function probeGpu(): Promise<GpuInfo> {
  const nav = navigator as Navigator & { gpu?: { requestAdapter(o?: { powerPreference?: string }): Promise<unknown> } };
  if (nav.gpu) {
    try {
      const adapter = (await nav.gpu.requestAdapter({ powerPreference: 'high-performance' })) as {
        info?: { vendor?: string; architecture?: string; description?: string; device?: string };
        isFallbackAdapter?: boolean;
      } | null;
      if (adapter) {
        const info = adapter.info ?? {};
        const vendor = (info.vendor ?? '').toLowerCase();
        const description = [info.vendor, info.architecture, info.description || info.device].filter(Boolean).join(' ');
        const software = Boolean(adapter.isFallbackAdapter) || /swiftshader|llvmpipe|software/i.test(description);
        return { vendor, description: description || 'WebGPU adapter', webgpu: true, software, discrete: /nvidia|amd|ati/.test(vendor) };
      }
    } catch {
      /* fall through to WebGL */
    }
  }
  try {
    const canvas = document.createElement('canvas');
    const gl = canvas.getContext('webgl2');
    if (gl) {
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const renderer = String(ext ? gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER));
      const vendor = String(ext ? gl.getParameter(ext.UNMASKED_VENDOR_WEBGL) : gl.getParameter(gl.VENDOR)).toLowerCase();
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      const software = /swiftshader|llvmpipe|software|microsoft basic/i.test(renderer);
      return { vendor, description: renderer, webgpu: false, software, discrete: /nvidia|geforce|rtx|radeon|amd/i.test(renderer) };
    }
  } catch {
    /* ignore */
  }
  return { vendor: '', description: 'неизвестный GPU', webgpu: false, software: true, discrete: false };
}

export function autoTier(gpu: GpuInfo): Tier {
  if (gpu.software) return 'low';
  if (gpu.discrete) return gpu.webgpu ? 'ultra' : 'high';
  return 'medium';
}

/**
 * Frame pacing for an optional frame cap. The remainder is carried over, so the average
 * rate matches the cap on any refresh rate (a 60 FPS cap on a 144 Hz display gives 60, not
 * 48). Returns the real time since the previous rendered frame, or null to skip this one.
 */
export class FramePacer {
  private last = 0;
  private sinceRender = 0;
  private budget = 0;

  reset(now: number) {
    this.last = now;
    this.sinceRender = 0;
    this.budget = 0;
  }

  tick(now: number, cap: number): number | null {
    const raw = Math.max(0, (now - this.last) / 1000);
    this.last = now;
    this.sinceRender += raw;
    if (cap > 0) {
      const interval = 1 / cap;
      this.budget += raw;
      if (this.budget < interval - 0.0015) return null;
      this.budget = Math.max(-interval, Math.min(interval, this.budget - interval));
    } else {
      this.budget = 0;
    }
    const dt = this.sinceRender;
    this.sinceRender = 0;
    return dt;
  }
}

/** Automatic simplification steps, applied only when the smallest particle budget is still too slow. */
export const SIMPLIFY_STEPS = ['', 'без свечения и шлейфов', 'пониженное разрешение', 'статичный кадр'] as const;

/**
 * Frame-rate governor. The rate is measured over real time (windows of at least half a
 * second), so it stays truthful at any speed, including software rendering at a few FPS.
 * - after 2.5 s below 83 % of the goal it removes 20 % of particles (down to `min`);
 * - after 12 s near the goal it adds 10 % back (up to `max`);
 * - when even `min` stays below half the goal for 4 s it simplifies the picture one step
 *   (see SIMPLIFY_STEPS). Simplification is not undone automatically: it would oscillate.
 * The goal is 60 FPS, or the frame cap when that is lower.
 */
export class Governor {
  simplify = 0;
  private measured = 0;
  private frames = 0;
  private window = 0;
  private low = 0;
  private high = 0;
  private crawl = 0;

  constructor(
    public active: number,
    private readonly max: number,
    private readonly min: number,
  ) {}

  /** Measured frames per second (0 until the first window closes). */
  get fps() {
    return Math.round(this.measured);
  }

  /** One rendered frame `dt` seconds after the previous one; `cap` is the frame cap (0 = none). */
  sample(dt: number, cap: number): 'budget' | 'simplify' | null {
    if (!(dt > 0)) return null;
    if (dt > 5) {
      // a pause (sleep, debugger, hidden window), not a slow frame
      this.frames = 0;
      this.window = 0;
      return null;
    }
    this.frames++;
    this.window += dt;
    if (this.window < 0.5) return null;
    const rate = this.frames / this.window;
    const span = this.window;
    this.frames = 0;
    this.window = 0;
    this.measured = this.measured > 0 ? this.measured * 0.5 + rate * 0.5 : rate;

    const goal = cap > 0 ? Math.min(cap, 60) : 60;
    if (this.measured < goal * 0.83) {
      this.low += span;
      this.high = 0;
    } else if (this.measured > goal * 0.96) {
      this.high += span;
      this.low = 0;
    } else {
      this.low = this.high = 0;
    }

    this.crawl = this.active <= this.min && this.measured < goal * 0.5 ? this.crawl + span : 0;
    if (this.crawl > 4 && this.simplify < SIMPLIFY_STEPS.length - 1) {
      this.crawl = 0;
      this.simplify++;
      return 'simplify';
    }
    if (this.low > 2.5 && this.active > this.min) {
      this.low = 0;
      this.active = Math.max(this.min, Math.floor(this.active * 0.8));
      return 'budget';
    }
    if (this.high > 12 && this.active < this.max) {
      this.high = 0;
      this.active = Math.min(this.max, Math.floor(this.active * 1.1));
      return 'budget';
    }
    return null;
  }
}
