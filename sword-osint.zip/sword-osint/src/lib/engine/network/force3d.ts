/**
 * 3D force-directed layout (d3-force model, extended to three dimensions) with a
 * Barnes–Hut octree for the many-body term — O(n log n) per tick. Runs inside a Web
 * Worker so large graphs never block the interface.
 */

export interface LayoutGraph {
  count: number;
  /** Initial positions (xyz per node); NaN means "place automatically". */
  init: Float32Array;
  /** Link endpoints as index pairs. */
  links: Uint32Array;
  /** Rest length per link. */
  distance: Float32Array;
  /** Relative strength per link (0…1, typically the confidence). */
  strength: Float32Array;
}

interface Cell {
  // bounds
  cx: number;
  cy: number;
  cz: number;
  half: number;
  // aggregate
  mass: number;
  mx: number;
  my: number;
  mz: number;
  /** Leaf: node index (or −1); internal nodes keep children. */
  body: number;
  children: (Cell | null)[] | null;
}

const THETA2 = 0.81; // θ = 0.9
const CHARGE = -70;
const DIST_MIN2 = 1;
const VELOCITY_DECAY = 0.6;

export class ForceLayout3D {
  readonly pos: Float32Array;
  private vel: Float32Array;
  private degree: Uint32Array;
  private bias: Float32Array;
  private linkStrength: Float32Array;
  alpha = 1;
  alphaMin = 0.002;
  alphaDecay = 1 - Math.pow(0.002, 1 / 320);
  alphaTarget = 0;

  constructor(private g: LayoutGraph) {
    const n = g.count;
    this.pos = new Float32Array(n * 3);
    this.vel = new Float32Array(n * 3);
    this.degree = new Uint32Array(n);
    for (let i = 0; i < g.links.length; i += 2) {
      this.degree[g.links[i]]++;
      this.degree[g.links[i + 1]]++;
    }
    const m = g.links.length / 2;
    this.bias = new Float32Array(m);
    this.linkStrength = new Float32Array(m);
    for (let l = 0; l < m; l++) {
      const s = g.links[l * 2];
      const t = g.links[l * 2 + 1];
      const ds = this.degree[s];
      const dt = this.degree[t];
      this.bias[l] = ds / (ds + dt);
      this.linkStrength[l] = (g.strength[l] ?? 1) / Math.max(1, Math.min(ds, dt));
    }
    // initial placement: keep known positions, put the rest on a spherical (Fibonacci) spiral
    const golden = Math.PI * (3 - Math.sqrt(5));
    for (let i = 0; i < n; i++) {
      const x = g.init[i * 3];
      if (Number.isFinite(x)) {
        this.pos[i * 3] = x;
        this.pos[i * 3 + 1] = g.init[i * 3 + 1];
        this.pos[i * 3 + 2] = g.init[i * 3 + 2];
      } else {
        const r = 10 * Math.cbrt(0.5 + i);
        const y = 1 - (2 * (i + 0.5)) / Math.max(1, n);
        const rr = Math.sqrt(Math.max(0, 1 - y * y));
        const a = i * golden;
        this.pos[i * 3] = Math.cos(a) * rr * r;
        this.pos[i * 3 + 1] = y * r;
        this.pos[i * 3 + 2] = Math.sin(a) * rr * r;
      }
    }
  }

  get done() {
    return this.alpha < this.alphaMin;
  }

  reheat(alpha = 0.6) {
    this.alpha = Math.max(this.alpha, alpha);
  }

  tick(): void {
    const { pos, vel } = this;
    const n = this.g.count;
    this.alpha += (this.alphaTarget - this.alpha) * this.alphaDecay;
    const alpha = this.alpha;

    // links (springs)
    const links = this.g.links;
    for (let l = 0; l < links.length / 2; l++) {
      const s = links[l * 2] * 3;
      const t = links[l * 2 + 1] * 3;
      let dx = pos[t] + vel[t] - pos[s] - vel[s] || jiggle();
      let dy = pos[t + 1] + vel[t + 1] - pos[s + 1] - vel[s + 1] || jiggle();
      let dz = pos[t + 2] + vel[t + 2] - pos[s + 2] - vel[s + 2] || jiggle();
      let d = Math.sqrt(dx * dx + dy * dy + dz * dz);
      d = ((d - this.g.distance[l]) / d) * alpha * this.linkStrength[l];
      dx *= d;
      dy *= d;
      dz *= d;
      const b = this.bias[l];
      vel[t] -= dx * b;
      vel[t + 1] -= dy * b;
      vel[t + 2] -= dz * b;
      vel[s] += dx * (1 - b);
      vel[s + 1] += dy * (1 - b);
      vel[s + 2] += dz * (1 - b);
    }

    // many-body repulsion (Barnes–Hut)
    if (n > 1) {
      const root = this.buildTree();
      for (let i = 0; i < n; i++) this.applyCharge(root, i, alpha);
    }

    // weak gravity towards the origin keeps disconnected components together
    const gravity = 0.012 * alpha;
    for (let i = 0; i < n * 3; i++) vel[i] -= pos[i] * gravity;

    // integrate
    for (let i = 0; i < n * 3; i++) {
      vel[i] *= VELOCITY_DECAY;
      pos[i] += vel[i];
    }

    // re-centre
    let cx = 0;
    let cy = 0;
    let cz = 0;
    for (let i = 0; i < n; i++) {
      cx += pos[i * 3];
      cy += pos[i * 3 + 1];
      cz += pos[i * 3 + 2];
    }
    if (n) {
      cx /= n;
      cy /= n;
      cz /= n;
      for (let i = 0; i < n; i++) {
        pos[i * 3] -= cx;
        pos[i * 3 + 1] -= cy;
        pos[i * 3 + 2] -= cz;
      }
    }
  }

  private buildTree(): Cell {
    const { pos } = this;
    const n = this.g.count;
    let minX = Infinity;
    let minY = Infinity;
    let minZ = Infinity;
    let maxX = -Infinity;
    let maxY = -Infinity;
    let maxZ = -Infinity;
    for (let i = 0; i < n; i++) {
      const x = pos[i * 3];
      const y = pos[i * 3 + 1];
      const z = pos[i * 3 + 2];
      if (x < minX) minX = x;
      if (y < minY) minY = y;
      if (z < minZ) minZ = z;
      if (x > maxX) maxX = x;
      if (y > maxY) maxY = y;
      if (z > maxZ) maxZ = z;
    }
    const half = Math.max(maxX - minX, maxY - minY, maxZ - minZ, 1) / 2 + 1;
    const root = cell((minX + maxX) / 2, (minY + maxY) / 2, (minZ + maxZ) / 2, half);
    for (let i = 0; i < n; i++) insert(root, i, pos, 0);
    accumulate(root, pos);
    return root;
  }

  private applyCharge(c: Cell, i: number, alpha: number) {
    const { pos, vel } = this;
    if (c.mass === 0) return;
    const x = pos[i * 3];
    const y = pos[i * 3 + 1];
    const z = pos[i * 3 + 2];
    let dx = c.mx - x;
    let dy = c.my - y;
    let dz = c.mz - z;
    let l = dx * dx + dy * dy + dz * dz;
    const w = c.half * 2;
    // far enough: treat the cell as a single body
    if (c.children === null || (w * w) / THETA2 < l) {
      if (c.children === null && c.body === i) return;
      if (dx === 0) {
        dx = jiggle();
        l += dx * dx;
      }
      if (dy === 0) {
        dy = jiggle();
        l += dy * dy;
      }
      if (dz === 0) {
        dz = jiggle();
        l += dz * dz;
      }
      if (l < DIST_MIN2) l = Math.sqrt(DIST_MIN2 * l);
      const k = (CHARGE * c.mass * alpha) / l;
      vel[i * 3] += dx * k;
      vel[i * 3 + 1] += dy * k;
      vel[i * 3 + 2] += dz * k;
      return;
    }
    for (const ch of c.children) if (ch) this.applyCharge(ch, i, alpha);
  }
}

function cell(cx: number, cy: number, cz: number, half: number): Cell {
  return { cx, cy, cz, half, mass: 0, mx: 0, my: 0, mz: 0, body: -1, children: null };
}

function octant(c: Cell, x: number, y: number, z: number): number {
  return (x >= c.cx ? 1 : 0) | (y >= c.cy ? 2 : 0) | (z >= c.cz ? 4 : 0);
}

function child(c: Cell, o: number): Cell {
  const h = c.half / 2;
  return cell(c.cx + (o & 1 ? h : -h), c.cy + (o & 2 ? h : -h), c.cz + (o & 4 ? h : -h), h);
}

function insert(c: Cell, i: number, pos: Float32Array, depth: number) {
  if (c.children === null) {
    if (c.body === -1) {
      c.body = i;
      return;
    }
    // coincident points beyond a depth limit share the leaf (counted in accumulate)
    if (depth > 24) {
      c.mass += 1;
      return;
    }
    const existing = c.body;
    c.body = -1;
    c.children = [null, null, null, null, null, null, null, null];
    insertChild(c, existing, pos, depth);
  }
  insertChild(c, i, pos, depth);
}

function insertChild(c: Cell, i: number, pos: Float32Array, depth: number) {
  const o = octant(c, pos[i * 3], pos[i * 3 + 1], pos[i * 3 + 2]);
  const kids = c.children as (Cell | null)[];
  let k = kids[o];
  if (!k) {
    k = child(c, o);
    kids[o] = k;
  }
  insert(k, i, pos, depth + 1);
}

function accumulate(c: Cell, pos: Float32Array): void {
  if (c.children === null) {
    if (c.body >= 0) {
      const extra = c.mass; // coincident overflow
      c.mass = 1 + extra;
      c.mx = pos[c.body * 3];
      c.my = pos[c.body * 3 + 1];
      c.mz = pos[c.body * 3 + 2];
    }
    return;
  }
  let m = 0;
  let x = 0;
  let y = 0;
  let z = 0;
  for (const k of c.children) {
    if (!k) continue;
    accumulate(k, pos);
    m += k.mass;
    x += k.mx * k.mass;
    y += k.my * k.mass;
    z += k.mz * k.mass;
  }
  c.mass = m;
  if (m > 0) {
    c.mx = x / m;
    c.my = y / m;
    c.mz = z / m;
  }
}

function jiggle(): number {
  return (Math.random() - 0.5) * 1e-6;
}
