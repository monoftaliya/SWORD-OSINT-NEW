//! # SWORD OSINT — Desktop Runtime (Tauri 2)
//!
//! Wires the engines to the WebView: application state, typed commands, the investigation
//! event stream, OS credential vault, logging and window lifecycle.

mod commands;
mod error;
mod events;
mod secrets;
mod state;

use std::path::PathBuf;

use tauri::Manager;
use tracing_subscriber::{fmt, prelude::*, EnvFilter};

use crate::state::{AppPaths, AppState};

fn init_logging(dir: &PathBuf) -> Option<tracing_appender::non_blocking::WorkerGuard> {
    std::fs::create_dir_all(dir).ok()?;
    let appender = tracing_appender::rolling::daily(dir, "sword-osint.log");
    let (writer, guard) = tracing_appender::non_blocking(appender);
    let filter = EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info,tao=warn,wry=warn,reqwest=warn,hyper=warn"));
    let registry = tracing_subscriber::registry().with(filter).with(fmt::layer().with_writer(writer).with_ansi(false));
    #[cfg(debug_assertions)]
    let registry = registry.with(fmt::layer().with_writer(std::io::stderr));
    let _ = registry.try_init();
    Some(guard)
}

pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_single_instance::init(|app, _args, _cwd| {
            if let Some(w) = app.get_webview_window("main") {
                let _ = w.unminimize();
                let _ = w.show();
                let _ = w.set_focus();
            }
        }))
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_opener::init())
        .setup(|app| {
            let data_dir = app.path().app_data_dir()?;
            let logs_dir = app.path().app_log_dir().unwrap_or_else(|_| data_dir.join("logs"));
            let guard = init_logging(&logs_dir);
            app.manage(LogGuard(guard));
            tracing::info!(version = sword_core::VERSION, "SWORD OSINT starting");

            sword_connectors::http::install_crypto_provider();
            let reports_dir = data_dir.join("reports");
            std::fs::create_dir_all(&reports_dir)?;
            let db_path = data_dir.join("sword.db");
            let db = sword_db::Database::open(&db_path)?;
            if let Ok(n) = db.mark_interrupted() {
                if n > 0 {
                    tracing::warn!(count = n, "investigations interrupted by previous shutdown");
                }
            }
            let (secrets, persistent) = secrets::open_store();
            let state = AppState::new(db, secrets, persistent, AppPaths { data_dir, db_path, reports_dir, logs_dir })?;
            // Retention policy
            let retention = state.settings().privacy.retention_days;
            if retention > 0 {
                match state.db.purge_older_than(retention) {
                    Ok(n) if n > 0 => tracing::info!(removed = n, "retention policy applied"),
                    Err(e) => tracing::warn!(error = %e, "retention policy failed"),
                    _ => {}
                }
            }
            app.manage(state);
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            // system
            commands::system::app_info,
            commands::system::get_settings,
            commands::system::save_settings,
            commands::system::record_metrics,
            commands::system::open_external,
            commands::system::open_path,
            commands::system::reveal_path,
            commands::system::open_data_dir,
            commands::system::open_logs_dir,
            // connectors
            commands::connectors::list_adapters,
            commands::connectors::check_adapter,
            commands::connectors::check_all_adapters,
            commands::connectors::set_adapter_enabled,
            commands::connectors::set_adapter_option,
            commands::connectors::set_credential,
            commands::connectors::delete_credential,
            // discovery
            commands::discovery::classify_query,
            commands::discovery::plan_investigation,
            commands::discovery::start_investigation,
            commands::discovery::cancel_investigation,
            commands::discovery::running_investigations,
            // history
            commands::history::list_history,
            commands::history::get_investigation,
            commands::history::delete_investigations,
            commands::history::compare_investigations,
            commands::history::update_notes,
            commands::history::export_investigation,
            commands::history::search_knowledge,
            // graph
            commands::graph::get_graph,
            commands::graph::export_graph,
            commands::graph::save_image,
            // intelligence
            commands::intelligence::list_assets,
            commands::intelligence::add_asset,
            commands::intelligence::remove_asset,
            commands::intelligence::verify_asset,
            commands::intelligence::pick_folder,
            commands::intelligence::start_audit,
            commands::intelligence::check_password,
            commands::intelligence::scan_text,
            commands::intelligence::scan_url,
            // analytics
            commands::analytics::get_analytics,
            // reports
            commands::reports::get_report_options,
            commands::reports::save_report_options,
            commands::reports::generate_report,
            commands::reports::list_reports,
            commands::reports::open_report,
            commands::reports::reveal_report,
            commands::reports::save_report_as,
            commands::reports::delete_report,
            // databases
            commands::databases::db_stats,
            commands::databases::db_integrity_check,
            commands::databases::db_vacuum,
            commands::databases::db_backup,
            commands::databases::db_export_all,
            commands::databases::db_purge,
            commands::databases::db_clear_history,
            commands::databases::opensearch_test,
            commands::databases::opensearch_reindex,
        ])
        .run(tauri::generate_context!())
        .expect("error while running SWORD OSINT");
}

/// Keeps the non-blocking log writer alive for the process lifetime.
struct LogGuard(#[allow(dead_code)] Option<tracing_appender::non_blocking::WorkerGuard>);
